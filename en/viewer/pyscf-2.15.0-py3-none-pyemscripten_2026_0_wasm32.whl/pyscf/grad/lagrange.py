#!/usr/bin/env python
# Copyright 2014-2021 The PySCF Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
import scipy
from scipy import linalg, optimize
from scipy.sparse import linalg as sparse_linalg
from pyscf import lib, __config__
from pyscf.lib import logger
from pyscf.grad import rhf as rhf_grad
from pyscf.soscf import ciah

default_level_shift = getattr(__config__, 'grad_lagrange_Gradients_level_shift', 1e-8)
default_conv_atol = getattr (__config__, 'grad_lagrange_Gradients_conv_atol', 1e-12)
default_conv_rtol = getattr (__config__, 'grad_lagrange_Gradients_conv_rtol', 1e-7)
default_max_cycle = getattr (__config__, 'grad_lagrange_Gradients_max_cycle', 50)

class Gradients (rhf_grad.GradientsBase):
    r''' Dummy parent class for calculating analytical nuclear gradients using the technique of
    Lagrange multipliers:
    L = E + \sum_i z_i L_i
    dE/dx = \partial L/\partial x iff all L_i = 0 for the given wave function
    I.E., the Lagrange multipliers L_i cancel the direct dependence of the wave function on the
    nuclear coordinates and allow the Hellmann-Feynman theorem to be used for some non-variational
    methods. '''

    ####################### Child classes MUST overwrite the methods below ########################

    def get_wfn_response (self, **kwargs):
        ''' Return first derivative of the energy wrt wave function parameters conjugate to the
            Lagrange multipliers. Used to calculate the value of the Lagrange multipliers. '''
        return np.zeros(self.nlag)

    def get_Aop_Adiag (self, **kwargs):
        ''' Return a function calculating Lvec . J_wfn, where J_wfn is the Jacobian of the Lagrange
            cofactors (e.g., in state-averaged CASSCF, the Hessian of the state-averaged energy wrt
            wfn parameters) along with the diagonal of the Jacobian. '''
        def Aop (Lvec):
            return np.zeros(self.nlag)
        Adiag = np.zeros(self.nlag)
        return Aop, Adiag

    def get_ham_response (self, **kwargs):
        ''' Return expectation values <dH/dx> where x is nuclear displacement.
        I.E., the gradient if the method were variational.
        '''
        return np.zeros((self.mol.natm, 3))

    def get_LdotJnuc (self, Lvec, **kwargs):
        ''' Return Lvec . J_nuc, where J_nuc is the Jacobian of the Lagrange cofactors wrt nuclear
        displacement. This is the second term of the final gradient expectation value.
        '''
        return np.zeros((self.mol.natm, 3))

    ####################### Child classes SHOULD overwrite the methods below ######################

    _keys = {
        'Lvec', 'nlag', 'level_shift', 'conv_atol', 'conv_rtol', 'max_cycle',
        'l_iter', 'l_hop_setup', 'l_hop_init', 'l_hop_solve',
        'l_hop_validation', 'l_hop_total',
    }

    def __init__(self, method, nlag):
        self._conv = False
        self.Lvec = None
        self.nlag = nlag
        self.level_shift = default_level_shift
        self.conv_atol = default_conv_atol
        self.conv_rtol = default_conv_rtol
        self.max_cycle = default_max_cycle
        rhf_grad.GradientsBase.__init__(self, method)

    def debug_lagrange (self, Lvec, bvec, Aop, Adiag, **kwargs):
        logger.debug (self, f"{self.base.__class__.__name__} gradient Lagrange factor debugging not enabled")

    def get_lagrange_callback (self, Lvec_last, itvec, geff_op):
        def my_call (x):
            itvec[0] += 1
            logger.info (self, 'Lagrange optimization iteration %d, |geff| = %.8g, |dLvec| = %.8g',
                         itvec[0], linalg.norm (geff_op (x)), linalg.norm (x - Lvec_last))
            Lvec_last[:] = x[:]
        return my_call

    def get_lagrange_precond (self, Adiag, level_shift=None, **kwargs):
        if level_shift is None: level_shift = self.level_shift
        return LagPrec (Adiag=Adiag, level_shift=level_shift, **kwargs)

    def get_init_guess (self, bvec, Adiag, Aop, precond):
        return precond (-bvec)

    @property
    def converged (self):
        return self._conv and getattr (self.base, 'converged', True)
    @converged.setter
    def converged (self, x):
        self._conv = x
        return self._conv and getattr (self.base, 'converged', True)

    ####################### Child classes SHOULD NOT overwrite the methods below ##################

    def solve_lagrange (self, Lvec_guess=None, level_shift=None, **kwargs):
        bvec = self.get_wfn_response (**kwargs)
        raw_Aop, Adiag = self.get_Aop_Adiag (**kwargs)
        hop_count = [0]
        def Aop (x):
            hop_count[0] += 1
            return raw_Aop (x)
        Lvec_last = np.zeros_like (bvec)
        precond = self.get_lagrange_precond (Adiag, level_shift=level_shift, **kwargs)
        it = np.asarray ([0])
        logger.debug(self, 'Lagrange multiplier determination initial gradient norm: %.8g',
                     linalg.norm(bvec))
        # Preserve the existing one-argument callback API.  geff_op reads the
        # residual already available inside CG instead of applying Aop again.
        geff_ref = [None]
        callback = self.get_lagrange_callback (
            Lvec_last, it, lambda x: geff_ref[0])
        def callback_with_residual (x, residual):
            # CG solves A L = -b, so residual = -b - A L = -geff.
            geff_ref[0] = -residual
            callback (x)

        self.l_hop_setup = hop_count[0]
        init_guess_start = hop_count[0]
        if Lvec_guess is None:
            Lvec_guess = self.get_init_guess (bvec, Adiag, Aop, precond)
        self.l_hop_init = hop_count[0] - init_guess_start

        solve_start = hop_count[0]
        Lvec, info_int, recursive_residual = _cg_with_residual (
            Aop, -bvec, Lvec_guess, precond, self.conv_rtol,
            self.conv_atol, self.max_cycle, callback=callback_with_residual)
        self.l_hop_solve = hop_count[0] - solve_start

        validation_start = hop_count[0]
        geff = bvec + Aop (Lvec)
        self.l_hop_validation = hop_count[0] - validation_start
        self.l_hop_total = hop_count[0]
        self.l_iter = int (it[0])
        conv_tol = max(float(self.conv_atol),
                       float(self.conv_rtol) * linalg.norm(bvec))
        converged = linalg.norm(geff) <= conv_tol
        logger.debug(self, 'Lagrange recursive/exact residual difference: %.8g',
                     linalg.norm(geff + recursive_residual))
        logger.info (self, ('Lagrange multiplier determination %s after %d iterations\n'
                            '   |geff| = %s, |Lvec| = %s\n'
                            '   Hessian products: setup %d, initial guess %d, '
                            'solve %d, validation %d, total %d'),
                     'converged' if converged else 'not converged',
                     it[0], linalg.norm(geff), linalg.norm(Lvec),
                     self.l_hop_setup, self.l_hop_init,
                     self.l_hop_solve, self.l_hop_validation,
                     self.l_hop_total)
        if info_int < 0:
            logger.info (self, 'Lagrange multiplier determination error code %s', info_int)
        return converged, Lvec, bvec, raw_Aop, Adiag

    def kernel (self, level_shift=None, **kwargs):
        cput0 = (logger.process_clock(), logger.perf_counter())
        log = logger.new_logger(self, self.verbose)
        if 'atmlst' in kwargs:
            self.atmlst = kwargs['atmlst']
        #self.natm = len (self.atmlst)

        if self.verbose >= logger.WARN:
            self.check_sanity()
        if self.verbose >= logger.INFO:
            self.dump_flags()

        self.converged, self.Lvec, bvec, Aop, Adiag = self.solve_lagrange (
            level_shift=level_shift, **kwargs)
        if self.verbose >= logger.INFO:
            self.debug_lagrange (self.Lvec, bvec, Aop, Adiag, **kwargs)
            cput1 = logger.timer (self, 'Lagrange gradient multiplier solution', *cput0)

        ham_response = self.get_ham_response (**kwargs)
        if self.verbose >= logger.INFO:
            logger.info(self, '--------------- %s gradient Hamiltonian response ---------------',
                        self.base.__class__.__name__)
            rhf_grad._write(self, self.mol, ham_response, self.atmlst)
            logger.info(self, '----------------------------------------------')
            cput1 = logger.timer (
                self, 'Lagrange gradient Hellmann-Feynman determination', *cput1)

        LdotJnuc = self.get_LdotJnuc (self.Lvec, **kwargs)
        if self.verbose >= logger.INFO:
            logger.info(self, '--------------- %s gradient Lagrange response ---------------',
                        self.base.__class__.__name__)
            rhf_grad._write(self, self.mol, LdotJnuc, self.atmlst)
            logger.info(self, '----------------------------------------------')
            logger.timer (self, 'Lagrange gradient Jacobian', *cput1)
        self.de = ham_response + LdotJnuc
        log.timer('Lagrange gradients', *cput0)
        self._finalize()
        return self.de

class LagPrec :
    ''' A callable preconditioner for solving the Lagrange equations.
        Default is 1/(Adiagd+level_shift)
    '''

    def __init__(self, Adiag=None, level_shift=None, **kwargs):
        self.Adiag = Adiag
        self.level_shift = level_shift

    def __call__(self, x):
        Adiagd = self.Adiag + self.level_shift
        Adiagd[abs(Adiagd)<1e-8] = 1e-8
        x /= Adiagd
        return x

def _cg_with_residual(Aop, bvec, x0, precond, tol, atol, maxiter,
                      callback=None):
    '''Preconditioned CG whose callback receives the current residual.'''
    x = np.array(x0, copy=True)
    rhs = np.asarray(bvec)
    conv_tol = max(float(atol), float(tol) * linalg.norm(rhs))
    residual = rhs - Aop(x)
    search = None
    rz_last = None

    for _ in range(maxiter):
        if linalg.norm(residual) <= conv_tol:
            return x, 0, residual
        # Some PySCF preconditioners modify their argument in place.
        zvec = np.asarray(precond(residual.copy()))
        rz = np.vdot(residual, zvec)
        rz_scale = linalg.norm(residual) * linalg.norm(zvec)
        if (not np.isfinite(rz) or rz_scale == 0 or
                abs(rz) <= np.finfo(float).eps * rz_scale):
            return x, -1, residual
        if search is None:
            search = zvec.copy()
        else:
            search *= rz / rz_last
            search += zvec
        hsearch = Aop(search)
        curvature = np.vdot(search, hsearch)
        curvature_scale = linalg.norm(search) * linalg.norm(hsearch)
        if (not np.isfinite(curvature) or curvature_scale == 0 or
                abs(curvature) <= np.finfo(float).eps * curvature_scale):
            return x, -1, residual
        alpha = rz / curvature
        x += alpha * search
        residual -= alpha * hsearch
        rz_last = rz
        if callback is not None:
            callback(x, residual)
    if linalg.norm(residual) <= conv_tol:
        return x, 0, residual
    return x, maxiter, residual

if int (scipy.__version__.split('.')[1]) >= 14: # scipy 1.14
    def _cg(A, b, x0=None, *, tol=1e-05, atol=0.0, maxiter=None, M=None, callback=None):
        return sparse_linalg.cg(A, b, x0, rtol=tol, atol=atol, maxiter=maxiter,
                                M=M, callback=callback)
else:
    _cg = sparse_linalg.cg

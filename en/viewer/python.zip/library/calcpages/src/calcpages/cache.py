"""Where calcpages keeps what it can always recompute: checkpoint grids, converted checkpoints and parsed Lotus logs."""

import os
from pathlib import Path


def cache_folder(name):
    """Folder of one kind of cached result, below ``$CALCPAGES_CACHE`` or else ``~/.cache/calcpages``.

    Deleting a cache folder is always safe; it only costs the time to recompute what it held.

    Args:
        name: Kind of result, such as ``fchk``.

    Returns:
        The folder's path, which may not exist yet.
    """
    return Path(os.environ.get("CALCPAGES_CACHE") or Path.home() / ".cache/calcpages") / name

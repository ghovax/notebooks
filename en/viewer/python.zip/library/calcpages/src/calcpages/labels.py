"""Labels of quantities: their LaTeX with units and their explanations, from data/quantities.yaml."""

import copy
import re
from fractions import Fraction
from functools import lru_cache

from runflow.basis import ANGULAR_LETTERS
from runflow.results import ureg
from runflow.text import identifier

from calcpages.i18n import PerLanguage, language, message
from calcpages.text import data


class Quantity(str):
    """A rendered label, Markdown with $...$ LaTeX, with the explanation of the quantity it names."""

    def __new__(cls, label, description):
        """The label as a string that also carries its explanation."""
        value = super().__new__(cls, label)
        value.description = description
        return value

    def __reduce__(self):
        """Pickle the label with its explanation, as the field caches and process pools need."""
        return Quantity, (str(self), self.description)


@lru_cache(maxsize=None)
def unit_latex(unit):
    """Format Pint units in their specified order with negative powers and thin spaces."""
    components = list(ureg.Unit(unit)._units.items())
    components.sort(key=lambda pair: pair[1] < 0)
    parts = []
    for name, exponent in components:
        symbol = format(ureg.Unit(name), "~L")
        symbol = (
            symbol.replace(r"\mathrm{a\_0}", "a_0")
            .replace(r"\mathrm{E\_h}", "E_h")
            .replace(r"\mathrm{Å}", r"\mathrm{\AA}")
            .replace(r"\mathrm{l}", r"\mathrm{L}")
            .replace(r"\mathrm{deg}", r"{}^\circ")
        )
        power = Fraction(exponent).limit_denominator(1000)
        if power != 1:
            exponent_text = (
                str(power.numerator)
                if power.denominator == 1
                else rf"\frac{{{power.numerator}}}{{{power.denominator}}}"
            )
            symbol += rf"^{{{exponent_text}}}"
        parts.append(symbol)
    return r"\,".join(parts) or "1"


def resolve_units(text):
    """Replace unit tokens in generated prose with Pint-formatted LaTeX."""
    return re.sub(r"@unit\(([^()]*)\)@", lambda match: unit_latex(match[1]), text)


def unit_label(label, unit):
    """Append a Pint-formatted unit to a mathematical or plain-text label."""
    formatted = unit_latex(unit)
    return label[:-1] + rf"\;[{formatted}]$" if label.endswith("$") else label + rf" $[{formatted}]$"


def scientific_latex(mantissa, exponent):
    """One ordinary math atom containing the complete scientific number."""
    return rf"$\mathord{{{mantissa}\times 10^{{{int(exponent)}}}}}$"


@lru_cache(maxsize=None)
def quantity_entries(code="en"):
    """The quantities of ``data/quantities.yaml`` in a language, by identifier, with their units in their labels.

    Args:
        code: Language code.

    Returns:
        Each quantity's label and description.
    """
    entries = copy.deepcopy(data("quantities", code))
    for entry in entries.values():
        if unit := entry.get("unit"):
            entry["label"] = unit_label(entry["label"], unit)
        entry["description"] = resolve_units(entry["description"])
    return entries


def quantity(name):
    """The label of a quantity, carrying its explanation.

    Args:
        name: The quantity's identifier, such as ``hartree-energy``, or a table column's codename, such as
            ``hartree_energy``, which names the same quantity.

    Raises:
        KeyError: data/quantities.yaml has no quantity of this identifier.
    """
    entry = quantity_entries(language())[identifier(name)]
    return Quantity(entry["label"], entry["description"])


# Rendered names of table columns and plot fields, by codename.


def _labels(code):
    """Labels of the codename columns of tables and charts in a language.

    Args:
        code: Language code, the current one while this runs.

    Returns:
        Each codename's label.
    """
    return {
        "frontier_level": quantity("frontier-level"),
        "orbital_composition": quantity("orbital-composition"),
        "composition_atom": quantity("composition-atom"),
        "molecular_fragment": quantity("molecular-fragment"),
        **{f"share_{letter}": quantity(f"share-{letter}") for letter in ANGULAR_LETTERS[:8]},
        "share_total": quantity("share-total"),
        "composition_share": quantity("composition-share"),
        "spectral_region": quantity("spectral-region"),
        "quantity": message("column-quantity"),
        "value": message("column-value"),
        "description": message("column-description"),
        "command": message("column-command"),
        "keyword": message("column-keyword"),
        "option": message("column-option"),
        "meaning": message("column-meaning"),
        "options": message("column-options"),
        "iop": "IOp",
        "weights": message("column-weights"),
        "dft_weight": message("column-dft-weight"),
        "atom": message("column-atom"),
        "element": message("column-element"),
        "x": quantity("coordinate-x"),
        "y": quantity("coordinate-y"),
        "z": quantity("coordinate-z"),
        "method": message("column-method"),
        "scf": quantity("scf-solution"),
        "energy": quantity("total-energy"),
        "cycles": quantity("scf-cycles"),
        "cycle": quantity("iteration"),
        "density_rms": quantity("density-change-rms"),
        "converged": quantity("converged"),
        "convergence": quantity("convergence"),
        "evaluation_force": quantity("evaluation-force"),
        "force_statistic": quantity("force-statistic"),
        "optimization_force": quantity("optimization-force"),
        "optimization_force_threshold": quantity("optimization-force-threshold"),
        "optimization_displacement": quantity("optimization-displacement"),
        "optimization_displacement_threshold": quantity("optimization-displacement-threshold"),
        "absolute_energy": quantity("thermochemistry-absolute-energy"),
        "linked_step": message("column-linked-step"),
        "section": message("column-section"),
        "step": quantity("optimization-step"),
        "check_index": quantity("convergence-check-index"),
        "point_index": quantity("point-index"),
        "branch": quantity("branch"),
        "maximum_force": quantity("force-max"),
        "rms_force": quantity("force-rms"),
        "maximum_displacement": quantity("displacement-max"),
        "rms_displacement": quantity("displacement-rms"),
        "relative": quantity("energy-above-final"),
        "threshold": message("column-threshold"),
        "criterion": quantity("optimization-criterion"),
        "mode": message("column-mode"),
        "mode_character": quantity("mode-character"),
        "symmetry": quantity("symmetry"),
        "frequency": quantity("wavenumber"),
        "reduced_mass": quantity("reduced-mass"),
        "force_constant": quantity("force-constant"),
        "intensity": quantity("infrared-intensity"),
        "contribution": message("column-contribution"),
        "thermal_total": message("column-thermal-total"),
        "thermal_electronic": message("column-thermal-electronic"),
        "thermal_translational": message("column-thermal-translational"),
        "thermal_rotational": message("column-thermal-rotational"),
        "thermal_vibrational": message("column-thermal-vibrational"),
        "thermo_level": quantity("thermochemistry-level"),
        "thermo_relative_energy": quantity("thermochemistry-relative-energy"),
        "thermal_energy": quantity("thermal-energy"),
        "heat_capacity": quantity("heat-capacity"),
        "entropy": quantity("entropy"),
        "state": quantity("excited-state"),
        "term": quantity("symmetry"),
        "character": quantity("transition-character"),
        "selection": quantity("dipole-selection"),
        "excitation": quantity("excitation-energy"),
        "wavelength": quantity("wavelength"),
        "oscillator": quantity("oscillator-strength"),
        "velocity": quantity("oscillator-strength-velocity"),
        "spin_squared": quantity("spin-squared"),
        "transition": quantity("orbital-transition"),
        "configurations": quantity("configurations"),
        "weight_percent": quantity("transition-weight"),
        "orbital": quantity("orbital"),
        "orbital_energy": quantity("orbital-energy"),
        "hartree": quantity("energy"),
        "electronvolt": quantity("energy"),
        "occupation": quantity("occupation"),
        "degeneracy": quantity("degeneracy"),
        "transferred": quantity("transferred-charge"),
        "transfer_distance": quantity("transfer-distance"),
        "overlap": quantity("hole-particle-overlap"),
        "charge": quantity("partial-charge"),
        "component": message("column-component"),
        "dipole": quantity("dipole-moment"),
        "axis": message("column-axis"),
        "polar_x": quantity("polarizability-x"),
        "polar_y": quantity("polarizability-y"),
        "polar_z": quantity("polarizability-z"),
        "pair": quantity("nto-pair"),
        "weight": quantity("nto-weight"),
        "stable": quantity("stable"),
        "message": message("column-message"),
        "requested": message("column-requested"),
        "decoded": message("column-decoded"),
        "records": message("column-records"),
        "iteration": quantity("iteration"),
        "density_change": quantity("density-change"),
        "epsilon": quantity("screening"),
        "gap": quantity("orbital-gap"),
        "checkpoint": message("column-checkpoint"),
        "atoms": quantity("atom-count"),
        "reaction_coordinate": quantity("reaction-coordinate"),
        "path_energy": quantity("ts-relative-energy"),
        "reverse_relative_energy": quantity("reverse-relative-energy"),
        "check": message("column-check"),
        "time": message("column-time"),
        "level": message("column-level"),
        "field": message("column-field"),
        "kind": message("column-kind"),
        "source": message("column-source"),
        "series": message("column-quantity"),
        "sign": message("column-sign"),
        "label": quantity("coordinate-label"),
        "definition": quantity("coordinate-definition"),
        "coordinate": quantity("coordinate-kind"),
        "action": quantity("coordinate-action"),
        "setting": quantity("coordinate-setting"),
        "start": quantity("coordinate-start"),
        "bonds": quantity("bonded-atoms"),
        "rule": quantity("optimize-rule"),
    }


# Labels of the codename columns of tables and charts, in the current language.
LABELS = PerLanguage(_labels)


# Plot fields carry this prefix, so their registered labels cannot clash with those of the notebook
# the calculations are appended to.
PLOT = "calculation_"


PLOT_LABELS = PerLanguage(lambda code: {PLOT + key: label for key, label in LABELS.items()})


# Readable names of the Lotus settings in the XYZ comment line.
# Labels of Lotus settings, in the current language.
LOTUS_SETTINGS = PerLanguage(
    lambda code: {
        "method": quantity("method"),
        "basis": quantity("basis-set"),
        "spin": quantity("spin-multiplicity"),
        "charge": quantity("molecular-charge"),
        "epsilon": quantity("initial-screening"),
        "sc_scrEx": quantity("screening-self-consistency"),
        "max_scf": quantity("maximum-scf-iterations"),
        "threshold_scf": quantity("scf-threshold"),
    }
)

"""The data files' schema: each English file under ``data/`` is the schema its translations follow.

Every key, at every level of every data file, is an identifier in kebab case (``runflow.text.identifier``).
``data/schema.yaml`` names, for each data file every language translates, the places of its texts to translate. A
translation ``data/<language>/<name>.yaml`` then gives a text for every such place where the English file has words,
keeping its placeholders (``{value}``, ``%(name)s``), units (``@unit(...)@``) and balanced inline math, writes no math outside ``$...$``, opens as a sentence rather than as a label and a colon, and gives
nothing else, except that a list is given whole, its other values as the English file has them. ``python -m
calcpages.schema`` reports what breaks these rules and fails when anything does; the tests and researchsite.render
run the same check.
"""

import logging
import re
from importlib.resources import files

import yaml
from runflow.runtime import run_script

from calcpages.i18n import LANGUAGES

LOGGER = logging.getLogger(__name__)

# What a text must keep in every language: format placeholders, doubled braces, catalog parameters and units.
KEPT = re.compile(r"\{\{|\}\}|\{[a-z_]+\}|%\([a-z_]+\)s|@unit\([^@]*\)@")
KEBAB = re.compile(r"[a-z0-9]+(-[a-z0-9]+)*")


def _folder():
    """The data folder."""
    return files(__package__).joinpath("data")


def _load(path):
    """A data file's contents."""
    return yaml.safe_load(path.read_text())


def _keys(node, where, problems):
    """Report every key of a data file that is not an identifier in kebab case."""
    if isinstance(node, dict):
        for key, value in node.items():
            if not (isinstance(key, str) and KEBAB.fullmatch(key)):
                problems.append(f"{where}: key {key!r} is not kebab case")
            _keys(value, f"{where}/{key}", problems)
    elif isinstance(node, list):
        for index, value in enumerate(node):
            _keys(value, f"{where}[{index}]", problems)


def _tokens(place):
    """A place of data/schema.yaml as its steps: keys, *, **, [] and [n]."""
    return [token for token in re.findall(r"\[\d*\]|[^.\[\]]+", place)]


def _matches(steps, path):
    """Whether a path of keys and list indices lies at one of a file's places of text."""
    if not steps:
        return not path
    first, rest = steps[0], steps[1:]
    if first == "**":
        return any(_matches(rest, path[index:]) for index in range(len(path) + 1))
    if not path:
        return False
    step = path[0]
    if first == "[]":
        fits = isinstance(step, int)
    elif first.startswith("["):
        fits = isinstance(step, int) and step == int(first[1:-1])
    else:
        fits = isinstance(step, str) and first in ("*", step)
    return fits and _matches(rest, path[1:])


def _worded(text):
    """Whether a text has words to translate outside its math, code, placeholders and units; a label that is only a
    symbol, such as $\\Delta d_k$, reads the same in every language and needs no translation.
    """
    bare = re.sub(r"(?<!\\)\$.*?(?<!\\)\$|`[^`]*`", "", KEPT.sub("", text))
    # English words have lower-case letters; names such as HF, UV-C or B3LYP are written alike in every language.
    return bool(re.search(r"[a-z]{3,}", bare))


# Math written outside math: a LaTeX command, a superscript or subscript, or ASCII operators such as <= or sqrt(, in
# text that is neither between dollar signs, display or inline, nor in a code span.
LOOSE_MATH = re.compile(r"\\[A-Za-z]+|[A-Za-z0-9)]\^[-+{A-Za-z0-9]|[A-Za-z)]_[{A-Za-z0-9]|<=|>=|!=|\bsqrt\(")


def _loose_math(text):
    """The pieces of math a text writes outside its math and code."""
    bare = re.sub(r"\$\$.*?\$\$", " ", text, flags=re.S)
    bare = re.sub(r"(?<!\\)\$.*?(?<!\\)\$|`[^`]*`|@unit\([^@]*\)@|\{[a-z_]+\}|%\([a-z_]+\)s", " ", bare)
    return LOOSE_MATH.findall(bare)


# A text that opens with a label and a colon, "Default: …" or "Link 103: …", rather than a sentence; a colon that
# introduces a list or a displayed formula ends its line instead.
LABELLED = re.compile(r"^(?:[A-Z`$][^:.;\n]{0,40}|[^\x00-\x7f][^:.;\n。、]{0,20}|既定|リンク[^:：。]{0,20}):\s*\S")


def _labelled(text):
    """Whether a text opens as a label and a colon instead of as a sentence."""
    bare = re.sub(r"\$\$.*?\$\$|\]\([^)]*\)|https?://\S+", " ", text, flags=re.S)
    return bool(LABELLED.match(bare.strip())) and not bare.rstrip().endswith(":")


def _texts(node, path, places):
    """Every text at one of a file's places of text, with its path."""
    if isinstance(node, dict):
        for key, value in node.items():
            yield from _texts(value, [*path, key], places)
    elif isinstance(node, list):
        for index, value in enumerate(node):
            yield from _texts(value, [*path, index], places)
    elif isinstance(node, str) and any(_matches(steps, path) for steps in places):
        yield path, node


def _where(name, path):
    """A place in a file, for a problem's message."""
    return name + "".join(f"[{step}]" if isinstance(step, int) else f"/{step}" for step in path)


def _compare(english, own, path, places, name, problems, in_list=False):
    """Compare a translation with its English data from one place down, reporting what breaks the schema."""
    textual = any(_matches(steps, path) for steps in places)
    if textual and isinstance(english, str):
        if _worded(english) and own is None:
            problems.append(f"{_where(name, path)}: untranslated")
        elif own is not None and not isinstance(own, str):
            problems.append(f"{_where(name, path)}: text in English, {type(own).__name__} here")
        elif own:
            if sorted(KEPT.findall(english)) != sorted(KEPT.findall(own)):
                problems.append(f"{_where(name, path)}: placeholders or units differ from the English text")
            if len(re.findall(r"(?<!\\)\$", own)) % 2:
                problems.append(f"{_where(name, path)}: unbalanced $ in its math")
        return
    if isinstance(english, dict):
        if own is not None and not isinstance(own, dict):
            problems.append(f"{_where(name, path)}: a mapping in English, {type(own).__name__} here")
            return
        own = own or {}
        for key in own.keys() - english.keys():
            problems.append(f"{_where(name, [*path, key])}: not in the English file")
        for key, value in english.items():
            _compare(value, own.get(key), [*path, key], places, name, problems, in_list)
    elif isinstance(english, list):
        if own is None:
            own = [None] * len(english)
        elif not isinstance(own, list) or len(own) != len(english):
            problems.append(f"{_where(name, path)}: a list of {len(english)} in English")
            return
        else:
            in_list = True
        for index, (first, second) in enumerate(zip(english, own)):
            _compare(first, second, [*path, index], places, name, problems, in_list)
    elif own is not None and not (in_list and own == english):
        problems.append(f"{_where(name, path)}: not a text to translate; a translation leaves it out")


def check():
    """Check every data file against the schema.

    Returns:
        A description of each problem, empty when every file follows the schema.
    """
    folder, problems = _folder(), []
    for path in sorted(folder.iterdir()):
        if path.name.endswith(".yaml"):
            _keys(_load(path), path.name, problems)
    for name, places in _load(folder.joinpath("schema.yaml")).items():
        english = _load(folder.joinpath(f"{name}.yaml"))
        steps = [_tokens(place) for place in places]
        for path, text in _texts(english, [], steps):
            if loose := _loose_math(text):
                problems.append(f"{_where(f'{name}.yaml', path)}: math outside $...$: {', '.join(loose)}")
            if _labelled(text):
                problems.append(f"{_where(f'{name}.yaml', path)}: opens with a label and a colon, not a sentence")
        for code in LANGUAGES[1:]:
            path = folder.joinpath(code, f"{name}.yaml")
            if not path.is_file():
                problems.append(f"{code}/{name}.yaml: missing")
                continue
            own = _load(path) or {}
            _keys(own, f"{code}/{name}.yaml", problems)
            _compare(english, own, [], steps, f"{code}/{name}.yaml", problems)
            for path, text in _texts(own, [], steps):
                if loose := _loose_math(text):
                    problems.append(f"{_where(f'{code}/{name}.yaml', path)}: math outside $...$: {', '.join(loose)}")
                if _labelled(text):
                    problems.append(
                        f"{_where(f'{code}/{name}.yaml', path)}: opens with a label and a colon, not a sentence"
                    )
    return problems


def main():
    """Log every problem of the data files as an error and fail when there is any."""
    problems = check()
    for problem in problems:
        LOGGER.error("Data file breaks its schema", extra={"metadata": {"problem": problem}})
    if problems:
        raise SystemExit(1)
    LOGGER.info("Every data file follows the schema")


if __name__ == "__main__":
    run_script(main)

"""The checks of the data files and of the catalogs that hold their texts.

Every key, at every level of every data file, is an identifier in kebab case (``runflow.text.identifier``).
``data/schema.yaml`` names the places of each calcpages data file's texts, and ``calcpages.catalogs.PROJECT_PLACES``
those of the research repository's files. No YAML file holds a text at those places; the catalogs hold them, the English
ones the source. Every other language translates each English text that reads differently in it
(``calcpages.catalogs.worded``), with nothing fuzzy, stale or left over, keeping its placeholders (``{value}``,
``%(name)s``), units (``@unit(...)@``) and balanced inline math, writing no math outside ``$...$`` and opening as a
sentence rather than as a label and a colon. ``python -m calcpages.schema`` reports what breaks these rules, for the
research repository too when run inside it, and fails when anything does; the tests and researchsite.render run the
same check.
"""

import logging
import re
from importlib.resources import files
from pathlib import Path

import yaml
from babel.messages.pofile import read_po
from runflow.runtime import run_script

from calcpages.catalogs import KEPT, SOURCE, _recorded, digest, files_with_texts, project_root, texts, worded
from calcpages.i18n import LANGUAGES

LOGGER = logging.getLogger(__name__)

KEBAB = re.compile(r"[a-z0-9]+(-[a-z0-9]+)*")


def _folder():
    """The data folder."""
    return files(__package__).joinpath("data")


def _load(path):
    """A data file's contents."""
    return yaml.safe_load(path.read_text())


def _keys(node, where, problems):
    """Report every key of a data file that is not an identifier in kebab case."""
    if isinstance(node, dict):
        for key, value in node.items():
            if not (isinstance(key, str) and KEBAB.fullmatch(key)):
                problems.append(f"{where}: key {key!r} is not kebab case")
            _keys(value, f"{where}/{key}", problems)
    elif isinstance(node, list):
        for index, value in enumerate(node):
            _keys(value, f"{where}[{index}]", problems)


# Math written outside math: a LaTeX command, a superscript or subscript, or ASCII operators such as <= or sqrt(, in
# text that is neither between dollar signs, display or inline, nor in a code span.
LOOSE_MATH = re.compile(r"\\[A-Za-z]+|[A-Za-z0-9)]\^[-+{A-Za-z0-9]|[A-Za-z)]_[{A-Za-z0-9]|<=|>=|!=|\bsqrt\(")


def _loose_math(text):
    """The pieces of math a text writes outside its math and code."""
    bare = re.sub(r"\$\$.*?\$\$", " ", text, flags=re.S)
    bare = re.sub(r"(?<!\\)\$.*?(?<!\\)\$|`[^`]*`|@unit\([^@]*\)@|\{[a-z_]+\}|%\([a-z_]+\)s", " ", bare)
    return LOOSE_MATH.findall(bare)


# A text that opens with a label and a colon, "Default: …" or "Link 103: …", rather than a sentence; a colon that
# introduces a list or a displayed formula ends its line instead.
LABELLED = re.compile(r"^(?:[A-Z`$][^:.;\n]{0,40}|[^\x00-\x7f][^:.;\n。、]{0,20}|既定|リンク[^:：。]{0,20}):\s*\S")


def _labelled(text):
    """Whether a text opens as a label and a colon instead of as a sentence."""
    bare = re.sub(r"\$\$.*?\$\$|\]\([^)]*\)|https?://\S+", " ", text, flags=re.S)
    return bool(LABELLED.match(bare.strip())) and not bare.rstrip().endswith(":")


def _where(name, path):
    """A place in a file, for a problem's message."""
    return name + "".join(f"[{step}]" if isinstance(step, int) else f"/{step}" for step in path)


def _english(name, path, places, problems):
    """Report a data file that still holds a text, and the English texts that write math outside $...$ or open with a
    label and a colon.
    """
    data = yaml.safe_load(Path(path).read_text()) if Path(path).is_file() else None
    for where, text in texts(data or {}, places):
        problems.append(f"{_where(name, where)}: a text belongs in its catalogs, not in the YAML file")
    return problems


def catalog_problems(english, own, name):
    """What breaks the rules in one catalog of another language against its English catalog.

    Args:
        english: The English catalog.
        own: The other language's catalog.
        name: A name for the messages.

    Returns:
        A description of each problem.
    """
    with Path(english).open("rb") as stream:
        source = {m.id: m.string for m in read_po(stream) if m.id}
    if not Path(own).is_file():
        return [f"{name}: missing"]
    with Path(own).open("rb") as stream:
        catalog = {m.id: m for m in read_po(stream) if m.id}
    problems = []
    for text_key, text in source.items():
        message = catalog.get(text_key)
        if message is None or not message.string:
            if worded(text):
                problems.append(f"{name}: {text_key}: untranslated")
            continue
        own_text = message.string
        if message.fuzzy or _recorded(message) != digest(text):
            problems.append(f"{name}: {text_key}: its English changed; confirm the translation")
        if sorted(KEPT.findall(text)) != sorted(KEPT.findall(own_text)):
            problems.append(f"{name}: {text_key}: placeholders or units differ from the English text")
        if len(re.findall(r"(?<!\\)\$", own_text)) % 2:
            problems.append(f"{name}: {text_key}: unbalanced $ in its math")
        if loose := _loose_math(own_text):
            problems.append(f"{name}: {text_key}: math outside $...$: {', '.join(loose)}")
        if _labelled(own_text):
            problems.append(f"{name}: {text_key}: opens with a label and a colon, not a sentence")
    problems += [f"{name}: {text_key}: no such text in English" for text_key in catalog.keys() - source.keys()]
    return problems


def _english_texts(catalog, name, problems):
    """Report the English texts of a catalog that write math outside $...$ or open with a label and a colon."""
    with Path(catalog).open("rb") as stream:
        for message in read_po(stream):
            if message.id:
                if loose := _loose_math(message.string):
                    problems.append(f"{name}: {message.id}: math outside $...$: {', '.join(loose)}")
                if _labelled(message.string):
                    problems.append(f"{name}: {message.id}: opens with a label and a colon, not a sentence")


def check(root=None):
    """Check every data file and catalog against the rules: calcpages' own, and the research repository's at ``root``.

    Args:
        root: The research repository, or None for calcpages alone.

    Returns:
        A description of each problem, empty when everything follows the rules.
    """
    folder, problems = _folder(), []
    for path in sorted(folder.iterdir()):
        if path.name.endswith(".yaml"):
            _keys(_load(path), path.name, problems)
    for name, path, places, catalogs in files_with_texts(root):
        _english(name, path, places, problems)
        for catalog in catalogs(SOURCE):
            _english_texts(catalog, str(catalog), problems)
            for code in LANGUAGES[1:]:
                own = Path(str(catalog).replace(f"/{SOURCE}/", f"/{code}/", 1))
                problems += catalog_problems(catalog, own, str(own))
    return problems


def main():
    """Log every problem of the data files as an error and fail when there is any."""
    try:
        root = project_root(Path.cwd())
    except StopIteration:
        root = None
    problems = check(root)
    for problem in problems:
        LOGGER.error("Data file breaks its schema", extra={"metadata": {"problem": problem}})
    if problems:
        raise SystemExit(1)
    LOGGER.info("Every data file follows the schema")


if __name__ == "__main__":
    run_script(main)

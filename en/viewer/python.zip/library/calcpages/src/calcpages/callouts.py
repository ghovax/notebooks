"""Status callouts and findings shared by calculation pages and the viewer."""

import sourcetypes
from runflow.text import identifier

from calcpages.appearance import CALLOUTS
from calcpages.i18n import message
from calcpages.text import TEXT


def status_callout(word, reason):
    """A Quarto status callout with its findings or other supporting detail; a calculation that has not been run
    shows no status at all.
    """
    if word == "Not run":
        return ""
    kind, name = CALLOUTS[identifier(word)]
    text: sourcetypes.markdown = f"""::: {{.callout-{kind}{f" .status-{name}" if name else ""} title="{TEXT["status-names"].get(identifier(word), word)}"}}
{reason}
:::
"""
    return text


def findings_table(findings, icons, show_source=True):
    """Warnings and errors in a single table; the source column is omitted where the callout names it."""
    kinds = {"Info": "hourglass", "Warning": "warning", "Error": "cross"}
    words = {
        "Info": message("finding-kind-info"),
        "Warning": message("finding-kind-warning"),
        "Error": message("finding-kind-error"),
    }
    grouped = {}
    for finding in findings:
        # A prepared calculation has no log to report on, so its status alone describes it.
        if finding.kind not in kinds or finding.status == "Not run":
            continue
        source = (finding.source or message("findings-calculation")).replace("|", r"\|") if show_source else ""
        text = finding.markdown().replace("|", r"\|")
        key = (finding.kind, source, text)
        grouped[key] = grouped.get(key, 0) + finding.count
    rows = []
    for (kind, source, text), count in grouped.items():
        icon = f"![{words[kind]}]({icons}{kinds[kind]}.svg){{.workflow-status}}"
        rows.append((icon, source, text) if show_source else (icon, text))
    if not rows:
        return ""
    line = lambda cells: "| " + " | ".join(cells) + " |"
    header = (
        (message("findings-kind"), message("findings-calculation"), message("findings-message"))
        if show_source
        else (message("findings-kind"), message("findings-message"))
    )
    return "\n".join([line(header), line(("---",) * len(header)), *(line(row) for row in rows)]) + "\n"

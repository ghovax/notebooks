"""Status callouts and findings shared by calculation pages and the viewer."""

import sourcetypes
from runflow.text import identifier

from calcpages.appearance import CALLOUTS
from calcpages.i18n import message
from calcpages.text import TEXT


def status_callout(code, reason):
    """A Quarto callout of the status a README records, holding its explanation and the run's findings."""
    text: sourcetypes.markdown = f"""::: {{.callout-{CALLOUTS[code]} .status-{code} title="{TEXT["statuses"][code]["name"]}"}}
{reason}
:::
"""
    return text


def findings_callout(table):
    """A callout of the findings a run's output records, its errors, warnings and activity, which are data about the
    run and set no status; empty without any.
    """
    if not table:
        return ""
    text: sourcetypes.markdown = f"""::: {{.callout-note title="{message("findings-title")}"}}
{table}
:::
"""
    return text


def findings_table(findings, icons, show_source=True):
    """Warnings and errors in a single table; the source column is omitted where the callout names it."""
    kinds = {"info": "hourglass", "warning": "warning", "error": "cross"}
    words = {
        "info": message("finding-kind-info"),
        "warning": message("finding-kind-warning"),
        "error": message("finding-kind-error"),
    }
    grouped = {}
    for finding in findings:
        # A calculation without a log has nothing to report.
        if finding.kind not in kinds or identifier(finding.code) == "missing-log":
            continue
        source = (finding.source or message("findings-calculation")).replace("|", r"\|") if show_source else ""
        text = finding.markdown().replace("|", r"\|")
        key = (finding.kind, source, text)
        grouped[key] = grouped.get(key, 0) + finding.count
    rows = []
    for (kind, source, text), count in grouped.items():
        icon = f"![{words[kind]}]({icons}{kinds[kind]}.svg){{.workflow-status}}"
        rows.append((icon, source, text) if show_source else (icon, text))
    if not rows:
        return ""
    line = lambda cells: "| " + " | ".join(cells) + " |"
    header = (
        (message("findings-kind"), message("findings-calculation"), message("findings-message"))
        if show_source
        else (message("findings-kind"), message("findings-message"))
    )
    return "\n".join([line(header), line(("---",) * len(header)), *(line(row) for row in rows)]) + "\n"

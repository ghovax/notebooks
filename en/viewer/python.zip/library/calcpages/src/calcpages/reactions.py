"""Fragments, bonds and frontier quantities of reactions, written for pages and notebooks."""

import re

import networkx as nx
import numpy as np
from runflow.basis import momentum_letter
from runflow.units import ELEMENTS

from calcpages.i18n import message
from calcpages.labels import Quantity, quantity, unit_latex


def _bonded_groups(numbers, coordinates, tolerance=0.4):
    """The molecule's bonded fragments, each as its Hill formula and its atom groups in the order of its bonds.

    Bonds are those of ``runflow.reaction.bond_graph``: within ``tolerance`` angstrom of the sum of the covalent radii,
    so bonds still forming at a saddle are not. A group is a heavy atom with the hydrogens bonded to it, each hydrogen with its nearest heavy
    atom, or a hydrogen bonded to none; it is named by the list of its atoms, such as C1, H7, H8. Within a fragment the groups follow a depth-first walk along the bonds, from the end atom of lowest number
    and through the neighbours in input order, so bonded groups are mostly adjacent; the fragments come in the order of
    their first atom.

    Args:
        numbers: Atomic numbers.
        coordinates: Positions in angstrom, one row per atom.
        tolerance: Margin in angstrom beyond the sum of covalent radii within which two atoms are bonded.

    Returns:
        A list of pairs of a fragment's Hill formula, written for mhchem, and its groups, each a pair of a LaTeX label and the
        zero-based atoms it holds.
    """
    from runflow.reaction import bond_graph, fragments, hill_formula

    graph = bond_graph(numbers, coordinates, tolerance)
    distances = np.linalg.norm(coordinates[:, None] - coordinates[None], axis=2)
    # Each hydrogen bonded to a heavy atom joins its nearest one.
    owner = {
        atom: min(partners, key=lambda other: distances[atom, other])
        for atom in graph
        if numbers[atom] == 1 and (partners := [other for other in graph[atom] if numbers[other] != 1])
    }
    skeleton = graph.subgraph(atom for atom in graph if atom not in owner)
    result = []
    for members in fragments(graph):
        order = []
        # A walk along the bonds of each connected part of the fragment's skeleton, from its end atom of lowest number.
        for part in sorted(
            (sorted(c) for c in nx.connected_components(skeleton.subgraph(members))), key=lambda c: c[0]
        ):
            start = min(part, key=lambda atom: (skeleton.degree(atom) > 1, atom))
            order += list(nx.dfs_preorder_nodes(skeleton.subgraph(part), source=start))
        formula = hill_formula(numbers, members)
        groups = []
        for atom in order:
            hydrogens = sorted(other for other, centre in owner.items() if centre == atom)
            # The group as the list of its atoms, such as C1, H7, H8, the heavy atom first.
            names = [rf"\ce{{{ELEMENTS[numbers[member] - 1]}{member + 1}}}" for member in (atom, *hydrogens)]
            groups.append((f"${', '.join(names)}$", [atom, *hydrogens]))
        result.append((formula, groups))
    return result


# Quantities written for a reaction's fragments by ``reaction_quantity``.
REACTION_QUANTITIES = (
    "frontier_overlap",
    "frontier_pair",
    "frontier_stabilization",
    "lumo_population",
    "orbital_sum",
    "orbital_overlap_density",
    "orbital_overlap",
    "reverse_overlap_density",
)


def reaction_quantity(key, reaction):
    """A quantity of a frontier pair of two fragments, written for a ``runflow.reaction.Reaction``: its X, the donor of
    normal demand, becomes the first fragment's formula and its Y, the acceptor, the second's, such as C4H6 and C2H4,
    in the label and in the explanation alike.
    """
    original = quantity(key)
    names = {"X": rf"\ce{{{reaction.formula(0)}}}", "Y": rf"\ce{{{reaction.formula(1)}}}"}
    fill = lambda text: re.sub(
        r"\((X|Y)\)|\$(X|Y)\$", lambda match: f"({names[match[1]]})" if match[1] else f"${names[match[2]]}$", text
    )
    return Quantity(fill(str(original)), fill(original.description))


def bond_tex(reaction, pair):
    r"""A bond of a ``runflow.reaction.Reaction`` in mhchem's notation, such as $\ce{C1-C6}$."""
    return rf"$\ce{{{reaction.bond_name(pair)}}}$"


def pair_group_markdown(reaction, first, second):
    """Markdown bullets that define the groups of atom pairs of two fragments of a ``runflow.reaction.Reaction``, one per
    role that has pairs, each one short sentence that opens with the group's name in bold, as the plots name it.
    """
    groups = reaction.pair_groups(first, second)
    atoms = lambda pairs: [(reaction.fragments[first][a], reaction.fragments[second][b]) for a, b in pairs]
    name = lambda role: reaction.role_name(role, str(quantity(f"pairs-{role}")))
    either = lambda names: (
        message("list-alternatives", head=", ".join(names[:-1]), last=names[-1]) if len(names) > 1 else names[0]
    )
    lines = []
    if groups["forming"]:
        bonds = message("list-last-separator").join(bond_tex(reaction, pair) for pair in atoms(groups["forming"]))
        lines.append(message("reaction-forming", name=name("forming"), bonds=bonds))
    if groups["reacting"]:
        lines.append(message("reaction-reacting", name=name("reacting")))
    if groups["spectator"]:
        heavy = sorted({atom for pair in atoms(groups["spectator"]) for atom in pair if atom not in reaction.reacting})
        listed = either([rf"$\ce{{{reaction.names[atom]}}}$" for atom in heavy])
        lines.append(message("reaction-spectator", name=name("spectator"), atoms=listed))
    if groups["hydrogen"]:
        lines.append(message("reaction-hydrogen", name=name("hydrogen")))
    return "\n".join(lines) + "\n"


def _atom_tex(numbers, atom):
    """A zero-based atom as its element symbol with its one-based number as a subscript, as the viewers name it."""
    return rf"$\mathrm{{{ELEMENTS[numbers[atom] - 1]}}}_{{{atom + 1}}}$"


def _part_tex(numbers, part):
    """The LaTeX name of a part of an orbital: an atom as the viewers name it, or the letter of an angular momentum."""
    return _atom_tex(numbers, part[1])[1:-1] if part[0] == "atom" else momentum_letter(part[1])


def _part_shares(matrix, part, momenta):
    """An orbital's shares on the atoms for one part of it, as ``VolumeViewer`` colours them: the values, every atom's
    hover text and the part's colour scale. The whole orbital and one atom take $w_A$, one atom's alone; the functions of
    one angular momentum take $w_{A,l}$.
    """
    texts = [_share_text(row, momenta) for row in matrix]
    if part is None:
        return matrix.sum(axis=1), texts, "whole"
    if part[0] == "momentum":
        return matrix[:, part[1]], texts, f"l{part[1]}"
    values = np.zeros(len(matrix))
    values[part[1]] = matrix[part[1]].sum()
    return values, texts, "whole"


def _share_text(part, momenta):
    """An atom's share of an orbital in percent as one equation for hover text: $w_A$ as the sum of its parts $w_{A,l}$
    of at least 0.05%, each with its value in parentheses, then the total.
    """
    percent = unit_latex("percent")
    value = lambda number: f"{number:.1f}".replace("-0.0", "0.0") + rf"\,{percent}"
    parts = [(letter, number) for letter, number in zip(momenta, part) if abs(number) >= 0.05]
    if len(parts) > 1:
        terms = "+".join(rf"w_{{A,{letter}}}\,({value(number)})" for letter, number in parts)
        return rf"$w_A={terms}={value(part.sum())}$"
    if parts:
        return rf"$w_A=w_{{A,{parts[0][0]}}}={value(part.sum())}$"
    return rf"$w_A={value(part.sum())}$"

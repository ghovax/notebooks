"""Gaussian's route keywords, options, IOps and Link 0 commands in words, with links to the manual."""

import re

import pandas as pd
from runflow.text import identifier, split_items, unwrap

from calcpages.i18n import message
from calcpages.labels import resolve_units
from calcpages.text import GAUSSIAN, IOPS, TEXT, gaussian_entry, keyword_entry, option_entry, solvents


def job_word(job, name):
    """Name of one job keyword, followed in parentheses by what kind of job it is, as Gaussian's options say it.

    An optimization names what it looks for: a relaxed scan when it logged scan points, else a TS or QST2/QST3 search
    when its route asks for one; an IRC names its direction when it follows only one; a job on excited states names
    their method, such as TD.

    Args:
        job: Linked job from a log or an input, with its ``request`` and, for a log, its ``scan_points``.
        name: Job keyword, lower case, such as ``opt`` or ``irc``.

    Returns:
        The display name, such as ``Opt (TS)``, ``Opt (scan)``, ``IRC (forward)``, ``SP (TD)`` or ``Freq``.
    """
    request = job["request"]
    options = request["options"].get(name, {})
    kinds = []
    if name == "opt":
        if job.get("scan_points"):
            kinds.append(message("job-scan"))
        else:
            kinds += [search.upper() for search in ("ts", "qst2", "qst3") if search in options][:1]
    if name == "irc":
        kinds += [
            message("job-irc-forward") if direction == "forward" else message("job-irc-reverse")
            for direction in ("forward", "reverse")
            if direction in options
        ][:1]
    if request.get("excited"):
        kinds.append(request["excited"]["method"].upper())
    word = TEXT["gaussian"]["job-names"].get(identifier(name), name.capitalize())
    return message("job-kinds", job=word, kinds=", ".join(kinds)) if kinds else word


def _method_name(name):
    """Use conventional functional casing without losing a spin restriction prefix.

    Args:
        name: Gaussian method as reported by the input or output parser.

    Returns:
        Canonical method name, retaining R, U or RO when explicitly present.
    """
    methods = GAUSSIAN["methods"]
    key = identifier(name)
    if key in methods:
        return methods[key]["name"]
    for prefix in ("ro", "r", "u"):
        if key.startswith(prefix) and key[len(prefix) :] in methods:
            return prefix.upper() + methods[key[len(prefix) :]]["name"]
    return name


def _basis_name(name):
    """Normalize supported basis names and equivalent polarization aliases.

    Args:
        name: Parsed basis name.

    Returns:
        Conventional Gaussian basis notation.
    """
    entry = gaussian_entry("basis-sets", name)
    return _basis_math(entry["name"] if entry else name)


def _basis_math(name):
    """A Pople or minimal basis-set name in LaTeX, as written in the READMEs: the split-valence digits and hyphen
    upright, diffuse plus signs and polarization stars as symbols, and the polarization functions in parentheses, such
    as 6-31G(d,p) as $6\\text{-}31\\mathrm{G}(d,p)$; other names are left as written.
    """
    match = re.fullmatch(r"(\d+)-(\d+)(\+{0,2})G(\*{0,2})(\([^)]*\))?", name)
    if match:
        plus = "{+}" * len(match[3])
        stars = f"^{{{'*' * len(match[4])}}}" if match[4] else ""
        return f"${match[1]}\\text{{-}}{match[2]}{plus}\\mathrm{{G}}{stars}{match[5] or ''}$"
    if match := re.fullmatch(r"STO-(\d+)G", name):
        return f"$\\mathrm{{STO}}\\text{{-}}{match[1]}\\mathrm{{G}}$"
    return name


def _keyword_name(name):
    """Normalize a route keyword or method for display.

    Args:
        name: Parsed route keyword or method.

    Returns:
        Canonical display name, preserving unsupported names verbatim.
    """
    # The form written, short or long, in the manual's spelling.
    short = GAUSSIAN["aliases"].get(identifier(name))
    entry = GAUSSIAN["keywords"].get(identifier(name))
    return short["name"] if short else entry["name"] if entry else _method_name(name)


def _manual(name):
    """Manual page and meaning of a route keyword, either possibly None."""
    key, entry = keyword_entry(name)
    entry = entry or GAUSSIAN["methods"].get(key) or {}
    page = entry.get("page") or (key if key in GAUSSIAN["pages"] else None)
    return page, entry.get("meaning")


def _link(text, page):
    """Literal keyword text linked to its Gaussian manual page when it has one."""
    shown = f"`{text}`"
    return f"[{shown}](https://gaussian.com/{page}/)" if page else shown


def _iop_rows(name, value):
    """Rows of one IOp setting: its name, value as written, meaning and, for a DFT weight IOp, a subtable of the
    weights its MMMMMNNNNN digits set, each with its value and meaning.
    """
    if (
        identifier(name) in TEXT["gaussian"]["dft-weights"]["iops"]
        and re.fullmatch(r"-?\d+", value)
        and int(value) > 0
        or (name in ("3/77", "3/78") and re.fullmatch(r"-\d+", value) and int(value) < -1)
    ):
        # Gaussian reads the value as an integer: MMMMM is its quotient by 100000 and NNNNN the remainder, so
        # leading zeros may be omitted. For 3/77 and 3/78 a negative sign applies to the local term only.
        code = abs(int(value))
        weights = (code // 100000 / 10000, (-1 if int(value) < 0 else 1) * (code % 100000) / 10000)
        table = pd.DataFrame(
            [
                (f"${entry['symbol']}$", weight, entry["meaning"])
                for entry, weight in zip(TEXT["gaussian"]["dft-weights"]["iops"][identifier(name)]["weights"], weights)
            ],
            columns=["dft_weight", "value", "meaning"],
        )
        meaning = TEXT["gaussian"]["dft-weights"]["iops"][identifier(name)]["meaning"] + (
            message("iop-weights-enter", functional=TEXT["gaussian"]["dft-weights"]["functional"])
            if name == "3/76"
            else ""
        )
        return [(_iop_name(name), f"`{value}`", meaning, table)]
    # A hand-written template explains a value it scales, such as N for N/10^6; a value the IOps Reference lists on
    # its own, such as 0 for the default, keeps the reference's meaning.
    template = (option_entry(name, "iop") or {}).get("meaning")
    listed = _listed_value(name, value) is not None
    meaning = resolve_units(template.format(value=value)) if template and not listed else _iop_meaning(name, value)
    return [(_iop_name(name), f"`{value}`" if value else None, meaning, None)]


def _iop_name(name):
    """An IOp's overlay/option, linked to its entry in the IOps Reference when it has one: on its overlay's page, at
    the anchor its overlay and option name unless the reference names another.
    """
    entry = IOPS.get(identifier(name))
    if not entry:
        return f"`{name}`"
    anchor = entry.get("anchor") or "overlay{0}/#iop_{0}_{1}".format(*name.split("/"))
    return f"[`{name}`](https://gaussian.com/{anchor})"


def _listed_value(name, value):
    """The IOps Reference's meaning of one value of an IOp when the reference lists that value, else None."""
    number = lambda text: int(text) if re.fullmatch(r"[-+]?\d+", text) else None
    return next(
        (
            text
            for setting, text in (IOPS.get(identifier(name)) or {}).get("values", [])
            if setting == value or number(setting) is not None and number(setting) == number(value)
        ),
        None,
    )


def _iop_meaning(name, value):
    """An IOp's description from the IOps Reference, followed by the meaning of its value when the reference
    lists that value. The descriptions are Markdown with their math in LaTeX and their units as ``@unit(...)@``.
    """
    entry = IOPS.get(identifier(name))
    if not entry:
        return ""
    meaning = resolve_units(entry.get("meaning", ""))
    match = _listed_value(name, value)
    return meaning + (message("iop-value-meaning", value=value, meaning=resolve_units(match)) if match else "")


def _setting(value):
    """A setting's value as read: an integer or decimal number as a number, other text as written, and a
    parenthesized list as its items separated by commas.
    """
    if re.fullmatch(r"[-+]?\d+", value):
        return int(value)
    if re.fullmatch(r"[-+]?(\d+\.\d*|\.\d+)([eEdD][-+]?\d+)?", value):
        return float(re.sub("[dD]", "e", value))
    return ", ".join(split_items(unwrap(value))) if value.startswith("(") else value


def _option_name(name):
    """A route option as the manual spells it, whatever its case in the input; unknown options as written."""
    entry = option_entry(name)
    return entry["name"] if entry else name


def _option_rows(keyword, options):
    """Rows of a keyword's options: the option's name, its value when it takes one, and its meaning; nested
    options are explained in place.
    """
    _, entry = keyword_entry(keyword)
    option_meaning = lambda option: entry.get("options", {}).get(identifier(option), {}).get("meaning", "")
    rows, items = [], []
    for item in split_items(unwrap(options)):
        # A solvent whose name has commas, such as n,n-DiMethylFormamide, is split at them like separate options.
        if (
            items
            and items[-1].lower().startswith("solvent=")
            and "=" not in item
            and any(name.startswith((items[-1].partition("=")[2] + "," + item).lower()) for name in solvents())
        ):
            items[-1] += "," + item
        else:
            items.append(item)
    for option in items:
        name, _, value = option.partition("=")
        template = option_meaning(name)
        nested = (
            [
                option_meaning(inner.partition("=")[0]).format(value=inner.partition("=")[2])
                for inner in split_items(unwrap(value))
            ]
            if value.startswith("(") and "=" in value
            else []
        )
        if nested:
            # Nested options spelled as the manual spells them, with their values as written.
            value = (
                "("
                + ",".join(
                    _option_name(inner.partition("=")[0]) + inner[len(inner.partition("=")[0]) :]
                    for inner in split_items(unwrap(value))
                )
                + ")"
            )
        elif name.lower() == "solvent" and value.lower() in solvents():
            value, epsilon = solvents()[value.lower()]
            template = entry.get("solvent-meaning", template).replace("{epsilon}", epsilon)
        # A solvent's name is one value, commas and all; a list's items are separated as words are.
        meaning = template.format(value=value if name.lower() == "solvent" else ", ".join(split_items(unwrap(value))))
        meaning = resolve_units(" ".join(part for part in [meaning, *nested] if part))
        rows.append((f"`{_option_name(name)}`", _setting(value) if value else None, meaning))
    return rows


def _options_table(keyword, options):
    """A keyword's options as a subtable, with the Value column only when some option takes a value."""
    table = pd.DataFrame(_option_rows(keyword, options), columns=["option", "value", "meaning"])
    return table if table.value.notna().any() else table.drop(columns="value")


def _link0_value(key, value):
    """A Link 0 command's value in words: a memory size as a number and its unit, such as 8 GB, a count as a
    number and a processor list with ranges written as en dashes.
    """
    if not value:
        return ""
    if key == "mem":
        match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([KMGT]?)(B|W)?", value.strip(), re.I)
        if match:
            # Gaussian counts memory in 8-byte words when no unit is given.
            if not (match[2] or match[3]):
                return message("memory-words", count=match[1])
            unit = match[2].upper() + ("B" if (match[3] or "W").upper() == "B" else "W")
            return f"{match[1]} {unit}"
    if re.fullmatch(r"\d+", value.strip()):
        return int(value)
    if key in ("cpu", "gpucpu"):
        return value.replace("-", "–").replace(",", ", ")
    return value


def _requested_resource(key, value):
    """A Slurm request as the overview shows it: memory as a number and its binary unit, such as 12 GB, and a
    partition list as its names, such as r01, r02, r03.
    """
    if key == "mem" and (match := re.fullmatch(r"(\d+(?:\.\d+)?)\s*([KMGT])i?B?", value.strip(), re.I)):
        return f"{match[1]} {match[2].upper()}B"
    if key == "partition":
        return ", ".join(name for name in re.split(r"[\s,]+", value.strip()) if name)
    return value

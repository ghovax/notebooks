"""Structure files dropped on the viewer page: SDF and Molfile records shown as molecules and tables."""

import re
from pathlib import Path

import numpy as np
import pandas as pd
from babel.dates import format_datetime
from molstarview import MolstarViewer
from runflow.molecules import atom_values, read_sdf, xyz_frames
from runflow.results import ureg
from runflow.units import ELEMENTS

from calcpages.i18n import date_locale, message
from calcpages.labels import quantity, unit_latex
from calcpages.notation import _value, quantities_table


class StructureFile:
    """The records of an SDF or Molfile, as runflow.molecules reads them, for the viewer page's structure sections."""

    def __init__(self, path):
        """Read every record of the file at ``path``."""
        self.path = Path(path)
        self.records = read_sdf(path)
        self.first = self.records[0]
        # Whether every record has the same atoms in the same order, as conformers do, so that one viewer plays them.
        self.shared = all(list(record["numbers"]) == list(self.first["numbers"]) for record in self.records)

    def viewers(self, limit=10):
        """One viewer whose frames are the records when they share their atoms, else one per record up to
        ``limit``.
        """
        frames = lambda record: record["coordinates"].to("angstrom").magnitude
        if self.shared:
            return [
                MolstarViewer(
                    xyz_frames(
                        self.first["numbers"], np.stack([frames(record) for record in self.records]) * ureg.angstrom
                    )
                )
            ]
        return [
            MolstarViewer(xyz_frames(record["numbers"], frames(record)[None] * ureg.angstrom))
            for record in self.records[:limit]
        ]

    def summary_table(self):
        """The first record's title, formula, atoms and bonds, and the program and dimensions its header states."""
        from runflow.reaction import hill_formula

        # The Hill system: with carbon, carbon, hydrogen, then alphabetically; without carbon, all alphabetically.
        formula = re.sub(r"(\d+)", r"_{\1}", hill_formula(self.first["numbers"]))
        rows = [
            (message("structure-title"), self.first["title"]),
            (message("structure-formula"), rf"$\mathrm{{{formula}}}$"),
            (message("structure-atoms"), _value(len(self.first["numbers"]))),
            (message("structure-bonds"), _value(self.first["bonds"])),
        ]
        if len(self.records) > 1:
            rows.append((message("structure-records"), _value(len(self.records))))
        written = self.first["written"]
        rows += [
            (message("structure-program"), self.first["program"]),
            (
                message("structure-written"),
                format_datetime(written, message("date-minute-pattern"), locale=date_locale()) if written else "",
            ),
            (message("structure-coordinates"), self.first["dimensions"]),
            (message("structure-comment"), self.first["comment"]),
        ]
        return quantities_table([row for row in rows if row[1]])

    def coordinates_table(self):
        """The first record's Cartesian coordinates in angstrom."""
        coordinates = self.first["coordinates"].to("angstrom").magnitude
        table = pd.DataFrame(coordinates, columns=["x", "y", "z"])
        table.insert(0, "element", [ELEMENTS[number - 1] for number in self.first["numbers"]])
        table.insert(0, "atom", range(1, len(coordinates) + 1))
        return table

    def charges(self):
        """The first record's partial charges by atom, from a data field named for them, with the field's name; None
        without one.
        """
        for name, text in self.first["properties"].items():
            if "CHARGE" in name.upper():
                values = atom_values(text, len(self.first["numbers"]))
                if values is not None:
                    return name, values
        return None

    def charges_viewer(self):
        """The first record with each atom coloured by its partial charge, red negative and blue positive on a scale
        symmetric about zero, with the charge in its hover label.
        """
        _, charges = self.charges()
        frame = xyz_frames(
            self.first["numbers"], self.first["coordinates"].to("angstrom").magnitude[None] * ureg.angstrom
        )
        details = [rf"$q={{{charge:+.3f}}}\,{unit_latex('elementary_charge')}$" for charge in charges]
        return MolstarViewer(
            frame,
            atom_values=list(charges),
            atom_details=details,
            color_label=quantity("atom-partial-charge"),
            trail=False,
        )

    def fields_table(self):
        """The first record's single-line data fields, by name."""
        rows = [
            dict(field=f"`{name}`", value=text) for name, text in self.first["properties"].items() if "\n" not in text
        ]
        return pd.DataFrame(rows, columns=["field", "value"])

    def long_fields(self):
        """The first record's data fields of several lines, as (name, text)."""
        return [(name, text) for name, text in self.first["properties"].items() if "\n" in text]

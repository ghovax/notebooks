"""Quarto pages of Gaussian and Lotus calculations, built from runflow's records."""

"""Fields from formatted checkpoints: orbitals, densities and their caches, and the viewers' surface choices."""

import hashlib
import os
import pickle
import re
from functools import lru_cache
from pathlib import Path

import numpy as np
from molstarview import color_field_view
from runflow.basis import basis_function_owners, density_grid, orbital_grid, overlap_matrix
from runflow.checkpoints import read_fchk_records, spin_record
from runflow.molecules import xyz_frames
from runflow.orbital_symmetry import orbital_symmetry
from runflow.results import ureg

from calcpages.cache import cache_folder
from calcpages.i18n import message
from calcpages.labels import quantity, unit_latex
from calcpages.notation import _point_group, _to_ev
from calcpages.sources import _checkpoint_digest, _parser_version


def potential_in_space(surfaces, isovalue=None):
    """The in-space view of the electrostatic potential colouring ``surfaces`` (density surfaces with the potential in
    volts as their colour field, one or a mapping of snapshot titles to them): red surfaces at -``isovalue`` volts,
    where a positive charge is attracted, and blue ones at +``isovalue``, by default the median magnitude of the
    potential over the density surfaces, for ``VolumeViewer``'s ``alternates``.
    """
    return color_field_view(
        surfaces,
        isovalue=isovalue,
        title=message("viewer-potential-in-space"),
        color_label=quantity("electrostatic-potential"),
        field_name=message("field-electrostatic-potential"),
        field_symbol="V",
        field_unit=unit_latex("volt"),
    )


class _LabelledFrames(list):
    """XYZ frames with optional one-based landmarks for the molecular viewer."""

    def __init__(self, frames, frame_labels):
        super().__init__(frames)
        self.frame_labels = frame_labels


def _frames(numbers, geometries):
    """XYZ frames of matching geometries in angstrom."""
    return xyz_frames(numbers, np.asarray(geometries, dtype=float) * ureg.angstrom)


def _fchk_digest(path):
    """First sixteen hex digits of a formatted checkpoint's digest, read once per checkpoint and stat."""
    info = Path(path).stat()
    return _checkpoint_digest(str(Path(path).resolve()), info.st_mtime_ns, info.st_size)


@lru_cache(maxsize=4)
def _fchk_parsed(path, digest):
    return read_fchk_records(path)


def _records(path):
    """The records of a formatted checkpoint, parsed once per page; a copy, so callers may add their own keys."""
    return dict(_fchk_parsed(str(Path(path).resolve()), _fchk_digest(path)))


def _fchk_pickled(path, kind, compute):
    """``compute()`` for a formatted checkpoint, cached on disk by the checkpoint's content and runflow's source."""
    cache = cache_folder("fchk") / f"{Path(path).stem}-{_fchk_digest(path)}-{kind}-{_parser_version()[:12]}.pickle"
    try:
        return pickle.loads(cache.read_bytes())
    except (OSError, EOFError, pickle.UnpicklingError):
        pass  # A missing or unreadable cache entry is computed again.
    result = compute()
    cache_folder("fchk").mkdir(parents=True, exist_ok=True)
    # Written beside its final name and moved, so a parallel reader never sees half a file.
    partial = cache.with_suffix(f".{os.getpid()}.part")
    partial.write_bytes(pickle.dumps(result))
    partial.replace(cache)
    return result


@lru_cache(maxsize=16)
def _overlap_cached(path):
    """Overlap matrix of a formatted checkpoint's basis, or None when its shells are not supported."""

    def compute():
        try:
            return overlap_matrix(_records(path))
        except (KeyError, ValueError, ImportError):
            return None

    return _fchk_pickled(path, "overlap", compute)


@lru_cache(maxsize=16)
def _symmetry_cached(path, spin="alpha"):
    """Symmetry of the canonical orbitals of one spin channel of a formatted checkpoint, or None when they cannot be
    classified.
    """

    def compute():
        try:
            return orbital_symmetry(_records(path), spin=spin)
        except (KeyError, ValueError, np.linalg.LinAlgError):
            return None

    return _fchk_pickled(path, f"symmetry-{spin}", compute)


def _same_name(latex, code):
    """Whether a LaTeX Schoenflies name and Gaussian's point-group code name the same group."""
    plain = lambda text: re.sub(r"[${}_\\]", "", text).lower().replace("infty", "*")
    return plain(latex) == plain(_point_group(code))


def _transfer(origin, axes, hole, particle):
    r"""Charge-transfer descriptors of hole and particle densities on a grid: the transferred charge :math:`q_{\mathrm{CT}}`, the
    distance :math:`d_{\mathrm{CT}}` between the centroids of the density gained and lost (Le Bahers, Adamo and Ciofini, J. Chem. Theory
    Comput. 7, 2498 (2011)), both in e and angstrom, the hole-particle centroid distance :math:`D` in angstrom and their
    overlap, :math:`\int\sqrt{\rho_{\mathrm{h}}\rho_{\mathrm{p}}}\,\mathrm{d}\mathbf{r}`.
    """
    hole, particle = hole.astype(float), particle.astype(float)
    step = np.diag(axes)
    coordinates = [origin[k] + step[k] * np.arange(hole.shape[k]) for k in range(3)]
    volume = np.prod(step)

    def centroid(density):
        """Centroid of a non-negative density on the grid, in bohr."""
        return (
            np.array([coordinates[k] @ density.sum(axis=tuple(j for j in range(3) if j != k)) for k in range(3)])
            / density.sum()
        )

    difference = particle - hole
    gain, loss = np.clip(difference, 0, None), np.clip(-difference, 0, None)
    bohr = (1 * ureg.bohr).to("angstrom").magnitude
    return dict(
        transferred=gain.sum() * volume,
        transfer_distance=np.linalg.norm(centroid(gain) - centroid(loss)) * bohr,
        separation=np.linalg.norm(centroid(particle) - centroid(hole)) * bohr,
        overlap=np.sqrt(hole * particle).sum() * volume,
    )


def _state_densities(path, groups, spacing, bounds=None):
    """Hole and particle densities of groups of degenerate excited states from their printed amplitudes, on one
    grid, cached on disk by the checkpoint's content, the amplitudes and the grid.

    ``groups`` holds, per group, each state's (occupied, virtual, amplitude) excitations with one-based orbital
    indices. A group's hole matrix is the mean over its states of X X^T and its particle matrix that of X^T X, each
    scaled to unit trace, so each density holds one electron; their eigenvectors combine the canonical orbitals into
    natural transition orbitals, so the densities keep every cross term. Degenerate states are averaged, as their
    level is. Gaussian prints only amplitudes above 0.1, so the densities are those of the printed part.
    """
    key = hashlib.sha256(
        Path(path).read_bytes()
        + repr((groups, spacing, None if bounds is None else np.round(np.asarray(bounds), 6).tolist())).encode()
    ).hexdigest()[:16]
    cache = cache_folder("fchk") / f"{Path(path).stem}-states-{key}.npz"
    if cache.exists():
        with np.load(cache) as stored:
            return stored["origin"], stored["axes"], stored["atoms"], stored["holes"], stored["particles"]
    records = _records(path)
    basis = int(records["Number of basis functions"])
    coefficients = np.asarray(records["Alpha MO coefficients"], dtype=float).reshape(-1, basis)
    rows, weights = [], []
    for group in groups:
        occupied = sorted({i - 1 for state in group for i, _, _ in state})
        virtual = sorted({a - 1 for state in group for _, a, _ in state})
        hole, particle = np.zeros((len(occupied),) * 2), np.zeros((len(virtual),) * 2)
        for state in group:
            x = np.zeros((len(occupied), len(virtual)))
            for i, a, amplitude in state:
                x[occupied.index(i - 1), virtual.index(a - 1)] += amplitude
            hole += x @ x.T
            particle += x.T @ x
        for matrix, indices in ((hole, occupied), (particle, virtual)):
            values, vectors = np.linalg.eigh(matrix / np.trace(matrix))
            start = len(rows)
            rows += list(vectors.T @ coefficients[indices])
            weights.append((start, np.clip(values, 0, None)))
    combined = dict(records)
    combined["Alpha MO coefficients"] = np.concatenate(rows)
    table = np.zeros((len(weights), len(rows)))
    for row, (start, values) in enumerate(weights):
        table[row, start : start + len(values)] = values
    origin, axes, atoms, densities = density_grid(
        combined, list(range(len(rows))), table, spacing=spacing, bounds=bounds
    )
    densities = np.asarray(densities, dtype=np.float32)
    holes, particles = densities[0::2], densities[1::2]
    cache_folder("fchk").mkdir(parents=True, exist_ok=True)
    # Uncompressed: smooth single-precision fields hardly compress, and reading them back stays a copy.
    np.savez(cache, origin=origin, axes=axes, atoms=atoms, holes=holes, particles=particles)
    return origin, axes, atoms, holes, particles


def _orbital_entries(sets, names=None):
    """Snapshot titles and orbitals of the sets: each title has the set's name from ``names`` when given, such as
    HOMO or LUMO_1, the label, the Cartesian function a degenerate component transforms like, as in 1e_{1g}(xz), the
    character and the energy; each orbital is a zero-based index, or for symmetry-adapted components the canonical
    indices and the weights that combine them.
    """
    entries = []
    for orbital_set in sets:
        count = len(orbital_set.indices)
        name = [names[id(orbital_set)]] if names else []
        for k, index in enumerate(orbital_set.indices):
            if orbital_set.components:
                parts = name + [f"${orbital_set.label()}({orbital_set.components[k]})$"]
                index = (tuple(orbital_set.indices), tuple(round(float(w), 12) for w in orbital_set.rotation[:, k]))
            else:
                parts = (
                    name
                    + [f"${orbital_set.label()}$"]
                    + ([f"orbital {orbital_set.indices[k] + 1}"] if count > 1 else [])
                )
            if orbital_set.character_label():
                parts.append(f"${orbital_set.character_label()}$")
            parts.append(rf"$\epsilon={{{_to_ev(orbital_set.energy):.3f}}}\,{unit_latex('eV')}$")
            entries.append((", ".join(parts), index))
    return entries


def _orbital_cached(path, index, spacing, isovalue, part=None, spin="alpha"):
    r"""An orbital of a formatted checkpoint on a fine grid over the box where its amplitude reaches an eighth of the
    isovalue, cached on disk by the checkpoint's content and the grid settings. ``index`` is a zero-based orbital,
    or canonical indices and weights whose combination is the orbital, as for symmetry-adapted components.

    ``part``, ``("atom", A)`` or ``("momentum", l)``, keeps only the terms of the orbital's own expansion on the
    functions of atom :math:`A`, :math:`\psi^{(A)}=\sum_{\mu\in A}c_\mu\phi_\mu`, or of angular momentum :math:`l`, on its own box, or on
    the whole orbital's box when it never reaches an eighth of the isovalue; the parts of each kind add up to the
    orbital. ``spin`` chooses the alpha or beta orbitals of an unrestricted
    wavefunction.
    """
    digest = _fchk_digest(path)
    name = (
        index if isinstance(index, (int, np.integer)) else "mix" + hashlib.sha256(repr(index).encode()).hexdigest()[:12]
    )
    piece = ("" if part is None else f"-{part[0]}{part[1]}-own") + ("" if spin == "alpha" else f"-{spin}")
    cache = cache_folder("fchk") / f"{Path(path).stem}-{digest}-orbital{name}{piece}-{spacing}-{isovalue}-eighth.npz"
    if cache.exists():
        stored = np.load(cache)
        # The same single-precision values a fresh evaluation returns, so a page never depends on the cache.
        return stored["origin"], stored["axes"], stored["atoms"], stored["values"].astype(np.float32)
    records = _records(path)
    basis = int(records["Number of basis functions"])
    coefficients = np.asarray(spin_record(records, spin, "{Spin} MO coefficients"), dtype=float).reshape(-1, basis)
    vector = (
        coefficients[index]
        if isinstance(index, (int, np.integer))
        else np.asarray(index[1]) @ coefficients[list(index[0])]
    )
    if part is not None:
        atoms, momenta = basis_function_owners(records)
        vector = np.where((atoms if part[0] == "atom" else momenta) == part[1], vector, 0.0)
    target = dict(records, **{"Alpha MO coefficients": vector[None, :]})
    # The box where this field reaches an eighth of the isovalue, found on a coarse grid with a margin. A part can
    # reach beyond the whole orbital's box, so it takes its own.
    coarse = 0.4
    origin, _, _, values = orbital_grid(target, 0, spacing=coarse)
    inside = np.argwhere(np.abs(values) >= isovalue / 8)
    if len(inside):
        lower, upper = origin + (inside.min(axis=0) - 3) * coarse, origin + (inside.max(axis=0) + 3) * coarse
    else:
        origin, axes, _, values = _orbital_cached(path, index, spacing, isovalue, spin=spin)
        lower, upper = origin, origin + (np.asarray(values.shape) - 1) * np.diag(axes)
    # The coarse grid can miss a thin lobe, so the fine box grows past every face the field still reaches.
    while True:
        origin, axes, atoms, values = orbital_grid(target, 0, spacing=spacing, bounds=(lower, upper))
        reached = np.abs(values) >= isovalue / 8
        low = [reached.take(0, axis=k).any() for k in range(3)]
        high = [reached.take(-1, axis=k).any() for k in range(3)]
        if not any(low) and not any(high):
            break
        lower = lower - 3 * coarse * np.asarray(low)
        upper = upper + 3 * coarse * np.asarray(high)
    cache_folder("fchk").mkdir(parents=True, exist_ok=True)
    # Half precision, about 0.05 % of a value, is finer than the 0.1 % the page writes the field in, and halves the
    # cache; uncompressed, as such a field hardly compresses, so reading it back is a copy. The orbital is returned as
    # stored, in single precision for the arithmetic, so a fresh and a cached render encode the same field.
    values = values.astype(np.float16)
    np.savez(cache, origin=origin, axes=axes, atoms=atoms, values=values)
    return origin, axes, atoms, values.astype(np.float32)


def _transition_cached(path, spacing, bounds=None):
    r"""Hole and particle densities of the natural transition orbitals of a formatted checkpoint, on one grid around
    the molecule, cached on disk by the checkpoint's content and the grid spacing.

    Gaussian stores hole k as the k-th occupied orbital below the last and particle k as the k-th unoccupied one, each with the pair's
    weight :math:`\lambda_k` as its orbital energy. Every pair adds :math:`\lambda_k/\sum_j\lambda_j` times its squared hole and particle
    to the two densities, so each holds one electron and the decomposition is complete. ``bounds``, the lower and upper
    corners in bohr, replaces the default box around the molecule. Returns the grid origin, step vectors and atom rows
    in bohr, the two densities in :math:`a_0^{-3}`, the number of pairs and the sum of their weights.
    """
    digest = _fchk_digest(path)
    box = "" if bounds is None else "-" + hashlib.sha256(np.round(np.asarray(bounds), 6).tobytes()).hexdigest()[:8]
    cache = cache_folder("fchk") / f"{Path(path).stem}-{digest}-transition-{spacing}{box}.npz"
    if cache.exists():
        with np.load(cache) as stored:
            return (
                stored["origin"],
                stored["axes"],
                stored["atoms"],
                stored["hole"],
                stored["particle"],
                int(stored["pairs"]),
                float(stored["total"]),
            )
    records = _records(path)
    occupied = int(records["Number of alpha electrons"])
    weights = np.asarray(records["Alpha Orbital Energies"], dtype=float)[:occupied][::-1]
    shares = weights / weights.sum()
    # One pass over the grid for both densities: holes first, then particles, each density weighting its own half.
    orbitals = [occupied - 1 - k for k in range(occupied)] + [occupied + k for k in range(occupied)]
    zeros = np.zeros(occupied)
    origin, axes, atoms, (hole, particle) = density_grid(
        records,
        orbitals,
        [np.concatenate([shares, zeros]), np.concatenate([zeros, shares])],
        spacing=spacing,
        bounds=bounds,
    )
    cache_folder("fchk").mkdir(parents=True, exist_ok=True)
    hole, particle = hole.astype(np.float32), particle.astype(np.float32)
    # Uncompressed: smooth single-precision fields hardly compress, and reading them back stays a copy.
    np.savez(
        cache, origin=origin, axes=axes, atoms=atoms, hole=hole, particle=particle, pairs=occupied, total=weights.sum()
    )
    return origin, axes, atoms, hole, particle, occupied, float(weights.sum())

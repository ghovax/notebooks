"""What the cells of one generated page share: its calculation and the status icons its tables draw."""

import IPython.display
import pandas as pd

from calcpages.i18n import message
from calcpages.labels import LABELS
from calcpages.notebook import scientific_table


class Page:
    """The calculation a page shows and the icons that stand for booleans and run states in its tables.

    Args:
        calculation: The page's :class:`calcpages.calculation.Calculation`.
        icons: Folder of the status icons, as the page links them, ending in a slash.
    """

    def __init__(self, calculation, icons):
        """Bind the page's calculation and the Markdown of its status icons."""
        self.calculation = calculation
        # Folder of the status icons, as the page links them.
        self.icons = icons
        mark = lambda word, name: f"![{word}]({icons}{name}.svg){{.workflow-status}}"
        # Booleans and finding kinds as icons.
        self.marks = {
            True: mark(message("mark-yes"), "check"),
            False: mark(message("mark-no"), "cross"),
            "Info": mark(message("finding-kind-info"), "hourglass"),
            "Warning": mark(message("finding-kind-warning"), "warning"),
            "Error": mark(message("finding-kind-error"), "cross"),
        }
        # Run states as icons.
        self.states = {
            "Complete": mark(message("state-complete"), "check"),
            "Failed": mark(message("state-failed"), "cross"),
            "Running": mark(message("state-running"), "hourglass"),
            "Pending": mark(message("state-pending"), "hourglass"),
            "Unfinished": mark(message("state-unfinished"), "hourglass"),
            "Missing": mark(message("state-missing"), "hourglass"),
        }

    def labels(self, data):
        """Codename columns under their labels and booleans as status icons, in subtables too.

        Args:
            data: Table whose columns are codenames of ``LABELS``.

        Returns:
            The table ready to show.
        """
        data = data.map(
            lambda value: (
                self.marks[value]
                if isinstance(value, bool)
                else self.labels(value)
                if isinstance(value, pd.DataFrame)
                else value
            )
        )
        return data.rename(columns=LABELS)

    def table(self, data, precision=5):
        """Show a table of codename columns under their labels, with booleans as status icons.

        Args:
            data: Table whose columns are codenames of ``LABELS``.
            precision: Significant digits of its numbers.
        """
        # Looked up when called, so a front end that replaces IPython's display, as the viewer page does, receives it.
        IPython.display.display(IPython.display.Markdown(scientific_table(self.labels(data), precision=precision)))

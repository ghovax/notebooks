"""Numbers, units, formulas, symmetry labels and times as the pages write them."""

import re
from datetime import timedelta

import numpy as np
import pandas as pd
from babel.dates import format_datetime
from runflow.results import ureg

from calcpages.i18n import date_locale, message, zone
from calcpages.labels import scientific_latex, unit_latex


def _mantissa(value, digits):
    """Mantissa and exponent of a very small or large number, or None for an ordinary one."""
    if value == 0 or 1e-3 <= abs(value) < 1e5:
        return None
    mantissa, exponent = f"{value:.{digits - 1}e}".split("e")
    return mantissa.rstrip("0").rstrip("."), int(exponent)


def _number(value, digits=6):
    """A number as text at the given significant digits; a very small or large one as a mantissa followed by
    a power of ten in LaTeX, as scientific_table writes them.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float, np.integer, np.floating)):
        return str(value)
    if (parts := _mantissa(value, digits)) is None:
        return f"{value:.{digits}g}"
    return scientific_latex(*parts)


def _value(value, unit=None, digits=6):
    """A value with its unit; a list becomes a parenthesized vector; text stays text. Only what needs math is LaTeX."""
    if isinstance(value, str):
        return value
    if unit == "hartree":
        value, unit = _to_ev(np.asarray(value) if isinstance(value, (list, tuple)) else value), "eV"
    if unit == "hartree/bohr":
        value, unit = (value * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude, "eV/angstrom"
    text = (
        "$(" + ", ".join(_number(item, digits).replace("$", "") for item in value) + ")$"
        if isinstance(value, (list, tuple, np.ndarray))
        else _number(value, digits)
    )
    return "$" + text.replace("$", "") + r"\," + unit_latex(unit) + "$" if unit else text


def _tensor(values, order, unit, digits=6):
    """A symmetric 3 x 3 tensor as a LaTeX matrix with its unit, from components in the given order.

    ``order`` names each value's component, such as "xy"; the matrix fills both triangles.
    """

    def latex(value):
        parts = _mantissa(value, digits)
        return f"{value:.{digits}g}" if parts is None else scientific_latex(*parts).strip("$")

    components = {}
    for name, value in zip(order, values):
        components[name] = components[name[::-1]] = value
    rows = [" & ".join(latex(components[a + b]) for b in "xyz") for a in "xyz"]
    return rf"$\begin{{pmatrix}}{r' \\ '.join(rows)}\end{{pmatrix}}\,{unit_latex(unit)}$"


def _formula(text):
    """A stoichiometry such as C16H14B2F2O5 or N1 as upright LaTeX, without counts of one, its elements in the Hill
    system through molmass; any suffix Gaussian adds, such as a charge in parentheses, is kept as written.
    """
    from molmass import Formula

    core, suffix = re.fullmatch(r"((?:[A-Z][a-z]?\d*)+)(.*)", text).groups() if re.match(r"[A-Z]", text) else ("", text)
    if core:
        core = Formula(core).formula
    return (
        r"$\mathrm{"
        + re.sub(r"([A-Z][a-z]?)(\d+)", lambda m: m[1] + (f"_{{{m[2]}}}" if m[2] != "1" else ""), core)
        + suffix
        + "}$"
    )


def _point_group(code):
    """A Gaussian point-group label such as C1, C02V, D03H, CS or D*H in Schoenflies notation, as LaTeX."""
    special = {
        "CS": "C_s",
        "CI": "C_i",
        "T": "T",
        "TD": "T_d",
        "TH": "T_h",
        "O": "O",
        "OH": "O_h",
        "I": "I",
        "IH": "I_h",
    }
    if code.upper() in special:
        return f"${special[code.upper()]}$"
    match = re.fullmatch(r"([CDS])(\*|\d+)([A-Z]*)", code.upper())
    if not match:
        return code
    order = r"{\infty}" if match[2] == "*" else str(int(match[2]))
    return f"${match[1]}_{{{order}{match[3].lower()}}}$"


def _symmetry_element(code):
    """Where a framework-group atom set sits: X general positions, O the centre, Cn axes and SG mirror planes,
    with a leading count of equivalent elements.
    """
    count, element = re.fullmatch(r"(\d*)(.+)", code).groups()
    many = count not in ("", "1")
    planes = {"SG": r"$\sigma$", "SGH": r"$\sigma_h$", "SGV": r"$\sigma_v$", "SGD": r"$\sigma_d$"}
    if element == "X":
        return message("symmetry-general-positions")
    if element == "O":
        return message("symmetry-centre")
    if element in planes:
        return message("symmetry-planes" if many else "symmetry-plane", number=count, plane=planes[element])
    if axis := re.fullmatch(r"C(\d+|\*)", element):
        order = r"\infty" if axis[1] == "*" else axis[1]
        return message("symmetry-axes" if many else "symmetry-axis", number=count, order=order)
    return message("symmetry-element", element=element)


def _framework(text):
    """Gaussian's framework group, such as [O(N1),3C2(H1)]: each atom set and the symmetry element it sits on."""
    parts = [
        message("symmetry-atoms", formula=_formula(atoms), place=_symmetry_element(element))
        for element, atoms in re.findall(r"([0-9A-Z*]+)\(([A-Za-z0-9]+)\)", text)
    ]
    return "; ".join(parts) if parts else text


def _moment(time):
    """Display a recorded instant in the shown zone, retaining seconds.

    Args:
        time: Recorded datetime, including its source timezone.

    Returns:
        Abbreviated local date and clock time labelled with the zone's abbreviation, such as zone().
    """
    return f"{format_datetime(time, message('date-time-pattern'), tzinfo=zone(), locale=date_locale())} {time.astimezone(zone()).tzname()}"


def _period(start, end):
    """Display the span between two recorded instants in the shown zone, retaining seconds.

    Args:
        start: Recorded datetime the span begins at, including its source timezone.
        end: Recorded datetime the span ends at, including its source timezone; the render time while it continues.

    Returns:
        The start and the end clock time, its date repeated only when it differs.
    """
    same_day = start.astimezone(zone()).date() == end.astimezone(zone()).date()
    finish = format_datetime(
        end, message("time-pattern") if same_day else message("date-time-pattern"), tzinfo=zone(), locale=date_locale()
    )
    return (
        f"{format_datetime(start, message('date-time-pattern'), tzinfo=zone(), locale=date_locale())} – {finish} "
        f"{end.astimezone(zone()).tzname()}"
    )


def _duration(seconds):
    """Format elapsed time with the standard library's compact duration notation.

    Args:
        seconds: Nonnegative elapsed time in seconds.

    Returns:
        Hours, minutes and seconds, prefixed by days when needed.
    """
    if seconds < 0:
        raise ValueError("Elapsed time must be nonnegative.")
    return str(timedelta(seconds=round(seconds)))


def _changes(values):
    """Values kept only where they differ from the previous one, so a column shows changes rather than repeats."""
    return [value if index == 0 or value != values[index - 1] else None for index, value in enumerate(values)]


def _title_math(title):
    """A Gaussian job title with its singlet and triplet states typeset: S0 becomes $S_{0}$ and "S0 to Sn" an arrow
    between states. Titles stay plain text in the input, where a backslash would break Gaussian's archive entry.
    """
    state = r"\b([ST])(\d+|n)\b"
    title = re.sub(state + r"\s+to\s+" + state, lambda m: f"${m[1]}_{{{m[2]}}}\\rightarrow {m[3]}_{{{m[4]}}}$", title)
    # States outside the math already written.
    parts = re.split(r"(\$[^$]*\$)", title)
    return "".join(
        part if part.startswith("$") else re.sub(state, lambda m: f"${m[1]}_{{{m[2]}}}$", part) for part in parts
    )


def quantities_table(rows):
    """Table of quantity, value and description rows; the Description column only when some row has one."""
    table = pd.DataFrame(
        [row if len(row) == 3 else (*row, "") for row in rows], columns=["quantity", "value", "description"]
    )
    return table if table.description.astype(bool).any() else table.drop(columns="description")


def _irrep(label):
    """A Gaussian irreducible-representation label, such as A, B1U, A' or SGG, in Mulliken notation as LaTeX."""
    match = re.fullmatch(r"(SG|PI|DLT|PHI|[ABET])(\d*)([GU]?)('*|\"?)", label.strip().upper().replace("?", ""))
    if not match:
        return label
    letter = {"SG": r"\Sigma", "PI": r"\Pi", "DLT": r"\Delta", "PHI": r"\Phi"}.get(match[1], match[1])
    subscript = match[2] + match[3].lower()
    primes = "''" if match[4] == '"' else match[4]
    return f"${letter}" + (f"_{{{subscript}}}" if subscript else "") + primes + "$"


def _lower_label(label):
    """Lower-case Mulliken label of a one-particle function, such as :math:`e_{1u}` for :math:`E_{1u}`."""
    for upper, lower in ((r"\Sigma", r"\sigma"), (r"\Pi", r"\pi"), (r"\Delta", r"\delta")):
        if label.startswith(upper):
            return lower + label[len(upper) :]
    return label[0].lower() + label[1:]


# Mulliken's letters of representations by dimension (t also written f), then the Greek names of linear molecules by
# angular momentum about the axis.
_IRREP_ORDER = ["a", "b", "e", "t", "f", "g", "h", "sigma", "pi", "delta", "phi", "gamma"]


def _irrep_order(label):
    """Sort key of a representation's label in LaTeX: Mulliken's order of letters, A, B, E, T, G, H, then the linear
    molecules' Sigma, Pi, Delta, ... in either case, then the label, so a' precedes a'' and a_{1} precedes b_{1};
    unknown or empty labels come last.
    """
    name = re.match(r"\\?([A-Za-z]+)", label or "")
    word = name[1].lower() if name else ""
    greek = word if label.startswith("\\") else word[:1]
    return (_IRREP_ORDER.index(greek) if greek in _IRREP_ORDER else len(_IRREP_ORDER), label)


def _to_ev(value):
    """Energy in hartree converted to eV."""
    return (value * ureg.hartree).to("eV").magnitude


def _to_kj(value):
    """A thermal contribution printed in kilocalories per mole, converted to kilojoules per mole."""
    return (value * ureg.kilocalorie / ureg.mole).to("kilojoule/mole").magnitude

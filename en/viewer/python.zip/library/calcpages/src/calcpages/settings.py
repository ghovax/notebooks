"""Defaults of the calculation pages that a reader may change, from ``data/settings.yaml`` and ``$CALCPAGES_SETTINGS``."""

import os
from functools import cache
from importlib.resources import files
from pathlib import Path

import yaml


def _merged(base, own):
    """``base`` with ``own`` laid over it, mappings merged key by key and any other value replaced.

    Args:
        base: The defaults.
        own: The values that replace them.

    Returns:
        The merged settings.
    """
    if not isinstance(base, dict) or not isinstance(own, dict):
        return own
    return {**base, **{key: _merged(base.get(key), value) for key, value in own.items()}}


@cache
def settings():
    """The page settings: the packaged defaults, with the file named by ``$CALCPAGES_SETTINGS`` laid over them.

    Returns:
        The settings as a mapping.
    """
    defaults = yaml.safe_load(files(__package__).joinpath("data", "settings.yaml").read_text())
    own = os.environ.get("CALCPAGES_SETTINGS")
    return _merged(defaults, yaml.safe_load(Path(own).read_text()) or {}) if own else defaults

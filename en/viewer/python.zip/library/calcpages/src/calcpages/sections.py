"""Sections of a calculation page, shared by researchsite.pages and the in-browser viewer.

Each function returns Quarto Markdown with Python cells; the cells call the ``_calculation`` methods of
calcpages.calculation, so a page shows only what runflow parsed. The calculation pages render these with Quarto, and
the viewer page renders them in the browser through calcpages.browser.
"""

import json
import re
from pathlib import PurePath

import sourcetypes
from runflow.checkpoints import read_fchk_records, read_gaussian_checkpoint

from calcpages.appearance import DENSITY_SHARE, ORBITAL_SHARE, POTENTIAL_SHARE
from calcpages.callouts import findings_callout, findings_table
from calcpages.i18n import message
from calcpages.labels import unit_latex


def cell(code, label=None, caption=None):
    """Python cell of a generated page; with a ``label`` such as ``fig-scf-1`` or ``tbl-route-1``, unique on the page,
    its output is a numbered figure or table with the Markdown ``caption``, below a figure and above a table.
    """
    options = (
        f"#| label: {label}\n#| {label.split('-')[0]}-cap: {json.dumps(caption, ensure_ascii=False)}\n" if label else ""
    )
    text: sourcetypes.markdown = f"""```{{python}}
{options}{code}
```

"""
    return text


def show(expression, label, caption, precision=None):
    """Captioned cell that renders a table of codename columns with their labels."""
    return cell(f"_page.table({expression}" + (f", precision={precision})" if precision else ")"), label, caption)


def chart(expression, label, caption, zoom=()):
    """Captioned cell that displays one Altair chart, with pan and zoom along the ``zoom`` axes where they make
    sense.
    """
    return cell(f"display_chart({expression}" + (f", zoom_axes={tuple(zoom)!r})" if zoom else ")"), label, caption)


def viewer(expression, label, caption):
    """Captioned cell that displays one molecular viewer."""
    return cell(f"display({expression})", label, caption)


def fold(heading, content):
    """Collapsible section: the heading stays in the table of contents."""
    text: sourcetypes.markdown = f"""::: {{.fold}}
{heading}

{content}:::

"""
    return text


def _shares():
    """The viewers' default levels as the page text states them, in percent.

    Returns:
        ``orbital_share``, ``density_share`` and ``potential_share``, from the ``viewers`` settings.
    """
    shares = {"orbital": ORBITAL_SHARE, "density": DENSITY_SHARE, "potential": POTENTIAL_SHARE}
    return {f"{name}_share": f"{share * 100:g}" for name, share in shares.items()}


def gaussian_input(calculation, number, level):
    """Input of one linked Gaussian job: Link 0 commands, route keywords and the molecule specification."""
    job = calculation.jobs[number - 1]
    parts = []
    links = job["links"]
    if links[0]["commands"]:
        text: sourcetypes.markdown = message("section-link0-commands", level=level)
        parts.append(
            text
            + show(f"_calculation.links_table({number}, 0)", f"tbl-link0-{number}", message("caption-link0-commands"))
        )
    text: sourcetypes.markdown = message("section-route-keywords", level=level)
    parts.append(
        text + show(f"_calculation.route_table({number})", f"tbl-route-{number}", message("caption-route-keywords"))
    )
    if calculation.gic_table(number) is not None:
        intro = (
            message("note-read-all-gic") if calculation.gic_mode(number) == "read-all" else message("note-gic-added")
        )
        text: sourcetypes.markdown = message("section-generalized-internal-coordinates", level=level, intro=intro)
        parts.append(
            text
            + show(
                f"_calculation.gic_table({number}, _page.icons)",
                f"tbl-gic-{number}",
                message("caption-generalized-internal-coordinates"),
            )
        )
    if calculation.modredundant_table(number) is not None:
        text: sourcetypes.markdown = message("section-redundant-coordinate-changes", level=level)
        parts.append(
            text
            + show(
                f"_calculation.modredundant_table({number}, _page.icons)",
                f"tbl-modredundant-{number}",
                message("caption-redundant-coordinate-changes"),
            )
        )
    if calculation.read_optimize_table(number) is not None:
        text: sourcetypes.markdown = message("section-optimized-atoms", level=level)
        parts.append(
            text
            + show(
                f"_calculation.read_optimize_table({number})",
                f"tbl-read-optimize-{number}",
                message("caption-optimized-atoms"),
            )
        )
    if calculation.connectivity_table(number) is not None:
        text: sourcetypes.markdown = message("note-connectivity")
        parts.append(
            fold(
                message("heading-connectivity", level=level),
                text
                + show(
                    f"_calculation.connectivity_table({number})",
                    f"tbl-connectivity-{number}",
                    message("caption-connectivity"),
                ),
            )
        )
    if calculation.iop_table(number) is not None:
        text: sourcetypes.markdown = message("section-internal-options", level=level)
        parts.append(
            text + show(f"_calculation.iop_table({number})", f"tbl-iop-{number}", message("caption-internal-options"))
        )
    text: sourcetypes.markdown = message("section-molecule-specification", level=level)
    parts.append(
        text
        + show(
            f"_calculation.molecule_table({number})",
            f"tbl-molecule-{number}",
            message("caption-molecule-specification"),
        )
    )
    return "".join(parts)


def _repeats(calculation, number, methods):
    """Whether every named table or chart of a linked job equals the previous job's, as when a later step reuses the
    same ground state. Charts are compared without Altair's numbered parameter and view names.
    """
    if number == 1:
        return False
    for name in methods:
        try:
            before, after = (getattr(calculation, name)(index) for index in (number - 1, number))
        except Exception:
            # A table that cannot be built for either job is no repeat: the page builds it and reports it there.
            return False
        if hasattr(before, "equals"):
            if not before.equals(after):
                return False
        elif re.sub(r"(param|view)_\d+", "", before.to_json()) != re.sub(r"(param|view)_\d+", "", after.to_json()):
            return False
    return True


def missing_file(part, needs):
    """A mark the viewer finds to list a part left out and the file it needs; pages show nothing of it.

    Args:
        part: The part left out, in words.
        needs: The file it needs, in words.

    Returns:
        An HTML comment naming both.
    """
    return f"<!-- missing: {part} | {needs} -->"


def missing_checkpoint(calculation, number, orbitals):
    """Callout in place of orbitals that cannot be drawn: the formatted checkpoint of the job's %chk is not available,
    or its basis has shells the grid evaluation does not support.
    """
    commands = calculation.jobs[number - 1]["links"][0]["commands"]
    value = next((value for key, value in commands.items() if key.lower() == "%chk"), None)
    source = (
        message("source-job-checkpoint", file=PurePath(value).with_suffix(".fchk").name)
        if value
        else message("source-no-job-checkpoint")
    )
    reason = (
        message("reason-cartesian-shells") if calculation._job_checkpoint(number) else message("reason-not-available")
    )
    text: sourcetypes.markdown = message("callout-orbitals-not-shown", orbitals=orbitals, source=source, reason=reason)
    return text + ("" if calculation._job_checkpoint(number) else missing_file(orbitals, source))


def symmetry_notice(calculation, number):
    """Explain why the excited states' transitions use orbital indices instead of symmetry labels."""
    if calculation.symmetry(number) is not None:
        return ""
    if calculation._job_checkpoint(number):
        detail = message("note-symmetry-unestablished")
    else:
        commands = calculation.jobs[number - 1]["links"][0]["commands"]
        value = next((value for key, value in commands.items() if key.lower() == "%chk"), None)
        source = (
            message("source-matching-checkpoint", file=PurePath(value).with_suffix(".fchk").name)
            if value
            else message("source-any-matching-checkpoint")
        )
        detail = message("note-symmetry-needs-checkpoint", source=source) + missing_file(
            message("missing-symmetry-labels"), source
        )
    text: sourcetypes.markdown = message("callout-symmetry-not-determined", detail=detail)
    return text


def system_section(calculation, number, level="##"):
    """The system, its level of theory and its solvent, before the parsed input and output."""
    text: sourcetypes.markdown = message("section-system", level=level)
    relations: sourcetypes.markdown = message("note-electron-counts")
    return (
        text
        + relations
        + show(f"_calculation.system_table({number})", f"tbl-system-{number}", message("caption-system"))
    )


def gaussian_output(calculation, number, level):
    """Output of one linked Gaussian job, each section present only when the job printed its data: the electronic solution,
    then how the geometry moved, then the vibrations and thermochemistry at the result, then ground-state properties and
    last excited states. A section whose data repeat the previous linked job's keeps its heading with a note pointing
    back instead.
    """
    job = calculation.jobs[number - 1]

    def repeated(*methods):
        """Whether the section's data repeat the previous job's; such a section is left out."""
        return _repeats(calculation, number, methods)

    parts = []
    if job["scf_history"]:
        count = len(job["scf_history"])
        if count > 1:
            reading = message("note-scf-cycles-chart")
            caption = message("caption-scf-cycles")
        elif sum(1 for row in job["scf_history"][0]["cycle_history"] if row["density_rms"]) > 1:
            reading = message("note-scf-density-chart")
            caption = message("caption-scf-density")
        else:
            reading = ""
        text: sourcetypes.markdown = message("section-scf-convergence", level=level, count=count, reading=reading)
        parts.append(
            text + (chart(f"_calculation.scf_chart({number})", f"fig-scf-{number}", caption, "x") if reading else "")
        )
    if job["stability"] and not repeated("stability_table"):
        text: sourcetypes.markdown = message("section-wavefunction-stability", level=level)
        parts.append(
            text
            + show(
                f"_calculation.stability_table({number})",
                f"tbl-stability-{number}",
                message("caption-wavefunction-stability"),
            )
        )
    if job["optimization_history"] and job["evaluations"]:
        steps = len(job["optimization_history"])
        text: sourcetypes.markdown = message("section-geometry-optimization", level=level, steps=steps)
        parts.append(
            text
            + cell(f"_energy, _forces, _displacements = _calculation.optimization_charts({number})")
            + chart("_energy", f"fig-optimization-energy-{number}", message("caption-optimization-energy"), ("x", "y"))
            + chart("_forces", f"fig-optimization-forces-{number}", message("caption-optimization-forces"), ("x", "y"))
            + chart(
                "_displacements",
                f"fig-optimization-displacements-{number}",
                message("caption-optimization-displacements"),
                ("x", "y"),
            )
        )
    if not job["optimization_history"] and any(
        evaluation.get("force_maximum") is not None or evaluation.get("force_rms") is not None
        for evaluation in job["evaluations"]
    ):
        text: sourcetypes.markdown = message("section-forces", level=level)
        parts.append(
            text
            + chart(
                f"_calculation.evaluation_forces_chart({number})",
                f"fig-forces-{number}",
                message("caption-forces"),
                ("x", "y"),
            )
        )
    if len(job["geometries"]) > 1:
        text: sourcetypes.markdown = message("section-geometries", level=level)
        parts.append(
            text
            + viewer(
                f"MolstarViewer(_calculation.trajectory({number}))",
                f"fig-geometries-{number}",
                message("caption-geometries"),
            )
        )
    if job["irc_points"] and not repeated("irc_chart", "irc_table"):
        points = len(job["irc_points"])
        text: sourcetypes.markdown = message("section-reaction-path", level=level, points=points)
        parts.append(
            text
            + chart(f"_calculation.irc_chart({number})", f"fig-irc-{number}", message("caption-reaction-path"), "x")
        )
    if job["frequency_sets"] and not repeated("ir_chart", "modes_table"):
        imaginary = sum(mode["frequency"] < 0 for mode in job["frequency_sets"][-1])
        note: sourcetypes.markdown = message(
            "section-vibrational-frequencies", level=level, modes=len(job["frequency_sets"][-1]), imaginary=imaginary
        )
        harmonic: sourcetypes.markdown = message("note-wavenumber")
        rule = calculation.infrared_rule(number)
        note += harmonic + (
            f"""{rule}

"""
            if rule
            else ""
        )
        text: sourcetypes.markdown = message("section-normal-mode-animations", level=level)
        modes = job["frequency_sets"][-1]
        parts.append(
            note
            + (
                chart(
                    f"_calculation.ir_chart({number})",
                    f"fig-infrared-{number}",
                    message("caption-infrared-spectrum"),
                    "x",
                )
                if any(mode["frequency"] >= 0 for mode in modes)
                else ""
            )
        )
        label: sourcetypes.markdown = message("section-normal-mode-frequencies", level=level)
        parts.append(
            label
            + chart(
                f"_calculation.mode_frequencies_chart({number})",
                f"fig-mode-frequencies-{number}",
                message("caption-normal-mode-frequencies"),
                "y",
            )
        )
        if job["geometries"] and all(
            len(mode["displacements"]) == len(job["geometries"][-1]["atomic_numbers"])
            and mode["reduced_mass"] is not None
            and mode["force_constant"] is not None
            and mode["ir_intensity"] is not None
            for mode in modes
        ):
            parts.append(
                text
                + viewer(
                    f"MolstarViewer(_calculation.mode_frames({number}))",
                    f"fig-modes-{number}",
                    message("caption-normal-mode-animations"),
                )
            )
    if job["orbital_data"]["orbitals"] and not repeated("frontier_table", "orbitals_chart"):
        note: sourcetypes.markdown = message("section-frontier-orbitals", level=level)
        unrestricted = len(calculation.spins(number)) > 1
        points = [message("note-level-hover"), *calculation.symmetry_points(number)]
        detail = (
            message("note-levels-near-gap-spin" if unrestricted else "note-levels-near-gap")
            + "".join(f"- {point}\n" for point in points)
            + "\n"
        )
        composed = calculation._frontier_composition(number) is not None
        text: sourcetypes.markdown = (
            message("note-orbital-surfaces", unit=unit_latex("bohr ** -1.5"), **_shares())
            + (message("note-orbital-part-dropdown") if composed else "")
            + "\n"
        )
        drawn = (
            text
            + viewer(
                f"_calculation.frontier_viewer({number})",
                f"fig-frontier-orbitals-{number}",
                message("caption-frontier-orbitals"),
            )
            if calculation.drawable(number)
            else missing_checkpoint(calculation, number, message("part-frontier-orbitals"))
        )
        parts.append(
            note
            + show(
                f"_calculation.frontier_table({number})", f"tbl-frontier-{number}", message("caption-frontier-energies")
            )
            + detail
            + chart(
                f"_calculation.orbitals_chart({number})",
                f"fig-levels-{number}",
                message("caption-levels-spin" if unrestricted else "caption-levels"),
                "y",
            )
            + drawn
        )
        if calculation.orbital_composition_chart(number) is not None:
            composition: sourcetypes.markdown = level + message("section-orbital-composition")
            parts.append(
                composition
                + chart(
                    f"_calculation.orbital_composition_chart({number})",
                    f"fig-composition-{number}",
                    message("caption-orbital-composition"),
                )
            )
    if calculation.potential_cube() is not None:
        text: sourcetypes.markdown = message(
            "section-electrostatic-potential",
            level=level,
            density=unit_latex("elementary_charge / bohr ** 3"),
            unit=unit_latex("volt"),
            **_shares(),
        )
        parts.append(
            text
            + viewer("_calculation.potential_viewer()", "fig-potential", message("caption-electrostatic-potential"))
        )
    # Charges and dipole of the ground-state density; transition-density analyses, as in NTO jobs, are not charges.
    populations = calculation.scf_population(number)
    quadrupole = calculation.quadrupole_equation(number)
    shown = [
        name
        for name, present in (
            ("charge_values", populations and populations["mulliken_charges"]),
            ("dipole_table", populations and populations["dipole"]),
        )
        if present
    ]
    if (shown or quadrupole) and (not shown or not repeated(*shown)):
        text: sourcetypes.markdown = message("section-charges-moments", level=level)
        parts.append(text)
        if populations and populations["mulliken_charges"]:
            text: sourcetypes.markdown = message("note-mulliken-charges")
            parts.append(
                text
                + viewer(
                    f"_calculation.charges_viewer({number})",
                    f"fig-charges-{number}",
                    message("caption-mulliken-charges"),
                )
            )
        if populations and populations["dipole"]:
            text: sourcetypes.markdown = message("note-dipole-moment")
            parts.append(text + cell(f"display(Markdown(_calculation.dipole_equation({number})))"))
        if quadrupole:
            text: sourcetypes.markdown = message("note-quadrupole-moment")
            parts.append(text + cell(f"display(Markdown(_calculation.quadrupole_equation({number})))"))
    complete = calculation.static_polarizability(number)
    if complete is not None and not repeated("polarizability_table"):
        text: sourcetypes.markdown = message("section-polarizability", level=level)
        parts.append(text + cell(f"display(Markdown(_calculation.polarizability_equation({number})))"))
    if job["excitations"] and not repeated("configurations_chart"):
        solutions = calculation.td_solutions(number)
        count = len(calculation.final_states(number))
        states_text = (
            message("note-excited-state-count", count=count)
            if solutions == 1
            else message("note-excited-state-count", count=count, solutions=solutions)
        )
        note: sourcetypes.markdown = message("section-excited-states", level=level, states_text=states_text)
        points = "".join(f"- {point}\n" for point in calculation.symmetry_points(number))
        rules = calculation.selection_rules(number)
        text: sourcetypes.markdown = (
            message("note-state-transitions")
            + points
            + """
"""
        )
        parts.append(
            note
            + chart(
                f"_calculation.spectrum_chart({number})",
                f"fig-spectrum-{number}",
                message("caption-excited-state-spectrum"),
                "x",
            )
            + rules
            + symmetry_notice(calculation, number)
            + text
            + chart(
                f"_calculation.configurations_chart({number})",
                f"fig-weights-{number}",
                message("caption-state-transitions"),
            )
        )
        if not job["nto_particles"] and calculation.drawable(number):
            orbitals: sourcetypes.markdown = message(
                "section-transition-orbitals", level=level, percent=unit_latex("percent"), **_shares()
            )
            densities: sourcetypes.markdown = message("section-state-density-change", level=level, **_shares())
            transfer: sourcetypes.markdown = (
                message("note-hole-particle-densities")
                + (message("note-inversion-charge-transfer") if calculation.inversion(number) else "")
                + """
"""
            )
            parts.append(
                orbitals
                + viewer(
                    f"_calculation.transition_orbitals_viewer({number})",
                    f"fig-transition-orbitals-{number}",
                    message("caption-transition-orbitals"),
                )
                + densities
                + viewer(
                    f"_calculation.state_density_viewer({number})",
                    f"fig-density-change-{number}",
                    message("caption-state-density-change"),
                )
                + transfer
                + show(
                    f"_calculation.state_transfer_table({number})",
                    f"tbl-transfer-{number}",
                    message("caption-charge-transfer"),
                )
            )
    if job["nto_particles"]:
        text: sourcetypes.markdown = message("section-natural-transition-orbitals", level=level, **_shares())
        heading: sourcetypes.markdown = message("section-natural-transition-orbitals-heading", level=level)
        if not calculation.drawable(number):
            parts.append(heading + missing_checkpoint(calculation, number, message("part-natural-transition-orbitals")))
        else:
            parts.append(
                text
                + viewer(
                    f"_calculation.nto_viewer({number})",
                    f"fig-nto-{number}",
                    message("caption-natural-transition-orbitals"),
                )
            )
            note: sourcetypes.markdown = message("section-transition-density", level=level, **_shares())
            detail: sourcetypes.markdown = message("note-charge-transfer-descriptors")
            text: sourcetypes.markdown = message("note-atomic-charge-changes")
            parts.append(
                note
                + viewer(
                    f"_calculation.transition_density_viewer({number})",
                    f"fig-transition-density-{number}",
                    message("caption-transition-density"),
                )
                + detail
                + show(
                    f"_calculation.charge_transfer_table({number})",
                    f"tbl-charge-transfer-{number}",
                    message("caption-charge-transfer-descriptors"),
                )
                + text
                + viewer(
                    f"_calculation.transition_charges_viewer({number})",
                    f"fig-charge-changes-{number}",
                    message("caption-atomic-charge-changes"),
                )
            )
    return "".join(parts)


def prelude(arguments, icons):
    """First cell of a page: its imports, the ``_calculation`` read from ``arguments`` (the source text of
    :class:`calcpages.calculation.Calculation`'s arguments) and the ``_page`` whose tables draw booleans with the status
    icons in the folder ``icons``.
    """
    code: sourcetypes.python = f"""from pathlib import Path
import pandas as pd
from IPython.display import Markdown, display
from runflow.results import read_gaussian_checkpoint, xyz_frames
from molstarview import MolstarViewer
from calcpages.calculation import Calculation
from calcpages.labels import LABELS, PLOT_LABELS
from calcpages.page import Page

_calculation = Calculation({arguments})
_page = Page(_calculation, "{icons}")
register_plot_labels(PLOT_LABELS)"""
    return cell(code)


def checkpoint_section(checkpoints, locate, level="##", logged=False):
    """Section of formatted checkpoints, as (role, path) pairs; ``locate`` writes the Python expression of a path.

    One table lists every checkpoint and one viewer animates their geometries in order. Without a log, whose output
    sections already show them, it also draws the last checkpoint's orbital levels, its reaction path and its modes.
    """
    if not checkpoints:
        return ""
    listed = "[" + ", ".join(f"({role!r}, {locate(path)})" for role, path in checkpoints) + "]"
    several = len(checkpoints) > 1
    text: sourcetypes.markdown = message("section-checkpoints", count=len(checkpoints), level=level)
    parts = [
        text
        + cell(f"_checkpoints = {listed}")
        + show("_calculation.checkpoints_table(_checkpoints)", "tbl-checkpoints", message("caption-checkpoints"))
    ]
    if several or not logged:
        text: sourcetypes.markdown = message("section-checkpoint-geometries", count=len(checkpoints), level=level)
        parts.append(
            text
            + viewer(
                "MolstarViewer(_calculation.checkpoint_frames(_checkpoints))",
                "fig-checkpoint-geometries",
                message("caption-checkpoint-geometries", count=len(checkpoints)),
            )
        )
    if logged:
        return "".join(parts)
    last = locate(checkpoints[-1][1])
    checkpoint = read_gaussian_checkpoint(checkpoints[-1][1])
    if _has_orbitals(checkpoints[-1][1]):
        text: sourcetypes.markdown = message("section-checkpoint-orbital-levels", level=level)
        parts.append(
            text
            + cell(
                f"""for _chart in _calculation.checkpoint_orbitals({last}):
    display_chart(_chart, zoom_axes=('y',))""",
                "fig-checkpoint-levels",
                message("caption-checkpoint-orbital-levels"),
            )
        )
    if checkpoint.irc is not None:
        text: sourcetypes.markdown = message(
            "section-checkpoint-reaction-path", level=level, points=len(checkpoint.irc.coordinate)
        )
        parts.append(
            text
            + viewer(
                f"MolstarViewer(read_gaussian_checkpoint({last}).irc.frames)",
                "fig-checkpoint-path",
                message("caption-checkpoint-reaction-path-geometries"),
            )
            + chart(
                f"_calculation.checkpoint_path_chart({last})",
                "fig-checkpoint-path-energy",
                message("caption-checkpoint-reaction-path"),
                "x",
            )
        )
    if checkpoint.vibrations is not None:
        text: sourcetypes.markdown = message("section-checkpoint-vibrational-modes", level=level)
        parts.append(
            text
            + show(
                f"_calculation.checkpoint_modes_table({last})",
                "tbl-checkpoint-modes",
                message("caption-vibrational-modes"),
            )
        )
    return "".join(parts)


def _has_orbitals(path):
    """Whether a formatted checkpoint holds orbital energies."""
    return "Alpha Orbital Energies" in read_fchk_records(path)


def structures_section(structures, locate):
    """Sections of a structure file, a calcpages.calculation StructureFile: its molecules in a viewer over the first
    record's summary and folded coordinates, its partial charges on the molecule when a data field holds them, and
    its data fields, those of several lines each in a fold; ``locate`` writes the file's Python expression.
    """
    count = len(structures.records)
    text: sourcetypes.markdown = message(
        "section-structure-records"
        if structures.shared
        else "section-structure-molecules"
        if count > 10
        else "section-structure-molecule",
        count=count,
    )
    code: sourcetypes.python = f"""from calcpages.structure_file import StructureFile
_structures = StructureFile({locate(structures.path)})"""
    shown: sourcetypes.python = """for _viewer in _structures.viewers():
    display(_viewer)"""
    detail: sourcetypes.markdown = message("note-structure-header")
    note: sourcetypes.markdown = message("note-structure-coordinates")
    parts = [
        text
        + cell(code)
        + cell(
            shown,
            "fig-structures",
            message("caption-structure-molecule")
            if count == 1
            else message("caption-structure-records")
            if structures.shared
            else message("caption-structure-molecules"),
        )
        + detail
        + show("_structures.summary_table()", "tbl-structure-summary", message("caption-structure-header"))
        + fold(
            message("heading-coordinates", level="###"),
            note + show("_structures.coordinates_table()", "tbl-coordinates", message("caption-structure-coordinates")),
        )
    ]
    charges = structures.charges()
    if charges:
        extra: sourcetypes.markdown = message("section-partial-charges", field=charges[0])
        parts.append(
            extra
            + viewer(
                "_structures.charges_viewer()",
                "fig-partial-charges",
                message("caption-partial-charges", field=charges[0]),
            )
        )
    if structures.first["properties"]:
        remark: sourcetypes.markdown = message("section-data-fields")
        parts.append(
            remark
            + (
                show("_structures.fields_table()", "tbl-data-fields", message("caption-data-fields"))
                if not structures.fields_table().empty
                else ""
            )
        )
        for name, value in structures.long_fields():
            block = "\n".join(["```", value, "```", ""])
            parts.append(fold(f"### `{name}`", block + "\n"))
    return "".join(parts)


def starting_section(calculation, level="###"):
    """The structure a calculation starts from, in a viewer over its folded coordinates; empty without one."""
    geometry = calculation.initial_geometry()
    if not geometry:
        return ""
    overlay = calculation.coordinate_overlay()
    shown = message("note-measured-coordinates") if overlay else ""
    text: sourcetypes.markdown = message("section-starting-geometry", level=level, shown=shown)
    label = "fig-starting-geometry"
    if overlay:
        return text + viewer(
            "MolstarViewer(_calculation.geometry_frame(), **_calculation.coordinate_overlay())",
            label,
            message("caption-starting-geometry-measured"),
        )
    return text + viewer("MolstarViewer(_calculation.geometry_frame())", label, message("caption-starting-geometry"))


def _input_sections(calculation):
    """Everything an input shows on its own, before any output: for a Gaussian input each linked job's Link 0
    commands, route and molecule specification, for a Lotus XYZ input its settings, and the starting geometry.
    """
    starting = starting_section(calculation)
    jobs = calculation.jobs
    if len(jobs) == 1:
        text: sourcetypes.markdown = message(
            "section-gaussian-input", input=gaussian_input(calculation, 1, "####"), starting=starting
        )
        return text
    if jobs:
        detail: sourcetypes.markdown = message("section-linked-jobs", jobs=len(jobs))
        parts = [detail]
        for number in range(1, len(jobs) + 1):
            note: sourcetypes.markdown = f"""### {calculation.step_name(number)} {{#Input_{calculation.step_anchor(number)} .step}}

{gaussian_input(calculation, number, "####")}{starting_section(calculation, "####") if number == 1 else ""}"""
            parts.append(note)
        return "".join(parts)
    if calculation.lotus_settings() is not None:
        remark: sourcetypes.markdown = message("section-lotus-settings")
        return (
            remark + show("_calculation.lotus_settings()", "tbl-settings", message("caption-lotus-settings")) + starting
        )
    extra: sourcetypes.markdown = message("heading-structure", level="###")
    return extra + starting if starting else ""


def input_output_tabs(inputs, outputs):
    """Input and Output sections rendered through the shared Quarto/Bootstrap tabset helper."""
    text: sourcetypes.markdown = message(
        "section-input-output", inputs=inputs or message("note-no-input"), outputs=outputs or message("note-no-output")
    )
    return text


def input_body(calculation, outputs=""):
    """Show retained input, with the Output tab only when output is available."""
    inputs = _input_sections(calculation)
    if not outputs:
        text: sourcetypes.markdown = message("section-input", inputs=inputs or message("note-no-input"))
        return text
    return input_output_tabs(inputs, outputs)


def step_callout(calculation, number, icons):
    """The findings of one linked job, in a callout of their own; empty without any."""
    return findings_callout(findings_table(calculation.step_findings(number), icons, show_source=False))


def calculation_body(calculation, locate, icons):
    """The system and method, the parsed input and output tabs, and the technical details at the end."""
    inputs, outputs = [], []
    if calculation.program == "gaussian":
        multiple = len(calculation.jobs) > 1
        level = "####" if multiple else "###"
        for number in range(1, len(calculation.jobs) + 1):
            input_text = gaussian_input(calculation, number, level)
            if number == 1:
                input_text += starting_section(calculation, level)
            output_text = gaussian_output(calculation, number, level)
            if multiple:
                anchor = calculation.step_anchor(number)
                name = calculation.step_name(number)
                input_text = f"""### {name} {{#Input_{anchor} .step}}

{input_text}"""
                output_text = f"""### {name} {{#{anchor} .step}}

{step_callout(calculation, number, icons)}
{output_text}"""
            inputs.append(input_text)
            outputs.append(output_text)
    elif calculation.lotus_settings() is not None:
        text: sourcetypes.markdown = message("section-lotus-settings")
        inputs.append(
            text
            + show("_calculation.lotus_settings()", "tbl-settings", message("caption-lotus-settings"))
            + starting_section(calculation)
        )
    if calculation.program == "lotus":
        text: sourcetypes.markdown = message("section-electronic-structure-screening")
        screening: sourcetypes.markdown = message("note-screening-model", unit=unit_latex("bohr ** -3"))
        terms = {"dd_blyp": ("B88", "LYP"), "dd_svwn": ("Slater", "VWN")}.get(calculation.result["method"])
        if terms:
            screening += message("note-self-consistent-screening", exchange=terms[0], correlation=terms[1])
        outputs.append(
            text
            + show(
                "_calculation.lotus_summary()",
                "tbl-lotus-summary",
                message("caption-electronic-structure-screening"),
                precision=10,
            )
            + screening
        )
        if calculation.lotus_energy_table() is not None:
            text: sourcetypes.markdown = message("section-energy-components")
            detail: sourcetypes.markdown = message("note-energy-components")
            outputs.append(
                text
                + show(
                    "_calculation.lotus_energy_table()",
                    "tbl-energy-components",
                    message("caption-energy-components"),
                    precision=12,
                )
                + detail
            )
        if calculation.result["checks"]:
            text: sourcetypes.markdown = message("section-lotus-checks")
            outputs.append(text + show("_calculation.lotus_checks()", "tbl-checks", message("caption-lotus-checks")))
        if calculation.result["scf_history"]:
            text: sourcetypes.markdown = message("section-lotus-scf-convergence")
            outputs.append(
                text
                + cell("_energy, _change = _calculation.lotus_scf_charts()")
                + chart("_energy", "fig-scf-energy", message("caption-lotus-energy"), "x")
                + chart("_change", "fig-scf-change", message("caption-lotus-density-change"), "x")
            )
        if calculation.result["orbital_history"]:
            text: sourcetypes.markdown = message("section-lotus-orbital-gap")
            outputs.append(
                text
                + chart(
                    "_calculation.lotus_orbitals_chart()", "fig-gap-steps", message("caption-lotus-orbital-gap"), "x"
                )
            )
        if calculation.result["screening_history"]:
            text: sourcetypes.markdown = message("section-screening-convergence")
            outputs.append(
                text
                + chart(
                    "_calculation.lotus_screening_chart()",
                    "fig-screening-steps",
                    message("caption-screening-convergence"),
                    "x",
                )
            )
    outputs.append(
        checkpoint_section(calculation.checkpoint_files(), locate, level="###", logged=calculation.result is not None)
    )
    system = system_section(calculation, 1, "##") if calculation.program == "gaussian" and calculation.jobs else ""
    details: sourcetypes.markdown = message("section-technical-details")
    return (
        system
        + input_output_tabs("".join(inputs), "".join(outputs))
        + details
        + show("_calculation.overview(_page.states)", "tbl-details", message("caption-technical-details"))
    )

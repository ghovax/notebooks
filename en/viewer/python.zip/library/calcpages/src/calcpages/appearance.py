"""How the calculation pages look, fixed for every page: the charts' colours and strokes, the share of a field the
viewers' surfaces hold by default, and the callout that shows each status.
"""

# Tableau's twenty categorical colours, for charts with more series than its ten main ones.
PALETTE = [
    "#4e79a7", "#a0cbe8", "#f28e2b", "#ffbe7d", "#59a14f", "#8cd17d", "#b6992d", "#f1ce63", "#499894", "#86bcb6",
    "#e15759", "#ff9d9a", "#79706e", "#bab0ac", "#d37295", "#fabfd2", "#b07aa1", "#d4a6c8", "#9d7660", "#d7b5a6",
]  # fmt: skip
# Colour scale of orbital composition heat maps, from no share to all of it.
COMPOSITION_COLORS = ("#efedf5", "#9e9ac8", "#3f007d")
# Opacity of what a selection or a trace leaves out.
FADED_OPACITY = 0.2
# Padding in pixels around the data of a scale that does not start at zero.
PADDING = 10
# Dashed reference lines, a limit, a saddle or a region's border, as Vega-Lite mark properties.
REFERENCE_LINE = {"strokeWidth": 1.5, "strokeDash": [5, 4], "color": "#595959", "clip": True}
# Dashes of a reference line for an RMS criterion, beside a maximum's long ones.
RMS_DASH = [2, 2]
# Room the axis labels take, as Vega-Lite axis properties, so that long typeset labels are never cut.
LABEL_BAND = {"minExtent": 0, "maxExtent": 10000}

# The default level of each viewer, chosen from the field it draws rather than fixed: the share of an orbital's
# density, of the magnitude of a density change, and of the molecular surface the colour scale of a potential covers.
ORBITAL_SHARE = 0.85
DENSITY_SHARE = 0.8
POTENTIAL_SHARE = 0.95

# The Quarto callout of each status, by its identifier: its kind and the status class that colours it.
CALLOUTS = {
    "accepted": ("tip", "accepted"),
    "completed": ("tip", "accepted"),
    "succeeded": ("tip", "accepted"),
    "caveats": ("warning", "caveats"),
    "problems": ("warning", "caveats"),
    "in-progress": ("note", "in-progress"),
    "submitted": ("note", "in-progress"),
    "rejected": ("important", "rejected"),
    "failed": ("important", "rejected"),
    "prepared": ("note", None),
    "job-summary": ("note", None),
    "not-run": ("note", None),
    "not-submitted": ("note", None),
}

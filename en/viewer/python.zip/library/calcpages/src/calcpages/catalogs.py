"""The texts of data files, in gettext catalogs: YAML holds the data and the settings, catalogs hold every text.

A data file names its places of text with patterns of keys (``*`` any one key, ``**`` any number of levels, ``[]``
every item of a list, ``[n]`` one item); calcpages' are in ``data/schema.yaml`` and the research repository's in
:data:`PROJECT_PLACES`. The YAML file holds none of those texts. Every language, English included, has them in its own
catalogs, one message per text, whose ``msgid`` is the text's place, such as ``pairs-forming.label`` or
``1-45.values[15][1]``, in the file's order; reading a file lays each language's texts back at their places, English
under any the language lacks.

The catalogs are organized like the files they hold the texts of:

- calcpages' ``data/<name>.yaml`` has ``locale/<language>/data/<name>.po``, and the Gaussian IOps, one catalog per
  overlay, ``locale/<language>/data/gaussian-iops/overlay-01.po`` and so on;
- a research file has its catalogs beside it, as a README has its translation: ``translations/<language>/notebook.po``
  for ``notebook.yaml``, ``translations/<language>/scans.po`` and, at the repository's top,
  ``translations/<language>/site.po``.

English is the source. Each message of another language records the English it translates as an extracted comment
``#. en <digest>``; ``python -m calcpages.catalogs`` rewrites every other language's catalog from the English one, in its
order, keeping each translation, marking one whose English changed as fuzzy, adding a new text untranslated and
dropping a text that is gone.
"""

import copy
import hashlib
import re
from datetime import datetime
from functools import cache
from importlib.resources import files
from pathlib import Path

import yaml
from babel import Locale
from babel.messages.catalog import Catalog
from babel.messages.pofile import read_po, write_po

from calcpages.i18n import LANGUAGES, language

# What a text must keep in every language: format placeholders, doubled braces, catalog parameters and units.
KEPT = re.compile(r"\{\{|\}\}|\{[a-z_]+\}|%\([a-z_]+\)s|@unit\([^@]*\)@")
# The places of text of the research repository's own data files, by file name.
PROJECT_PLACES = {
    "site.yaml": ["homepage.title", "homepage.abstract", "figures.*[].figures[].caption"],
    "notebook.yaml": ["words.*", "guesses.*.name", "guesses.*.link", "axis-ticks[].tick"],
    "scans.yaml": ["axes.*.title", "axes.*.label", "axes.*.description", "outcomes.*.title", "outcomes.*.description"],
}
# How a large data file's texts are split among catalogs, by each text's path: the Gaussian IOps by overlay.
SPLITS = {"gaussian-iops": lambda path: f"gaussian-iops/overlay-{int(path[0].split('-')[0]):02d}"}
SOURCE = LANGUAGES[0]


def worded(text):
    """Whether a text reads differently in another language: it has a word with a lower-case letter, such as "Yes" or
    "Use", or prose punctuation, such as the full stop that ends "$N$.", outside its math, code, placeholders and
    units. A label that is only a symbol, such as $\\Delta d_k$, or a name such as B3LYP reads the same everywhere.
    """
    bare = re.sub(r"(?<!\\)\$.*?(?<!\\)\$|`[^`]*`", "", KEPT.sub("", text))
    return bool(re.search(r"(?=[A-Za-z]{2})[A-Za-z]*[a-z]", bare) or re.search(r"[.,;:!?]", bare))


def digest(text):
    """A short fingerprint of an English text, which a translation records to tell when the English changed."""
    return hashlib.sha1(text.encode()).hexdigest()[:10]


# ----- Places and keys.


def steps(place):
    """A place pattern as its steps: keys, ``*``, ``**``, ``[]`` and ``[n]``."""
    return re.findall(r"\[\d*\]|[^.\[\]]+", place)


def matches(pattern, path):
    """Whether a path of keys and list indices lies at a place, given as its steps."""
    if not pattern:
        return not path
    first, rest = pattern[0], pattern[1:]
    if first == "**":
        return any(matches(rest, path[index:]) for index in range(len(path) + 1))
    if not path:
        return False
    step = path[0]
    if first == "[]":
        fits = isinstance(step, int)
    elif first.startswith("["):
        fits = isinstance(step, int) and step == int(first[1:-1])
    else:
        fits = isinstance(step, str) and first in ("*", step)
    return fits and matches(rest, path[1:])


def texts(node, places, path=()):
    """Every text at one of the places, as its path and the text, in the file's order."""
    patterns = [steps(place) for place in places] if places and isinstance(places[0], str) else places
    if isinstance(node, dict):
        for key, value in node.items():
            yield from texts(value, patterns, (*path, key))
    elif isinstance(node, list):
        for index, value in enumerate(node):
            yield from texts(value, patterns, (*path, index))
    elif isinstance(node, str) and node and any(matches(pattern, list(path)) for pattern in patterns):
        # An empty string holds no text; it stays in the data file.
        yield path, node


def key(path):
    """A text's message key: its path of keys and list positions, such as ``1-45.values[15][1]``."""
    where = ""
    for step in path:
        where += f"[{step}]" if isinstance(step, int) else (f".{step}" if where else str(step))
    return where


def path_of(text_key):
    """The path a message key names."""
    return tuple(
        int(token[1:-1]) if token.startswith("[") else token for token in re.findall(r"\[\d+\]|[^.\[\]]+", text_key)
    )


def laid(tree, messages):
    """A copy of a data file's contents with texts laid at the places their keys name, creating the mappings and list
    items they need; a text at a list's end extends it.

    Args:
        tree: The file's contents, without its texts.
        messages: Each text by its key, in the file's order.

    Returns:
        The contents with their texts.
    """
    result = copy.deepcopy(tree) if tree is not None else {}
    for text_key, text in messages.items():
        path, node = path_of(text_key), result
        for step, following in zip(path, path[1:]):
            empty = [] if isinstance(following, int) else {}
            if isinstance(step, int):
                if step == len(node):
                    node.append(empty)
                node = node[step]
            else:
                node = node.setdefault(step, empty)
        last = path[-1]
        if isinstance(last, int) and last == len(node):
            node.append(text)
        else:
            node[last] = text
    return _ordered(result, tree if tree is not None else {}, [path_of(text_key) for text_key in messages])


def _ordered(node, data, paths, where=()):
    """A mapping's keys in the file's order: the order the catalog's keys come in, with the keys only the data file
    holds in their place among them, so a mapping that the YAML file no longer lists still reads in its order.
    """
    if isinstance(node, list):
        return [
            _ordered(
                item, data[index] if isinstance(data, list) and index < len(data) else None, paths, (*where, index)
            )
            for index, item in enumerate(node)
        ]
    if not isinstance(node, dict):
        return node
    texts_order = list(
        dict.fromkeys(path[len(where)] for path in paths if len(path) > len(where) and path[: len(where)] == where)
    )
    held = list(data) if isinstance(data, dict) else []
    order, pending = [], [key for key in held]
    for each in texts_order:
        if each in pending:
            # Keys only the data file holds that come before this one keep their place.
            while pending and pending[0] != each:
                order.append(pending.pop(0))
            pending.pop(0)
        if each not in order:
            order.append(each)
    order += [key for key in pending if key not in order]
    order += [key for key in node if key not in order]
    return {
        key: _ordered(node[key], data.get(key) if isinstance(data, dict) else None, paths, (*where, key))
        for key in order
        if key in node
    }


# ----- Where the catalogs are.


def package_folder():
    """Calcpages' own folder, which holds ``data/`` and ``locale/``."""
    return Path(str(files(__package__)))


def data_places():
    """The place patterns of each calcpages data file with texts, from ``data/schema.yaml``."""
    return yaml.safe_load((package_folder() / "data/schema.yaml").read_text())


def data_catalogs(name, code):
    """The catalogs of one calcpages data file in a language: ``locale/<code>/data/<name>.po``, or the catalogs of its
    folder ``locale/<code>/data/<name>/`` in name order.
    """
    folder = package_folder() / "locale" / code / "data"
    return [path for path in [folder / f"{name}.po", *sorted((folder / name).glob("*.po"))] if path.is_file()]


def project_root(path):
    """The research repository holding a path: the nearest folder at or above it with ``site.yaml``."""
    path = Path(path).resolve()
    return next(folder for folder in [path, *path.parents] if (folder / "site.yaml").is_file())


def project_catalog(path, code):
    """The catalog of a research file in a language: ``translations/<code>/<stem>.po`` beside it."""
    path = Path(path)
    return path.parent / "translations" / code / f"{path.stem}.po"


def project_files(root):
    """Every data file of the research repository with texts, including a notebook's whose only data are its words,
    which has its catalogs and no ``notebook.yaml``.
    """
    root = Path(root)
    found = {root / "site.yaml"}
    for name in ("notebook.yaml", "scans.yaml"):
        found |= {path for path in (root / "projects").rglob(name) if "translations" not in path.parts}
        found |= {
            catalog.parent.parent.parent / name
            for catalog in (root / "projects").rglob(f"translations/{SOURCE}/{Path(name).stem}.po")
        }
    return sorted(found)


def files_with_texts(root=None):
    """Every data file with texts and its English catalogs.

    Args:
        root: The research repository, or None for calcpages' files alone.

    Returns:
        A list of ``(name, file, places, catalogs)``: the file's name for messages, its path, its place patterns and
        a function of a language code giving its catalogs.
    """
    found = []
    for name, places in data_places().items():
        found.append(
            (
                f"data/{name}.yaml",
                package_folder() / "data" / f"{name}.yaml",
                places,
                lambda code, n=name: data_catalogs(n, code),
            )
        )
    if root is not None:
        for path in project_files(root):
            name = str(path.relative_to(root))
            # A file with no texts, such as a notebook.yaml of numbers only, has no catalogs.
            catalogs = lambda code, p=path: [c for c in [project_catalog(p, code)] if c.is_file()]
            found.append((name, path, PROJECT_PLACES[path.name], catalogs))
    return found


# ----- Reading.


@cache
def _messages(path):
    """A catalog's texts by key, in its order, without its fuzzy or empty ones."""
    with Path(path).open("rb") as stream:
        return {m.id: m.string for m in read_po(stream) if m.id and m.string and not m.fuzzy}


def catalog_texts(catalogs):
    """The texts of some catalogs by key, in their order."""
    found = {}
    for path in catalogs:
        if Path(path).is_file():
            found.update(_messages(str(path)))
    return found


def with_texts(tree, catalogs, code):
    """A data file's contents with its texts in a language: English from its English catalogs, under the language's.

    Args:
        tree: The file's contents.
        catalogs: Function of a language code giving the file's catalogs.
        code: Language code.

    Returns:
        The contents with their texts.
    """
    messages = catalog_texts(catalogs(SOURCE))
    if code != SOURCE:
        # The language's texts over the English ones, in the English order.
        messages = {**messages, **catalog_texts(catalogs(code))}
    return laid(tree, messages)


def project_texts(path, tree, code=None):
    """A research file's contents with its texts in a language, from the catalogs beside it.

    Args:
        path: The file, such as a workflow's ``notebook.yaml``.
        tree: Its contents.
        code: Language code; the page language by default.

    Returns:
        The contents with their texts.
    """
    return with_texts(tree, lambda each: [project_catalog(path, each)], code or language())


# ----- Writing.


def _header(code, owner):
    """An empty catalog with the header every catalog of data texts shares."""
    name = Locale.parse(code).english_name
    return Catalog(
        locale=code,
        project=owner,
        version="1",
        header_comment=f"# The {name} texts of {owner}, one message per text by its place, in the file's order.",
        msgid_bugs_address="-",
        revision_date=datetime.now().astimezone(),
        last_translator="research-findings maintainers",
        language_team=name,
        fuzzy=False,
    )


def write_catalog(path, code, owner, messages):
    """Write a catalog.

    Args:
        path: The ``.po`` file.
        code: Its language.
        owner: The data file its texts belong to, for its header.
        messages: Each message as ``(key, text, english)``, with the English text another language translates, or None
            in English; a text fuzzy when its English changed is given with its key in a set as ``fuzzy``.
    """
    catalog = _header(code, owner)
    for text_key, text, english, fuzzy in messages:
        comments = [f"en {digest(english)}"] if english is not None else []
        catalog.add(text_key, text, auto_comments=comments, flags={"fuzzy"} if fuzzy else ())
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as stream:
        write_po(stream, catalog, width=0, omit_header=False, sort_output=False)
    _messages.cache_clear()


def _recorded(message):
    """The digest of the English a translation recorded, or None."""
    return next((comment[3:] for comment in message.auto_comments if comment.startswith("en ")), None)


def sync(english, path, code, owner):
    """Rewrite one catalog of another language from its English catalog: the English's keys and order, each
    translation kept, one whose English changed marked fuzzy, a new text untranslated and a text that is gone dropped.

    Args:
        english: The English catalog.
        path: The other language's catalog.
        code: Its language.
        owner: The data file, for the header.
    """
    with Path(english).open("rb") as stream:
        source = [m for m in read_po(stream) if m.id]
    old = {}
    if Path(path).is_file():
        with Path(path).open("rb") as stream:
            old = {m.id: m for m in read_po(stream) if m.id}
    messages = []
    for message in source:
        kept = old.get(message.id)
        text = kept.string if kept else ""
        if not text and not worded(message.string):
            # A symbol or a name reads the same in every language; English stands in for it.
            continue
        changed = bool(text) and (kept.fuzzy or _recorded(kept) != digest(message.string))
        messages.append((message.id, text, message.string, changed))
    write_catalog(path, code, owner, messages)


def sync_all(root=None):
    """Rewrite every other language's catalogs from the English ones, and remove the catalogs no English one has.

    Args:
        root: The research repository, or None for calcpages' catalogs alone.

    Returns:
        The catalogs written.
    """
    written = []
    for name, _, _, catalogs in files_with_texts(root):
        for english in catalogs(SOURCE):
            for code in LANGUAGES[1:]:
                own = Path(str(english).replace(f"/{SOURCE}/", f"/{code}/", 1))
                sync(english, own, code, name)
                written.append(own)
    for code in LANGUAGES[1:]:
        for stray in (package_folder() / "locale" / code / "data").rglob("*.po"):
            if stray not in written:
                stray.unlink()
    return written


def main():
    """Rewrite every other language's catalogs from the English ones: calcpages' own, and the research repository's
    when run inside it.
    """
    try:
        root = project_root(Path.cwd())
    except StopIteration:
        root = None
    print(f"{len(sync_all(root))} catalogs written")


if __name__ == "__main__":
    main()

"""Files of a calculation folder: parsed logs, checkpoint paths and digests."""

import hashlib
import os
import pickle
from functools import lru_cache
from pathlib import Path

import runflow
from runflow.results import read_gaussian, read_lotus

from calcpages.cache import cache_folder
from calcpages.i18n import TRANSLATIONS
from calcpages.readme import readme_metadata


@lru_cache(maxsize=1)
def _parser_version():
    """Digest of runflow's own source, so a parser change invalidates every parsed log."""
    digest = hashlib.sha256()
    for path in sorted(Path(runflow.__file__).parent.rglob("*.py")):
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _parsed(program, log):
    """A Gaussian or Lotus log parsed by runflow: Gaussian logs from runflow's cache, which notebook cells share,
    and Lotus logs from this one, reused while the log and the parser are unchanged.
    """
    # Parsing every Gaussian log took most of a page build; runflow caches that parse by the log's content.
    if program == "gaussian":
        return read_gaussian(log)
    info = log.stat()
    key = hashlib.sha256(f"{program}|{log.resolve()}|{info.st_size}|{info.st_mtime_ns}|{_parser_version()}".encode())
    cached = cache_folder("parsed") / f"{key.hexdigest()}.pickle"
    try:
        return pickle.loads(cached.read_bytes())
    except (OSError, EOFError, pickle.UnpicklingError):
        pass  # A missing or unreadable cache entry is parsed again.
    result = read_lotus(log)
    cache_folder("parsed").mkdir(parents=True, exist_ok=True)
    # Written beside its final name and moved, so a parallel reader never sees half a file.
    partial = cached.with_suffix(f".{os.getpid()}.part")
    partial.write_bytes(pickle.dumps(result))
    partial.replace(cached)
    return result


@lru_cache(maxsize=None)
def _original_folders(root):
    """Map original native-output folder paths to current scientific folders.

    Args:
        root: The folder that holds the projects.

    Returns:
        Mapping from preserved project/workflow/run paths to current local directories.
    """
    mapping = {}
    for readme in root.rglob("README.md"):
        # A README's translations, in its translations folder, are not folders of their own.
        if TRANSLATIONS in readme.relative_to(root).parts or "original-folder" not in readme_metadata(readme.parent):
            continue
        folder = readme.parent
        chain = []
        for depth in range(1, len(folder.relative_to(root).parts) + 1):
            parent = root.joinpath(*folder.relative_to(root).parts[:depth])
            original = readme_metadata(parent).get("original-folder")
            if not original:
                break
            chain.append(str(original))
        else:
            mapping["/".join(chain)] = folder
    return mapping


def _checkpoint_path(folder, value):
    """Resolve a checkpoint reference without rewriting paths in retained native output.

    Args:
        folder: Current run directory.
        value: Checkpoint path recorded by Gaussian.

    Returns:
        Corresponding local formatted-checkpoint path, whether or not retained locally.
    """
    direct = (folder / value).resolve().with_suffix(".fchk")
    if direct.exists():
        return direct
    # A formatted checkpoint kept in the folder's checkpoints/ under the checkpoint's own name, whatever folder the
    # job wrote it in.
    kept = folder / "checkpoints" / Path(value).with_suffix(".fchk").name
    if kept.exists():
        return kept.resolve()
    root = next((parent for parent in folder.resolve().parents if parent.name == "projects"), None)
    if root is None:
        return direct
    mapping = _original_folders(root)
    old = next((key for key, current in mapping.items() if current == folder.resolve()), None)
    if old is None:
        return direct
    if Path(value).is_absolute():
        relative = value.split("/projects/", 1)[-1]
    else:
        relative = os.path.normpath(old + "/" + value)
    for key, current in sorted(mapping.items(), key=lambda item: -len(item[0])):
        if relative.startswith(key + "/"):
            return (current / relative[len(key) + 1 :]).with_suffix(".fchk")
    return direct


@lru_cache(maxsize=None)
def _sha256_by_stat(path, modified, size):
    """SHA-256 of a file, cached by its path, modification time and size, so each version of it is read once."""
    with open(path, "rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def _file_sha256(path):
    """SHA-256 of a file, read once per version of it: workflow diagrams and scans ask for a log's digest many times."""
    info = Path(path).stat()
    return _sha256_by_stat(str(Path(path).resolve()), info.st_mtime_ns, info.st_size)


def _checkpoint_digest(path, modified, size):
    """First sixteen hex digits of a checkpoint's digest, cached by its path and stat so each checkpoint is read once."""
    return _sha256_by_stat(path, modified, size)[:16]

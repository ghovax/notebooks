"""Helpers of notebook and calculation-page cells: scientific tables, labelled charts and TikZ figures."""

import math
from numbers import Real
from pathlib import Path

import altair as alt

from calcpages.i18n import message
from calcpages.labels import quantity, quantity_entries, scientific_latex, unit_label, unit_latex

# What notebooks and generated pages import with `from calcpages.notebook import *`.
__all__ = [
    "described",
    "display_chart",
    "fold_explanations",
    "irc_profile_chart",
    "quantity",
    "register_plot_labels",
    "scientific_table",
    "thin_line_markers",
    "tikz_along",
    "tikz_figure",
    "tikz_values",
    "unit_label",
    "unit_latex",
    "unit_math",
    "unit_text",
    "upper_y_limit",
    "with_tooltips",
    "zoomable",
]


def notebook_data(module_file):
    """A notebook's literal data: the ``notebook.yaml`` beside its ``notebook.py``, in the page language. The words a
    notebook's computation shows, such as legend entries and table labels, are its ``words``, which live in the catalogs
    beside it, ``translations/<code>/notebook.po``, one per language, English included (``calcpages.catalogs``).

    Args:
        module_file: The notebook module's ``__file__``.

    Returns:
        The data, a mapping.
    """
    import yaml

    from calcpages.catalogs import project_texts

    path = Path(module_file).with_name("notebook.yaml")
    # A notebook whose only literal data are its words has no notebook.yaml, only its catalogs.
    tree = yaml.safe_load(path.read_text()) if path.is_file() else None
    return project_texts(path, tree or {})


def optimization_frame_labels(ended, saddle=False):
    """Snapshot frame labels of an optimization path, in the page language: its first frame, the initial geometry, and
    once it has ended, its last, named the transition state when it reached the saddle and the final geometry otherwise.

    Args:
        ended: Whether the optimization recorded an outcome, so that its last frame is where it stopped.
        saddle: Whether that outcome is the transition state sought.

    Returns:
        The frame number of each label, one-based, with -1 for the last frame.
    """
    labels = {message("frame-initial-geometry"): 1}
    if ended:
        labels[message("frame-transition-state") if saddle else message("frame-final-geometry")] = -1
    return labels


def unit_text(expression, unit, bracket=False):
    """Typeset a measurement expression using a Pint-formatted unit."""
    formatted = unit_latex(unit)
    formatted = f"[{formatted}]" if bracket else formatted
    spacer = r"\;" if bracket else "" if formatted == r"{}^\circ" else r"\,"
    return "$" + (expression + spacer if expression else "") + formatted + "$"


def unit_math(expression, unit, bracket=False):
    """Render a measurement in Quarto inline Python."""
    from IPython.display import Markdown

    return Markdown(unit_text(expression, unit, bracket))


def described(label, description=None):
    """A table cell with its explanation, by default that of the quantity its label names: a marker holding the
    explanation's Markdown source, which the page turns into an info button opening it, typeset, in a hover popover;
    the label alone without one.
    """
    import base64

    description = description if description is not None else getattr(label, "description", None)
    if not isinstance(description, str) or not description.strip():
        return label
    encoded = base64.b64encode(description.strip().encode()).decode()
    return f'{label}<span class="quantity-info" data-description="{encoded}"></span>'


# Columns of explanations: their text moves into the info button of the row's first cell.
EXPLANATION_COLUMNS = {"description", "meaning"}


def fold_explanations(data):
    """The table with each explanation column folded into its rows' first cells as their info buttons, in subtables
    too.
    """
    import pandas as pd

    data = data.map(lambda value: fold_explanations(value) if isinstance(value, pd.DataFrame) else value)
    explanations = [column for column in data.columns if str(column).casefold() in EXPLANATION_COLUMNS]
    labels = [column for column in data.columns if column not in explanations]
    if not explanations or not labels:
        return data
    data = data.copy()
    first = labels[0]
    for index in data.index:
        text = " ".join(
            str(data.at[index, column])
            for column in explanations
            if isinstance(data.at[index, column], str) and data.at[index, column].strip()
        )
        if text:
            data.at[index, first] = described(data.at[index, first], text)
    return data.drop(columns=explanations)


def scientific_table(data, precision=5, highlight=()):
    """Format numerical table cells without changing the source data or units.

    ``highlight`` marks cells for the highlighter: a row position marks the whole
    row, and a ``(row position, column)`` pair marks one cell. A cell may hold a
    DataFrame of its own, drawn as a subtable inside that cell; such a table is
    written as HTML whose cells Quarto reads as Markdown, since pipe tables cannot nest.
    """
    import base64
    import re

    import pandas as pd

    def format_value(value):
        """Use decimal values or LaTeX powers of ten at the displayed precision; a quantity label gets its info
        button.
        """
        if getattr(value, "description", None):
            return described(value)
        if not isinstance(value, Real) or isinstance(value, bool):
            return value
        if math.isnan(value):
            return ""
        if not math.isfinite(value):
            return str(value)
        # The same range as the page text's numbers, so energies such as -33794.38 stay decimal.
        if value != 0 and (abs(value) < 0.001 or abs(value) >= 1e5):
            mantissa, exponent = f"{value:.{precision - 1}e}".split("e")
            mantissa = mantissa.rstrip("0").rstrip(".")
            return '<span class="scientific-number">' + scientific_latex(mantissa, exponent) + "</span>"
        return f"{value:.{precision}g}"

    from pandas.api.types import is_bool_dtype, is_numeric_dtype

    def dittoed(values):
        """Shown values of one column, each that repeats the one above it written as the ditto mark, so a reader
        sees at once what changes from row to row; an empty cell or a table is never one."""
        mark, shown, previous = message("table-repeat"), [], None
        for value in values:
            plain = value if isinstance(value, str) else None
            shown.append(mark if plain and plain.strip() and plain == previous else value)
            previous = plain
        return shown

    data = fold_explanations(data)
    targets = [column for column in data.columns if str(column).casefold() == "target"]
    ordered = data.loc[:, targets + [column for column in data.columns if column not in targets]]
    alignments = [
        ("right" if is_numeric_dtype(ordered[column]) and not is_bool_dtype(ordered[column]) else "left")
        for column in ordered.columns
    ]
    cells = ordered.map(format_value).astype(object)
    for column in cells.columns:
        cells[column] = dittoed(
            [value if isinstance(value, (str, pd.DataFrame)) else str(value) for value in cells[column]]
        )
    for item in highlight:
        row, columns = (item, cells.columns) if isinstance(item, int) else (item[0], [item[1]])
        for column in columns:
            value = cells.iloc[row, cells.columns.get_loc(column)]
            if isinstance(value, str) and value.strip():
                cells.iloc[row, cells.columns.get_loc(column)] = f"[{value}]{{.hl}}"
    nested = [column for column in cells.columns if any(isinstance(value, pd.DataFrame) for value in cells[column])]
    if not nested:
        # Cells are already formatted; tabulate would otherwise parse them back into numbers and round them to
        # six significant digits.
        cells.columns = [described(column) for column in cells.columns]
        return cells.to_markdown(index=False, colalign=alignments, disable_numparse=True)

    # A column holding tables becomes a group of columns under one spanning heading, the tables' own column names in
    # the header row below; at any depth, so a table inside a subtable cell groups the same way. Each row spans as
    # many rows as its tallest group, and a table shorter than its row lets its last row span the rest.
    def cell(tag, content, alignment, span="", stripe=None):
        """One HTML cell whose Markdown content Quarto parses, LaTeX and links included; ``stripe`` marks a
        subtable cell as on an odd or even row of its subtable.
        """
        if content is None or (isinstance(content, float) and math.isnan(content)):
            content = ""
        # Running text, as opposed to a name or a number, keeps a readable width (the prose class).
        classes = ([f"sub-{stripe}"] if stripe else []) + (
            ["prose"] if tag == "td" and len(str(content).split()) > 4 else []
        )
        if classes:
            span += f' class="{" ".join(classes)}"'
        if not str(content).strip():
            return f'<{tag}{span} style="text-align: {alignment}"></{tag}>'
        # Quarto parses Markdown from a qmd attribute of a div or span, not of the cell itself. An image alone in a
        # paragraph would become a figure captioned by its alt text; a trailing non-breaking space keeps it inline.
        content = str(content)
        if re.fullmatch(r"!\[[^\]]*\]\([^)]*\)(\{[^}]*\})?", content.strip()):
            content = content.strip() + "\\ "
        encoded = base64.b64encode(content.encode()).decode()
        return f'<{tag}{span} style="text-align: {alignment}"><div data-qmd-base64="{encoded}"></div></{tag}>'

    def merged(frames):
        """Every column of the tables, each placed after the column it follows in a table that has it."""
        order = []
        for frame in frames:
            for position, name in enumerate(frame.columns):
                if name not in order:
                    order.insert(order.index(frame.columns[position - 1]) + 1 if position else 0, name)
        return order

    def layout(frames, names):
        """The columns of these tables as (name, alignment, nested layout or None), a nested layout for a column
        holding tables; numbers align right.
        """
        result = []
        for name in names:
            values = [value for frame in frames if name in frame.columns for value in frame[name]]
            tables = [value for value in values if isinstance(value, pd.DataFrame)]
            if tables:
                result.append((name, "center", layout(tables, merged(tables))))
            else:
                series = pd.Series(values, dtype=object).infer_objects()
                numeric = is_numeric_dtype(series) and not is_bool_dtype(series)
                result.append((name, "right" if numeric else "left", None))
        return result

    def leaves(columns):
        """The alignments of a layout's innermost columns, in order."""
        return [align for _, align, nested in columns for align in ([align] if nested is None else leaves(nested))]

    def depth(columns):
        """Header rows a layout needs."""
        return max(1 if nested is None else 1 + depth(nested) for _, _, nested in columns)

    def heights(frame, columns):
        """Rows each of a table's rows spans: one, or as many as its tallest nested table."""
        return [
            max(
                [1]
                + [
                    sum(heights(row[name], nested))
                    for name, _, nested in columns
                    if nested is not None and isinstance(row.get(name), pd.DataFrame) and len(row[name])
                ]
            )
            for _, row in frame.iterrows()
        ]

    def block(frame, columns, height, stripe):
        """A table's cells as ``height`` lines of cells; ``stripe`` marks rows as subtable rows."""
        spans = heights(frame, columns)
        spans[-1] += height - sum(spans)
        # Each column's shown values, a repeat of the row above written as the ditto mark.
        shown = {
            name: dittoed(
                [value if isinstance(value, pd.DataFrame) else str(format_value(value)) for value in frame[name]]
            )
            for name, _, nested in columns
            if nested is None and name in frame.columns
        }
        lines = []
        for number, ((_, row), span) in enumerate(zip(frame.iterrows(), spans)):
            rows = [[] for _ in range(span)]
            shade = ("odd" if number % 2 == 0 else "even") if stripe else None
            rowspan = f' rowspan="{span}"' if span > 1 else ""
            for name, align, nested in columns:
                value = row.get(name)
                if nested is None:
                    rows[0].append(cell("td", shown[name][number] if name in shown else "", align, rowspan, shade))
                elif isinstance(value, pd.DataFrame) and len(value):
                    for line, cells_ in enumerate(block(value, nested, span, True)):
                        rows[line] += cells_
                else:
                    rows[0] += [cell("td", "", inner, rowspan) for inner in leaves(nested)]
            lines += rows
        return lines

    columns = [
        (
            name,
            align,
            layout(
                [value for value in cells[name] if isinstance(value, pd.DataFrame)],
                merged([value for value in cells[name] if isinstance(value, pd.DataFrame)]),
            )
            if name in nested
            else None,
        )
        for name, align in zip(cells.columns, alignments)
    ]
    levels = depth(columns)
    header = [[] for _ in range(levels)]

    def head(columns, level):
        """Header cells of a layout from row ``level`` down."""
        for name, align, nested in columns:
            if nested is None:
                header[level].append(
                    cell("th", described(name), align, f' rowspan="{levels - level}"' if levels - level > 1 else "")
                )
            else:
                header[level].append(cell("th", described(name), "center", f' colspan="{len(leaves(nested))}"'))
                head(nested, level + 1)

    head(columns, 0)
    body = []
    for number, (index, row) in enumerate(cells.iterrows()):
        # Outer rows stripe alternately, each over all of its subtable rows.
        stripe = "group-odd" if number % 2 == 0 else "group-even"
        lines = block(cells.loc[[index]], columns, heights(cells.loc[[index]], columns)[0], False)
        body += [
            f'<tr class="{"group-start" if line == 0 else "group-row"} {stripe}">' + "".join(parts) + "</tr>"
            for line, parts in enumerate(lines)
        ]
    head_rows = "".join(
        ("<tr>" if level == 0 else '<tr class="subheader">') + "".join(parts) + "</tr>"
        for level, parts in enumerate(header)
    )
    # A raw HTML block, so Quarto converts the whole table, spans included, into a native table; the fence is
    # built, so this notebook's own code fences stay unambiguous.
    fence = "`" * 3
    return (
        fence
        + '{=html}\n<table class="subtables"><thead>'
        + head_rows
        + "</thead>"
        + f"<tbody>{''.join(body)}</tbody></table>\n"
        + fence
        + "\n"
    )


def register_plot_labels(quantity_labels):
    """Map native Altair text labels to the notebook's mathematical quantities, and each to its explanation, which the
    page opens from an info button beside an axis or legend title.
    """
    import json

    from IPython.display import HTML, display

    labels = dict(quantity_labels)
    labels.update({key.replace("_", " ").capitalize(): value for key, value in quantity_labels.items()})
    descriptions = {entry["label"]: entry["description"] for entry in quantity_entries().values()}
    # The page's own quantities, such as those written for its reaction's fragments, explain themselves over the generic
    # entries, by name and by the label text the page looks them up with.
    for key, value in labels.items():
        if getattr(value, "description", None):
            descriptions[key] = descriptions[str(value)] = value.description
    script = lambda kind, mapping: (
        f'<script class="quarto-plot-{kind}" type="application/json">'
        + json.dumps(mapping).replace("</", "<\\/")
        + "</script>"
    )
    display(HTML(script("labels", labels) + script("descriptions", descriptions)))


def with_tooltips(chart):
    """Give every mark that has none a hover box of its x, y, colour and dash fields, so each point of every chart
    reports its values; reference rules and text marks stay silent, and a mark with its own hover box keeps it.
    """
    # Validated once, when JupyterChart takes the finished chart.
    specification = chart.to_dict(validate=False)

    def give(node):
        for key in ("layer", "hconcat", "vconcat", "concat"):
            if key in node:
                node[key] = [give(child) for child in node[key]]
        if "spec" in node and isinstance(node["spec"], dict):
            node["spec"] = give(node["spec"])
        mark = node.get("mark")
        kind = mark.get("type") if isinstance(mark, dict) else mark
        encoding = node.get("encoding")
        if not kind or kind in ("rule", "text") or not isinstance(encoding, dict) or "tooltip" in encoding:
            return node
        fields = []
        for channel in ("x", "y", "color", "strokeDash", "shape"):
            value = encoding.get(channel)
            if (
                isinstance(value, dict)
                and isinstance(value.get("field"), str)
                and value["field"] not in [f["field"] for f in fields]
            ):
                entry = {"field": value["field"], "type": value.get("type", "nominal")}
                if entry["type"] == "quantitative":
                    entry["format"] = ".6~g"
                fields.append(entry)
        if fields:
            encoding["tooltip"] = fields
        return node

    specification = give(specification)
    return type(chart).from_dict(specification, validate=False)


def thin_line_markers(chart, *, max_per_series=40, max_hit_per_series=150):
    """Keep complete lines but show evenly spaced original markers, including each series' endpoints.

    This applies only to line charts that explicitly request point overlays. Independent scatter and highlighted
    points keep every mark. The window runs after each chart's own transformations and never alters the line data.
    """
    import copy

    import altair as alt

    # Validated once, when JupyterChart takes the finished chart.
    specification = chart.to_dict(validate=False)
    outer_keys = {
        "$schema",
        "datasets",
        "config",
        "width",
        "height",
        "title",
        "description",
        "background",
        "padding",
        "autosize",
        "params",
    }

    def thin(node):
        for key in ("layer", "hconcat", "vconcat", "concat"):
            if key in node:
                node[key] = [thin(child) for child in node[key]]
        if "spec" in node and isinstance(node["spec"], dict):
            node["spec"] = thin(node["spec"])
        mark = node.get("mark")
        encoding = node.get("encoding", {})
        if not isinstance(mark, dict) or mark.get("type") != "line" or not mark.get("point"):
            return node
        x = encoding.get("x", {})
        # Windowing raw rows before aggregation, binning or conditional grouping would change the meaning of points.
        if (
            not isinstance(x, dict)
            or not isinstance(x.get("field"), str)
            or x.get("type") not in ("quantitative", "temporal", "ordinal")
            or any(
                isinstance(value, dict) and ("aggregate" in value or "bin" in value or "condition" in value)
                for value in encoding.values()
            )
        ):
            return node
        outer = {key: node.pop(key) for key in list(node) if key in outer_keys}
        line = copy.deepcopy(node)
        point_style = line["mark"].pop("point")
        # Transparent hit targets, denser than the markers, so stretches of the line between them can be hovered.
        hit = copy.deepcopy(line)
        hit["mark"] = {"type": "point", "opacity": 0, "size": 64}
        points = copy.deepcopy(line)
        # An interactive selection may name the original line's view; only that line may retain the name.
        hit.pop("name", None)
        points.pop("name", None)
        points["mark"] = {"type": "point", "filled": True, **(point_style if isinstance(point_style, dict) else {})}
        groupby = []
        for channel in ("color", "detail", "strokeDash", "shape"):
            fields = encoding.get(channel, [])
            fields = fields if isinstance(fields, list) else [fields]
            for field in fields:
                if isinstance(field, dict) and field.get("type") in ("nominal", "ordinal") and field.get("field"):
                    if field["field"] not in groupby:
                        groupby.append(field["field"])
        window = {
            "window": [{"op": "row_number", "as": "__marker_index"}, {"op": "count", "as": "__marker_count"}],
            "sort": [{"field": x["field"], "order": "ascending"}],
            "frame": [None, None],
        }
        if groupby:
            window["groupby"] = groupby

        # Evenly spaced indices including both endpoints: a row is kept when it is the nearest row to one of the target
        # positions k (count - 1) / (kept - 1). A fixed stride anchored at the first row would leave a short last interval.
        # Vega expressions accept only identifier callees, so they use round(), never Math.round().
        def sampled(limit):
            total = f"min({limit}, datum.__marker_count)"
            return [
                window,
                {
                    "filter": f"datum.__marker_count <= {limit} || datum.__marker_index - 1 "
                    f"=== round(round((datum.__marker_index - 1) * ({total} - 1) "
                    f"/ (datum.__marker_count - 1)) * (datum.__marker_count - 1) / ({total} - 1))"
                },
            ]

        points.setdefault("transform", []).extend(sampled(max_per_series))
        # Every target is a node Vega moves on each frame of a zoom, and more than a plot's width can tell apart only
        # slow it.
        hit.setdefault("transform", []).extend(sampled(max_hit_per_series))
        return {**outer, "layer": [line, hit, points]}

    specification = thin(specification)
    # A single line can become a layer; composite charts retain their original top-level type.
    cls = alt.LayerChart if isinstance(chart, alt.Chart) and "layer" in specification else type(chart)
    return cls.from_dict(specification, validate=False)


def irc_profile_chart(data):
    """Draw recorded IRC energies on signed branches, with the saddle marked at zero.

    Energies are relative to the actual reverse endpoint. Duplicate an actual zero-coordinate row for the two
    branches, but never manufacture a saddle point or change the source data.
    """
    import altair as alt
    import pandas as pd

    if data.empty or data["coordinate"].min() >= 0:
        raise ValueError("A recorded reverse IRC point is needed for the energy reference.")
    data = data.assign(path_energy=data["energy"] - data.loc[data["coordinate"].idxmin(), "energy"])
    reverse = data.loc[data["coordinate"] <= 0].assign(branch=message("chart-reverse-path"))
    forward = data.loc[data["coordinate"] >= 0].assign(branch=message("chart-forward-path"))
    branches = pd.concat([reverse, forward], ignore_index=True).sort_values("coordinate")
    line = (
        alt.Chart(branches)
        .mark_line(point=True, clip=True)
        .encode(
            x=alt.X("coordinate:Q", scale=alt.Scale(zero=False)),
            y=alt.Y("path_energy:Q", scale=alt.Scale(domainMax=upper_y_limit(data["path_energy"], logarithmic=False))),
            color=alt.Color(
                "branch:N", title=None, sort=[message("chart-reverse-path"), message("chart-forward-path")]
            ),
            tooltip=[
                alt.Tooltip("branch:N", title=message("chart-path")),
                alt.Tooltip("coordinate:Q", title=message("chart-coordinate")),
                alt.Tooltip("path_energy:Q", title=message("chart-path-energy")),
            ],
        )
    )
    saddle = (
        alt.Chart(pd.DataFrame({"coordinate": [0.0]}))
        .mark_rule(strokeWidth=1.5, strokeDash=[5, 4], color="#595959", clip=True)
        .encode(x="coordinate:Q")
    )
    # Put the reference first so the zoom selection belongs to a non-faceted layer.
    return saddle + line


class _PreservedLayer(alt.LayerChart):
    """A layer chart whose Vega-Lite specification is embedded as given: Altair hoists a layer's parameters to the top
    of a layer chart, where Vega-Lite then repeats them once per layer.
    """

    def __init__(self, specification):
        object.__setattr__(self, "_specification", specification)
        object.__setattr__(self, "_kwds", dict(specification, params=[]))

    def to_dict(self, *args, **kwargs):
        import copy

        return copy.deepcopy(self._specification)


def zoomable(chart, zoom_axes=()):
    """The chart with pan and zoom along the given axes. Vega-Lite repeats a top-level bound-scale selection once per
    layer and Vega rejects the duplicate signals, so a layered chart carries its selection on its first layer.
    """
    if not zoom_axes:
        return chart
    encodings = [axis for axis in ("x", "y") if axis in zoom_axes]
    selection = alt.selection_interval(bind="scales", encodings=encodings)
    # Validated once, when JupyterChart takes the finished chart.
    specification = chart.to_dict(validate=False)
    if not specification.get("layer"):
        return chart.add_params(selection)
    # Selections Altair lifted from a layer, such as a click that highlights a level, stay at the top level; only a
    # bound-scale one would be repeated per layer.
    kept = [param for param in specification.pop("params", []) if param.get("bind") != "scales"]
    if kept:
        specification["params"] = kept
    specification["layer"][0].setdefault("params", []).append(
        {"name": selection.to_dict()["param"], "select": {"type": "interval", "encodings": encodings}, "bind": "scales"}
    )
    return _PreservedLayer(specification)


def display_chart(chart, *, zoom_axes=()):
    """Display a responsive native Altair chart with consistent notation and interaction."""
    import altair as alt
    import ipywidgets as widgets
    from IPython.display import display

    chart = thin_line_markers(with_tooltips(chart))
    # A faceted chart sizes its cells itself: Vega-Lite fits only a single or layered view to its container.
    if not isinstance(chart, alt.FacetChart):
        chart = chart.properties(width="container")
    chart = (
        chart.configure(font="system-ui")
        .configure_range(category=alt.RangeScheme(scheme="tableau10"))
        .configure_legend(orient="bottom", labelFontSize=14, titleFontSize=14, labelLimit=0, titleLimit=0)
        .configure_axis(
            labelFontSize=14,
            titleFontSize=14,
            titlePadding=8,
            format=".5~g",
        )
        .configure_axisX(
            labelAngle=-45,
            labelAlign="right",
            # Shift rotated labels right so their text sits under the tick, not left of it.
            labelOffset=2.5,
            labelPadding=5,
            labelBaseline="middle",
            labelOverlap=True,
            # A fixed band for the labels, whatever their current width, so a zoom never resizes the plot or moves the
            # axis title. Labels that need more room push the title out in the page's math header.
            minExtent=48,
            maxExtent=48,
        )
        .configure_axisY(minExtent=64, maxExtent=64)
        .configure_mark(opacity=1, fillOpacity=1, strokeOpacity=1)
        .configure_rule(strokeWidth=2)
    )
    display(
        alt.JupyterChart(
            zoomable(chart, zoom_axes), layout=widgets.Layout(width="100%"), embed_options={"actions": False}
        )
    )


def tikz_figure(picture, preamble="", scale=1.2):
    """Compile a TikZ picture with LaTeX and dvisvgm and display it as inline SVG.

    Text and math are set in LaTeX's own Computer Modern; glyphs become paths. ``scale`` maps 10 pt text to the 16 px
    body text. A picture with Japanese text, as a Japanese page's figure has, is compiled with XeLaTeX instead, which
    sets each run of Japanese characters in Hiragino Mincho, the serif that sits beside Computer Modern.

    Args:
        picture: TikZ picture source.
        preamble: Additional TeX declarations for the figure.
        scale: Mapping from TeX points to the document text size.

    Returns:
        None; displays the SVG figure inline.
    """
    import re
    import subprocess
    import tempfile

    from IPython.display import HTML, display

    # Runs of kana, kanji and full-width forms, which Computer Modern lacks.
    japanese = re.compile(r"[　-ヿ㐀-䶿一-鿿＀-￯]+")
    xetex = bool(japanese.search(picture))
    if xetex:
        picture = japanese.sub(lambda m: rf"{{\japanese {m.group(0)}}}", picture)
    source = "\n".join(
        [
            r"\PassOptionsToPackage{dvisvgm}{graphicx,xcolor}",
            r"\RequirePackage{fix-cm}",
            r"\documentclass[10pt]{article}",
            r"\usepackage{amsmath}",
            *([r"\usepackage[no-math]{fontspec}", r"\newfontfamily\japanese{Hiragino Mincho ProN}"] if xetex else []),
            r"\def\pgfsysdriver{pgfsys-dvisvgm.def}",
            r"\usepackage{tikz}",
            r"\usetikzlibrary{arrows.meta, decorations.text}",
            r"\definecolor{absorption}{HTML}{6A3D9A}",
            r"\definecolor{relaxation}{HTML}{B2182B}",
            r"\definecolor{gap}{HTML}{1B7837}",
            r"\definecolor{muted}{HTML}{595959}",
            preamble,
            r"\pagestyle{empty}",
            r"\begin{document}",
            picture,
            r"\end{document}",
        ]
    )
    with tempfile.TemporaryDirectory() as folder:
        Path(folder, "figure.tex").write_text(source)
        compile_ = ["xelatex", "-no-pdf"] if xetex else ["latex"]
        for command in (
            [*compile_, "-interaction=nonstopmode", "-halt-on-error", "figure.tex"],
            # Glyphs become paths; a 2 pt margin keeps edge glyphs (an i's dot) inside the box.
            [
                "dvisvgm",
                "--no-fonts",
                "--exact-bbox",
                "--bbox=2pt",
                "--precision=3",
                "figure." + ("xdv" if xetex else "dvi"),
                "-o",
                "figure.svg",
            ],
        ):
            run = subprocess.run(command, cwd=folder, capture_output=True, text=True)
            if run.returncode:
                raise RuntimeError(f"{command[0]} failed:\n{run.stdout[-3000:]}{run.stderr[-3000:]}")
        svg = Path(folder, "figure.svg").read_text()
    svg = svg[svg.index("<svg") :]
    # Scale from TeX points to CSS pixels so 10 pt text renders near the 16 px body text.
    for dimension in ("width", "height"):
        svg = re.sub(
            rf"{dimension}='([\d.]+)pt'",
            lambda m: f"{dimension}='{float(m.group(1)) * 4 / 3 * scale:.1f}px'",
            svg,
            count=1,
        )
    display(
        HTML(
            f'<div class="tikz-figure" style="text-align: center;">{svg}</div>'
            "<style>.tikz-figure { margin-bottom: 0.75rem; } .tikz-figure svg { max-width: 100%; height: auto; }</style>"
        )
    )


def tikz_along(curve, start, end, offset, units=(1.0, 1.0), samples=40):
    """TikZ coordinates of ``curve`` between two abscissae, shifted by ``offset`` (cm) along
    its normal, and the arrow's midpoint with its tangent angle for a label set on it.

    ``units`` are the picture's x and y lengths in cm, so the normal and the angle are the
    ones seen on the page even when x and y are scaled differently.
    """
    x_unit, y_unit = units

    def shifted(x):
        slope = (curve(x + 1e-4) - curve(x - 1e-4)) / 2e-4 * y_unit / x_unit
        norm = math.hypot(1, slope)
        return x - offset * slope / norm / x_unit, curve(x) + offset / norm / y_unit, math.degrees(math.atan(slope))

    points = [shifted(start + (end - start) * i / samples)[:2] for i in range(samples + 1)]
    return " -- ".join(f"({x:.3f},{y:.3f})" for x, y in points), shifted((start + end) / 2)


def tikz_values(header, rows, color):
    """A small table for a figure: a header over method names and right-aligned values."""
    body = r"\\".join(" & ".join(row) for row in rows)
    columns = "l" + r"@{\hspace{0.7em}}r" * (len(rows[0]) - 1)
    return (
        rf"\textcolor{{{color}}}{{\renewcommand{{\arraystretch}}{{1.05}}\begin{{tabular}}{{@{{}}{columns}@{{}}}}"
        rf"\multicolumn{{{len(rows[0])}}}{{@{{}}l@{{}}}}{{{header}}}\\{body}\end{{tabular}}}}"
    )


def upper_y_limit(values, *, logarithmic=False):
    """Add five percent of the displayed data span above Y, leaving its minimum unchanged."""
    import numpy as np

    data = np.asarray(values, dtype=float)
    data = data[np.isfinite(data)]
    if logarithmic:
        data = data[data > 0]
        if not len(data):
            raise ValueError("A logarithmic Y axis needs positive finite data.")
        data = np.log10(data)
    if not len(data):
        raise ValueError("A Y axis needs finite data.")
    lower, upper = float(data.min()), float(data.max())
    padding = 0.05 * (upper - lower) if upper > lower else 0.05 * max(abs(upper), 1.0)
    maximum = upper + padding
    return 10**maximum if logarithmic else maximum

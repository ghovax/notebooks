"""Languages of the calculation pages: messages, localized data, and the locale and time zone of dates.

Every sentence a page shows is a gettext message of ``locale/<language>/LC_MESSAGES/calcpages.po``, found by its key
and given named parameters: the catalog, not the code, holds the words, their order and their plural forms, written with
``%(name)s`` placeholders so a translation can place them anywhere. The texts of the data files in ``data/`` are
in catalogs of their own, every language's, English included,
``locale/<language>/data/<name>.po`` (``calcpages.catalogs``). English and Japanese are complete;
a key a catalog lacks falls back to English.

The language is ``$CALCPAGES_LANGUAGE``, or else the ``language`` setting, unless :func:`use_language` chose one; the
time zone of dates is the ``time-zone`` setting unless :func:`use_zone` chose one, as the viewer page does for its
visitor. These two choices are the only state the pages keep.
"""

import gettext
import io
import os
from collections.abc import Mapping
from functools import cache
from pathlib import Path
from zoneinfo import ZoneInfo

from babel.messages.mofile import write_mo
from babel.messages.pofile import read_po

from calcpages.settings import settings

# Languages with message files, the source language first.
LANGUAGES = ("en", "ja")
# The language and time zone chosen at run time, overriding the environment and the settings.
_CHOSEN = {}


def use_language(language):
    """Write the pages of this process in a language.

    Args:
        language: A code of :data:`LANGUAGES`.

    Raises:
        ValueError: The language has no message files.
    """
    if language not in LANGUAGES:
        raise ValueError(f"No messages in {language!r}; the languages are {', '.join(LANGUAGES)}.")
    _CHOSEN["language"] = language


def language():
    """The language the pages are written in.

    Returns:
        Its code.
    """
    return _CHOSEN.get("language") or os.environ.get("CALCPAGES_LANGUAGE") or settings()["language"]


# Folder beside a hand-written file that holds its translations, one folder per language code.
TRANSLATIONS = "translations"


def translation(path):
    """A file's translation into the page language: the file of the same name in ``translations/<code>/`` beside it,
    such as ``translations/ja/README.md`` for ``README.md``. Its links are written as from the original's folder,
    since its text stands in for the original's.

    Args:
        path: The original file.

    Returns:
        The translation's path, or None when the file has none in the page language.
    """
    path = Path(path)
    own = path.parent / TRANSLATIONS / language() / path.name
    return own if own.is_file() else None


def use_zone(name):
    """Show times in a time zone, as the viewer page does in its visitor's.

    Args:
        name: IANA name of the zone; a name the time-zone database lacks keeps the current one.
    """
    try:
        _CHOSEN["zone"] = ZoneInfo(name)
    except (ValueError, KeyError, OSError):
        pass


def zone():
    """The time zone dates are shown in.

    Returns:
        The zone.
    """
    return _CHOSEN.get("zone") or ZoneInfo(settings()["time-zone"])


def date_locale():
    """The Babel locale dates and numbers are written in, for the current language.

    Returns:
        Its identifier, such as ``en_GB``.
    """
    return settings()["date-locales"].get(language(), language())


@cache
def _translations(folder, domain, code):
    """The messages of one language of a package's catalogs, compiled from its ``.po`` file, with English behind them
    for any it lacks.

    Args:
        folder: The package folder holding ``locale/``.
        domain: The catalogs' name, the package's own.
        code: Language code.

    Returns:
        The gettext translations.
    """
    path = Path(folder) / "locale" / code / "LC_MESSAGES" / f"{domain}.po"
    with path.open("rb") as stream:
        catalog = read_po(stream, locale=code)
    compiled = io.BytesIO()
    write_mo(compiled, catalog)
    compiled.seek(0)
    translations = gettext.GNUTranslations(compiled)
    if code != "en":
        translations.add_fallback(_translations(folder, domain, "en"))
    return translations


def messages(folder, domain):
    """The message function of a package's catalogs, ``locale/<language>/LC_MESSAGES/<domain>.po`` in its folder, in the
    language of the moment; a package that shows its own words, as researchsite does, keeps them this way.

    Args:
        folder: The package folder holding ``locale/``.
        domain: The catalogs' name.

    Returns:
        A function like :func:`message` over those catalogs.
    """

    def message(key, count=None, **parameters):
        """One message in the current language, its parameters placed where its pattern puts them.

        Args:
            key: The message's identifier in the catalogs, such as ``scf-intro``.
            count: A number the pattern shows as ``count``, which also chooses the plural form of a message that has
                them.
            **parameters: The other values the pattern names.

        Returns:
            The message.

        Raises:
            KeyError: The English catalog has no such message.
        """
        catalog = _translations(str(folder), domain, language())
        # A message with plural forms is chosen by ``count``; any other ignores it for the choice.
        text = catalog.ngettext(key, key, count) if count is not None else key
        if text == key:
            text = catalog.gettext(key)
        if text == key:
            raise KeyError(f"No message {key!r} in the {domain} catalogs")
        if count is not None:
            parameters["count"] = count
        # Patterns are always formatted, so a literal percent sign is written %% in every catalog.
        return text % parameters

    def pattern(key):
        """One message's pattern in the current language, its parameters unfilled, as a page script fills them.

        Args:
            key: The message's identifier in the catalogs.

        Returns:
            The pattern, with ``%(name)s`` where each parameter goes.
        """
        text = _translations(str(folder), domain, language()).gettext(key)
        if text == key:
            raise KeyError(f"No message {key!r} in the {domain} catalogs")
        return text

    message.pattern = pattern
    return message


# The messages of calcpages's pages, from its own catalogs.
message = messages(Path(__file__).resolve().parent, "calcpages")


class PerLanguage(Mapping):
    """A mapping built once for each language and read in the language of the moment.

    Args:
        build: Function of a language code returning the mapping in that language.
    """

    def __init__(self, build):
        """Keep the builder; nothing is built until read."""
        self._build = build
        self._built = {}

    def _content(self):
        """The mapping in the current language."""
        code = language()
        if code not in self._built:
            self._built[code] = self._build(code)
        return self._built[code]

    def __getitem__(self, key):
        """One entry."""
        return self._content()[key]

    def __iter__(self):
        """The keys."""
        return iter(self._content())

    def __len__(self):
        """The number of entries."""
        return len(self._content())

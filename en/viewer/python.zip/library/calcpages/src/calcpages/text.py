"""The words and reference tables of calculation pages, from the data files beside this package, in the page language."""

import copy
from collections.abc import Mapping
from functools import cache
from importlib.resources import files

import yaml
from runflow.text import identifier

from calcpages.i18n import PerLanguage


@cache
def data(name, code="en"):
    """One data file of calcpages, with its translation into a language laid over it key by key.

    Args:
        name: The file's name in ``data/``, without ``.yaml``.
        code: Language code; ``data/<code>/<name>.yaml`` holds the translation, when there is one.

    Returns:
        Its contents.
    """
    folder = files(__package__).joinpath("data")
    content = yaml.safe_load(folder.joinpath(f"{name}.yaml").read_text())
    translation = folder.joinpath(code, f"{name}.yaml")
    if code != "en" and translation.is_file():
        content = _overlaid(content, yaml.safe_load(translation.read_text()) or {})
    return content


def _overlaid(base, own):
    """``base`` with the entries of ``own`` laid over it, mappings key by key.

    Args:
        base: The English data.
        own: Its translation, possibly partial.

    Returns:
        The translated data.
    """
    if not isinstance(base, dict) or not isinstance(own, dict):
        return own
    return {**base, **{key: _overlaid(base.get(key), value) for key, value in own.items()}}


# Names, messages and small tables the pages show, by the lower-case names of data/vocabulary.yaml.
TEXT = PerLanguage(lambda code: data("vocabulary", code))


def _gaussian(code):
    """Gaussian's hand-written keyword data with the manual's options, Link 0 commands and basis sets merged in.

    Every table is keyed by identifier. The manual's spelling is shown, and the hand-written meanings are kept where
    both explain a name.

    Args:
        code: Language code.

    Returns:
        The merged keyword data.
    """
    gaussian, manual = copy.deepcopy(data("gaussian-keywords", code)), data("gaussian-manual", code)
    for keyword, options in manual["options"].items():
        entry = gaussian["keywords"].setdefault(keyword, {"name": keyword.capitalize(), "page": keyword})
        known = entry.setdefault("options", {})
        for option, words in options.items():
            known[option] = {**words, **known.get(option, {}), "name": words["name"]}
    for table in ("link0", "basis-sets"):
        for name, words in manual[table].items():
            gaussian[table][name] = {**words, **gaussian[table].get(name, {}), "name": words["name"]}
    return gaussian


# Gaussian's route keywords, options, Link 0 commands, basis sets and solvents with their meanings, by identifier.
GAUSSIAN = PerLanguage(_gaussian)
# Gaussian's IOps with their meanings, from the IOps Reference, by identifier, such as 1-5 for IOp(1/5).
IOPS = PerLanguage(lambda code: data("gaussian-iops", code))


def gaussian_entry(table, name):
    """An entry of one of Gaussian's tables by a name as an input or a log writes it: by the name's identifier, or by
    another spelling the entry lists among its aliases, such as 6-31G* for 6-31G(d).

    Args:
        table: The table, such as ``basis-sets``, ``link0``, ``methods`` or ``solvents``.
        name: The name as written, in any case.

    Returns:
        The entry, or None when the table has none for the name.
    """
    entries, key = GAUSSIAN[table], identifier(name)
    if key in entries:
        return entries[key]
    return next((entry for entry in entries.values() if key in map(identifier, entry.get("aliases", []))), None)


def keyword_entry(name):
    """A route keyword's entry by its name as written, a short form such as Pop naming its long form's entry.

    Args:
        name: The keyword as written.

    Returns:
        The keyword's identifier and its entry, an empty one when Gaussian's tables have none.
    """
    key = identifier(name)
    key = GAUSSIAN["aliases"].get(key, {}).get("keyword", key)
    return key, GAUSSIAN["keywords"].get(key, {})


def option_entry(name, keyword=None):
    """A route option's entry by its name as written: among its keyword's options, or among every keyword's when the
    keyword is not known, as for an option nested in another.

    Args:
        name: The option as written.
        keyword: The keyword it belongs to, as written, or None.

    Returns:
        The entry, or None.
    """
    key = identifier(name)
    if keyword is not None:
        return keyword_entry(keyword)[1].get("options", {}).get(key)
    return next(
        (entry["options"][key] for entry in GAUSSIAN["keywords"].values() if key in entry.get("options", {})), None
    )


def solvents():
    """Gaussian's SCRF solvents by lower-case name.

    Returns:
        Each solvent's name as the manual writes it and its dielectric constant.
    """
    return {entry["name"].lower(): (entry["name"], entry["epsilon"]) for entry in GAUSSIAN["solvents"].values()}


def lookup(table, code):
    """An entry of a nested table by its dotted code, such as ``gaussian.error.route-syntax``.

    Args:
        table: Mapping nested as the code's parts are.
        code: Dotted code.

    Returns:
        The entry, or None when the table has none for the code.
    """
    entry = table
    for part in code.split("."):
        part = identifier(part)
        if not isinstance(entry, Mapping) or part not in entry:
            return None
        entry = entry[part]
    return entry

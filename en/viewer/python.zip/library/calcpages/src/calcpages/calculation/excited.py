"""Excited states: their symmetry, spectra, transitions and transition densities."""

import altair as alt
import numpy as np
import pandas as pd
from molstarview import CubeGrid, VolumeSurface, VolumeViewer
from runflow.orbital_symmetry import state_symmetry
from runflow.results import ureg
from runflow.transfer import descriptors

from calcpages.appearance import DENSITY_SHARE
from calcpages.charts import _chart, _distinct_colors, _hovered, _nominal, _region, _regions, _series, margin
from calcpages.fields import _orbital_entries, _records, _state_densities, _transition_cached
from calcpages.i18n import message
from calcpages.labels import PLOT, quantity, unit_latex
from calcpages.notation import _number, _value, quantities_table, spoken_list
from calcpages.text import TEXT


def _atom_integrals(origin, axes, atoms, values):
    r"""A field integrated over the region of each atom, the grid points nearer its nucleus than any other's, as
    :math:`\int_A f\,\mathrm{d}\mathbf{r}`: for a density, the electrons the atom holds or gains.

    Args:
        origin: The grid's origin in bohr.
        axes: The grid's axes in bohr, diagonal.
        atoms: The grid's atoms, as ``CubeGrid`` holds them, their positions in bohr in the last three columns.
        values: The field on the grid.

    Returns:
        One integral per atom, in the field's unit times cubic bohr.
    """
    from scipy.spatial import cKDTree

    step = np.diag(axes)
    nuclei = np.asarray(atoms)[:, 2:]
    # Every grid point is assigned to its nearest nucleus, found in a k-d tree of the nuclei.
    points = np.stack(
        np.meshgrid(*[origin[k] + step[k] * np.arange(values.shape[k]) for k in range(3)], indexing="ij"), axis=-1
    ).reshape(-1, 3)
    nearest = cKDTree(nuclei).query(points)[1]
    return np.bincount(nearest, weights=np.asarray(values, dtype=float).ravel(), minlength=len(nuclei)) * np.prod(step)


class ExcitedStatesPart:
    """Excited states: their symmetry, spectra, transitions and transition densities. A part of :class:`calcpages.calculation.Calculation`."""

    def selection_rules(self, number):
        """Markdown on why a state is bright or dark: the oscillator strength, the dipole selection rule of the point
        group of the geometry, and the states each leading transition between orbital sets can form.
        """
        text = message("excited-oscillator-strength")
        symmetry = self._closed_symmetry(number)
        if symmetry is None:
            return text + message("excited-no-symmetry")
        group = symmetry.group
        ground = next(irrep.label for irrep in group.irreps if np.allclose(irrep.characters, 1))
        if len(group.irreps) == 1:
            return text + message(
                "excited-single-irrep", group=group.name, orbital=group.irreps[0].orbital(), ground=ground
            )
        components = spoken_list(
            message("excited-dipole-component", axes=f"({axes})" if "," in axes else axes, label=label)
            for label, axes in group.dipole.items()
        )
        allowed = r",\ ".join(group.dipole)
        text += message("excited-dipole-rule", group=group.name, ground=ground, components=components, allowed=allowed)
        pairs, seen = [], set()
        for state in self.final_states(number):
            weights, sets = {}, {}
            for configuration in state["configurations"]:
                if configuration["direction"] != "->":
                    continue
                source = self._set_of(number, configuration["occupied"], configuration.get("spin"))
                target = self._set_of(number, configuration["virtual"], configuration.get("spin"))
                # A restricted contribution stands for both spins, so its weight is twice its squared amplitude.
                spin = configuration.get("spin")
                key = (source.label(), target.label(), spin)
                sets[key] = (source, target)
                weights[key] = weights.get(key, 0) + (1 if spin else 2) * configuration["amplitude"] ** 2
            for key, weight in weights.items():
                source, target = sets[key]
                if weight >= 0.1 and key not in seen and source.irrep and target.irrep:
                    seen.add(key)
                    pairs.append((source, target))
        if not pairs:
            return text

        def product(first, second):
            counts = group.reduce(first.characters * second.characters)
            return r"\oplus ".join(
                (f"{round(count)}" if round(count) > 1 else "") + irrep.label
                for count, irrep in zip(counts, group.irreps)
                if round(count) > 0
            )

        # One product per pair of orbital symmetries, with the leading transitions that share it.
        products = {}
        for s, a in pairs:
            products.setdefault((s.irrep.label, a.irrep.label), (s.irrep, a.irrep, []))[2].append(
                rf"${s.label()}\rightarrow{a.label()}$"
            )
        lines = "".join(
            rf"""- ${s.orbital()}\otimes {a.orbital()}={product(s, a)}$: {", ".join(moves)}.
"""
            for s, a, moves in products.values()
        )
        text += message("excited-transition-products", lines=lines)
        return text

    def final_states(self, number):
        """Excited states of the job's last TD solution. A TD optimization solves the states again at every geometry,
        restarting the state numbering each time; only the set at the final geometry describes the result.
        """
        states = self.jobs[number - 1]["excitations"]
        starts = [
            index for index, state in enumerate(states) if index == 0 or state["state"] <= states[index - 1]["state"]
        ]
        return states[starts[-1] :] if starts else []

    def td_solutions(self, number):
        """Number of TD solutions in the job, one per geometry it solved the states at."""
        states = self.jobs[number - 1]["excitations"]
        return sum(
            1 for index, state in enumerate(states) if index == 0 or state["state"] <= states[index - 1]["state"]
        )

    def states(self, number):
        """The final excited states, each with its name, numbered per spin multiplicity as S_n or T_n, its symmetry
        and character, its dipole selection from the ground state, and its configurations merged over degenerate
        orbitals into transitions between orbital sets with their summed weight 2c^2 in percent.
        """
        job = self.jobs[number - 1]
        states = self.final_states(number)
        symmetry = self.symmetry(number)
        electrons = job["electron_counts"] or []
        closed = len(electrons) == 2 and electrons[0] == electrons[1]
        counts, result = {}, []
        for state in states:
            multiplicity = state.get("multiplicity")
            counts[multiplicity] = counts.get(multiplicity, 0) + 1
            letters = TEXT["spin-letters"]
            letter = (
                letters[multiplicity - 1]
                if isinstance(multiplicity, int) and 0 < multiplicity <= len(letters)
                else None
            )
            name = f"${letter}_{{{counts[multiplicity]}}}$" if letter else rf"$\Psi_{{{state['state']}}}$"
            merged = {}
            for configuration in state["configurations"]:
                source = self._set_of(number, configuration["occupied"], configuration.get("spin"))
                target = self._set_of(number, configuration["virtual"], configuration.get("spin"))
                arrow = r"\rightarrow" if configuration["direction"] == "->" else r"\leftarrow"
                # An unrestricted contribution names its spin after each orbital.
                spin = configuration.get("spin")
                channel = rf"\,(\{spin})" if spin else ""
                key = (source.label(), target.label(), arrow, spin)
                entry = merged.setdefault(
                    key,
                    dict(
                        transition=f"${source.label()}{channel}{arrow}{target.label()}{channel}$",
                        sets=(spin, source, target),
                        character=(
                            f"${source.character_label()}{arrow}{target.character_label()}$"
                            if source.character and target.character
                            else ""
                        ),
                        weight_percent=0.0,
                    ),
                )
                entry["weight_percent"] += (100 if spin else 200) * configuration["amplitude"] ** 2
            configurations = sorted(merged.values(), key=lambda entry: -entry["weight_percent"])
            result.append(dict(state=state, name=name, multiplicity=multiplicity, configurations=configurations))
        # Degenerate states together: consecutive, of one multiplicity, equal in energy at the printed precision.
        groups = []
        for entry in result:
            last = groups[-1] if groups else None
            if (
                last
                and last[-1]["multiplicity"] == entry["multiplicity"]
                and abs(last[-1]["state"]["energy"] - entry["state"]["energy"]) < 1e-3
            ):
                last.append(entry)
            else:
                groups.append([entry])
        for group in groups:
            irrep = None
            if symmetry is not None and closed:
                irrep = state_symmetry(
                    symmetry,
                    [
                        [
                            (c["occupied"], c["virtual"], c["amplitude"])
                            for c in entry["state"]["configurations"]
                            if c["direction"] == "->"
                        ]
                        for entry in group
                    ],
                )
            for entry in group:
                multiplicity = entry["multiplicity"]
                entry["term"] = f"$^{{{multiplicity}}}{irrep.label}$" if irrep is not None and multiplicity else ""
                if not closed or multiplicity is None:
                    entry["selection"] = None
                elif multiplicity != 1:
                    entry["selection"] = (False, "spin")
                elif irrep is None:
                    entry["selection"] = None
                elif irrep.label in symmetry.group.dipole:
                    entry["selection"] = (True, f"${symmetry.group.dipole[irrep.label]}$")
                else:
                    entry["selection"] = (False, "")
                # The character of the transitions holding most of the weight.
                shares = {}
                for configuration in entry["configurations"]:
                    shares[configuration["character"]] = (
                        shares.get(configuration["character"], 0) + configuration["weight_percent"]
                    )
                total = sum(shares.values())
                leading = sorted(shares.items(), key=lambda item: -item[1])
                if not leading or "" in shares:
                    entry["character"] = ""
                elif leading[0][1] >= 0.7 * total:
                    entry["character"] = leading[0][0]
                else:
                    entry["character"] = ", ".join(name for name, share in leading if share >= 0.2 * total)
        return result

    @_hovered
    def spectrum_chart(self, number):
        """Stick spectrum of the excited states against wavelength: each state a rule from zero to its oscillator
        strength, over the ultraviolet, visible and infrared regions.
        """
        data = pd.DataFrame(
            [
                dict(
                    state=entry["name"],
                    wavelength=entry["state"]["wavelength"],
                    oscillator=entry["state"]["oscillator"],
                    excitation=entry["state"]["energy"],
                    spectral_region=_region(entry["state"]["wavelength"], TEXT["spectral-regions"]["uv"]),
                    series=message("chart-oscillator-strength"),
                )
                for entry in self.states(number)
            ]
        )
        color = _series(message("chart-oscillator-strength"))
        sticks = _chart(data).encode(
            x=alt.X(f"{PLOT}wavelength:Q", scale=margin()),
            y=alt.Y(f"{PLOT}oscillator:Q"),
            color=color,
            tooltip=[
                PLOT + "state",
                alt.Tooltip(f"{PLOT}excitation:Q", format=".4f"),
                alt.Tooltip(f"{PLOT}wavelength:Q", format=".2f"),
                alt.Tooltip(f"{PLOT}oscillator:Q", format=".4f"),
                alt.Tooltip(f"{PLOT}spectral_region:N"),
            ],
        )
        return alt.layer(
            sticks.mark_rule(strokeWidth=2, clip=True).encode(y2=alt.datum(0)),
            *_regions("wavelength", data.wavelength.min(), data.wavelength.max(), TEXT["spectral-regions"]["uv"]),
        )

    def configurations_chart(self, number):
        """Weights of every excited state's transitions between orbital sets, stacked per state, coloured by transition
        without a legend: the hover box of a segment gives its state's name, symmetry, dipole selection, excitation
        energy, wavelength and oscillator strengths, and its transition's character and weight; fields that no state
        fills are left out.
        """
        job = self.jobs[number - 1]
        velocity = {row["state"]: row["oscillator"] for row in job["velocity_moments"]}
        states = self.states(number)
        selections = {True: message("dipole-allowed"), False: message("dipole-forbidden")}
        data = pd.DataFrame(
            [
                dict(
                    state=entry["name"],
                    term=entry["term"],
                    selection=(
                        ""
                        if not entry["selection"]
                        else "Spin-forbidden"
                        if entry["selection"][1] == "spin"
                        else ", ".join(filter(None, (selections[entry["selection"][0]], entry["selection"][1])))
                    ),
                    excitation=entry["state"]["energy"],
                    wavelength=entry["state"]["wavelength"],
                    oscillator=entry["state"]["oscillator"],
                    velocity=velocity.get(entry["state"]["state"]),
                    spin_squared=entry["state"]["spin_squared"],
                    transition=configuration["transition"],
                    character=configuration["character"],
                    weight_percent=configuration["weight_percent"],
                )
                for entry in states
                for configuration in entry["configurations"]
            ]
        )
        filled = [
            name
            for name in ("term", "selection", "velocity", "spin_squared", "character")
            if data[name].notna().any() and data[name].astype(bool).any()
        ]
        formats = {
            "excitation": ".4f",
            "wavelength": ".2f",
            "oscillator": ".4f",
            "velocity": ".4f",
            "spin_squared": ".4f",
            "weight_percent": ".1f",
        }
        fields = [
            "state",
            "term",
            "selection",
            "excitation",
            "wavelength",
            "oscillator",
            "velocity",
            "spin_squared",
            "transition",
            "character",
            "weight_percent",
        ]
        tooltip = [
            alt.Tooltip(f"{PLOT}{name}:Q", format=formats[name]) if name in formats else PLOT + name
            for name in fields
            if name not in ("term", "selection", "velocity", "spin_squared", "character") or name in filled
        ]
        order = [entry["name"] for entry in states]
        # Transitions in order of first appearance, each in a colour of its own however many there are.
        transitions = list(dict.fromkeys(data.transition))
        return (
            _chart(data)
            .mark_bar()
            .encode(
                x=_nominal("state", order),
                y=alt.Y(f"{PLOT}weight_percent:Q", stack="zero"),
                color=alt.Color(
                    f"{PLOT}transition:N",
                    legend=None,
                    scale=alt.Scale(domain=transitions, range=_distinct_colors(len(transitions))),
                ),
                tooltip=tooltip,
            )
        )

    def nto_viewer(self, number, isovalue=0.02, spacing=0.2):
        """The dominant hole and particle natural transition orbitals of a job that saved them, with the pair weight;
        None without their checkpoint.
        """
        path = self._job_checkpoint(number)
        if not path:
            return None
        records = _records(path)
        occupied = int(records["Number of alpha electrons"])
        weights = np.asarray(records["Alpha Orbital Energies"], dtype=float)
        orbitals = [
            (message("nto-orbital-title", role=role, symbol=symbol, weight=f"{weights[index]:.3f}"), index, "alpha")
            for role, symbol, index in (
                (message("nto-hole"), "h", occupied - 1),
                (message("nto-particle"), "p", occupied),
            )
        ]
        # Each NTO's composition on the atoms, which colours them and draws the 2D map, as for canonical orbitals.
        shares, momenta = self._orbital_shares(path, orbitals)
        return self._orbital_viewer(
            path,
            orbitals,
            quantity("nto-amplitude"),
            "NTO amplitude",
            r"\phi",
            isovalue,
            spacing,
            shares,
            momenta=momenta,
        )

    def transition_densities(self, number, spacing=0.2, bounds=None):
        """Hole and particle densities of a job that saved its NTOs, from ``_transition_cached``; None without their
        checkpoint.
        """
        if not self.jobs[number - 1]["nto_particles"]:
            return None
        path = self._job_checkpoint(number)
        return _transition_cached(path, spacing, bounds) if path else None

    def charge_transfer_table(self, number):
        r"""Charge-transfer descriptors of the excitation from its hole and particle densities.

        The difference density is split into its gain :math:`\rho_{+}` and loss :math:`\rho_{-}`; their integral is the transferred charge
        :math:`q_{\mathrm{CT}}` and their centroids are :math:`d_{\mathrm{CT}}` apart (Le Bahers, Adamo and Ciofini, J. Chem. Theory Comput. 7, 2498
        (2011)). The hole and particle centroids give the distance :math:`D`, and :math:`\int\sqrt{\rho_{\mathrm{h}}\rho_{\mathrm{p}}}\,\mathrm{d}\mathbf{r}` their
        overlap.
        """
        origin, axes, _, hole, particle, pairs, total = self.transition_densities(number)
        found = descriptors(origin, axes, hole, particle)
        charge, distance, separation, overlap = (
            found["transferred"],
            found["transfer_distance"],
            found["separation"],
            found["overlap"],
        )
        dipole = (charge * ureg.elementary_charge * distance * ureg.angstrom).to("debye").magnitude
        return quantities_table(
            [
                (
                    message("ct-centroid-distance"),
                    _value(separation, "angstrom", 4),
                    message("ct-centroid-distance-meaning"),
                ),
                (message("ct-overlap"), _number(overlap, 4), message("ct-overlap-meaning")),
                (message("ct-charge"), _value(charge, "elementary_charge", 4), message("ct-charge-meaning")),
                (message("ct-distance"), _value(distance, "angstrom", 4), message("ct-distance-meaning")),
                (message("ct-dipole"), _value(dipole, "debye", 4), ""),
                (message("ct-spread"), _value(found["spread"], "angstrom", 4), message("ct-spread-meaning")),
                (
                    message("ct-separation-index"),
                    _value(found["separation_index"], "angstrom", 4),
                    message("ct-separation-index-meaning"),
                ),
                (
                    message("ct-nto-pairs"),
                    message("ct-nto-pairs-value", pairs=pairs, total=f"{total:.4f}"),
                    message("ct-nto-pairs-meaning"),
                ),
            ]
        )

    @staticmethod
    def _density_viewer(surfaces, fields, origin, axes, atoms, isovalue):
        r"""A viewer of density fields, blue where electrons leave and red where they arrive at :math:`\pm` ``isovalue``,
        whose atoms carry each field's change in charge, :math:`\Delta q_A=-\int_A\Delta\rho\,\mathrm{d}\mathbf{r}` over the
        region nearer atom :math:`A` than any other, as the charge-change view integrates it: the toolbar colours the
        atoms by it in the charge colours, red where electrons arrive, and the 2D drawing maps it.

        Args:
            surfaces: The fields' surfaces by snapshot title.
            fields: The fields' values on their common grid, in the order of ``surfaces``.
            origin: The grid's origin in bohr.
            axes: The grid's axes in bohr.
            atoms: The grid's atoms, as ``CubeGrid`` holds them.
            isovalue: The level of the colour scale, in electrons per cubic bohr.

        Returns:
            The ``VolumeViewer``.
        """
        shares = []
        for values in fields:
            changes = -_atom_integrals(origin, axes, atoms, values)
            texts = [rf"$\Delta q={{{change:+.3f}}}\,{unit_latex('elementary_charge')}$" for change in changes]
            shares.append((changes, texts, "charge"))
        return VolumeViewer(
            surfaces,
            color_range=(-isovalue, isovalue),
            colors=("#2b6cb0", "#d7301f"),
            opacity=0.85,
            color_label=quantity("density-change-field"),
            field_name=message("field-density-change"),
            field_symbol=r"\Delta\rho",
            field_unit=unit_latex("bohr ** -3"),
            atom_shares=shares,
            atom_label=quantity("charge-change"),
            # The charge colours: red where electrons arrive, a negative change, as the surfaces show it.
            atom_colors=("#d7301f", "#ffffff", "#2b6cb0"),
            atom_signed=True,
            display_label=message("viewer-show"),
            display_options=(
                message("viewer-show-density"),
                message("viewer-show-density-charges"),
                message("viewer-show-charges"),
            ),
        )

    def transition_density_viewer(self, number, isovalue=0.001, spacing=0.2):
        r"""The electron density the excitation removes, adds and moves on the molecule, chosen in the snapshot
        selector: the loss :math:`-\rho_{\mathrm{h}}`, the gain :math:`\rho_{\mathrm{p}}` and their sum, the difference density, at :math:`\pm` ``isovalue``.

        The fields come from a grid as fine as the orbital views', over the box where either density reaches an
        eighth of the isovalue on the coarser grid of the descriptors, so the viewer's settings can move the surfaces
        down to an eighth of the isovalue or render the density as a volume that fades out inside the box.
        """
        origin, axes, _, hole, particle, _, _ = self.transition_densities(number)
        step = np.diag(axes)
        inside = np.argwhere(np.maximum(hole, particle) >= isovalue / 8)
        bounds = (origin + (inside.min(axis=0) - 3) * step, origin + (inside.max(axis=0) + 3) * step)
        origin, axes, atoms, hole, particle, _, _ = self.transition_densities(number, spacing, bounds)
        fields = {
            message("density-loss"): -hole.astype(float),
            message("density-gain"): particle.astype(float),
            message("density-difference"): particle.astype(float) - hole.astype(float),
        }
        # Each field at the level whose surfaces hold DENSITY_SHARE of its magnitude; isovalue sets only the box.
        surfaces = {
            title: VolumeSurface.enclosing(CubeGrid(origin, axes, atoms, values), DENSITY_SHARE)
            for title, values in fields.items()
        }
        # Blue where electrons leave, red where they arrive, as red marks negative charge in the charge views.
        return self._density_viewer(surfaces, list(fields.values()), origin, axes, atoms, isovalue)

    def transition_charges_viewer(self, number):
        """Each atom's change in charge on excitation, minus the difference density integrated over the region
        nearest its nucleus, drawn on the molecule in the charge colours.
        """
        origin, axes, atoms, hole, particle, _, _ = self.transition_densities(number)
        difference = particle.astype(float) - hole.astype(float)
        changes = -_atom_integrals(origin, axes, atoms, difference)
        return self._charge_viewer(number, list(changes), quantity("charge-change"), r"\Delta q")

    def transition_sets(self, number, threshold=10):
        """Orbital sets that a transition of at least ``threshold`` percent of some excited state's weight leaves or
        enters, as pairs of their spin channel (alpha for a restricted job) and the set, in order of channel and energy.
        """
        used = {
            (spin or "alpha", id(s))
            for entry in self.states(number)
            for configuration in entry["configurations"]
            if configuration["weight_percent"] >= threshold
            for spin, *pair in [configuration["sets"]]
            for s in pair
        }
        return [
            (spin, s) for spin in self.spins(number) for s in self.orbital_sets(number, spin) if (spin, id(s)) in used
        ]

    def transition_orbitals_viewer(self, number, isovalue=0.02, spacing=0.2):
        """Every orbital of the sets the excited states' main transitions use, with its label, component, character
        and energy; None without the job's checkpoint.
        """
        path = self._job_checkpoint(number)
        if not path or self.jobs[number - 1]["nto_particles"]:
            return None
        chosen, spins = self.transition_sets(number), self.spins(number)
        entries = [
            (title, index, spin)
            for spin in spins
            for title, index in _orbital_entries([s for channel, s in chosen if channel == spin])
        ]
        # Each orbital's composition on the atoms, which colours them and draws the 2D map, as for the frontier orbitals.
        shares, momenta = self._orbital_shares(path, entries, chosen)
        return self._orbital_viewer(
            path,
            entries,
            quantity("orbital-amplitude"),
            message("field-orbital-amplitude"),
            r"\psi",
            isovalue,
            spacing,
            shares,
            spins=spins if len(spins) > 1 else None,
            momenta=momenta,
        )

    def _state_groups(self, number):
        """The states grouped into degenerate levels, as ``states`` returns them, with each level's name."""
        levels = []
        for entry in self.states(number):
            last = levels[-1] if levels else None
            if (
                last
                and last[-1]["multiplicity"] == entry["multiplicity"]
                and last[-1]["term"] == entry["term"]
                and abs(last[-1]["state"]["energy"] - entry["state"]["energy"]) < 1e-3
            ):
                last.append(entry)
            else:
                levels.append([entry])
        return levels

    def _level_name(self, level):
        """Name of a degenerate level, such as S_3/S_4."""
        return "$" + "/".join(entry["name"].strip("$") for entry in level) + "$"

    def state_densities(self, number, spacing=0.25, bounds=None):
        """Hole and particle densities of every degenerate level of excited states, from ``_state_densities``;
        None without the job's checkpoint.
        """
        path = self._job_checkpoint(number)
        if not path or self.jobs[number - 1]["nto_particles"]:
            return None
        groups = [
            [
                [
                    (c["occupied"], c["virtual"], c["amplitude"])
                    for c in entry["state"]["configurations"]
                    if c["direction"] == "->"
                ]
                for entry in level
            ]
            for level in self._state_groups(number)
        ]
        return _state_densities(str(path), groups, spacing, bounds)

    def state_transfer_table(self, number):
        """How far each level of excited states moves charge: the transferred charge q_CT, the distance d_CT it moves
        and the hole-particle overlap, from the densities of ``state_densities``.
        """
        origin, axes, _, holes, particles = self.state_densities(number)
        rows = []
        for level, hole, particle in zip(self._state_groups(number), holes, particles):
            found = descriptors(origin, axes, hole, particle)
            rows.append(
                dict(
                    state=self._level_name(level),
                    term=level[0]["term"],
                    transferred=found["transferred"],
                    transfer_distance=found["transfer_distance"],
                    overlap=found["overlap"],
                )
            )
        table = pd.DataFrame(rows)
        return table if table.term.astype(bool).any() else table.drop(columns="term")

    def state_density_viewer(self, number, isovalue=0.001, spacing=0.2):
        r"""The difference density of every level of excited states, one snapshot each: blue where electrons leave,
        red where they arrive, at :math:`\pm` ``isovalue``, over the box where any level's densities reach an eighth of it.
        """
        origin, axes, _, holes, particles = self.state_densities(number)
        step = np.diag(axes)
        inside = np.argwhere(np.maximum(holes.max(axis=0), particles.max(axis=0)) >= isovalue / 8)
        bounds = (origin + (inside.min(axis=0) - 3) * step, origin + (inside.max(axis=0) + 3) * step)
        origin, axes, atoms, holes, particles = self.state_densities(number, spacing, bounds)
        surfaces, fields = {}, []
        for level, hole, particle in zip(self._state_groups(number), holes, particles):
            term = f", {level[0]['term']}" if level[0]["term"] else ""
            values = particle.astype(float) - hole.astype(float)
            fields.append(values)
            surfaces[self._level_name(level) + term] = VolumeSurface.enclosing(
                CubeGrid(origin, axes, atoms, values), DENSITY_SHARE
            )
        return self._density_viewer(surfaces, fields, origin, axes, atoms, isovalue)

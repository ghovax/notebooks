"""Harmonic modes, their symmetry and spectra, and thermochemistry."""

import re

import altair as alt
import numpy as np
import pandas as pd
from runflow.checkpoints import Vibrations
from runflow.results import ureg
from runflow.symmetry import point_group

from calcpages.charts import _chart, _hovered, _mode_tooltip, _nominal, _region, _regions, _series, margin
from calcpages.i18n import message
from calcpages.labels import PLOT, quantity, unit_latex
from calcpages.notation import _irrep, _lower_label, _to_ev, _to_kj, _value
from calcpages.text import TEXT


class VibrationsPart:
    """Harmonic modes, their symmetry and spectra, and thermochemistry. A part of :class:`calcpages.calculation.Calculation`."""

    def mode_symmetry(self, number):
        """Point group of a frequency job's geometry and the irreducible representation of every harmonic mode in it,
        in lower case as for orbitals, degenerate modes together; None when no mode set carries one representation.

        Each operation moves every atom's displacement to the atom it moves to and rotates it; the character of a set
        of degenerate modes is the trace of that action within the set.
        """
        if number in self._mode_symmetry:
            return self._mode_symmetry[number]
        job = self.jobs[number - 1]
        if not job["frequency_sets"] or not job["geometries"]:
            return None
        modes, geometry = job["frequency_sets"][-1], job["geometries"][-1]
        if any(len(mode["displacements"]) != len(geometry["atomic_numbers"]) for mode in modes):
            return None
        coordinates = (np.asarray(geometry["vectors"], dtype=float) * ureg.angstrom).to("bohr").magnitude
        group = point_group(np.asarray(geometry["atomic_numbers"]), coordinates)
        displacements = np.asarray([mode["displacements"] for mode in modes], dtype=float)
        # Modes within 0.5 cm-1 of the previous one are taken as degenerate partners.
        sets = []
        for index, mode in enumerate(modes):
            if sets and abs(mode["frequency"] - modes[sets[-1][-1]]["frequency"]) < 0.5:
                sets[-1].append(index)
            else:
                sets.append([index])
        labels = [None] * len(modes)
        for indices in sets:
            vectors = displacements[indices].reshape(len(indices), -1).T
            inverse, characters = np.linalg.pinv(vectors), []
            for matrix, permutation in zip(group.operations, group.permutations):
                moved = np.zeros_like(displacements[indices])
                moved[:, permutation, :] = displacements[indices] @ matrix.T
                characters.append(np.trace(inverse @ moved.reshape(len(indices), -1).T))
            irrep = group.assign(np.array(characters), len(indices))
            if irrep is None:
                self._mode_symmetry[number] = None
                return None
            for index in indices:
                labels[index] = irrep
        self._mode_symmetry[number] = (group, labels)
        return self._mode_symmetry[number]

    def modes_table(self, number):
        """Harmonic modes of a linked job with their reduced masses, force constants and IR intensities; symmetry in
        the point group of the geometry when ``mode_symmetry`` finds it, otherwise as Gaussian printed it.
        """
        modes = self.jobs[number - 1]["frequency_sets"][-1]
        found = self.mode_symmetry(number)
        symmetry = (
            [f"${irrep.orbital()}$" for irrep in found[1]] if found else [_irrep(mode["symmetry"]) for mode in modes]
        )
        table = pd.DataFrame(
            [
                dict(
                    mode=mode["mode"],
                    symmetry=label,
                    frequency=mode["frequency"],
                    reduced_mass=mode["reduced_mass"],
                    force_constant=mode["force_constant"],
                    intensity=mode["ir_intensity"],
                )
                for mode, label in zip(modes, symmetry)
            ]
        )
        # Under a single irreducible representation, as without symmetry, the column says nothing.
        return table.drop(columns="symmetry") if table.symmetry.nunique() == 1 else table

    @_hovered
    def ir_chart(self, number):
        """IR stick spectrum of the real harmonic modes, over the usual spectral regions; each stick's hover gives all
        that is known of its mode.
        """
        table = self.modes_table(number)
        table = table[table.frequency >= 0]
        table = table.assign(spectral_region=[_region(value, TEXT["ir-regions"]) for value in table.frequency])
        sticks = (
            _chart(table.assign(series=message("chart-infrared-intensity")))
            .mark_rule(strokeWidth=2)
            .encode(
                x=alt.X(f"{PLOT}frequency:Q"),
                y=alt.Y(f"{PLOT}intensity:Q"),
                y2=alt.datum(0),
                color=_series(message("chart-infrared-intensity")),
                tooltip=_mode_tooltip(table) + [alt.Tooltip(f"{PLOT}spectral_region:N")],
            )
        )
        # A thin stick is hard to reach, so a wide transparent one takes the pointer.
        hover = sticks.mark_rule(strokeWidth=12, opacity=0)
        regions = _regions("frequency", 0, table.frequency.max(), TEXT["ir-regions"]) if len(table) else []
        return alt.layer(sticks, hover, *regions)

    def mode_frequencies_chart(self, number):
        """All harmonic modes in frequency order, distinguishing imaginary wavenumbers."""
        table = self.modes_table(number).sort_values(["frequency", "mode"], kind="stable").copy()
        table["mode"] = table["mode"].astype(str)
        table["mode_character"] = np.where(
            table.frequency < 0, message("chart-imaginary"), message("chart-non-imaginary")
        )
        present = [
            label
            for label in (message("chart-non-imaginary"), message("chart-imaginary"))
            if label in table.mode_character.values
        ]
        base = _chart(table).encode(
            x=alt.X(
                f"{PLOT}mode:N",
                sort=table["mode"].tolist(),
                scale=alt.Scale(domain=table["mode"].tolist()),
                axis=alt.Axis(labelExpr="datum.value", labelOverlap="greedy", labelLimit=0),
            ),
            y=alt.Y(f"{PLOT}frequency:Q"),
            color=alt.Color(
                f"{PLOT}mode_character:N",
                scale=alt.Scale(
                    domain=[message("chart-non-imaginary"), message("chart-imaginary")], range=["#3976b6", "#f58518"]
                ),
                legend=alt.Legend(values=present),
            ),
            tooltip=_mode_tooltip(table),
        )
        levels = base.mark_tick(thickness=3, size=12, orient="horizontal", clip=True)
        hover = base.mark_point(opacity=0, size=256)
        return alt.layer(levels, hover)

    def infrared_rule(self, number):
        """Markdown on which modes can absorb in the infrared, from the point group of the geometry; empty without it."""
        found = self.mode_symmetry(number)
        if not found or found[0].order == 1:
            return ""
        group = found[0]
        active = ", ".join(f"${_lower_label(label)}$ $({axes})$" for label, axes in group.dipole.items())
        return message("vibrations-infrared-rule", group=group.name, active=active)

    def shown_modes(self, number):
        """Modes the viewer animates, in mode order: every imaginary mode, the six lowest real modes and the four
        most intense in the infrared.
        """
        modes = self.jobs[number - 1]["frequency_sets"][-1]
        real = [mode for mode in modes if mode["frequency"] >= 0]
        chosen = {mode["mode"] for mode in modes if mode["frequency"] < 0}
        chosen |= {mode["mode"] for mode in real[:6]}
        chosen |= {mode["mode"] for mode in sorted(real, key=lambda mode: -(mode["ir_intensity"] or 0))[:4]}
        return [mode for mode in modes if mode["mode"] in chosen]

    def mode_frames(self, number):
        """Animated frames of each shown mode at a 0.6 angstrom largest atomic excursion, by snapshot title."""
        job = self.jobs[number - 1]
        modes = job["frequency_sets"][-1]
        geometry = job["geometries"][-1]
        vibrations = Vibrations(
            numbers=np.asarray(geometry["atomic_numbers"]),
            coordinates=np.asarray(geometry["vectors"]) * ureg.angstrom,
            frequencies=[mode["frequency"] for mode in modes],
            masses=[mode["reduced_mass"] for mode in modes],
            constants=[mode["force_constant"] for mode in modes],
            intensities=[mode["ir_intensity"] for mode in modes],
            modes=np.asarray([mode["displacements"] for mode in modes], dtype=float),
        )
        frames = {}
        for mode in self.shown_modes(number):
            title = message(
                "vibrations-mode-title",
                mode=mode["mode"],
                frequency=f"{mode['frequency']:.2f}",
                unit=unit_latex("1 / centimeter"),
            )
            frames[title] = vibrations.trajectory(mode["mode"], amplitude=0.6 * ureg.angstrom, steps=21)
        return frames

    def thermochemistry_table(self, number):
        """Gaussian's thermochemistry summary at its temperature and pressure."""
        thermo = self.jobs[number - 1]["thermochemistry"]
        rows = [
            (quantity("temperature"), thermo["temperature"], "K"),
            (quantity("pressure"), thermo["pressure"], "atm"),
            (quantity("zero-point-correction"), thermo["zero_point"], "hartree"),
            (quantity("thermal-correction-energy"), thermo["thermal_energy"], "hartree"),
            (quantity("thermal-correction-enthalpy"), thermo["thermal_enthalpy"], "hartree"),
            (quantity("thermal-correction-gibbs"), thermo["thermal_gibbs"], "hartree"),
            (quantity("energy-zero-point-total"), thermo["energy_zero_point"], "hartree"),
            (quantity("energy-thermal-total"), thermo["energy_thermal"], "hartree"),
            (quantity("enthalpy-total-symbol"), thermo["enthalpy"], "hartree"),
            (quantity("gibbs-total-symbol"), thermo["gibbs"], "hartree"),
            (quantity("symmetry-number"), thermo["symmetry_number"], None),
        ]
        return pd.DataFrame(
            [(name, _value(value, unit, 10)) for name, value, unit in rows if value is not None],
            columns=["quantity", "value"],
        )

    def thermal_components(self, number):
        """Gaussian's thermal contributions by quantity, with the printed vibrational modes in a subtable."""
        rows = self.jobs[number - 1]["thermal_components"]
        aggregates = {
            row["component"].lower(): row
            for row in rows
            if not re.fullmatch(r"(?:vibration\s+)?\d+", row["component"], re.I)
        }
        modes = [
            (int(match.group(1)), row)
            for row in rows
            if (match := re.fullmatch(r"(?:vibration\s+)?(\d+)", row["component"], re.I))
        ]
        table = []
        for key, field in (("thermal_energy", "energy"), ("heat_capacity", "heat_capacity"), ("entropy", "entropy")):
            values = {"quantity": quantity(key)}
            # Gaussian prints the energy contributions in kilocalories per mole; the other two stay in calories.
            shown = _to_kj if key == "thermal_energy" else (lambda value: value)
            for name in ("total", "electronic", "translational", "rotational"):
                if (row := aggregates.get(name)) is not None and row.get(field) is not None:
                    values["thermal_" + name] = shown(row[field])
            vibrational = aggregates.get("vibrational")
            if vibrational is not None and vibrational.get(field) is not None:
                # The aggregate and its printed modes share one nested group under the Vibrational heading.
                vibrational_values = {message("thermal-aggregate"): shown(vibrational[field])}
                vibrational_values.update(
                    {rf"$k={mode}$": shown(row[field]) for mode, row in modes if row.get(field) is not None}
                )
                values["thermal_vibrational"] = pd.DataFrame([vibrational_values])
            table.append(values)
        return pd.DataFrame(
            table,
            columns=[
                "quantity",
                "thermal_total",
                "thermal_electronic",
                "thermal_translational",
                "thermal_rotational",
                "thermal_vibrational",
            ],
        )

    def thermochemistry_levels(self, number):
        """Reported energies in eV relative to the inferred electronic-structure reference."""
        thermo = self.jobs[number - 1]["thermochemistry"]
        pairs = [
            ("energy_zero_point", "zero_point"),
            ("energy_thermal", "thermal_energy"),
            ("enthalpy", "thermal_enthalpy"),
            ("gibbs", "thermal_gibbs"),
        ]
        reference = next(
            (
                thermo[total] - thermo[correction]
                for total, correction in pairs
                if thermo.get(total) is not None and thermo.get(correction) is not None
            ),
            None,
        )
        if reference is None:
            return pd.DataFrame(columns=["level", "relative_energy", "absolute_energy"])
        values = [
            (r"$E_{\mathrm{el}}$", reference),
            (r"$E_{\mathrm{el}}+E_{\mathrm{ZPE}}$", thermo.get("energy_zero_point")),
            (r"$U$", thermo.get("energy_thermal")),
            (r"$H$", thermo.get("enthalpy")),
            (r"$G$", thermo.get("gibbs")),
        ]
        return pd.DataFrame(
            [
                dict(level=label, relative_energy=_to_ev(value - reference), absolute_energy=_to_ev(value))
                for label, value in values
                if value is not None
            ]
        )

    def thermochemistry_chart(self, number):
        """Thermodynamic energy levels relative to the electronic-structure energy."""
        data = self.thermochemistry_levels(number)
        if len(data) < 2:
            return None
        data = data.rename(columns={"level": "thermo_level", "relative_energy": "thermo_relative_energy"})
        return (
            _chart(data)
            .mark_tick(thickness=3, size=38)
            .encode(
                x=_nominal("thermo_level", list(data.thermo_level)),
                y=alt.Y(f"{PLOT}thermo_relative_energy:Q", scale=margin()),
                tooltip=[
                    alt.Tooltip(f"{PLOT}thermo_level:N"),
                    alt.Tooltip(f"{PLOT}thermo_relative_energy:Q", format=".6f"),
                    alt.Tooltip(f"{PLOT}absolute_energy:Q", format=".6f"),
                ],
            )
        )

"""The input of each linked job: Link 0 commands, route, IOps, coordinate sections, molecule and starting geometry."""

import json
from datetime import datetime

import pandas as pd
from runflow.inputs.gic import evaluate, merge_definitions
from runflow.inputs.sections import PRINTED, evaluate_modredundant, merge_modredundant
from runflow.route import route_keywords
from runflow.text import identifier, split_items, unwrap
from runflow.units import ELEMENTS

from calcpages.coordinates import (
    _action_icons,
    _coordinate_kind,
    _coordinate_value,
    _gic_group,
    _gic_row,
    _modredundant_definition,
    _modredundant_settings,
)
from calcpages.fields import _frames
from calcpages.i18n import message, zone
from calcpages.keywords import (
    _basis_name,
    _iop_rows,
    _keyword_name,
    _link,
    _link0_value,
    _manual,
    _method_name,
    _options_table,
)
from calcpages.labels import LOTUS_SETTINGS, quantity
from calcpages.notation import (
    _duration,
    _formula,
    _framework,
    _moment,
    _number,
    _point_group,
    _title_math,
    _value,
    quantities_table,
)
from calcpages.text import GAUSSIAN, TEXT, gaussian_entry


class InputsPart:
    """The input of each linked job: Link 0 commands, route, IOps, coordinate sections, molecule and starting geometry. A part of :class:`calcpages.calculation.Calculation`."""

    def links_table(self, number, index=0):
        """Report the selected link from a Gaussian job's ordered link records.

        Args:
            number: One-based linked-job number.
            index: Zero-based position in its links, including repeated executions.

        Returns:
            Commands for the initial link, or timing details for an executable link.
        """
        links = self.jobs[number - 1]["links"]
        link = links[index]
        if "commands" not in link:
            rows = [(message("link-row-link"), _value(link["index"]))]
            rows += [
                (label, _duration(link[key]))
                for key, label in (("wall_time", message("link-wall-time")), ("cpu_time", message("link-cpu-time")))
                if link.get(key) is not None
            ]
            if link.get("finished"):
                rows.append(
                    (
                        message("link-finished"),
                        _moment(datetime.strptime(link["finished"], "%a %b %d %H:%M:%S %Y").replace(tzinfo=zone())),
                    )
                )
            return quantities_table(rows)
        definitions = GAUSSIAN["link0"]
        rows, present = [], set()
        for name, value in link["commands"].items():
            key = identifier(name)
            present.add(key)
            definition = definitions.get(key, {})
            shown = bool(value) if key in ("chk", "oldchk") else _link0_value(key, value)
            rows.append((_link(definition.get("name", name), "link0"), shown, definition.get("meaning", "")))
        for key in ("chk", "oldchk"):
            if key not in present:
                definition = definitions[key]
                rows.append((_link(definition["name"], "link0"), False, definition["meaning"]))
        return pd.DataFrame(rows, columns=["command", "value", "meaning"])

    def route_table(self, number):
        """Route keywords of one linked job: each keyword with its meaning and a subtable of its options."""
        rows = []
        for name, options in route_keywords(self.jobs[number - 1]["route"]):
            if "/" in name and not options:
                method, basis = name.split("/", 1)
                entry = gaussian_entry("basis-sets", basis) or {}
                basis_label = entry.get("name", basis)
                page, meaning = _manual(method)
                rows += [
                    (_link(_method_name(method), page), meaning or message("route-method"), None),
                    (
                        _link(basis_label, "basissets"),
                        entry.get("meaning", message("basis-set-meaning")),
                        None,
                    ),
                ]
                continue
            # IOps have a table of their own (iop_table).
            if name.lower() == "iop":
                continue
            page, meaning = _manual(name)
            rows.append(
                (_link(_keyword_name(name), page), meaning or "", _options_table(name, options) if options else None)
            )
        table = pd.DataFrame(rows, columns=["keyword", "meaning", "options"])
        # The Options column only when some keyword has options.
        return table if table.options.notna().any() else table.drop(columns="options")

    def iop_table(self, number):
        """The IOps of one linked job's route, each with its value and meaning from the IOps Reference, and for a DFT
        weight IOp a subtable of the weights it sets; None when the route sets none.
        """
        rows = [
            row
            for name, options in route_keywords(self.jobs[number - 1]["route"])
            if name.lower() == "iop"
            for option in split_items(unwrap(options))
            for row in _iop_rows(*option.partition("=")[::2])
        ]
        if not rows:
            return None
        table = pd.DataFrame(rows, columns=["iop", "value", "meaning", "weights"])
        return table if table.weights.notna().any() else table.drop(columns="weights")

    def _input_job(self, number):
        """The input's definition of one linked job; None when the input is missing, unreadable or has fewer jobs."""
        jobs = getattr(self, "gaussian_input", None) or []
        return jobs[number - 1] if 0 < number <= len(jobs) else None

    def _result_job(self, number):
        """One linked job as the Gaussian output records it; None without output for it."""
        jobs = (self.result or {}).get("jobs", []) if self.program == "gaussian" else []
        return jobs[number - 1] if 0 < number <= len(jobs) else None

    def gic_mode(self, number):
        """How the route of one linked job builds its generalized internal coordinates: read-all, add, automatic or
        old; None without a GIC option or input.
        """
        job = self._input_job(number)
        return job["gic"]["mode"] if job and job.get("gic") else None

    def gic_table(self, number, icons=None):
        """The GIC section of one linked job's input, lines of one form as one row: their labels, the equations that
        define them in LaTeX, what the coordinate measures, what the lines do, their settings as a subtable and the
        start value; None without a section.

        Args:
            number: One-based linked job.
            icons: Folder of the page's icons, drawing the coordinate and action columns as icons; words without one.

        Returns:
            The table, or None.
        """
        job = self._input_job(number)
        gic = job.get("gic") if job else None
        if not gic or not gic["entries"]:
            return None
        output = self._result_job(number)
        merged = merge_definitions(gic["entries"], output.get("internal_coordinates") or []) if output else []
        printed = {row["name"].lower(): row["value"] for row in merged if row["expression"] is not None}
        geometry = job["geometries"][0]["vectors"] if job["geometries"] else None
        computed = evaluate(gic["entries"], geometry) if geometry else {}
        groups = {}
        for entry in gic["entries"]:
            groups.setdefault(_gic_group(entry), []).append(entry)
        rows = [_gic_row(entries, printed, computed, icons) for entries in groups.values()]
        table = pd.DataFrame(rows, columns=["label", "definition", "coordinate", "action", "setting", "start"])
        return table.drop(
            columns=[name for name in ("definition", "coordinate", "setting", "start") if table[name].isna().all()]
        )

    def modredundant_table(self, number, icons=None):
        """The ModRedundant section of one linked job: each line's printed label, coordinate in LaTeX, what it
        measures, what it does, its settings as a subtable and its start value; None without a section.

        The lines are the input's, or those the log echoes when no input is retained. Start values are Gaussian's
        printed initial parameters when the output has them, else measured at the input geometry.

        Args:
            number: One-based linked job.
            icons: Folder of the page's icons, drawing the coordinate and action columns as icons; words without one.

        Returns:
            The table, or None.
        """
        job = self._input_job(number)
        output = self._result_job(number)
        section = job.get("modredundant") if job else None
        entries = section["entries"] if section else (output.get("modredundant_input") if output else None)
        if not entries:
            return None
        merged = merge_modredundant(entries, (output.get("internal_coordinates") or []) if output else [])
        geometry = job["geometries"][0]["vectors"] if job and job["geometries"] and section else None
        measured = evaluate_modredundant(entries, geometry) if geometry else [None] * len(entries)
        rows = []
        for entry, row, value in zip(entries, merged, measured):
            start = row["start"] if row["start"] is not None else value
            rows.append(
                (
                    f"`{row['name']}`" if row["name"] else None,
                    _modredundant_definition(entry),
                    _coordinate_kind(entry["measure"], entry["unit"], icons),
                    _action_icons([entry["action"]], icons),
                    _modredundant_settings(entry, start),
                    _coordinate_value(start),
                )
            )
        table = pd.DataFrame(rows, columns=["label", "definition", "coordinate", "action", "setting", "start"])
        return table.drop(columns=[name for name in ("label", "setting", "start") if table[name].isna().all()])

    def read_optimize_table(self, number):
        """The ReadOptimize rules of one linked job, each with what it does, and the atoms left to optimize; None
        without a section.
        """
        job = self._input_job(number)
        section = job.get("read_optimize") if job else None
        if not section:
            return None
        rows = []
        for rule in section["rules"]:
            if rule["selection"] == "none":
                rows.append(("`noatoms`", message("optimized-atoms-none")))
                continue
            name = ("" if rule["include"] else "not") + rule["selection"]
            rows.append(
                (
                    f"`{name}={','.join(rule['items'])}`",
                    message(
                        "optimized-atoms-include" if rule["include"] else "optimized-atoms-exclude",
                        selection=rule["selection"],
                        items=", ".join(rule["items"]),
                    ),
                )
            )
        atoms = section["atoms"]
        if atoms is not None:
            rows.append(
                (
                    message("optimized-atoms-result-label"),
                    message(
                        "optimized-atoms-result",
                        count=len(atoms),
                        atoms=", ".join(map(str, atoms)) or message("optimized-atoms-result-empty"),
                    ),
                )
            )
        return pd.DataFrame(rows, columns=["rule", "meaning"])

    def connectivity_table(self, number):
        """The connectivity section of one linked job: each atom that lists bonds, with its element and bonded atoms
        and their orders; None without a section.
        """
        job = self._input_job(number)
        records = job.get("connectivity") if job else None
        if not records:
            return None
        numbers = job["geometries"][0]["atomic_numbers"] if job["geometries"] else []
        element = lambda atom: ELEMENTS[numbers[atom - 1] - 1] if 0 < atom <= len(numbers) else None
        rows = [
            (
                record["atom"],
                element(record["atom"]) if record["atom"] else None,
                ", ".join(f"{bond['atom']} ({_bond_order(bond['order'])})" for bond in record["bonds"])
                + "".join(f" `{item}`" for item in record["unparsed"]),
            )
            for record in records
            if record["bonds"] or record["unparsed"]
        ]
        table = pd.DataFrame(rows, columns=["atom", "element", "bonds"])
        return table if table.element.notna().any() else table.drop(columns="element")

    def molecule_table(self, number):
        """Title, charge, multiplicity and where the job takes its geometry from."""
        job = self.jobs[number - 1]
        names = {name.lower(): options for name, options in route_keywords(job["route"])}
        geometry = names.get("geom", "").lower()
        source = (
            message("geometry-source-checkpoint")
            if any(word in geometry for word in ("allcheck", "check"))
            else message("geometry-source-input")
        )
        rows = []
        if job["archive"] and job["archive"]["title"]:
            rows.append((message("molecule-title"), _title_math(job["archive"]["title"])))
        if job["charge"] is not None:
            rows += [
                (quantity("molecular-charge"), _value(job["charge"])),
                (quantity("spin-multiplicity"), _value(job["multiplicity"])),
            ]
        rows.append((quantity("geometry-source"), source))
        further = (self._input_job(number) or {}).get("structures") or []
        for position, structure in enumerate(further, 2):
            rows.append(
                (
                    message("molecule-structure", position=position),
                    _title_math(structure["title"]) if structure["title"] else message("molecule-untitled"),
                )
            )
        return pd.DataFrame(rows, columns=["quantity", "value"])

    def system_table(self, number):
        """The system: formula, charge, spin, size, symmetry, electrons and solvent, each once; the method and basis are
        those of the input, shown with it.
        """
        job = self.jobs[number - 1]
        archive = job.get("archive") or {}
        electrons = job["electron_counts"] or []
        rows = [
            (message("system-formula"), _formula(archive["formula"]) if archive.get("formula") else ""),
            (quantity("molecular-charge"), _value(job.get("charge")) if job.get("charge") is not None else ""),
            (
                quantity("spin-multiplicity"),
                _value(job.get("multiplicity")) if job.get("multiplicity") is not None else "",
            ),
            (quantity("atom-count"), _value(job["atom_count"]) if job["atom_count"] else ""),
            (quantity("point-group-gaussian"), _point_group(job["point_group"]) if job["point_group"] else ""),
            (
                quantity("framework-group"),
                _framework(str(archive.get("properties", {}).get("PG", "")).partition(" ")[2])
                if " " in str(archive.get("properties", {}).get("PG", ""))
                else "",
            ),
            (
                quantity("point-group-geometry"),
                f"${self.symmetry(number).group.name}$" if self.symmetry(number) else "",
            ),
            (quantity("basis-functions"), _value(job["basis_count"]) if job["basis_count"] else ""),
            (quantity("independent-functions"), _value(job["independent_count"]) if job["independent_count"] else ""),
            (quantity("alpha-electrons"), _value(electrons[0]) if electrons else ""),
            (quantity("beta-electrons"), _value(electrons[1]) if len(electrons) > 1 else ""),
            (quantity("closed-shell"), job["closed_shell"] if job["closed_shell"] is not None else ""),
        ]
        solvents = dict.fromkeys(
            (entry["solvent"], entry["epsilon"], entry["epsilon_infinity"]) for entry in job["solvent"]["parameters"]
        )
        for solvent, epsilon, infinity in solvents:
            rows += [
                (quantity("solvent"), solvent),
                (quantity("static-permittivity"), _value(epsilon)),
                (quantity("optical-permittivity"), _value(infinity)),
            ]
        return pd.DataFrame([row for row in rows if row[1] != ""], columns=["quantity", "value"])

    def initial_geometry(self, number=1):
        """Starting atoms of a linked job as element symbols and Cartesian rows in angstrom, and their source.

        For Gaussian, the first geometry it printed for the job: what it read from the input in any
        molecule-specification format, or from the checkpoint. For Lotus, the folder's XYZ input.
        None when neither exists.
        """
        if self.jobs and self.jobs[number - 1]["geometries"]:
            geometry = self.jobs[number - 1]["geometries"][0]
            return (
                [ELEMENTS[n - 1] for n in geometry["atomic_numbers"]],
                geometry["vectors"],
                message("starting-geometry-printed") if self.result else message("starting-geometry-input"),
            )
        xyz = [path for path in self.inputs if path.suffix == ".xyz"]
        if xyz:
            lines = xyz[0].read_text().splitlines()
            rows = [line.split() for line in lines[2 : 2 + int(lines[0])] if line.strip()]
            # A prepared input declares its atom count before runflow writes the coordinates.
            if len(rows) == int(lines[0]):
                return [row[0] for row in rows], [list(map(float, row[1:4])) for row in rows], f"`{xyz[0].name}`"
        return None

    def coordinate_overlay(self, number=1, limit=12):
        """What the starting-geometry viewer draws of the coordinates the input's GIC or ModRedundant section defines:
        bonds as distances, angles and dihedrals as their measurements, each with a readout of its value; Cartesian and
        centroid terms are not drawn. Empty without such a section or input atoms.

        Args:
            number: One-based linked job.
            limit: Most coordinates drawn, so a long section does not cover the molecule.

        Returns:
            Keyword arguments of ``MolstarViewer``: ``distances``, ``angles``, ``readouts`` and ``dihedrals``, each
            only when not empty.
        """
        job = self._input_job(number)
        atom_count = len(job["geometries"][0]["atomic_numbers"]) if job and job["geometries"] else 0
        if not atom_count:
            return {}
        terms = [
            (term["function"], term["atoms"])
            for entry in ((job.get("gic") or {}).get("entries") or [])
            if entry["kind"] == "coordinate" and not entry.get("error")
            for term in entry.get("terms", [])
        ]
        terms += [
            (PRINTED[entry["type"]], entry["atoms"])
            for entry in ((job.get("modredundant") or {}).get("entries") or [])
            if entry["type"] in ("B", "A", "D") and entry["action"] not in ("remove", "kill")
        ]
        distances, angles, readouts, dihedrals, seen = [], [], [], [], set()
        for function, atoms in terms:
            if not atoms or not all(isinstance(atom, int) and 1 <= atom <= atom_count for atom in atoms):
                continue
            key = (function, tuple(min(atoms, atoms[::-1])))
            if key in seen:
                continue
            seen.add(key)
            subscript = ",".join(map(str, atoms))
            if function == "R" and len(atoms) == 2 and len(readouts) < limit:
                distances.append(list(atoms))
                readouts.append(
                    dict(kind="distance", atoms=list(atoms), label=f"r_{{{subscript}}}", unit=r"\text{\AA}")
                )
            elif function == "A" and len(atoms) == 3 and len(readouts) < limit:
                angles.append(list(atoms))
                readouts.append(dict(kind="angle", atoms=list(atoms), label=rf"\theta_{{{subscript}}}"))
            elif function == "D" and len(atoms) == 4 and len(readouts) + len(dihedrals) < limit:
                dihedrals.append(dict(atoms=list(atoms), label=rf"\tau_{{{subscript}}}"))
        overlay = dict(distances=distances, angles=angles, readouts=readouts, dihedrals=dihedrals)
        return {name: value for name, value in overlay.items() if value}

    def geometry_frame(self, number=1):
        """XYZ frame of the starting geometry."""
        symbols, coordinates, _ = self.initial_geometry(number)
        return _frames([ELEMENTS.index(symbol) + 1 for symbol in symbols], [coordinates])

    def _lotus_settings(self):
        """Lotus settings from the JSON comment line of the XYZ input, empty without them."""
        xyz = [path for path in self.inputs if path.suffix == ".xyz"]
        try:
            return json.loads(xyz[0].read_text().splitlines()[1])
        except (IndexError, ValueError):
            return {}

    def lotus_settings(self):
        """Lotus settings as a table, the method under its standard name, or None without settings."""
        settings = self._lotus_settings()
        if not settings:
            return None

        def shown(key, value):
            if key == "method":
                return TEXT["lotus"]["methods"].get(identifier(value), {}).get("name", f"`{value}`")
            if key == "basis":
                return _basis_name(value)
            if isinstance(value, bool):
                return value
            return f"`{value}`" if isinstance(value, str) else _value(value)

        return quantities_table(
            [
                (
                    LOTUS_SETTINGS.get(key, f"`{key}`"),
                    shown(key, value),
                    (gaussian_entry("basis-sets", value) or {}).get("meaning", "")
                    if key == "basis"
                    else (
                        TEXT["lotus"]["methods"].get(identifier(value), {}).get("description", "")
                        if key == "method"
                        else ""
                    ),
                )
                for key, value in settings.items()
            ]
        )


def _bond_order(order):
    """A bond order's name, such as aromatic for 1.5, or the number itself when it has none."""
    return next((entry["name"] for entry in TEXT["bond-orders"] if entry["order"] == order), _number(order))

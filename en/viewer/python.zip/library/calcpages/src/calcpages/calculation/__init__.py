"""A calculation folder with its parsed Gaussian or Lotus results, and every table, chart and viewer its page shows."""

import re
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

import pandas as pd
from runflow.gaussian.job import warning_code
from runflow.results import read_gaussian_input
from runflow.route import route_keywords
from runflow.runtime import read_log

from calcpages.cache import cache_folder
from calcpages.findings import Finding, _coalesced, _warning_findings
from calcpages.i18n import message, zone
from calcpages.keywords import _requested_resource, job_word
from calcpages.labels import quantity
from calcpages.notation import _duration, _period, _value
from calcpages.readme import readme_text, recorded_status
from calcpages.sources import _checkpoint_digest, _checkpoint_path, _parsed
from calcpages.text import TEXT

from .checkpoints import CheckpointsPart
from .convergence import ConvergencePart
from .excited import ExcitedStatesPart
from .inputs import InputsPart
from .lotus import LotusPart
from .orbitals import OrbitalsPart
from .properties import PropertiesPart
from .vibrations import VibrationsPart


class Calculation(
    InputsPart,
    ConvergencePart,
    VibrationsPart,
    OrbitalsPart,
    ExcitedStatesPart,
    PropertiesPart,
    LotusPart,
    CheckpointsPart,
):
    """One calculation folder with its parsed Gaussian or Lotus results and runflow records."""

    def __init__(self, folder, log=None):
        """``log`` names the program log when it is not found by the run-folder convention, as for the viewer's
        dropped files.
        """
        self.folder = Path(folder)
        # Mode symmetry per linked job, found once.
        self._mode_symmetry = {}
        heading = next(line for line in readme_text(self.folder).splitlines() if line.startswith("# "))
        # Calculation title: the README heading, with its inline math.
        self.title = heading.removeprefix("# ").strip()
        self.inputs = sorted(path for path in (self.folder / "inputs").glob("*") if path.is_file())
        logs = self.folder / "logs"
        # Program log: Gaussian's is named after the input file, Lotus writes lotus.log.
        candidates = [logs / f"{path.stem}.log" for path in self.inputs if path.suffix == ".gjf"] + [logs / "lotus.log"]
        self.log = Path(log) if log else next((path for path in candidates if path.exists()), None)
        # Program code: gaussian or lotus, None without a log.
        self.program = None if self.log is None else ("lotus" if self.log.name == "lotus.log" else "gaussian")
        self.result = _parsed(self.program, self.log) if self.log else None
        # The jobs a Gaussian input defines, read whether or not the calculation has output, since only the input holds
        # its GIC section; with output, an input runflow cannot read leaves none rather than breaking the page.
        inputs = [path for path in self.inputs if path.suffix == ".gjf"]
        try:
            self.gaussian_input = read_gaussian_input(inputs[0]) if inputs else []
        except (ValueError, IndexError, OSError):
            if self.result is None:
                raise
            self.gaussian_input = []
        # The input's jobs stand for the jobs while the calculation has no output.
        self.input_jobs = self.gaussian_input if self.result is None else []
        scheduler = logs / "scheduler.log"
        self.records = read_log(scheduler) if scheduler.exists() else []

    @property
    def jobs(self):
        """Linked Gaussian jobs as the output records them, or as the input defines them without output; empty for
        Lotus.
        """
        return self.result["jobs"] if self.program == "gaussian" else self.input_jobs

    def findings(self):
        """Parsed reasons behind the status, from the program output and the runflow records only."""
        if self.result is None:
            job = re.search(r"^- Slurm job `(\d+)`\.$", (self.folder / "README.md").read_text(), re.M)
            return [Finding("submitted", "", job[1]) if job else Finding("missing_log")]
        findings = []
        if self.program == "gaussian":
            state = self.result["status"]["state"]
            if state == "failed":
                findings.append(Finding("incomplete", "Gaussian", state))
            elif state in ("running", "pending"):
                findings.append(Finding("running", "Gaussian", state))
            elif state != "complete":
                findings.append(Finding("unfinished", "Gaussian"))
            for number, job in enumerate(self.jobs, 1):
                # A linked step is identified by what it does; the page already names the program.
                source = "Gaussian" if len(self.jobs) == 1 else self.step_name(number)
                findings += [
                    Finding(
                        "error",
                        source,
                        error["message"],
                        diagnostic_code=error.get("code", "gaussian.error.other"),
                        original_message=error["message"],
                    )
                    for error in job["errors"]
                ]
                if job["error_termination"]:
                    known = {error["message"] for error in job["errors"]}
                    context = [
                        entry["message"] for entry in job.get("error_context", []) if entry["message"] not in known
                    ]
                    if context:
                        findings.append(
                            Finding(
                                "error_context",
                                source,
                                message("finding-termination-context", context=" | ".join(context)),
                                diagnostic_code="gaussian.error.termination-context",
                            )
                        )
                if job["error_termination"] and not job["errors"]:
                    findings.append(Finding("error", source, message("finding-error-termination")))
                if any(not scf["converged"] for scf in job["scf_history"]):
                    findings.append(Finding("scf_unconverged", source))
                findings += _warning_findings(job["warnings"], source)
                if (
                    job["optimization_history"]
                    and not job["optimization_complete"]
                    and job.get("state") != "unfinished"
                ):
                    findings.append(Finding("optimization_unconverged", source))
                if job["request"]["excited"] and not job["td_converged"] and job.get("state") != "unfinished":
                    findings.append(Finding("td_unconverged", source))
                if job["frequencies"] and job.get("state") != "unfinished" and "opt" in job["request"]["jobs"]:
                    imaginary = sum(mode["frequency"] < 0 for mode in job["frequency_sets"][-1])
                    expected = int(
                        any(option in job["request"]["options"].get("opt", {}) for option in ("ts", "qst2", "qst3"))
                    )
                    if imaginary != expected:
                        findings.append(
                            Finding(
                                "imaginary_modes",
                                source,
                                message(
                                    "finding-imaginary-modes-one-expected"
                                    if expected
                                    else "finding-imaginary-modes-none-expected",
                                    count=imaginary,
                                ),
                            )
                        )
                findings += [
                    Finding("unstable", source, entry["message"]) for entry in job["stability"] if not entry["stable"]
                ]
        else:
            if not self.result["scf_history"] or self.result["density_change"] is None:
                findings.append(Finding("lotus_unconverged", "Lotus"))
            findings += _warning_findings(self.result["warnings"], "Lotus", "lotus")
            findings += [
                Finding("check_failed", "Lotus", name.replace("_", " "))
                for name, check in (self.result["checks"] or {}).items()
                if isinstance(check, dict) and check.get("passed") is False
            ]
        for record in self.records:
            if record["level"] in ("ERROR", "CRITICAL"):
                # The traceback's last line names the exception and its message.
                lines = [line.strip() for line in record["detail"] if line.strip()]
                findings.append(Finding("script_error", "runflow", lines[-1] if lines else record["message"]))
            elif record["level"] == "WARNING":
                findings.append(
                    Finding(
                        "script_warning",
                        "runflow",
                        record["message"],
                        diagnostic_code=warning_code(record["message"], "runflow"),
                    )
                )
        return _coalesced(findings)

    def findings_table(self, icons):
        """Every warning and error, with its kind as an icon from ``icons`` (by Warning or Error), its source,
        message.
        """
        return pd.DataFrame(
            [
                dict(kind=icons[finding.kind], source=finding.source, message=finding.markdown())
                for finding in self.findings()
            ]
        )

    def status(self):
        """The status this run's README records: our assessment of it, never inferred from its output."""
        return recorded_status(self.folder)

    def status_reason(self):
        """What the run's README says under its Scientific assessment heading, in the page language; empty without
        one.
        """
        if not (self.folder / "README.md").is_file():
            return ""
        section = re.search(r"(?ms)^#{2,3} Scientific assessment\s*\n(.*?)(?=^#{1,3} |\Z)", readme_text(self.folder))
        return section[1].strip() if section else ""

    def wall_time(self):
        """Wall time in seconds: Gaussian's own timing, else the span of the runflow records; None without either."""
        seconds = sum((job["timing"] or {}).get("wall_time") or 0 for job in self.jobs)
        if not seconds and len(self.records) > 1:
            seconds = (self.records[-1]["time"] - self.records[0]["time"]).total_seconds()
        return seconds or None

    def wall_time_text(self):
        """Wall time written out, or empty."""
        seconds = self.wall_time()
        return _duration(seconds) if seconds else ""

    def job_type(self):
        """Short job description: the job keywords of every linked job, or the Lotus method."""
        if self.program == "lotus":
            settings = self._lotus_settings()
            return message("job-self-consistent-screening") if settings.get("sc_scrEx") else message("job-screening")
        kinds = []
        for job in self.jobs:
            request = job["request"]
            words = ([request["excited"]["method"].upper()] if request["excited"] else []) + [
                job_word(job, name) for name in request["jobs"] if not (request["excited"] and name == "sp")
            ]
            kinds.append(" ".join(words))
        return ", ".join(kinds)

    def step_name(self, number):
        """What a linked Gaussian step does, from its route keywords, such as Excited states or Natural transition
        orbitals.
        """
        request = self.jobs[number - 1]["request"]
        keywords = {name.lower(): options.lower() for name, options in route_keywords(self.jobs[number - 1]["route"])}
        excited = request["excited"] is not None
        if "only" in keywords.get("guess", "") and "nto" in keywords.get("pop", keywords.get("population", "")):
            return message("step-natural-transition-orbitals")
        if "irc" in request["jobs"]:
            return message("step-reaction-path")
        if "modredundant" in request["options"].get("opt", {}):
            return message("step-relaxed-scan")
        if "opt" in request["jobs"]:
            return message("step-excited-state-optimization") if excited else message("step-geometry-optimization")
        if "freq" in request["jobs"]:
            return message("step-excited-state-frequencies") if excited else message("step-vibrational-frequencies")
        if excited:
            return message("step-excited-states")
        return message("step-single-point")

    def step_anchor(self, number):
        """The identifier of a linked step's section, its name as written with underscores for spaces, as Wikipedia
        writes anchors, such as Excited_states; a name repeated by a later step is numbered from its second, as in
        Excited_states_2.
        """
        anchor = lambda index: re.sub(r"\s+", "_", re.sub(r"[^\w\s.()-]", "", self.step_name(index)).strip())
        repeats = sum(anchor(index) == anchor(number) for index in range(1, number + 1))
        return anchor(number) + (f"_{repeats}" if repeats > 1 else "")

    def step_findings(self, number):
        """Findings that name a linked job; repeated step names share theirs."""
        source = "Gaussian" if len(self.jobs) == 1 else self.step_name(number)
        return [finding for finding in self.findings() if finding.source == source]

    def screening(self):
        """Screening evaluated by Lotus, as reported in the runflow records, or None."""
        values = [record["fields"]["dielectric"] for record in self.records if "dielectric" in record["fields"]]
        return values[-1] if values else None

    def overview(self, icons=None):
        """Program, resources and timing; a status word takes its icon from the page's mapping when given."""
        rows = [(quantity("program"), TEXT["programs"].get(self.program, ""))]
        submission = self.folder / "scripts" / "submit.sh"
        if submission.is_file():
            directives = dict(re.findall(r"(?m)^#SBATCH\s+--([\w-]+)(?:=|\s+)([^\s#]+)", submission.read_text()))
            for key, label in (
                ("time", quantity("requested-wall-time")),
                ("mem", quantity("requested-memory")),
                ("cpus-per-task", quantity("requested-cpus")),
                ("nodes", quantity("requested-nodes")),
                ("ntasks", quantity("requested-tasks")),
                ("partition", quantity("requested-partitions")),
            ):
                if key in directives:
                    rows.append((label, _requested_resource(key, directives[key])))
        state = (self.result or {}).get("status")
        code = None
        if isinstance(state, dict) and state.get("state"):
            code = state["state"]
        elif self.program == "lotus" and self.result is not None:
            finished = any(record["message"] == "Calculation converged" for record in self.records)
            failed = any(record["level"] in ("ERROR", "CRITICAL") for record in self.records)
            code = "complete" if finished else "failed" if failed else "unknown"
        if code:
            rows.append((quantity("clean-completion"), (icons or {}).get(code) or state_name(code)))
        if self.jobs:
            rows += [
                (quantity("gaussian-version"), self.jobs[0]["version"] or ""),
                (quantity("linked-jobs"), _value(len(self.jobs))),
                (quantity("processors"), _value(self.jobs[0]["processors"]) if self.jobs[0]["processors"] else ""),
            ]
        if self.records:
            fields = self.records[0]["fields"]
            if "job_id" in fields:
                rows.append((quantity("slurm-job"), str(fields["job_id"])))
            state = (self.result or {}).get("status") if self.result else None
            complete = (
                state["state"] == "complete"
                if state is not None
                else not any(
                    finding.code in ("unfinished", "incomplete", "lotus_unconverged") for finding in self.findings()
                )
            )
            end = self.records[-1]["time"] if complete else datetime.now(zone())
            rows.append((quantity("execution-interval"), _period(self.records[0]["time"], end)))
        if self.wall_time():
            rows.append((quantity("wall-time"), self.wall_time_text()))
        cpu = sum((job["timing"] or {}).get("cpu_time") or 0 for job in self.jobs)
        if cpu:
            rows.append((quantity("cpu-time"), _duration(cpu)))
        return pd.DataFrame([row for row in rows if row[1] != ""], columns=["quantity", "value"])

    def formatted_checkpoint(self, value):
        """Formatted checkpoint of a checkpoint reference: the retained one, or else one converted with formchk from
        the retained binary checkpoint into the local cache, never into the run folder; None when neither exists.
        """
        path = _checkpoint_path(self.folder, value)
        if path.exists():
            return path
        binary = (self.folder / value).resolve()
        tool = shutil.which("formchk") or str(Path.home() / ".local/bin/formchk")
        if not binary.exists() or not Path(tool).exists():
            return None
        stat = binary.stat()
        digest = _checkpoint_digest(binary, stat.st_mtime_ns, stat.st_size)
        target = cache_folder("fchk") / f"{binary.stem}-{digest}.fchk"
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            subprocess.run([tool, str(binary), str(target)], check=True, capture_output=True)
        return target

    def _job_checkpoint(self, number):
        """Formatted checkpoint the job saved through its %chk, or None."""
        commands = self.jobs[number - 1]["links"][0]["commands"]
        value = next((v for k, v in commands.items() if k.lower() == "%chk"), None)
        return value and self.formatted_checkpoint(value)

    def checkpoint_files(self):
        """Find locally retained input and final formatted checkpoints without converting binary files.

        Args:
            None.

        Returns:
            Ordered pairs of role and formatted checkpoint path, with duplicate paths removed.
        """
        found = {}
        for job in self.jobs:
            links = job["links"]
            for name, value in links[0]["commands"].items():
                role = name.lower().lstrip("%")
                if role not in ("chk", "oldchk"):
                    continue
                path = _checkpoint_path(self.folder, value)
                if path.exists():
                    found.setdefault(
                        path, message("checkpoint-starting") if role == "oldchk" else message("checkpoint-saved")
                    )
        for path in sorted((self.folder / "checkpoints").glob("*.fchk")):
            found.setdefault(path.resolve(), message("checkpoint-saved"))
        return sorted(
            [(role, path) for path, role in found.items()], key=lambda item: item[0] != message("checkpoint-starting")
        )


def state_name(code):
    """A run state's name in the page language, such as Complete for ``complete``."""
    return {
        "complete": message("state-complete"),
        "failed": message("state-failed"),
        "running": message("state-running"),
        "pending": message("state-pending"),
        "unfinished": message("state-unfinished"),
        "missing": message("state-missing"),
        "unknown": message("state-unknown"),
    }[code]

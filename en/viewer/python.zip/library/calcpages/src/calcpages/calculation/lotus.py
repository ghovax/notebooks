"""Lotus calculations: their SCF, screening and orbital histories, final quantities and checks."""

import altair as alt
import pandas as pd
from runflow.text import identifier

from calcpages.charts import _chart, _hovered, _series, margin
from calcpages.i18n import message
from calcpages.labels import PLOT, quantity
from calcpages.notation import _to_ev, _value, quantities_table
from calcpages.text import TEXT


class LotusPart:
    """Lotus calculations: their SCF, screening and orbital histories, final quantities and checks. A part of :class:`calcpages.calculation.Calculation`."""

    @_hovered
    def lotus_scf_charts(self):
        """Energy and density change at every Lotus SCF iteration."""
        data = pd.DataFrame(
            [
                dict(
                    iteration=row["iteration"] + 1,
                    native_iteration=row["iteration"],
                    energy=_to_ev(row["energy"]),
                    density_change=row["density_change"],
                )
                for row in self.result["scf_history"]
            ]
        )
        energy = (
            _chart(data.assign(series=message("chart-electronic-energy")))
            .mark_line(point=True)
            .encode(
                x=alt.X(f"{PLOT}iteration:Q", axis=alt.Axis(tickMinStep=1), scale=margin()),
                y=alt.Y(f"{PLOT}energy:Q", scale=margin()),
                color=_series(message("chart-electronic-energy")),
            )
        )
        change = (
            _chart(data.dropna().assign(series=message("chart-density-change")))
            .mark_line(point=True)
            .encode(
                x=alt.X(f"{PLOT}iteration:Q", axis=alt.Axis(tickMinStep=1), scale=margin()),
                y=alt.Y(f"{PLOT}density_change:Q", scale=alt.Scale(type="log")),
                color=_series(message("chart-density-change")),
            )
        )
        return energy, change

    @_hovered
    def lotus_screening_chart(self):
        """Screening parameter applied at each outer iteration."""
        data = pd.DataFrame(
            [
                dict(
                    iteration=row["iteration"] + 1,
                    native_iteration=row["iteration"],
                    epsilon=row["epsilon"],
                    series=message("chart-applied-screening"),
                )
                for row in self.result["screening_history"]
            ]
        )
        return (
            _chart(data)
            .mark_line(point=True)
            .encode(
                x=alt.X(f"{PLOT}iteration:Q", axis=alt.Axis(tickMinStep=1), scale=margin()),
                y=alt.Y(f"{PLOT}epsilon:Q", scale=margin()),
                color=_series(message("chart-applied-screening")),
            )
        )

    @_hovered
    def lotus_orbitals_chart(self):
        """Frontier orbital gap at each iteration, in eV."""
        data = pd.DataFrame(
            [
                dict(
                    iteration=row["iteration"] + 1,
                    native_iteration=row["iteration"],
                    gap=_to_ev(row["gap"]),
                    series=message("chart-orbital-gap"),
                )
                for row in self.result["orbital_history"]
            ]
        )
        return (
            _chart(data)
            .mark_line(point=True)
            .encode(
                x=alt.X(f"{PLOT}iteration:Q", axis=alt.Axis(tickMinStep=1), scale=margin()),
                y=alt.Y(f"{PLOT}gap:Q", scale=margin()),
                color=_series(message("chart-orbital-gap")),
            )
        )

    def lotus_summary(self):
        """Final Lotus quantities: method, iterations, convergence, screening, frontier orbitals and weights."""
        result = self.result
        rows = [
            (
                quantity("method"),
                TEXT["lotus-methods"].get(identifier(result["method"]), f"`{result['method']}`"),
                TEXT["lotus-descriptions"].get(identifier(result["method"]), ""),
            ),
            (quantity("scf-iterations"), _value(result["scf_iterations"])),
            (quantity("final-density-change"), _value(result["density_change"])),
        ]
        if result["screening_history"]:
            rows.append((quantity("applied-screening"), _value(result["screening_history"][-1]["epsilon"])))
        if (value := self.screening()) is not None:
            rows.append((quantity("evaluated-screening"), _value(value)))
        if result["orbital_history"]:
            last = result["orbital_history"][-1]
            rows += [
                (quantity("highest-occupied-energy"), _value(last["homo"], "hartree")),
                (quantity("lowest-unoccupied-energy"), _value(last["lumo"], "hartree")),
                (quantity("orbital-gap-lotus"), _value(last["gap"], "hartree")),
            ]
        # A weight of zero marks a term the functional does not contain.
        rows += [
            (
                TEXT["lotus-weights"].get(identifier(name), name.replace("_", " ").capitalize() + " weight"),
                _value(value),
            )
            for name, value in (result["weights"] or {}).items()
            if value
        ]
        return quantities_table(rows)

    def lotus_energy_table(self):
        """Last native Lotus interaction components, excluding its volume and without reweighting exchange."""
        records = self.result["energy_parts"]
        if not records:
            return None
        values = records[-1]["values"]
        exchange = (
            "nonlocal_exchange_energy"
            if self.result["method"] in ("ds_ex_vwn", "ds_ex_lyp")
            else "exact_exchange_energy"
        )
        labels = [
            ("Hartree", "hartree_energy"),
            ("exact_Ex", exchange),
            ("pure_dft", "dft_energy"),
            ("env", "environment_energy"),
            ("proj", "projection_energy"),
        ]
        rows = [(quantity(label), _value(values[key], "hartree", 12)) for key, label in labels if key in values]
        history = self.result.get("scf_history", [])
        if history:
            rows.append((quantity("lotus-total-energy"), _value(history[-1]["energy"], "hartree", 12)))
        return pd.DataFrame(rows, columns=["quantity", "value"])

    def lotus_checks(self):
        """Response and consistency checks reported by Lotus, one row per scalar entry."""
        rows = []
        for name, check in (self.result["checks"] or {}).items():
            entries = check.items() if isinstance(check, dict) else [("value", check)]
            rows += [
                dict(
                    check=name.replace("_", " ").capitalize(),
                    quantity=key.replace("_", " ").capitalize(),
                    value=value if isinstance(value, bool) else _value(value),
                )
                for key, value in entries
                if not isinstance(value, (list, dict))
            ]
        return pd.DataFrame(rows)

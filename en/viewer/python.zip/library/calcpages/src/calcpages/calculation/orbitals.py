"""Canonical orbitals: their energies, symmetry, composition and viewers."""

import json

import altair as alt
import numpy as np
import pandas as pd
from molstarview import CubeGrid, VolumeSurface, VolumeViewer
from runflow.basis import basis_supported, momentum_letter, orbital_composition
from runflow.results import ureg
from runflow.units import ELEMENTS

from calcpages.appearance import COMPOSITION_COLORS, LABEL_BAND, ORBITAL_SHARE
from calcpages.charts import (
    _chart,
    _energy_sets,
    _frontier,
    _frontier_names,
    _hovered,
    _levels_chart,
)
from calcpages.fields import (
    _orbital_cached,
    _orbital_entries,
    _overlap_cached,
    _records,
    _same_name,
    _symmetry_cached,
)
from calcpages.i18n import message
from calcpages.labels import PLOT, Quantity, quantity, unit_latex
from calcpages.notation import _point_group, _to_ev
from calcpages.reactions import _bonded_groups, _part_shares, _part_tex


class OrbitalsPart:
    """Canonical orbitals: their energies, symmetry, composition and viewers. A part of :class:`calcpages.calculation.Calculation`."""

    def _homo(self, number):
        """One-based index of the highest occupied alpha orbital."""
        return self.jobs[number - 1]["electron_counts"][0]

    def spins(self, number):
        """The spin channels of a job's SCF: alpha alone for a restricted wavefunction, alpha and beta for an
        unrestricted one, whose output prints both.
        """
        records = self.jobs[number - 1]["orbital_data"]["orbitals"]
        return ["alpha", "beta"] if any(record.get("spin") == "beta" for record in records) else ["alpha"]

    def _scf_orbitals(self, number, spin="alpha"):
        """The occupied and virtual orbital energies of one spin channel of a job's last SCF; a restricted job's beta
        channel is its alpha one.
        """
        records = self.jobs[number - 1]["orbital_data"]["orbitals"]
        return next(
            (record for record in reversed(records) if record.get("spin", "alpha") == spin),
            next(record for record in reversed(records) if record.get("spin", "alpha") == "alpha"),
        )

    def symmetry(self, number, spin="alpha"):
        """Point group of the geometry and symmetry of the canonical orbitals of one spin channel of a job, from its
        saved checkpoint when that holds the job's orbitals: None without one, for NTOs or when its orbital energies
        differ from the job's last SCF.
        """
        job = self.jobs[number - 1]
        if job.get("nto_particles") or not job.get("orbital_data", {}).get("orbitals"):
            return None
        path = self._job_checkpoint(number)
        symmetry = _symmetry_cached(str(path), spin) if path else None
        if symmetry is None:
            return None
        orbitals = self._scf_orbitals(number, spin)
        energies = np.concatenate([orbitals["occupied"], orbitals["virtual"]])
        own = np.array([energy for s in symmetry.sets for energy in [s.energy] * len(s.indices)])
        if len(own) != len(energies) or np.abs(own - energies).max() > 1e-4:
            return None
        return symmetry

    def orbital_sets(self, number, spin="alpha"):
        """Canonical orbital sets of one spin channel of a job's last SCF, degenerate orbitals together: with their
        symmetry when ``symmetry`` finds it, otherwise by energy alone.
        """
        if (symmetry := self.symmetry(number, spin)) is not None:
            return symmetry.sets
        orbitals = self._scf_orbitals(number, spin)
        return _energy_sets(orbitals["occupied"], orbitals["virtual"])

    def symmetry_points(self, number):
        """What the orbital and state labels mean for a job, one sentence each."""
        symmetry = self.symmetry(number)
        if symmetry is None:
            return [message("orbitals-index-labels")]
        group = symmetry.group.name
        computed = self.jobs[number - 1]["point_group"]
        points = [message("orbitals-symmetry-labels", group=group)]
        if computed and not _same_name(group, computed):
            points.append(message("orbitals-computed-group", group=_point_group(computed)))
        return points

    def symmetry_note(self, number):
        """Sentences on what the orbital and state labels mean for a job."""
        return " ".join(self.symmetry_points(number))

    def _closed_symmetry(self, number):
        """The orbital symmetry of a closed-shell job, or None."""
        electrons = self.jobs[number - 1]["electron_counts"] or []
        closed = len(electrons) == 2 and electrons[0] == electrons[1]
        return self.symmetry(number) if closed else None

    def inversion(self, number):
        """Whether the geometry of a job, by its orbital symmetry, has an inversion centre."""
        symmetry = self.symmetry(number)
        return symmetry is not None and any(np.allclose(matrix, -np.eye(3)) for matrix in symmetry.group.operations)

    def _set_of(self, number, index, spin=None):
        """The orbital set of a one-based orbital index, in its spin channel; None means a restricted orbital."""
        return next(s for s in self.orbital_sets(number, spin or "alpha") if index - 1 in s.indices)

    @_hovered
    def orbitals_chart(self, number, window=4):
        """Canonical orbital energies of a linked job's last SCF around the gap, as ``_levels_chart`` draws them, both
        spin channels of an unrestricted job side by side.
        """
        spins = self.spins(number)
        return _levels_chart(
            [(spin if len(spins) > 1 else None, self.orbital_sets(number, spin)) for spin in spins], window
        )

    def frontier_table(self, number):
        """Energies of the HOMO and LUMO sets of each spin channel, with their symmetry labels, and the HOMO–LUMO gap in
        eV: for an unrestricted job, the lowest unoccupied orbital of either channel above the highest occupied one.
        """
        spins = self.spins(number)
        rows, tops, bottoms = [], [], []
        for spin in spins:
            sets = self.orbital_sets(number, spin)
            top = next(s for s in reversed(sets) if s.occupied)
            bottom = next(s for s in sets if not s.occupied)
            channel = rf"^{{\{spin}}}" if len(spins) > 1 else ""

            def row(frontier, orbital):
                """Name of one frontier orbital's energy row, with its spin channel when the job has two."""
                symbol = rf"$\epsilon_{{\mathrm{{{frontier}}}}}{channel}$"
                if len(spins) > 1:
                    return message(
                        "frontier-homo-spin" if frontier == "HOMO" else "frontier-lumo-spin",
                        spin=rf"$\{spin}$",
                        symbol=symbol,
                        label=f"${orbital.label()}$",
                    )
                return message(
                    "frontier-homo" if frontier == "HOMO" else "frontier-lumo",
                    symbol=symbol,
                    label=f"${orbital.label()}$",
                )

            rows += [
                (Quantity(row("HOMO", top), quantity("highest-occupied-energy").description), top.energy),
                (Quantity(row("LUMO", bottom), quantity("lowest-unoccupied-energy").description), bottom.energy),
            ]
            tops.append(top.energy)
            bottoms.append(bottom.energy)
        rows.append((quantity("orbital-gap-row"), min(bottoms) - max(tops)))
        return pd.DataFrame([dict(quantity=name, electronvolt=_to_ev(value)) for name, value in rows])

    def _frontier_composition(self, number, window=2):
        """The Mulliken share in percent of each atom's functions of each angular momentum in the frontier orbital sets,
        at least ``window`` sets on each side of the gap, of each spin channel in turn: ``shown`` (the sets), ``names``
        (HOMO, LUMO_1, ... by set, with the spin as a superscript for an unrestricted job), ``spins`` (each set's
        channel), ``unrestricted``,
        ``orbitals`` (per orbital index, shape orbitals x atoms x momenta), ``means`` (by set, its orbitals averaged),
        ``numbers`` (atomic numbers) and ``momenta`` (the letters of the momenta); None without a saved checkpoint of a
        supported basis, or when the checkpoint holds natural transition orbitals.
        """
        cache = self.__dict__.setdefault("_compositions", {})
        if (number, window) in cache:
            return cache[number, window]
        result = None
        if not self.jobs[number - 1]["nto_particles"] and (path := self._job_checkpoint(number)):
            overlap = _overlap_cached(str(path))
            if overlap is not None:
                records = _records(path)
                spins = self.spins(number)
                unrestricted = len(spins) > 1
                shown, names, blocks, means, channels = [], {}, [], {}, {}
                try:
                    for spin in spins:
                        sets = self.orbital_sets(number, spin)
                        part = _frontier(sets, window, True) + _frontier(sets, window, False)
                        shares = (
                            orbital_composition(
                                records, [index for s in part for index in s.indices], overlap, spin=spin
                            )
                            * 100
                        )
                        first = 0
                        for s in part:
                            means[id(s)] = shares[first : first + len(s.indices)].mean(axis=0)
                            channels[id(s)] = spin
                            first += len(s.indices)
                        shown += part
                        names.update(_frontier_names(part, spin if unrestricted else None))
                        blocks.append(shares)
                except ValueError:
                    blocks = []
                if blocks:
                    shares = np.concatenate(blocks)
                    result = dict(
                        shown=shown,
                        names=names,
                        spins=channels,
                        unrestricted=unrestricted,
                        orbitals=shares,
                        means=means,
                        numbers=np.asarray(records["Atomic numbers"], dtype=int),
                        momenta="".join(map(momentum_letter, range(shares.shape[2]))),
                        coordinates=(
                            np.asarray(records["Current cartesian coordinates"], dtype=float).reshape(-1, 3) * ureg.bohr
                        )
                        .to("angstrom")
                        .magnitude,
                    )
        cache[number, window] = result
        return result

    def orbital_composition_chart(self, number, window=4):
        """The frontier orbitals' composition as one heat map that follows the molecule's bonds, as wide as the page,
        with Part, Element and Atom controls above it choosing what the cells show, as the orbital viewer's do: each
        atom group's share $w_A$ of the whole orbital, its share $w_{A,l}$ of the functions of one angular momentum, or
        for one atom, chosen by its element and number, its $w_{A,l}$ of each angular momentum, one row each. The parts
        offered are those of the viewer's dropdowns (``_orbital_parts``); the colour scale runs from zero to the chosen
        part's largest share.

        One column per set of the level diagram, at least ``window`` orbitals each side of the gap, from the lowest to
        the highest, an unrestricted job's alpha sets then its beta sets; one row per atom group of ``_bonded_groups``,
        a heavy atom with its hydrogens, in the order of the bonds, one bonded fragment after another. The fragment is
        the title, or with several the label right of its first row. Groups below 1% of every set are summed as the
        rest of their fragment, or as the whole fragment when none reaches it. Degenerate components are averaged.
        None where ``_frontier_composition`` is.
        """
        composition = self._frontier_composition(number, window)
        if composition is None:
            return None
        shown, names, momenta = composition["shown"], composition["names"], composition["momenta"]
        means = np.stack([composition["means"][id(s)] for s in shown])
        numbers = composition["numbers"]
        _, pieces = self._orbital_parts(composition)
        # The matrices' rows, each fragment's groups with at least 1% of some set, and the rest of it summed.
        fragments = []
        for formula, groups in _bonded_groups(numbers, composition["coordinates"]):
            fragment = rf"$\ce{{{formula}}}$"
            kept = [(label, atoms) for label, atoms in groups if (means[:, atoms].sum(axis=(1, 2)) >= 1).any()]
            rest = [atom for label, atoms in groups if (label, atoms) not in kept for atom in atoms]
            if rest and (np.abs(means[:, rest].sum(axis=(1, 2))) >= 0.05).any():
                kept.append((message("orbitals-remainder", fragment=fragment) if kept else fragment, rest))
            if kept:
                fragments.append((fragment, kept, {atom for _, atoms in groups for atom in atoms}))
        # The parts, as the viewer's dropdowns offer them: Part chooses the whole orbital, the functions of one angular
        # momentum or one atom, and Element and Atom which atom, by its element and its number. The data key the
        # parts by the whole orbital, each momentum and each atom number.
        parts, elements = {"whole": message("composition-whole")}, {}
        for (kind, element, atom), part in pieces:
            if part and part[0] == "momentum":
                letter = momenta[part[1]]
                parts[kind] = message("composition-momentum", letter=letter)
            elif part:
                parts["atom"] = message("composition-atom")
                elements[atom + 1] = element
        keys = [key for key in parts if key != "atom"] + [f"a{atom}" for atom in elements]
        # Rows by key, a fragment's groups as "fragment-position" and an atom's momenta as "atom-momentum", ordered by
        # ``order``; the cells of every set of both channels share them.
        rows, labels, firsts, homes = [], {}, {}, {}
        for index, (fragment, kept, members) in enumerate(fragments):
            firsts[f"{index}-0"] = fragment
            homes.update({atom: fragment for atom in elements if atom - 1 in members})
            for s, part in zip(shown, means):
                cells = []
                for position, (label, atoms) in enumerate(kept):
                    shares = part[atoms].sum(axis=0)
                    key = f"{index}-{position}"
                    labels[key] = label
                    cells.append(("whole", key, 1000 * index + position, label, shares.sum()))
                    cells += [
                        (f"l{momentum}", key, 1000 * index + position, label, shares[momentum])
                        for momentum in range(len(momenta))
                        if f"l{momentum}" in parts
                    ]
                for atom in elements:
                    if atom - 1 in members:
                        # The chosen atom is named by the controls; its rows are its angular momenta.
                        for momentum, letter in enumerate(momenta):
                            labels[f"atom-{momentum}"] = message("composition-functions", letter=letter)
                            cells.append(
                                (
                                    f"a{atom}",
                                    f"atom-{momentum}",
                                    momentum,
                                    labels[f"atom-{momentum}"],
                                    part[atom - 1, momentum],
                                )
                            )
                # Rounded shares, with a rounded negative zero written as zero.
                rows += [
                    dict(
                        part=part_key,
                        composition_row=key,
                        order=order,
                        composition_atom=label,
                        molecular_fragment=fragment,
                        frontier_level=names[id(s)],
                        orbital=f"${s.label()}$",
                        composition_share=round(float(value), 1) + 0.0,
                    )
                    for part_key, key, order, label, value in cells
                ]
        data = pd.DataFrame(rows)
        largest = {key: max(float(data.loc[data.part == key, "composition_share"].max()), 1.0) for key in keys}
        levels = list(dict.fromkeys(names[id(s)] for s in shown))
        params = [
            alt.param(
                name="composition_part",
                value="whole",
                bind=alt.binding_select(options=list(parts), labels=list(parts.values()), name=message("choice-part")),
            )
        ]
        chosen = "composition_part"
        if elements:
            # Atom's options are the atom numbers labelled by their element; the page draws them as an Element
            # dropdown and a field taking the number of an atom of that element, shown only for one atom.
            params.append(
                alt.param(
                    name="composition_atom",
                    value=next(iter(elements)),
                    bind=alt.binding_select(
                        options=list(elements), labels=list(elements.values()), name=message("choice-atom")
                    ),
                )
            )
            chosen = "(composition_part == 'atom' ? 'a' + composition_atom : composition_part)"
        rows_axis = dict(sort=alt.EncodingSortField(f"{PLOT}order", op="min"), title=None)
        tooltip = [
            f"{PLOT}frontier_level",
            f"{PLOT}orbital",
            *([f"{PLOT}molecular_fragment"] if len(fragments) > 1 else []),
            f"{PLOT}composition_atom",
            alt.Tooltip(f"{PLOT}composition_share:Q", format=".1f"),
        ]
        base = (
            _chart(data)
            .transform_filter(f"datum.{PLOT}part == {chosen}")
            .encode(
                # Nominal axes write each LaTeX name as it is, the shared number format would turn it into NaN, and labels
                # are whole: one cut short ends in an ellipsis that leaves its math unclosed.
                x=alt.X(
                    f"{PLOT}frontier_level:N", sort=levels, axis=alt.Axis(labelExpr="datum.value", labelOverlap=False)
                )
            )
        )
        matrix = base.mark_rect(stroke="white", strokeWidth=1).encode(
            y=alt.Y(
                f"{PLOT}composition_row:N",
                **rows_axis,
                axis=alt.Axis(
                    labelExpr=f"{json.dumps(labels)}[datum.value]",
                    labelOverlap=False,
                    labelLimit=0,
                    **LABEL_BAND,
                ),
            ),
            color=alt.Color(
                f"{PLOT}composition_share:Q",
                scale=alt.Scale(
                    domainMin=0,
                    domainMax={"expr": f"{json.dumps(largest)}[{chosen}]"},
                    range=list(COMPOSITION_COLORS),
                    clamp=True,
                ),
            ),
            tooltip=tooltip,
        )
        if len(fragments) == 1:
            chart = matrix.properties(title=alt.TitleParams(fragments[0][0], fontSize=14, fontWeight="normal"))
        else:
            # Each fragment named right of its first row, or of the chosen atom's first, by an axis of its own drawn
            # under the matrix.
            name = f"{json.dumps(firsts)}[datum.value] || ''"
            if homes:
                name = f"datum.value == 'a-0' ? {json.dumps(homes)}[composition_atom] : {name}"
            names_axis = base.mark_rect(opacity=0).encode(
                y=alt.Y(
                    f"{PLOT}composition_row:N",
                    **rows_axis,
                    axis=alt.Axis(
                        orient="right",
                        labelExpr=name,
                        labelOverlap=False,
                        labelLimit=0,
                        ticks=False,
                        domain=False,
                        **LABEL_BAND,
                    ),
                )
            )
            chart = alt.layer(names_axis, matrix).resolve_axis(y="independent")
        return chart.properties(height=alt.Step(26)).add_params(*params)

    def drawable(self, number):
        """Whether the job's orbitals can be drawn: its formatted checkpoint is saved and ``basis_supported`` accepts
        its basis.
        """
        path = self._job_checkpoint(number)
        return bool(path) and basis_supported(_records(path))

    @staticmethod
    def _orbital_viewer(
        path, orbitals, label, name, symbol, isovalue, spacing, atom_shares=None, parts=((), ()), spins=None, momenta=""
    ):
        """Molstar snapshots of alpha orbitals of a formatted checkpoint, one per (title, zero-based index), each drawn
        as its surfaces at amplitude -level (red) and +level (blue), the level whose surfaces hold ``ORBITAL_SHARE`` of
        its density; ``isovalue`` sets only the box, where the amplitude reaches an eighth of it. ``atom_shares``, one pair of atom shares
        and hover texts per orbital, adds the viewer's composition toggles. ``parts``, the dropdowns and the parts of
        ``_orbital_parts``, add dropdowns after the orbital's that draw each orbital's part at the same isovalue.
        An orbital may name its spin channel third, as (title, index, spin); ``spins``, both channels of an
        unrestricted job, adds a Spin dropdown before the orbital's. ``atom_shares`` holds, per orbital, its shares in
        percent by atom and angular momentum, whose letters are ``momenta``; the composition toggle colours the atoms by
        the shown part's own share, on a scale per part: $w_A$ for the whole orbital, $w_{A,l}$ for the functions of
        one angular momentum, and for one atom its $w_A$ alone.

        Each orbital is evaluated from its basis functions on a ``spacing`` grid in bohr over the box where its
        amplitude reaches an eighth of the isovalue, found first on a coarse grid. The page carries that whole box in the
        compact encoding of ``CubeGrid.compact``, so the viewer's settings can move the surfaces down to an eighth of
        the isovalue or render the amplitude as a volume that fades out inside the box.
        """
        levels = {}

        def level(index, spin):
            """The level whose surfaces hold ``ORBITAL_SHARE`` of the orbital's density in its box, which its parts share
            so their sizes compare.
            """
            if (index, spin) not in levels:
                origin, axes, atoms, values = _orbital_cached(path, index, spacing, isovalue, None, spin)
                levels[index, spin] = VolumeSurface.enclosing(
                    CubeGrid(origin, axes, atoms, values), ORBITAL_SHARE, 2
                ).isovalue
            return levels[index, spin]

        def surface(index, spin, part=None):
            origin, axes, atoms, values = _orbital_cached(path, index, spacing, isovalue, part, spin)
            # A part too weak to reach its orbital's level is drawn just inside its own largest amplitude instead.
            value = min(level(index, spin), 0.9 * float(np.abs(values).max()))
            return VolumeSurface(
                grid=CubeGrid(origin, axes, atoms, values), isovalue=value, signed=True, floor=value / 8
            )

        orbitals = [(item[0], item[1], item[2] if len(item) > 2 else "alpha") for item in orbitals]
        axes, pieces = parts
        choices, fields = (), None
        if len(pieces) > 1 or spins:
            several = len(pieces) > 1
            # Every snapshot as its keys, orbital, spin and part. A part that never reaches the lowest level the viewer
            # can show, an eighth of the isovalue, has nothing to draw, so that combination is not offered.
            snapshots = []
            for k, (_, index, spin) in enumerate(orbitals):
                for keys, part in pieces if several else pieces[:1]:
                    if (
                        part is not None
                        and np.abs(_orbital_cached(path, index, spacing, isovalue, part, spin)[3]).max() < isovalue / 8
                    ):
                        continue
                    snapshots.append(
                        ((*((spin,) if spins else ()), k, *(keys if several else ())), k, index, spin, part)
                    )
            surfaces = {key: surface(index, spin, part) for key, _, index, spin, part in snapshots}
            # Only the options some snapshot uses, in their own order.
            used = [set(key[axis] for key, *_ in snapshots) for axis in range(len(snapshots[0][0]))]
            lead = [(message("choice-spin"), {spin: rf"$\{spin}$" for spin in spins})] if spins else []
            choices = [
                *lead,
                (message("choice-orbital"), {k: title for k, (title, _, _) in enumerate(orbitals)}),
                *(axes if several else []),
            ]
            choices = [
                (choice[0], {value: text for value, text in choice[1].items() if value in used[axis]}, *choice[2:])
                for axis, choice in enumerate(choices)
            ]
            if several:
                # A part is named by its own symbol, psi^(A) or psi^(l), on the colour scale and in hover labels.
                numbers = next(iter(surfaces.values())).display_grids[0].atoms[:, 0].astype(int)
                fields = [
                    (str(label).replace(symbol, each, 1), each)
                    for each in (
                        symbol if part is None else rf"{symbol}^{{({_part_tex(numbers, part)})}}"
                        for *_, part in snapshots
                    )
                ]
            if atom_shares is not None:
                atom_shares = [_part_shares(atom_shares[k], part, momenta) for _, k, _, _, part in snapshots]
        else:
            surfaces = {title: surface(index, spin) for title, index, spin in orbitals}
            if atom_shares is not None:
                atom_shares = [_part_shares(matrix, None, momenta) for matrix in atom_shares]
        # The colour scale of each part's shares: w_A, or w_{A,l} for the functions of one angular momentum.
        whole = quantity("share-total")
        atom_label = {
            "whole": whole,
            **{
                f"l{momentum}": Quantity(
                    str(whole).replace("w_A", rf"w_{{A,{letter}}}"), quantity(f"share-{letter}").description
                )
                for momentum, letter in enumerate(momenta)
            },
        }
        return VolumeViewer(
            surfaces,
            color_range=(-isovalue, isovalue),
            colors=("#d7301f", "#2b6cb0"),
            opacity=0.85,
            choices=choices,
            color_label=label,
            field_name=name,
            field_symbol=symbol,
            field_unit=unit_latex("bohr ** -1.5"),
            atom_shares=atom_shares,
            atom_label=atom_label if atom_shares is not None else "",
            atom_title=message("viewer-toggle-composition"),
            surface_title=message("viewer-toggle-surfaces"),
            snapshot_fields=fields,
        )

    def frontier_viewer(self, number, isovalue=0.02, spacing=0.2, window=2):
        """The highest occupied and lowest unoccupied canonical orbital sets, at least ``window`` orbitals each, with
        their labels, components and energies, from the job's saved checkpoint; None without it or when the
        checkpoint holds NTOs.
        """
        if self.jobs[number - 1]["nto_particles"]:
            return None
        path = self._job_checkpoint(number)
        if not path:
            return None
        spins = self.spins(number)
        unrestricted = len(spins) > 1
        shown, entries = [], []
        for spin in spins:
            sets = self.orbital_sets(number, spin)
            part = _frontier(sets, window, True) + _frontier(sets, window, False)
            shown += part
            entries += [
                (title, index, spin)
                for title, index in _orbital_entries(part, _frontier_names(part, spin if unrestricted else None))
            ]
        # Each orbital's composition on the atoms; a degenerate component, a mixture of its set, takes the set's average.
        composition, shares = self._frontier_composition(number, window), None
        if composition is not None:
            shares, first = [], 0
            for s in shown:
                for k in range(len(s.indices)):
                    part = composition["means"][id(s)] if s.components else composition["orbitals"][first + k]
                    shares.append(part)
                first += len(s.indices)
        return self._orbital_viewer(
            path,
            entries,
            quantity("orbital-amplitude"),
            message("field-orbital-amplitude"),
            r"\psi",
            isovalue,
            spacing,
            shares,
            self._orbital_parts(composition),
            spins if unrestricted else None,
            composition["momenta"] if composition else "",
        )

    @staticmethod
    def _orbital_parts(composition, momentum_share=1, atom_share=1, most=16):
        """The parts of the frontier orbitals the viewer offers, chosen in three dropdowns after the orbital's: Part (the
        whole orbital, the functions of each angular momentum with at least ``momentum_share`` percent of some orbital
        shown, or one atom), then Element and Atom for an atom, among the atoms with at least ``atom_share`` percent of
        some orbital (the rows of the composition chart), at most ``most`` of the strongest; the atom's number is typed
        into a field and clamped to the nearest atom of the chosen element. Both are hidden for the other parts.

        Returns:
            The dropdowns as pairs of a label and its options, and the parts as pairs of their keys on the three dropdowns
            and a part for ``_orbital_cached`` (None for the whole orbital); no dropdowns and only the whole orbital
            without a composition.
        """
        whole = [(("whole", "all", "all"), None)]
        if composition is None:
            return (), whole
        kinds = {"whole": message("orbital-part-whole")}
        elements, atoms = {"all": message("orbital-part-all-elements")}, {"all": message("orbital-part-all-atoms")}
        pieces = list(whole)
        means = np.stack([composition["means"][id(s)] for s in composition["shown"]])
        for momentum, letter in enumerate(composition["momenta"]):
            if (means[:, :, momentum].sum(axis=1) >= momentum_share).any():
                kinds[f"l{momentum}"] = message("orbital-part-momentum", letter=letter)
                pieces.append(((f"l{momentum}", "all", "all"), ("momentum", momentum)))
        strongest = means.sum(axis=2).max(axis=0)
        chosen = sorted(atom for atom in np.argsort(-strongest, kind="stable")[:most] if strongest[atom] >= atom_share)
        if chosen:
            kinds["atom"] = message("orbital-part-atom")
        numbers = composition["numbers"]
        # Elements in order of atomic number, each atom under its element in input order.
        for atom in sorted(chosen, key=lambda atom: (numbers[atom], atom)):
            element = ELEMENTS[numbers[atom] - 1]
            elements.setdefault(element, rf"$\mathrm{{{element}}}$")
            atoms[int(atom)] = str(atom + 1)
            pieces.append((("atom", element, int(atom)), ("atom", int(atom))))
        return [
            (message("choice-part"), kinds),
            (message("choice-element"), elements, {"collapse": True}),
            (message("choice-atom"), atoms, {"input": True, "collapse": True}),
        ], pieces

"""Ground-state properties: charges, electrostatic potential, moments, polarizability and stability."""

import numpy as np
import pandas as pd
from molstarview import CubeGrid, MolstarViewer, VolumeSurface, VolumeViewer
from runflow.results import ureg

from calcpages.appearance import POTENTIAL_SHARE
from calcpages.fields import _frames, potential_in_space
from calcpages.labels import quantity, unit_latex
from calcpages.notation import _number, _tensor
from calcpages.text import TEXT


class PropertiesPart:
    """Ground-state properties: charges, electrostatic potential, moments, polarizability and stability. A part of :class:`calcpages.calculation.Calculation`."""

    def scf_population(self, number):
        """The final SCF's population analysis when its evaluation and geometry are known, else None."""
        job = self.jobs[number - 1]
        evaluations = job["evaluations"]
        found = [
            entry
            for entry in job["populations"]
            if "SCF" in entry["density"]
            and entry.get("evaluation") == len(evaluations) - 1
            and entry.get("geometry") is not None
        ]
        return found[-1] if evaluations and found else None

    def _charge_viewer(self, number, charges, label, symbol="q"):
        """Molstar view of the job's last geometry with each atom coloured by its charge, red negative and blue
        positive on a scale symmetric about zero, with its charge, written as ``symbol``, in its hover label.
        """
        details = [rf"${symbol}={{{charge:+.3f}}}\,{unit_latex('elementary_charge')}$" for charge in charges]
        return MolstarViewer(
            self.trajectory(number)[-1:], atom_values=charges, atom_details=details, color_label=label, trail=False
        )

    def charge_values(self, number):
        """Mulliken atomic charges of the job's last SCF population analysis, by atom."""
        return pd.Series([row["charge"] for row in self.scf_population(number)["mulliken_charges"]])

    def charges_viewer(self, number):
        """Mulliken atomic charges of the job's last SCF population analysis, drawn on the molecule."""
        population = self.scf_population(number)
        charges = [row["charge"] for row in population["mulliken_charges"]]
        geometry = self.jobs[number - 1]["geometries"][population["geometry"]]
        details = [rf"$q={{{charge:+.3f}}}\,{unit_latex('elementary_charge')}$" for charge in charges]
        return MolstarViewer(
            _frames(geometry["atomic_numbers"], [geometry["vectors"]]),
            atom_values=charges,
            atom_details=details,
            color_label=quantity("mulliken-charge"),
            trail=False,
        )

    def potential_cube(self):
        """The first electrostatic-potential cube the run saved under fields/ beside its density cube, or None."""
        return next(
            (
                path
                for path in sorted((self.folder / "fields").glob("*-potential.cube"))
                if path.with_name(path.name.replace("-potential.cube", "-density.cube")).exists()
            ),
            None,
        )

    def potential_viewer(self, density_level=0.002, isovalue=None):
        """The electrostatic potential of the saved cube in one viewer with two views, switched from its toolbar with
        the camera kept: on the electron-density surface at ``density_level`` in elementary charges per cubic bohr, in
        volts on one symmetric colour scale; and in space, at -isovalue (red, where a positive charge is attracted) and
        +isovalue (blue), in volts, whose settings move the level down to an eighth of ``isovalue`` or as far as the
        cube's box allows. Requires ``potential_cube``.
        """
        path = self.potential_cube()
        density = path.with_name(path.name.replace("-potential.cube", "-density.cube"))
        # The cube holds hartree per elementary charge.
        volts = (1 * ureg.hartree / ureg.e).to("volt", "energy").magnitude
        surface = VolumeSurface(
            grid=CubeGrid.read(density), color_grid=CubeGrid.read(path), isovalue=density_level, color_factor=volts
        )
        # The scale covers POTENTIAL_SHARE of the surface, so the strong potential at a few points near nuclei does not
        # wash the rest out; those points show in the end colours.
        scale = surface.color_quantile(POTENTIAL_SHARE) * volts
        return VolumeViewer(
            surface,
            color_range=(-scale, scale),
            color_label=quantity("electrostatic-potential"),
            title=TEXT["surface-potential"],
            alternates=[potential_in_space(surface, isovalue)],
        )

    def dipole_table(self, number):
        """Dipole moment components and magnitude in debye."""
        x, y, z, total = self.scf_population(number)["dipole"]
        return pd.DataFrame(
            [
                dict(component=name, dipole=value)
                for name, value in ((r"$\mu_x$", x), (r"$\mu_y$", y), (r"$\mu_z$", z), (r"$\lvert\mu\rvert$", total))
            ]
        )

    def dipole_equation(self, number):
        """The printed dipole vector and magnitude in debye and atomic units, in the printed orientation."""
        values = self.scf_population(number)["dipole"]
        debye = [_number(value, 6).strip("$") for value in values[:3]]
        atomic = [_number((value * ureg.debye).to("e*bohr").magnitude, 6).strip("$") for value in values[:3]]
        magnitude, magnitude_atomic = (
            _number(values[3], 6).strip("$"),
            _number((values[3] * ureg.debye).to("e*bohr").magnitude, 6).strip("$"),
        )
        vector = lambda parts: r" \\ ".join(parts)
        return (
            rf"$$\boldsymbol{{\mu}}=\begin{{pmatrix}}{vector(debye)}\end{{pmatrix}}\,\mathrm{{D}}"
            rf"=\begin{{pmatrix}}{vector(atomic)}\end{{pmatrix}}\,e a_0,\qquad "
            rf"|\boldsymbol{{\mu}}|={magnitude}\,\mathrm{{D}}={magnitude_atomic}\,e a_0$$"
        )

    def static_polarizability(self, number):
        """Last complete, nonzero static tensor; zero-filled response placeholders are not a physical result."""
        entries = [
            entry
            for entry in self.jobs[number - 1]["polarizability"]
            if entry.get("complete")
            and entry.get("frequency") == 0
            and any(value != 0 for row in entry["tensor"] for value in row)
        ]
        return entries[-1] if entries else None

    def polarizability_equation(self, number):
        """Static tensor and isotropic mean in the printed coordinate frame."""
        tensor = self.static_polarizability(number)["tensor"]
        rows = [" & ".join(_number(value, 6).strip("$") for value in row) for row in tensor]
        matrix = r" \\ ".join(rows)
        mean = _number(sum(tensor[i][i] for i in range(3)) / 3, 6).strip("$")
        return (
            rf"$$\boldsymbol{{\alpha}}=-\frac{{\partial^2E}}{{\partial F_i\,\partial F_j}}"
            rf"=\begin{{pmatrix}}{matrix}\end{{pmatrix}}\,a_0^3,\qquad "
            rf"\bar{{\alpha}}=\tfrac{{1}}{{3}}\operatorname{{tr}}\boldsymbol{{\alpha}}={mean}\,a_0^3$$"
        )

    def quadrupole_equation(self, number):
        """The traceless quadrupole tensor of the archived density, in atomic units and debye angstrom."""
        properties = (self.jobs[number - 1].get("archive") or {}).get("properties", {})
        values = properties.get("Quadrupole")
        if not isinstance(values, list) or len(values) != 6:
            return None
        atomic = _tensor(values, TEXT["archive-tensors"]["quadrupole"], "e*bohr**2").strip("$")
        debye = _tensor(
            [(value * ureg.e * ureg.bohr**2).to("debye*angstrom").magnitude for value in values],
            TEXT["archive-tensors"]["quadrupole"],
            "debye*angstrom",
        ).strip("$")
        return rf"$$\mathbf{{Q}}={atomic}={debye}$$"

    def polarizability_table(self, number):
        """Static polarizability tensor in bohr cubed, from the last complete tensor."""
        entries = [entry for entry in self.jobs[number - 1]["polarizability"] if entry.get("complete")]
        table = pd.DataFrame(np.asarray(entries[-1]["tensor"]), columns=["polar_x", "polar_y", "polar_z"])
        table.insert(0, "axis", ["$x$", "$y$", "$z$"])
        return table

    def stability_table(self, number):
        """Wavefunction stability conclusions."""
        return pd.DataFrame(
            [dict(stable=entry["stable"], message=entry["message"]) for entry in self.jobs[number - 1]["stability"]]
        )

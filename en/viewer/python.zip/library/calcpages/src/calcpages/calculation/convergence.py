"""SCF solutions, optimization steps, reaction paths and the geometries a job moved through."""

import altair as alt
import numpy as np
import pandas as pd
from runflow.results import ureg
from runflow.text import identifier

from calcpages.charts import _chart, _hovered, _marker_rows, _step_path, margin, reference, rms_reference
from calcpages.fields import _frames, _LabelledFrames
from calcpages.i18n import message
from calcpages.keywords import _method_name
from calcpages.labels import LABELS, PLOT, quantity
from calcpages.notation import _changes, _to_ev, _value


class ConvergencePart:
    """SCF solutions, optimization steps, reaction paths and the geometries a job moved through. A part of :class:`calcpages.calculation.Calculation`."""

    def energy_table(self, number):
        """Printed energy components and virial ratio of the last SCF, without mixing geometries or linked jobs."""
        history = self.jobs[number - 1]["scf_history"]
        if not history:
            return None
        scf = history[-1]
        components = [
            ("kinetic_energy", "kinetic_energy"),
            ("nuclear_attraction", "nuclear_attraction"),
            ("electron_interaction", "electron_interaction"),
            ("nuclear_repulsion", "nuclear_repulsion"),
        ]
        rows = [(quantity(label), _value(scf[key], "hartree", 12)) for key, label in components if scf[key] is not None]
        if not rows and scf["virial_ratio"] is None:
            return None
        rows.append((quantity("scf-energy"), _value(scf["energy"], "hartree", 12)))
        if scf["virial_ratio"] is not None:
            rows.append((quantity("virial-ratio"), _value(scf["virial_ratio"], digits=6)))
        return pd.DataFrame(rows, columns=["quantity", "value"])

    def scf_method(self, number):
        """The method shared by every SCF of a linked job, or None when they differ."""
        methods = {scf["method"] for scf in self.jobs[number - 1]["scf_history"]}
        return methods.pop() if len(methods) == 1 else None

    def scf_table(self, number):
        """Every SCF of a linked job: final energy, cycles and density convergence; convergence where it changes."""
        history = self.jobs[number - 1]["scf_history"]
        table = pd.DataFrame(
            dict(
                scf=range(1, len(history) + 1),
                method=[_method_name(scf["method"]) for scf in history],
                energy=[_to_ev(scf["energy"]) for scf in history],
                cycles=[scf["cycles"] for scf in history],
                density_rms=[scf["density_rms"] for scf in history],
                converged=_changes([scf["converged"] for scf in history]),
            )
        )
        return table.drop(columns="method") if self.scf_method(number) else table

    @_hovered
    def scf_chart(self, number):
        """SCF cycles or density history, with convergence shown for each reported point."""
        history = self.jobs[number - 1]["scf_history"]
        status = lambda value: (
            message("chart-converged")
            if value is True
            else message("chart-not-converged")
            if value is False
            else message("chart-unknown")
        )
        color = alt.Color(
            f"{PLOT}convergence:N",
            scale=alt.Scale(
                domain=[message("chart-converged"), message("chart-not-converged"), message("chart-unknown")],
                range=["#198754", "#dc3545", "#6c757d"],
            ),
        )
        # A rule's second endpoint would otherwise merge both field names into one axis title.
        if len(history) > 1:
            data = pd.DataFrame(
                [
                    dict(scf=index, cycles=row["cycles"], convergence=status(row.get("converged")))
                    for index, row in enumerate(history, 1)
                ]
            )
            x = alt.X(f"{PLOT}scf:Q", axis=alt.Axis(tickMinStep=1), scale=margin(), title=f"{PLOT}scf")
            y = alt.Y(f"{PLOT}cycles:Q", axis=alt.Axis(tickMinStep=1), title=f"{PLOT}cycles")
            line = (
                _chart(_step_path(data, "scf", "cycles"))
                .mark_line(strokeWidth=2)
                .encode(x=x, y=y, color=color, detail=f"{PLOT}segment:N")
            )
            # A dot marks where the staircase changes level and the last SCF always, so the path ends on a dot.
            changed = data[data.cycles.ne(data.cycles.shift()) | (data.index == data.index[-1])]
            points = (
                _chart(changed)
                .mark_point(filled=True, size=50)
                .encode(
                    x=x,
                    y=y,
                    color=color,
                    tooltip=[
                        alt.Tooltip(f"{PLOT}scf:Q"),
                        alt.Tooltip(f"{PLOT}cycles:Q"),
                        alt.Tooltip(f"{PLOT}convergence:N"),
                    ],
                )
            )
            return line + points
        scf = history[0]
        threshold = scf.get("rms_threshold")
        data = pd.DataFrame(
            [
                dict(
                    cycle=row["iteration"],
                    density_rms=row["density_rms"],
                    convergence=status(row["density_rms"] <= threshold if threshold is not None else None),
                )
                for row in scf["cycle_history"]
                if row["density_rms"] is not None and row["density_rms"] > 0
            ]
        )
        x = alt.X(f"{PLOT}cycle:Q", axis=alt.Axis(tickMinStep=1), scale=margin(), title=f"{PLOT}cycle")
        y = alt.Y(f"{PLOT}density_rms:Q", title=f"{PLOT}density_rms", scale=alt.Scale(type="log"))
        line = (
            _chart(_step_path(data, "cycle", "density_rms"))
            .mark_line(strokeWidth=2)
            .encode(x=x, y=y, color=color, detail=f"{PLOT}segment:N")
        )
        points = (
            _chart(_marker_rows(data, "cycle"))
            .mark_point(filled=True, size=50)
            .encode(
                x=x,
                y=y,
                color=color,
                tooltip=[
                    alt.Tooltip(f"{PLOT}cycle:Q"),
                    alt.Tooltip(f"{PLOT}density_rms:Q"),
                    alt.Tooltip(f"{PLOT}convergence:N"),
                ],
            )
        )
        if threshold is None or threshold <= 0:
            return line + points
        rule = _chart(pd.DataFrame([dict(density_rms=threshold)])).mark_rule(**reference()).encode(y=y)
        return line + points + rule

    @_hovered
    def evaluation_forces_chart(self, number):
        """Recorded Cartesian force magnitudes by SCF solution, the axis of the SCF convergence chart, including IRC corrector steps."""
        rows = []
        conversion = (1 * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude
        for index, evaluation in enumerate(self.jobs[number - 1]["evaluations"], 1):
            for key, label in (
                ("force_maximum", message("chart-force-maximum")),
                ("force_rms", message("chart-force-rms")),
            ):
                value = evaluation.get(key)
                if value is not None:
                    rows.append(dict(scf=index, evaluation_force=value * conversion, force_statistic=label))
        # With a marker, a job of one evaluation still shows its value.
        return (
            _chart(pd.DataFrame(rows))
            .mark_line(point=True)
            .encode(
                x=alt.X(f"{PLOT}scf:Q", axis=alt.Axis(tickMinStep=1), scale=margin(), title=f"{PLOT}scf"),
                y=alt.Y(f"{PLOT}evaluation_force:Q", scale=margin()),
                color=alt.Color(f"{PLOT}force_statistic:N"),
                tooltip=[
                    alt.Tooltip(f"{PLOT}scf:Q"),
                    alt.Tooltip(f"{PLOT}force_statistic:N"),
                    alt.Tooltip(f"{PLOT}evaluation_force:Q", format=".6~g"),
                ],
            )
        )

    def irc_branches(self, number):
        """Directions along the reaction path, in the order the job reached them."""
        return list(dict.fromkeys(point["direction"].capitalize() for point in self.jobs[number - 1]["irc_points"]))

    def irc_reference(self, number):
        """Printed IRC saddle energy, or the last SCF before the first recorded path point."""
        job = self.jobs[number - 1]
        if job["irc_reference"] is not None:
            return job["irc_reference"]
        indices = [point["evaluation"] for point in job["irc_points"] if point["evaluation"] is not None]
        if not indices:
            return None
        first = min(indices)
        return job["evaluations"][first - 1]["energy"] if 0 < first <= len(job["evaluations"]) else None

    def irc_table(self, number, branch=None):
        """Reaction-path points in order: branch, reaction coordinate and energy relative to the saddle."""
        job = self.jobs[number - 1]
        energies = [evaluation["energy"] for evaluation in job["evaluations"]]
        reference = self.irc_reference(number)
        rows = []
        for point in job["irc_points"]:
            if branch is not None and point["direction"].capitalize() != branch:
                continue
            index = point["evaluation"]
            energy = energies[index] if index is not None and 0 <= index < len(energies) else None
            rows.append(
                dict(
                    point_index=point["point"],
                    branch=point["direction"].capitalize(),
                    reaction_coordinate=point["coordinate"],
                    path_energy=(energy - reference)
                    * (1 * ureg.hartree * ureg.avogadro_constant).to("kilojoule/mole").magnitude
                    if energy is not None and reference is not None
                    else None,
                )
            )
        table = pd.DataFrame(rows)
        return table.drop(columns="branch") if branch is not None and "branch" in table else table

    @_hovered
    def irc_chart(self, number):
        """Join the reverse and forward paths at the transition state, with a dashed line at zero."""
        data = self.irc_table(number).copy()
        data["reaction_coordinate"] = np.where(
            data["branch"] == "Reverse", -data["reaction_coordinate"].abs(), data["reaction_coordinate"].abs()
        )
        # Add the actual saddle only when its energy is known, once for each displayed branch.
        if self.irc_reference(number) is not None:
            saddle = pd.DataFrame(
                [dict(branch=branch, reaction_coordinate=0.0, path_energy=0.0) for branch in data["branch"].unique()]
            )
            data = pd.concat([data, saddle], ignore_index=True)
        reverse = data[(data["branch"] == "Reverse") & data["path_energy"].notna()]
        # A missing reverse branch cannot supply this reference. Keep the transition-state reference in that case.
        if reverse.empty:
            energy = "path_energy"
        else:
            endpoint = reverse.loc[reverse["reaction_coordinate"].idxmin(), "path_energy"]
            data["reverse_relative_energy"] = data["path_energy"] - endpoint
            energy = "reverse_relative_energy"
        # The branches as their legend names them, in the page language.
        data["branch"] = data["branch"].map(
            {"Reverse": message("irc-reverse-path"), "Forward": message("irc-forward-path")}
        )
        line = (
            _chart(data)
            .mark_line(point=True)
            .encode(
                x=alt.X(f"{PLOT}reaction_coordinate:Q"),
                y=alt.Y(f"{PLOT}{energy}:Q"),
                color=alt.Color(f"{PLOT}branch:N"),
            )
        )
        transition = (
            _chart(pd.DataFrame({"reaction_coordinate": [0.0]}))
            .mark_rule(**reference())
            .encode(x=f"{PLOT}reaction_coordinate:Q")
        )
        # Put the reference first so the zoom selection belongs to a non-faceted layer.
        return transition + line

    def optimization_table(self, number):
        """Energy and the four convergence criteria at every optimization step; convergence where it changes."""
        job = self.jobs[number - 1]
        energies = [evaluation["energy"] for evaluation in job["evaluations"]]
        rows = []
        for index, step in enumerate(job["optimization_history"], 1):
            row = dict(check_index=index)
            if step["evaluation"] is not None and step["evaluation"] < len(energies):
                row["energy"] = _to_ev(energies[step["evaluation"]])
            for check in step["checks"]:
                row[identifier(check["criterion"]).replace("-", "_")] = (
                    (check["value"] * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude
                    if "force" in check["criterion"]
                    else check["value"]
                )
            row["converged"] = all(check["passed"] for check in step["checks"])
            rows.append(row)
        table = pd.DataFrame(rows)
        table["converged"] = _changes(list(table["converged"]))
        return table

    def optimization_thresholds(self, number):
        """Distinct convergence limits, with check indices only where a limit changes."""
        limits = {}
        for index, step in enumerate(self.jobs[number - 1]["optimization_history"], 1):
            for check in step["checks"]:
                key = check["criterion"], check["threshold"]
                limits.setdefault(key, []).append(index)
        varying = any(sum(name == criterion for name, _ in limits) > 1 for criterion, _ in limits)
        rows = []
        for (criterion, threshold), indices in limits.items():
            key = identifier(criterion).replace("-", "_")
            value = (
                (threshold * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude
                if "force" in criterion
                else threshold
            )
            row = dict(criterion=LABELS[key], threshold=value)
            if varying:
                row["check_index"] = "$" + ", ".join(map(str, indices)) + "$"
            rows.append(row)
        return pd.DataFrame(rows)

    @_hovered
    def optimization_charts(self, number):
        """Optimization energy in eV, forces and native displacements, with separate maximum/RMS limits."""
        job = self.jobs[number - 1]
        indexed = []
        segment, previous = 0, None
        for index, step in enumerate(job["optimization_history"], 1):
            if previous is not None and step["iteration"] <= previous:
                segment += 1
            indexed.append((index, segment, step))
            previous = step["iteration"]
        samples = [
            (index, segment, job["evaluations"][step["evaluation"]]["energy"], step["checks"])
            for index, segment, step in indexed
            if step["evaluation"] is not None
        ]
        final = samples[-1][2]
        status = lambda value: (
            message("chart-converged")
            if value is True
            else message("chart-not-converged")
            if value is False
            else message("chart-unknown")
        )
        color = alt.Color(
            f"{PLOT}convergence:N",
            scale=alt.Scale(
                domain=[message("chart-converged"), message("chart-not-converged"), message("chart-unknown")],
                range=["#198754", "#dc3545", "#6c757d"],
            ),
        )

        def overall(checks):
            flags = [check.get("passed") for check in checks]
            if any(flag is False for flag in flags):
                return False
            return True if len(flags) >= 4 and all(flag is True for flag in flags) else None

        data = pd.DataFrame(
            [
                dict(
                    check_index=index,
                    optimization_segment=segment,
                    relative=_to_ev(value - final),
                    convergence=status(overall(checks)),
                )
                for index, segment, value, checks in samples
            ]
        )
        # Pair consecutive checks in output order, so the line reaches the last point even where a restart begins.
        segments = data.assign(
            next_check=data.check_index.shift(-1),
            next_relative=data.relative.shift(-1),
            convergence=data.convergence.shift(-1),
        ).dropna(subset=["next_check"])
        check_axis = alt.X(
            f"{PLOT}check_index:Q", axis=alt.Axis(tickMinStep=1), scale=margin(), title=f"{PLOT}check_index"
        )
        relative_axis = alt.Y(f"{PLOT}relative:Q", title=f"{PLOT}relative", scale=margin())
        energy_line = (
            _chart(segments)
            .mark_rule(strokeWidth=2)
            .encode(x=check_axis, x2=f"{PLOT}next_check:Q", y=relative_axis, y2=f"{PLOT}next_relative:Q", color=color)
        )
        energy_points = (
            _chart(_marker_rows(data, "check_index", group="optimization_segment"))
            .mark_point(filled=True, size=64)
            .encode(
                x=check_axis,
                y=relative_axis,
                color=color,
                tooltip=[
                    alt.Tooltip(f"{PLOT}check_index:Q"),
                    alt.Tooltip(f"{PLOT}relative:Q"),
                    alt.Tooltip(f"{PLOT}convergence:N"),
                ],
            )
        )
        energy = energy_line + energy_points

        def criteria(family):
            """Show one family in its own units, with shape and line style identifying maximum and RMS."""
            value_field, limit_field = f"optimization_{family}", f"optimization_{family}_threshold"
            names = (
                [message("chart-force-maximum"), message("chart-force-rms")]
                if family == "force"
                else [message("chart-displacement-maximum"), message("chart-displacement-rms")]
            )
            rows = []
            for index, segment, step in indexed:
                for check in step["checks"]:
                    if family not in check["criterion"]:
                        continue
                    value, threshold = check["value"], check["threshold"]
                    if family == "force":
                        value = (value * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude
                        threshold = (threshold * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude
                    rows.append(
                        dict(
                            check_index=index,
                            optimization_segment=segment,
                            criterion=names["rms" in check["criterion"]],
                            **{value_field: value, limit_field: threshold},
                            convergence=status(check.get("passed")),
                        )
                    )
            check_axis = alt.X(
                f"{PLOT}check_index:Q", axis=alt.Axis(tickMinStep=1), scale=margin(), title=f"{PLOT}check_index"
            )
            value_axis = alt.Y(f"{PLOT}{value_field}:Q", title=PLOT + value_field, scale=margin())
            base = _chart(pd.DataFrame(rows)).encode(x=check_axis, y=value_axis)
            # Both legends carry a title so Vega-Lite aligns their entries beneath it in one bottom row.
            style = alt.StrokeDash(
                f"{PLOT}criterion:N",
                scale=alt.Scale(domain=names, range=[[], [2, 2]]),
                legend=alt.Legend(title=PLOT + "criterion"),
            )
            shape = alt.Shape(
                f"{PLOT}criterion:N",
                scale=alt.Scale(domain=names, range=["circle", "square"]),
                legend=alt.Legend(title=PLOT + "criterion"),
            )
            # Pair each criterion's consecutive checks, so every line reaches its last printed point.
            frame = pd.DataFrame(rows)
            grouped = frame.groupby("criterion", sort=False)
            segments = frame.assign(
                next_check=grouped.check_index.shift(-1),
                next_value=grouped[value_field].shift(-1),
                convergence=grouped.convergence.shift(-1),
            ).dropna(subset=["next_check"])
            line = (
                _chart(segments)
                .mark_rule(strokeWidth=2)
                .encode(
                    x=check_axis,
                    x2=f"{PLOT}next_check:Q",
                    y=value_axis,
                    y2=f"{PLOT}next_value:Q",
                    color=color,
                    strokeDash=style,
                )
            )
            points = base.mark_point(filled=True, size=64).encode(shape=shape, color=color)
            # Each limit spans the whole plot, in its criterion's line type; a restart that changes it adds another.
            limits = [
                _chart(pd.DataFrame({limit_field: checks[limit_field].dropna().unique()}))
                .mark_rule(**(rms_reference() if name == names[1] else reference()))
                .encode(y=alt.Y(f"{PLOT}{limit_field}:Q", title=PLOT + value_field, scale=margin()))
                for name, checks in frame.groupby("criterion", sort=False)
            ]
            hit = base.mark_point(opacity=0, size=576).encode(
                tooltip=[
                    alt.Tooltip(f"{PLOT}check_index:Q"),
                    alt.Tooltip(f"{PLOT}criterion:N"),
                    alt.Tooltip(f"{PLOT}{value_field}:Q", format=".6~g"),
                    alt.Tooltip(f"{PLOT}{limit_field}:Q", format=".6~g"),
                    alt.Tooltip(f"{PLOT}convergence:N"),
                ]
            )
            return alt.layer(line, *limits, points, hit).properties(height=200)

        return energy, criteria("force"), criteria("displacement")

    def trajectory(self, number):
        """XYZ frames of every geometry Gaussian printed in a linked job, a reaction path ordered from its reverse
        endpoint, through the starting saddle, to its forward endpoint.
        """
        job = self.jobs[number - 1]
        geometries = job["geometries"]
        points = job["irc_points"]
        # Only reorder when every point has a known branch and coordinate. An incomplete record with unknown
        # direction must not be silently assigned to the reverse branch; retain native geometry order instead.
        if points and all(
            point["direction"] in ("reverse", "forward")
            and point["coordinate"] is not None
            and np.isfinite(point["coordinate"])
            for point in points
        ):
            angstrom = lambda values: (
                values.to("angstrom").magnitude if hasattr(values, "to") else np.asarray(values, dtype=float)
            )
            # Gaussian outputs may carry either signed or unsigned branch coordinates.
            reverse = sorted(
                (point for point in points if point["direction"] == "reverse"),
                key=lambda point: -abs(point["coordinate"]),
            )
            forward = sorted(
                (point for point in points if point["direction"] == "forward"),
                key=lambda point: abs(point["coordinate"]),
            )
            between = [geometries[0]["vectors"]] if geometries else []
            frames = (
                [angstrom(point["coordinates"]) for point in reverse]
                + between
                + [angstrom(point["coordinates"]) for point in forward]
            )
            labels = {}
            if reverse:
                labels[message("frame-reverse-endpoint")] = 1
            if between:
                labels[message("frame-transition-state")] = len(reverse) + 1
            if forward:
                labels[message("frame-forward-endpoint")] = len(frames)
            return _LabelledFrames(_frames(points[0]["atomic_numbers"], frames, job.get("charge")), labels)
        return _frames(
            geometries[0]["atomic_numbers"], [geometry["vectors"] for geometry in geometries], job.get("charge")
        )

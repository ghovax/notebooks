"""Formatted checkpoints of a calculation: their geometries, orbitals, paths and modes."""

import numpy as np
import pandas as pd
from runflow.checkpoints import read_gaussian_checkpoint
from runflow.molecules import xyz_frames
from runflow.results import ureg

from calcpages.charts import _chart, _energy_sets, _hover, _hovered, _levels_chart
from calcpages.fields import _records, _symmetry_cached
from calcpages.labels import PLOT
from calcpages.notation import _number, _to_ev


class CheckpointsPart:
    """Formatted checkpoints of a calculation: their geometries, orbitals, paths and modes. A part of :class:`calcpages.calculation.Calculation`."""

    def checkpoints_table(self, checkpoints):
        """The formatted checkpoints as (role, path) pairs, one row each: what it is, or its number in order when
        there are several, its atoms, its energy and its orbital gap in eV.
        """
        rows = []
        for index, (role, path) in enumerate(checkpoints, 1):
            records = _records(path)
            energies, electrons = records.get("Alpha Orbital Energies"), records.get("Number of alpha electrons")
            gap = (
                _to_ev(energies[electrons] - energies[electrons - 1])
                if energies is not None and electrons and electrons < len(energies)
                else None
            )
            energy = records.get("Total Energy", records.get("SCF Energy"))
            rows.append(
                dict(
                    checkpoint=index if len(checkpoints) > 1 else role,
                    atoms=records.get("Number of atoms"),
                    energy=_number(_to_ev(energy), 10) if energy is not None else "",
                    gap=gap,
                )
            )
        table = pd.DataFrame(rows)
        return table.drop(columns="gap") if table.gap.isna().all() else table

    def checkpoint_frames(self, checkpoints):
        """XYZ frames of the checkpoints' geometries in order, for one animated viewer; checkpoints of other atoms
        than the first are left out.
        """
        read = [read_gaussian_checkpoint(path) for _, path in checkpoints]
        kept = [checkpoint for checkpoint in read if np.array_equal(checkpoint.numbers, read[0].numbers)]
        return xyz_frames(
            read[0].numbers,
            np.stack([checkpoint.coordinates.to("angstrom").magnitude for checkpoint in kept]) * ureg.angstrom,
        )

    def checkpoint_orbitals(self, path):
        """Orbital-level charts of a formatted checkpoint, as the output sections draw them: one for a restricted
        wavefunction, the alpha then the beta orbitals for an unrestricted one; empty without orbital energies.
        """
        records = _records(path)
        charts = []
        for spin in ("Alpha", "Beta"):
            energies = records.get(spin + " Orbital Energies")
            electrons = records.get(f"Number of {spin.lower()} electrons")
            if energies is not None and electrons and electrons < len(energies):
                symmetry = _symmetry_cached(str(path), spin.lower())
                sets = (
                    symmetry.sets if symmetry is not None else _energy_sets(energies[:electrons], energies[electrons:])
                )
                charts.append(_hover(_levels_chart([(None, sets)])))
        return charts

    @_hovered
    def checkpoint_path_chart(self, path):
        """Energy along the reaction path a formatted checkpoint holds, relative to its highest point, the transition
        structure, against the reaction coordinate.
        """
        reaction = read_gaussian_checkpoint(path).irc
        energies = reaction.energies.to("hartree").magnitude
        data = pd.DataFrame(
            dict(
                reaction_coordinate=reaction.coordinate.magnitude, path_energy=(energies - energies.max()) * 627.509474
            )
        )
        return (
            _chart(data.sort_values("reaction_coordinate"))
            .mark_line(point=True)
            .encode(x=f"{PLOT}reaction_coordinate:Q", y=f"{PLOT}path_energy:Q")
        )

    def checkpoint_modes_table(self, path):
        """Harmonic modes of a formatted checkpoint with their reduced masses, force constants and IR intensities, as
        the output sections list them.
        """
        modes = read_gaussian_checkpoint(path).vibrations
        return pd.DataFrame(
            dict(
                mode=range(1, len(modes.frequencies) + 1),
                frequency=modes.frequencies.to("1/cm").magnitude,
                reduced_mass=modes.masses.to("dalton").magnitude,
                force_constant=modes.constants.to("millidyne/angstrom").magnitude,
                intensity=modes.intensities.to("km/mol").magnitude,
            )
        )

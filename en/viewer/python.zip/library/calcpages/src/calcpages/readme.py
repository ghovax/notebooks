"""README files: their front matter, read once per version of each file, and their text in the page language.

A README may have a translation in the ``translations`` folder beside it, one folder per language code, such as
``translations/ja/README.md`` beside ``README.md``.
It repeats only what it translates, all in its own language: its front matter may give the ``page-title``, its part
before the first ``##`` heading replaces the title, status quote and introduction when it has a title, and each of its
``##`` sections replaces the English section its heading's id names, such as ``## 目的 {#goal}`` for ``## Goal``. The
text keeps README.md's heading lines, which programs read, with the translated sections under them. Everything else, and every record a program reads, such
as the front matter's dates and assessment, stays that of ``README.md``.
"""

import copy
import functools
import re
from pathlib import Path

import yaml
from runflow.text import FILLER_WORDS, identifier

from calcpages.i18n import translation as translated_file


@functools.lru_cache(maxsize=None)
def _parsed_yaml(text):
    """Parsed YAML text, which a build asks for tens of thousands of times over the same few files."""
    return yaml.safe_load(text)


def load_yaml(text):
    """YAML text as data of the caller's own, parsed once per distinct text so that an edited file is always read afresh."""
    return copy.deepcopy(_parsed_yaml(text))


def readme_metadata(folder):
    """Read YAML front matter from a README; a README without front matter has no metadata. Each version of a README
    is parsed once, and every caller gets its own copy.
    """
    path = Path(folder) / "README.md"
    info = path.stat()
    return copy.deepcopy(_front_matter(str(path), info.st_mtime_ns, info.st_size))


@functools.lru_cache(maxsize=None)
def _front_matter(path, modified, size):
    """The front matter of one version of a README, by its path, modification time and size."""
    text = Path(path).read_text()
    match = re.match(r"\A---[ \t]*\n(.*?)\n---[ \t]*(?:\n|$)", text, re.S)
    if not match:
        return {}
    data = load_yaml(match[1]) or {}
    if not isinstance(data, dict):
        raise ValueError(f"{path}: front matter must be a mapping")
    return data


# Front matter fields a translation may give; the rest of the front matter is the record of README.md.
TRANSLATED_FIELDS = {"page-title"}


def translation(folder):
    """The translation of a folder's README into the page language, or None when it has none.

    Args:
        folder: Folder holding the README.

    Returns:
        The path of ``translations/<code>/README.md``, or None.
    """
    return translated_file(Path(folder) / "README.md")


def readme_text(folder):
    """A folder's README in the page language: ``README.md`` with its translation laid over it, part by part.

    Args:
        folder: Folder holding the README.

    Returns:
        The README text, its front matter that of ``README.md``.
    """
    english = Path(folder) / "README.md"
    own = translation(folder)
    if own is None:
        return english.read_text()
    first, second = english.stat(), own.stat()
    return _overlaid(str(english), first.st_mtime_ns, first.st_size, str(own), second.st_mtime_ns, second.st_size)


def translated_metadata(folder):
    """A README's front matter with the fields its translation gives, for what the page shows.

    Args:
        folder: Folder holding the README.

    Returns:
        The front matter of ``README.md`` with the translated fields laid over it.

    Raises:
        ValueError: The translation gives a field that is a record rather than text to show.
    """
    metadata = readme_metadata(folder)
    own = translation(folder)
    if own is None:
        return metadata
    info = own.stat()
    fields = _front_matter(str(own), info.st_mtime_ns, info.st_size)
    if extra := set(fields) - TRANSLATED_FIELDS:
        raise ValueError(
            f"{own}: a translation's front matter gives only {', '.join(sorted(TRANSLATED_FIELDS))}, not {sorted(extra)}"
        )
    return {**metadata, **copy.deepcopy(fields)}


def _parts(text):
    """A README's front matter block, its part before the first ``##`` heading and its sections by heading line,
    with headings inside fenced blocks left in their section.
    """
    match = re.match(r"\A---[ \t]*\n.*?\n---[ \t]*(?:\n|$)", text, re.S)
    front = match[0] if match else ""
    head, sections, current, fenced = [], {}, None, False
    for line in text[len(front) :].splitlines(keepends=True):
        if line.startswith("```"):
            fenced = not fenced
        if not fenced and line.startswith("## "):
            current = line.rstrip()
            sections[current] = []
        (sections[current] if current else head).append(line)
    return front, "".join(head), {heading: "".join(lines) for heading, lines in sections.items()}


def heading_texts(folder):
    """The ``##`` headings a README's translation gives, by the English heading text each names by its id.

    Args:
        folder: Folder holding the README.

    Returns:
        Each translated heading's text, without its id, by English heading text; empty without a translation.
    """
    own = translation(folder)
    if own is None:
        return {}
    english = {
        section_id(line): line[3:].strip()
        for line in (Path(folder) / "README.md").read_text().splitlines()
        if line.startswith("## ")
    }
    given = {}
    for line in own.read_text().splitlines():
        if line.startswith("## ") and section_id(line) in english:
            given[english[section_id(line)]] = re.sub(r"\s*\{#[a-z0-9-]+\}\s*$", "", line[3:]).strip()
    return given


def section_id(heading):
    """The id of a ``##`` heading line: the one it gives, as in ``## 目的 {#goal}``, or else its text's identifier
    without filler words, ``goal`` for ``## Goal`` and ``interpretation-remaining-work`` for
    ``## Interpretation and remaining work``.
    """
    match = re.fullmatch(r"##\s+(.*?)(?:\s*\{#([a-z0-9-]+)\})?\s*", heading)
    return match[2] or "-".join(word for word in identifier(match[1]).split("-") if word not in FILLER_WORDS)


@functools.lru_cache(maxsize=None)
def _overlaid(english, english_modified, english_size, own, own_modified, own_size):
    """The README ``english`` with the parts its translation ``own`` gives, for one version of each file."""
    front, head, sections = _parts(Path(english).read_text())
    _, own_head, own_sections = _parts(Path(own).read_text())
    if re.search(r"(?m)^# ", own_head):
        head = own_head if own_head.endswith("\n") else own_head + "\n"
    headings = {section_id(heading): heading for heading in sections}
    given = {
        headings[section_id(heading)]: headings[section_id(heading)] + "\n" + body.partition("\n")[2]
        for heading, body in own_sections.items()
        if section_id(heading) in headings
    }
    merged = {heading: given.get(heading, body) for heading, body in sections.items()}
    return front + head + "".join(body if body.endswith("\n") else body + "\n" for body in merged.values())

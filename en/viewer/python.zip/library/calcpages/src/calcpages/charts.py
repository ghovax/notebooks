"""Altair charts of calculation records: energy levels, hover boxes, spectral regions and status-coloured paths."""

import json

import altair as alt
import networkx as nx
import numpy as np
import pandas as pd
from runflow.orbital_symmetry import OrbitalSet

from calcpages.appearance import FADED_OPACITY, PADDING, PALETTE, REFERENCE_LINE, RMS_DASH
from calcpages.i18n import message
from calcpages.labels import PLOT
from calcpages.notation import _irrep_order, _to_ev


def level_diagram(levels, columns, *, color, scale=alt.Undefined, links=None, domain=None, tooltip=(), close=None):
    """Energy levels as a diagram: a bar per level in its column, named on hover rather than written beside it, so the
    diagram stays legible however many levels it holds. Levels of one column closer than ``close`` share their row side
    by side and a degenerate set splits its bar into components, so no two bars overlap; dashed links join levels of
    different columns, darker for larger weights. Clicking a level keeps its whole chain in full colour, every level its
    links reach directly or through others and those links, and fades every other level and link by the same amount;
    clicking empty space restores them.

    Args:
        levels: Table of levels: ``column`` (position in ``columns``), ``orbital_energy`` in eV, ``components`` (bars
            side by side, one by default) and the fields named by ``color`` and ``tooltip``.
        columns: Column titles under the axis, LaTeX inside ``$...$``.
        color: Field that colours the bars.
        scale: Colour scale of that field.
        links: Table of links: ``source`` and ``target``, positions of two levels of different columns in ``levels``,
            and ``weight`` from zero to one; None for none.
        domain: Energies framed at first, in eV; by default every level with half an electronvolt to spare.
        tooltip: Fields of the levels listed when hovering a bar, before the energy.
        close: Energy difference in eV below which levels of a column share a row; by default 3% of the framed span.

    Returns:
        The layered Altair chart.
    """
    levels = levels.reset_index(drop=True).copy()
    if domain is None:
        domain = (levels.orbital_energy.min() - 0.5, levels.orbital_energy.max() + 0.5)
    close = 0.03 * (domain[1] - domain[0]) if close is None else close
    # Half the width of a column's bars, and the space between bars sharing a row.
    half, space = 0.36, 0.04
    for column, group in levels.groupby("column"):
        rows = []
        for index in group.sort_values("orbital_energy").index:
            if rows and levels.orbital_energy[index] - levels.orbital_energy[rows[-1][0]] < close:
                rows[-1].append(index)
            else:
                rows.append([index])
        for row in rows:
            width = (2 * half - space * (len(row) - 1)) / len(row)
            for k, index in enumerate(row):
                levels.loc[index, "left"] = column - half + k * (width + space)
                levels.loc[index, "right"] = column - half + k * (width + space) + width
    # Each level is known by its position and lists every level its links reach, directly or through others, both ways,
    # as |i|j|...|: its connected component of the links. A click on one keeps that whole chain in colour.
    levels["level"] = levels.index
    graph = nx.Graph()
    graph.add_nodes_from(levels.index)
    graph.add_edges_from(
        (link["source"], link["target"]) for link in (links.to_dict("records") if links is not None else [])
    )
    chain = {
        index: "|" + "|".join(str(member) for member in sorted(component)) + "|"
        for component in nx.connected_components(graph)
        for index in component
    }
    levels["linked"] = [chain[index] for index in levels.index]
    bars = []
    for record in levels.to_dict("records"):
        count = int(record.get("components") or 1)
        width = (record["right"] - record["left"] - space * (count - 1)) / count
        bars += [
            dict(record, start=record["left"] + k * (width + space), end=record["left"] + k * (width + space) + width)
            for k in range(count)
        ]
    # Every layer names the same y title, which Vega would otherwise merge from the layers' fields.
    title = PLOT + "orbital_energy"
    heights = alt.Scale(domain=list(domain), nice=False, zero=False)
    across = alt.Scale(domain=[-0.5, len(columns) - 0.5], nice=False, zero=False)
    # The columns are numbered; the axis, styled as every other, writes each number as its title.
    axis = alt.Axis(
        values=list(range(len(columns))),
        labelExpr=f"{json.dumps(list(columns))}[datum.value]",
        grid=False,
        labelOverlap=False,
        labelLimit=0,
        title=None,
    )
    x = lambda field: alt.X(f"{PLOT}{field}:Q", scale=across, axis=axis)
    y = alt.Y(f"{PLOT}orbital_energy:Q", scale=heights, title=title)
    # The clicked level: Vega-Lite holds a point selection's value as {field: [value]}, empty when nothing is chosen.
    pick = alt.selection_point(name="level_pick", fields=[f"{PLOT}level"], on="click")
    chosen = (
        f"!isValid(level_pick.{PLOT}level) || indexof(datum.{PLOT}linked, '|' + level_pick.{PLOT}level[0] + '|') >= 0"
    )
    layers = []
    if links is not None and len(links):
        joined = []
        for link in links.to_dict("records"):
            first, second = sorted((levels.loc[link["source"]], levels.loc[link["target"]]), key=lambda row: row.column)
            # A link belongs to the chain of the levels it joins.
            joined.append(
                dict(
                    start=first.right,
                    end=second.left,
                    orbital_energy=first.orbital_energy,
                    target=second.orbital_energy,
                    weight=link["weight"],
                    linked=chain[link["source"]],
                )
            )
        layers.append(
            _chart(pd.DataFrame(joined))
            .mark_rule(**reference())
            .encode(
                x=x("start"),
                x2=f"{PLOT}end",
                y=y,
                y2=alt.Y2(f"{PLOT}target", title=title),
                opacity=alt.condition(
                    f"!({chosen})",
                    alt.value(FADED_OPACITY),
                    alt.Opacity(f"{PLOT}weight:Q", scale=alt.Scale(domain=[0, 1], range=[0.25, 1]), legend=None),
                ),
            )
        )
    fade = alt.condition(chosen, alt.value(1), alt.value(FADED_OPACITY))
    layers.append(
        _chart(pd.DataFrame(bars))
        .mark_rule(strokeWidth=3, clip=True)
        .encode(
            x=x("start"),
            x2=f"{PLOT}end",
            y=y,
            color=alt.Color(f"{PLOT}{color}:N", scale=scale),
            opacity=fade,
            tooltip=[PLOT + field for field in tooltip] + [alt.Tooltip(f"{PLOT}orbital_energy:Q", format=".4f")],
        )
    )
    # A thin bar is hard to reach, so a wider transparent one takes the pointer and the click; its own opacity overrides
    # the highlight.
    layers.append(layers[-1].mark_rule(strokeWidth=12, clip=True).encode(opacity=alt.value(0)).add_params(pick))
    # One layer of every part: each + would copy the whole chart built so far. The links' opacity shows their weight, so
    # it keeps its own scale.
    return alt.layer(*layers).resolve_scale(opacity="independent")


def _energy_sets(occupied, virtual, degeneracy=1e-4):
    """Orbital sets from energies in hartree alone, without symmetry: degenerate orbitals together."""
    sets = []
    for index, energy in enumerate(list(occupied) + list(virtual)):
        is_occupied = index < len(occupied)
        last = sets[-1] if sets else None
        if last and last.occupied == is_occupied and abs(energy - last.energy) < degeneracy:
            last.indices.append(index)
        else:
            sets.append(OrbitalSet([index], float(energy), is_occupied))
    return sets


def _frontier(sets, count, occupied):
    """The occupied sets from the highest down, or the unoccupied ones from the lowest up, until they hold at least
    ``count`` orbitals.
    """
    chosen, held = [], 0
    for orbital_set in reversed(sets) if occupied else sets:
        if orbital_set.occupied != occupied or held >= count:
            continue
        chosen.append(orbital_set)
        held += len(orbital_set.indices)
    return chosen[::-1] if occupied else chosen


def _frontier_names(shown, spin=None):
    """HOMO, HOMO_1, HOMO_2, ... for the occupied sets shown and LUMO, LUMO_1, ... for the unoccupied ones, the
    subscript counting sets from the frontier, in LaTeX, by set; ``spin``, alpha or beta for an unrestricted
    wavefunction, adds the channel as a superscript, such as HOMO^beta.
    """
    occupied = [s for s in shown if s.occupied][::-1]
    virtual = [s for s in shown if not s.occupied]
    channel = rf"^{{\{spin}}}" if spin else ""
    names = {id(s): r"$\mathrm{HOMO}" + channel + (f"_{{{k}}}" if k else "") + "$" for k, s in enumerate(occupied)}
    names.update({id(s): r"$\mathrm{LUMO}" + channel + (f"_{{{k}}}" if k else "") + "$" for k, s in enumerate(virtual)})
    return names


def _levels_chart(channels, window=4):
    """Orbital energies around the gap, in eV, as a ``level_diagram``: one column per symmetry of each spin channel,
    coloured by occupation, each set named by its position from the frontier on hover. ``channels`` are pairs of a
    spin, alpha or beta for an unrestricted wavefunction or None for a restricted one, and its orbital sets.
    """
    species = lambda s: s.irrep.orbital() if s.irrep is not None else ""
    columns, rows = [], []
    for spin, sets in channels:
        shown = _frontier(sets, window, True) + _frontier(sets, window, False)
        names = _frontier_names(shown, spin)
        kinds = sorted(dict.fromkeys(species(s) for s in shown), key=_irrep_order)
        offset = len(columns)
        columns += [
            ", ".join(part for part in (rf"$\{spin}$" if spin else "", f"${kind}$" if kind else "") if part)
            for kind in kinds
        ]
        rows += [
            dict(
                column=offset + kinds.index(species(s)),
                orbital_energy=_to_ev(s.energy),
                components=len(s.indices),
                orbital=f"${s.label()}$",
                frontier_level=names[id(s)],
                degeneracy=len(s.indices),
                occupation=message("orbital-occupied") if s.occupied else message("orbital-unoccupied"),
                character=f"${s.character_label()}$" if s.character_label() else "",
            )
            for s in shown
        ]
    levels = pd.DataFrame(rows)
    tooltip = [
        "frontier_level",
        "orbital",
        *(["character"] if levels.character.astype(bool).any() else []),
        "occupation",
        "degeneracy",
    ]
    return level_diagram(
        levels,
        columns,
        color="occupation",
        scale=alt.Scale(domain=[message("orbital-occupied"), message("orbital-unoccupied")]),
        tooltip=tooltip,
    )


def _distinct_colors(count):
    """``count`` colours, no two alike: Tableau's ten main colours for up to ten, its twenty for up to twenty, and
    beyond that hues spread by the golden angle at alternating lightness.
    """
    if count <= 10:
        return PALETTE[::2][:count]
    if count <= 20:
        return PALETTE[:count]
    import colorsys

    return [
        "#"
        + "".join(f"{round(255 * c):02x}" for c in colorsys.hls_to_rgb((k * 0.381966) % 1, 0.45 + 0.15 * (k % 2), 0.6))
        for k in range(count)
    ]


def _chart(data):
    """Altair chart of a table whose columns are renamed to their plot fields."""
    return alt.Chart(data.rename(columns=lambda name: PLOT + name))


def _hover(chart):
    """The chart with a hover box listing its encoded x, y and colour fields, unless it declares its own. Every
    drawn line or point layer of a layered chart gets one; reference rules stay silent, since their second endpoints
    are not data fields.
    """
    if isinstance(chart, alt.LayerChart):
        chart.layer = [
            layer if isinstance(layer, alt.Chart) and getattr(layer.mark, "type", None) == "rule" else _hover(layer)
            for layer in chart.layer
        ]
        return chart
    if chart.encoding.tooltip is not alt.Undefined:
        return chart
    fields = [
        channel.shorthand
        for channel in (chart.encoding.x, chart.encoding.y, chart.encoding.color)
        if channel is not alt.Undefined and isinstance(getattr(channel, "shorthand", None), str)
    ]
    return chart.encode(
        tooltip=[alt.Tooltip(field, format=".6~g") if field.endswith(":Q") else alt.Tooltip(field) for field in fields]
    )


def _hovered(method):
    """Decorate a chart method so that every chart it returns, alone or in a tuple, has a hover box."""

    def wrapper(*args, **kwargs):
        result = method(*args, **kwargs)
        return tuple(map(_hover, result)) if isinstance(result, tuple) else _hover(result)

    wrapper.__doc__, wrapper.__name__ = method.__doc__, method.__name__
    return wrapper


def _annotation(chart, **style):
    """Text marks written in a plot: dark text over a white halo of the same text, so that the marks they cross
    stay behind it, instead of running through it; clipped to the plot when it is zoomed. The chart carries the
    text and its position; the result is the halo and the text, two charts to layer with the plot's others.
    """
    style = dict(fontSize=13, clip=True) | style
    return [
        chart.mark_text(color="white", stroke="white", strokeWidth=4, strokeJoin="round", **style),
        chart.mark_text(color="#333333", **style),
    ]


def _regions(field, low, high, regions):
    """Layers dividing a spectrum's x axis between ``low`` and ``high`` into regions: a dashed line at each border
    inside that range. The regions are named on hover of each band, by ``_region``, not written in the plot.
    """
    shown = [
        (region["name"], max(region["from"], low), min(region["to"], high))
        for region in regions
        if region["from"] < high and region["to"] > low
    ]
    borders = sorted({edge for _, lower, upper in shown for edge in (lower, upper)} - {low, high})
    return [
        alt.Chart(pd.DataFrame({PLOT + field: borders}))
        .mark_rule(**{**reference(), "color": "#adb5bd"})
        .encode(x=f"{PLOT}{field}:Q")
    ]


def _region(value, regions):
    """Name of the region a value falls in, or an empty name outside them all."""
    return next((region["name"] for region in regions if region["from"] <= value < region["to"]), "")


def _series(label):
    """Colour encoding of a single plotted quantity, so its chart carries a legend naming it."""
    return alt.Color(f"{PLOT}series:N", scale=alt.Scale(domain=[label]))


def _mode_tooltip(table):
    """Hover box of a normal mode: all the columns of its table that the job printed, in physical order."""
    fields = (
        ("mode", "N", None),
        ("mode_character", "N", None),
        ("symmetry", "N", None),
        ("frequency", "Q", ".2f"),
        ("reduced_mass", "Q", ".4f"),
        ("force_constant", "Q", ".4f"),
        ("intensity", "Q", ".3f"),
    )
    return [
        alt.Tooltip(f"{PLOT}{name}:{kind}", **({"format": style} if style else {}))
        for name, kind, style in fields
        if name in table
    ]


def _step_path(data, x, y):
    """A step-after path, one line per run of points of one status, each coloured by that status; the piece into a change
    of status takes the colour of the point it arrives at. A line per pair would draw a node per pair.
    """
    rows, segment = [], -1
    for index in range(len(data) - 1):
        first, second = data.iloc[index], data.iloc[index + 1]
        status = second["convergence"]
        if not rows or rows[-1]["convergence"] != status:
            segment += 1
            rows.append({x: first[x], y: first[y], "convergence": status, "segment": segment})
        rows.append({x: second[x], y: first[y], "convergence": status, "segment": segment})
        rows.append({x: second[x], y: second[y], "convergence": status, "segment": segment})
    return pd.DataFrame(rows)


def _marker_rows(frame, field, group=None, maximum=40):
    """Rows a line shows markers for, as thin_line_markers samples a point overlay: at most ``maximum`` rows of each
    series, evenly spaced in order with both endpoints kept.
    """
    columns = [field] + ([group] if group else [])
    data = frame.sort_values(columns)
    parts = []
    for _, series in data.groupby(group, sort=False) if group else [(None, data)]:
        count = len(series)
        parts.append(
            series if count <= maximum else series.iloc[np.rint(np.linspace(0, count - 1, maximum)).astype(int)]
        )
    return pd.concat(parts).sort_values(columns)


def _nominal(field, order):
    """A categorical axis in a fixed order, kept when charts are layered, whose labels are its values, not numbers.
    Every category keeps its label: Vega would judge overlap from a label's LaTeX source, longer than its typeset
    text, and drop some.
    """
    return alt.X(
        f"{PLOT}{field}:N",
        sort=order,
        scale=alt.Scale(domain=order),
        axis=alt.Axis(labelExpr="datum.value", labelOverlap=False, labelLimit=0),
    )


def margin():
    """A scale that does not start at zero, with the configured padding around its data.

    Returns:
        The Altair scale.
    """
    return alt.Scale(zero=False, padding=PADDING)


def reference():
    """Mark properties of a dashed reference line: a limit, a saddle or a region's border.

    Returns:
        The properties, from the ``reference-line`` setting.
    """
    return dict(REFERENCE_LINE)


def rms_reference():
    """Mark properties of the reference line of an RMS criterion, with shorter dashes than a maximum's.

    Returns:
        The properties.
    """
    return {**reference(), "strokeDash": RMS_DASH}

"""Tables of the coordinates an input defines: GIC and ModRedundant lines, their settings and icons."""

import re

import numpy as np
import pandas as pd
from runflow.inputs.gic import latex
from runflow.inputs.sections import PRINTED
from runflow.results import ureg
from runflow.text import identifier

from calcpages.i18n import message
from calcpages.labels import quantity, unit_latex
from calcpages.notation import _number
from calcpages.text import TEXT


def _icon(icons, name, title):
    """An icon of the folder ``icons`` with ``title`` as its hover text; the title alone without a folder or icon."""
    return f'![{title}]({icons}{name}.svg "{title}"){{.workflow-status}}' if icons and name else title


def _coordinate_kind(measure, unit, icons):
    """What a coordinate measures, as its icon, or in words without icons, followed by its unit in brackets, the unit
    of every value in the row; None for nothing.
    """
    kind = TEXT["coordinate-measures"].get(identifier(measure)) if measure else None
    if not kind:
        return None
    shown = _icon(icons, kind["icon"], kind["name"])
    return f"{shown} $[{unit_latex(unit)}]$" if unit else shown


def _action_icons(actions, icons):
    """Actions, by runflow's codes, as icons with their words as hover text, or the words without icons; None for none."""
    known = TEXT["coordinate-actions"]
    shown = (known.get(action, {"word": action, "icon": None}) for action in actions)
    return " ".join(_icon(icons, action["icon"], action["word"]) for action in shown) or None


def _coordinate_value(value, digits=6):
    """A coordinate's value in LaTeX, in the unit its row's coordinate column gives; None for no value."""
    if value is None:
        return None
    return "$" + _number(value, digits).replace("$", "") + "$"


def _settings_table(rows):
    """Settings of a line as a subtable of option and value; None without any."""
    return pd.DataFrame(rows, columns=["option", "value"]) if rows else None


def _scan_rows(steps, step, start):
    """Rows of a scan's settings: its steps, its step size and, when the start is known, its last point."""
    rows = [(quantity("scan-steps"), steps), (quantity("scan-step-size"), _coordinate_value(step, 12))]
    if start is not None:
        rows.append((quantity("scan-last-point"), _coordinate_value(start + steps * step)))
    return rows


def _modredundant_definition(entry):
    """A ModRedundant line's coordinate in LaTeX: its printed function with the atoms as a subscript, a Cartesian
    line as the atom's position; the line as written when its type is unknown.
    """
    if not entry["type"]:
        return f"`{entry['text']}`"
    atoms = ",".join(r"\ast" if atom == "*" else str(atom) for atom in entry["atoms"])
    symbol = r"\mathbf{r}" if entry["type"] == "X" else rf"\mathrm{{{PRINTED[entry['type']]}}}"
    return f"${symbol}_{{{atoms}}}$"


def _modredundant_settings(entry, start):
    """What a ModRedundant line sets, as a subtable: a value, a scan, a Hessian element, limits and words not
    understood; None when it sets nothing.
    """
    rows = []
    if entry["value"] is not None:
        rows.append((message("coordinate-value"), _coordinate_value(entry["value"])))
    if entry["action"] == "scan" and entry["steps"] is not None and entry["step"] is not None:
        rows += _scan_rows(entry["steps"], entry["step"], start)
    if entry["hessian"] is not None:
        rows.append((message("coordinate-diagonal"), _coordinate_value(entry["hessian"])))
    if entry["minimum"] is not None:
        rows.append((message("coordinate-lower-bound"), _coordinate_value(entry["minimum"])))
    if entry["maximum"] is not None:
        rows.append((message("coordinate-upper-bound"), _coordinate_value(entry["maximum"])))
    rows += [(message("coordinate-not-understood"), f"`{item}`") for item in entry["unparsed"]]
    return _settings_table(rows)


def _gic_group(entry):
    """Key of the GIC lines a table shows as one row: the label without its trailing number, the formula with its atom
    and label numbers left out, the actions and the settings; a standalone line is a row of its own.
    """
    if entry["kind"] != "coordinate":
        return ("line", entry["line"])
    shape = re.sub(r"(?<=[A-Za-z(,])\d+", "#", entry["expression"] or "")
    return (
        re.sub(r"\d+$", "", entry["label"] or ""),
        shape,
        tuple(entry["actions"]),
        tuple(sorted(entry["options"].items())),
        tuple(entry["unparsed"]),
    )


def _gic_definition(entry):
    """A GIC line's formula in LaTeX, a sum of three or more consecutively numbered labels as a sum over n; the formula
    as written when it cannot be read; None for options on an existing label.
    """
    expression = entry["expression"]
    if not expression:
        return None
    terms = [re.fullmatch(r"([A-Za-z_]+)(\d+)", term.strip()) for term in expression.split("+")]
    if len(terms) >= 3 and all(terms) and len({term[1] for term in terms}) == 1:
        numbers = [int(term[2]) for term in terms]
        if numbers == list(range(numbers[0], numbers[0] + len(numbers))):
            name = terms[0][1].replace("_", r"\_")
            return f"$\\sum_{{n={numbers[0]}}}^{{{numbers[-1]}}}\\mathrm{{{name}}}_{{n}}$"
    try:
        return f"${latex(expression)}$"
    except ValueError:
        return f"`{expression}`"


# Atom and label numbers of a GIC formula: digits right after a letter, an opening parenthesis or a comma.
FORMULA_NUMBERS = re.compile(r"(?<=[A-Za-z(,])\d+")


def _group_formula(entries):
    """The formula of lines of one form written once for their n-th line, n being the number that ends each label,
    with every atom or label number that steps with n written as a multiple of n plus a constant; None when the
    labels carry no numbers or a number does not follow n.

    Returns:
        The formula and, in parentheses, the range of n in LaTeX, such as the formula of X(n) for n from 1 to 30, or None.
    """
    labels = [re.fullmatch(r"(.*?)(\d+)", entry["label"] or "") for entry in entries]
    if not all(labels) or any(not entry["expression"] for entry in entries):
        return None
    ns = [int(label[2]) for label in labels]
    if ns != list(range(ns[0], ns[0] + len(ns))):
        return None
    columns = [[int(value) for value in FORMULA_NUMBERS.findall(entry["expression"])] for entry in entries]
    if len({len(column) for column in columns}) != 1:
        return None
    written = []
    for values in zip(*columns):
        slope = values[1] - values[0]
        offset = values[0] - slope * ns[0]
        if any(value != slope * n + offset for value, n in zip(values, ns)):
            return None
        written.append(
            str(values[0])
            if slope == 0
            else ("" if slope == 1 else str(slope))
            + "n"
            + (f"+{offset}" if offset > 0 else f"{offset}" if offset else "")
        )
    template = FORMULA_NUMBERS.sub(lambda match, parts=iter(written): next(parts), entries[0]["expression"])
    try:
        formula = latex(template)
    except ValueError:
        return None
    return f"${formula}$ ($n={ns[0]},\\dots,{ns[-1]}$)"


def _gic_start(entry, printed, computed):
    """Start value of one labeled GIC line with its unit: Gaussian's printed value, else the value at the input
    geometry; bonds and Cartesian components in angstrom, angles in degrees, a formula in its own units.
    """
    label = (entry["label"] or "").lower()
    value = printed.get(label)
    unit = {"angstrom": "angstrom", "degree": "degree"}.get(entry["unit"])
    if value is None and label in computed:
        value = computed[label]
        # Gaussian's internal bohr and radians, converted for a coordinate printed in angstrom or degrees.
        if unit == "angstrom":
            value = (value * ureg.bohr).to("angstrom").magnitude
        elif unit == "degree":
            value = float(np.degrees(value))
    return value, unit


def _gic_row(entries, printed, computed, icons):
    """One row of the GIC table for lines of one form: the first and last labels and equations, what the coordinate
    measures, what the lines do, a subtable of their settings, and the start value when all the lines share it.
    """
    first, last = entries[0], entries[-1]
    if first["kind"] != "coordinate":
        actions = [first["command"]] if first.get("command") in TEXT["coordinate-actions"] else first["actions"]
        return (f"`{first['text']}`", None, None, _action_icons(actions, icons), None, None)
    label = lambda entry: f"`{entry['label']}`" if entry["label"] else None
    labels = (
        label(first)
        if len(entries) == 1
        else (f"{label(first)}–{label(last)}" if first["label"] and last["label"] else None)
    )
    definitions = [_gic_definition(entry) for entry in ((first,) if len(entries) == 1 else (first, last))]
    definition = (
        (_group_formula(entries) if len(entries) > 1 else None)
        or ", …, ".join(text for text in definitions if text)
        or None
    )
    actions = list(first["actions"])
    options = first["options"]
    if "nsteps" in options:
        actions = [action for action in actions if action != "active"] + ["scan"]
    if not actions and first["expression"]:
        actions = ["active"]
    starts = [_gic_start(entry, printed, computed) for entry in entries]
    unit = starts[0][1]
    values = [value for value, _ in starts if value is not None]
    start = values[0] if len(values) == len(entries) and len(set(np.round(values, 6))) == 1 else None
    rows = []
    if "nsteps" in options and "stepsize" in options:
        rows += _scan_rows(options["nsteps"], options["stepsize"], start)
    for name, value in options.items():
        if name not in ("nsteps", "stepsize"):
            rows.append(
                (
                    TEXT["setting-names"].get(identifier(name), name),
                    _coordinate_value(value, 12) if isinstance(value, float) else f"`{value}`",
                )
            )
    rows += [(message("coordinate-not-understood"), f"`{item}`") for item in first["unparsed"]]
    return (
        labels,
        definition,
        _coordinate_kind(first.get("measure"), unit, icons),
        _action_icons(actions, icons),
        _settings_table(rows),
        _coordinate_value(start),
    )

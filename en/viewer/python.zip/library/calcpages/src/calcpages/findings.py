"""Findings: the parsed reasons behind a calculation's status, and how they combine."""

import re
from dataclasses import dataclass

from runflow.gaussian.job import warning_code
from runflow.text import identifier

from calcpages.i18n import message
from calcpages.notation import _number
from calcpages.text import TEXT, lookup


@dataclass(frozen=True)
class Finding:
    """One parsed reason behind a calculation's status: a TEXT["findings"] code, where it comes from and its detail."""

    code: str
    # Where the finding comes from: Gaussian or a named linked step, or Lotus; empty for the runflow script.
    source: str = ""
    detail: str = ""
    count: int = 1
    diagnostic_code: str = ""
    original_message: str = ""

    @property
    def status(self):
        """Status word this finding implies; a warning repeated within a job stays a problem."""
        return TEXT["findings"][identifier(self.code)]["status"]

    @property
    def kind(self):
        """Classify a finding as an error, warning or activity information."""
        return (
            "Error"
            if self.status == "Failed"
            else "Warning"
            if self.code == "warning" or self.status == "Problems"
            else "Info"
        )

    def message(self):
        """Readable message: Gaussian's Fortran numbers such as 0.11361587D+02 written as numbers, a warning Gaussian
        prints in capitals with exclamation marks written as a sentence, first letter capital.
        """
        detail = re.sub(
            r"[-+]?\d*\.\d+[DdEe][-+]?\d+",
            lambda match: _number(float(re.sub("[Dd]", "e", match[0]))),
            re.sub(r"^(?:[\w.]+(?:Error|Exception)):\s*", "", self.detail).rstrip(". !"),
        )
        if self.code == "warning" and detail == detail.upper() and re.search("[A-Z]{4}", detail):
            detail = re.sub(
                r"[A-Z]+", lambda match: match[0] if match[0] in TEXT["acronyms"] else match[0].lower(), detail
            )
        text = TEXT["findings"][identifier(self.code)]["message"].format(detail=detail)
        if self.code == "error":
            explanation = lookup(TEXT["error-explanations"], self.diagnostic_code)
            if explanation and self.diagnostic_code == "gaussian.error.optimization-steps-exceeded":
                steps = re.search(r"NStep=\s*(\d+)", detail)
                text = (
                    message("finding-steps-exceeded", explanation=explanation, steps=steps[1])
                    if steps
                    else message("finding-explanation", explanation=explanation)
                )
            elif explanation and "{link}" in explanation:
                link = re.search(r"Lnk(?:1e|le) in \S*?l(\d+)\.exe", detail, re.I)
                text = (
                    message("finding-error-termination-link", link=link[1])
                    if link
                    else message("finding-error-termination-unknown-link")
                )
            elif explanation:
                text = message("finding-explanation", explanation=explanation)
        elif self.code == "script_warning":
            if explanation := lookup(TEXT["script-warning-explanations"], self.diagnostic_code):
                text = message("finding-explanation", explanation=explanation)
        return text[:1].upper() + text[1:]

    def markdown(self):
        """Typeset scientific symbols without changing existing math or quoted text."""
        message = self.message()
        kept = []

        def keep(match):
            """Keep existing math and quoted text unchanged."""
            kept.append(match[0])
            return f"\x00K{len(kept) - 1}K\x00"

        message = re.sub(
            r"\$[^$]+\$|`[^`]*`|" + chr(39) + r"[^" + chr(39) + r"]*" + chr(39) + r"|\S*/\S*", keep, message
        )
        message = re.sub(r"\b(alpha|beta)\b", lambda match: rf"$\{match[1].lower()}$", message, flags=re.IGNORECASE)
        message = re.sub(r"\bdelta epsilon\b", r"$\\Delta\\epsilon$", message, flags=re.IGNORECASE)
        return re.sub(r"\x00K(\d+)K\x00", lambda match: kept[int(match[1])], message)

    def text(self):
        """One line with source, message and repeat count, for hover titles."""
        count = f" ({self.count} times)" if self.count > 1 else ""
        return (f"{self.source}: " if self.source else "") + self.message().removesuffix(".") + count + "."


def _warning_findings(warnings, source, program="gaussian"):
    """One warning finding per kind of native warning, grouping repeats that differ only in their numbers.

    The detail keeps the first occurrence, without Gaussian's own "Warning" prefix and asterisks.
    """
    groups = {}
    for original in warnings:
        text = re.sub(r"^[*\s]*warning\W*", "", " ".join(original.split()), flags=re.IGNORECASE)
        groups.setdefault(re.sub(r"[-+]?\d[\d.]*(?:[DEde][-+]?\d+)?", "#", text), []).append((text, original))
    return [
        Finding(
            "checkpoint_basis"
            if texts[0][0].casefold().rstrip(" .") == "basis set taken from checkpoint file"
            else "warning",
            source,
            texts[0][0],
            len(texts),
            warning_code(texts[0][0], program),
            texts[0][1],
        )
        for texts in groups.values()
    ]


def _worst_status(findings):
    """Worst status implied by the findings; Succeeded when there are none."""
    order = {"Not run": 0, "Submitted": 1, "Succeeded": 2, "Problems": 3, "Failed": 4}
    return max((finding.status for finding in findings), key=order.get, default="Succeeded")


def _coalesced(findings):
    """Drop findings that restate another finding and normalise wrapper failures."""
    native = [finding for finding in findings if finding.code == "error" and finding.source != "runflow"]
    stepped = {finding.source for finding in native if finding.diagnostic_code.endswith("optimization_steps_exceeded")}
    linked = {finding.source for finding in native if finding.diagnostic_code.endswith("termination")}
    eigen = {finding.source for finding in native if finding.diagnostic_code.endswith("wrong_negative_eigenvalues")}
    atomless = {finding.source for finding in native if finding.diagnostic_code.endswith("no_atoms")}
    kept = []
    seen = set()
    for finding in findings:
        if finding.code == "incomplete" and native:
            continue
        if finding.code == "error_context" and any(other.source == finding.source for other in native):
            continue
        if finding.code == "optimization_unconverged" and finding.source in stepped:
            continue
        if finding.code == "error" and finding.source != "runflow":
            if finding.diagnostic_code.endswith("optimization_stopped") and finding.source in stepped:
                continue
            if finding.diagnostic_code.endswith("optimization_stopped") and finding.source in eigen:
                continue
            if finding.diagnostic_code.endswith("input_molecular_specification") and finding.source in atomless:
                continue
            if finding.detail.startswith("Error termination request processed by link") and finding.source in linked:
                continue
        if finding.code == "script_error":
            match = re.search(r"returned non-zero exit status (\d+)", finding.detail)
            if match:
                if native:
                    continue
                replaced = Finding(
                    finding.code,
                    finding.source,
                    message(
                        "finding-gaussian-exit-status" if "g16" in finding.detail else "finding-script-exit-status",
                        status=match[1],
                    ),
                    diagnostic_code=finding.diagnostic_code,
                )
                finding = replaced
        key = (finding.code, finding.source, finding.detail)
        if key in seen:
            continue
        seen.add(key)
        kept.append(finding)
    return kept

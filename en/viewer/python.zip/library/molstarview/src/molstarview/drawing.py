"""How RDKit draws a molecule, one style for the drawings below the viewers and for researchsite's figures.

The style lives in ``data/drawing.yaml`` as RDKit's own drawing options. They reach RDKit as the JSON its
``UpdateDrawerParamsFromJSON`` reads, and RDKit.js reads the same JSON with the same parser in the viewer's front
end, so a figure drawn by the Python RDKit and a drawing below a viewer drawn by RDKit.js follow one set of options.
Only the standard library and PyYAML are needed to build the options; RDKit is imported only to apply them.
"""

import json
from importlib.resources import files

import yaml

# The shared style, from data/drawing.yaml; see that file for each setting.
SETTINGS = yaml.safe_load(files(__package__).joinpath("data", "drawing.yaml").read_text())
# Highlight colours of parts and measurements, in order, as RGB fractions.
COLORS = [tuple(float(value) for value in color) for color in SETTINGS["colors"]]
# Atomic numbers an atom palette covers: RDKit's -1 for any element not listed, then every element.
ELEMENTS = range(-1, 119)


def _rdkit_name(key):
    """RDKit's name of an option from its kebab-case key, ``clear-background`` to ``clearBackground``.

    Args:
        key: The kebab-case key.

    Returns:
        The camel-case name.
    """
    first, *rest = key.split("-")
    return first + "".join(word[:1].upper() + word[1:] for word in rest)


def _translated(settings):
    """RDKit's options for one section of the style.

    Args:
        settings: A mapping of kebab-case keys.

    Returns:
        RDKit's option names and values.
    """
    options = {}
    for key, value in settings.items():
        if key == "black-labels":
            # RDKit's JSON merges a palette into the current one, so its black-and-white palette is written out in
            # full, every element black, which draws exactly as ``useBWAtomPalette`` does.
            if value:
                options["atomColourPalette"] = {str(number): [0.0, 0.0, 0.0] for number in ELEMENTS}
        else:
            options[_rdkit_name(key)] = value
    return options


def options(highlighted=False):
    """RDKit's drawing options of the shared style.

    Args:
        highlighted: Whether the drawing highlights parts or measurements, which adds the ``highlighted`` section.

    Returns:
        A mapping of RDKit's option names to their values, as RDKit's JSON takes them.
    """
    chosen = _translated(SETTINGS["options"])
    if highlighted:
        chosen.update(_translated(SETTINGS["highlighted"]))
    return chosen


def style():
    """The shared style as a viewer's front end takes it.

    Returns:
        The options of every drawing and those added where something is highlighted, and the highlight colours.
    """
    return {
        # RDKit's options of every drawing.
        "options": options(),
        # The options added on top where parts or measurements are highlighted.
        "highlighted": _translated(SETTINGS["highlighted"]),
        # Highlight colours of parts and measurements, in order, as RGB fractions.
        "colors": [list(color) for color in COLORS],
    }


def apply(drawer, highlighted=False):
    """Give an RDKit drawer the shared style, through the JSON RDKit.js reads too.

    Args:
        drawer: An RDKit ``MolDraw2D``.
        highlighted: Whether the drawing highlights parts or measurements.
    """
    from rdkit.Chem.Draw import rdMolDraw2D

    rdMolDraw2D.UpdateDrawerParamsFromJSON(drawer, json.dumps(options(highlighted)))

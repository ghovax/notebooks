"""Scalar fields on a grid: Gaussian cubes, sampled functions, and their compact encoding for the browser."""

import gzip
import hashlib
import json
import os
from dataclasses import dataclass
from functools import lru_cache
from io import StringIO
from pathlib import Path
from textwrap import dedent

import numpy as np
from runflow.results import ureg

from molstarview import store
from molstarview.cache import cache_folder

# The finest step of the asinh-compressed samples of ``CubeGrid.compact``: about 0.1 % of a value above the knee, far
# below what a surface or the volume fog can show, which leaves gzip far fewer distinct differences to store.
RESOLUTION = 2e-3


def _encoded(source, knee, written):
    """The compact encoding of a grid, reused from the disk cache by the grid's content and checked against its digest.

    Args:
        source: The grid to encode.
        knee: The magnitude below which the encoding is linear.
        written: The unit the decoded field is written in.

    Returns:
        The encoded bytes.

    Raises:
        OSError: If a store is set and the cache cannot keep the bytes the uploader must find.
    """
    name = cache_folder("volumes") / f"{_payload_key(source, (knee, written))}.name"
    try:
        digest = name.read_text()
        data = store.stored(digest).read_bytes()
        if hashlib.sha256(data).hexdigest() == digest:
            return data
    except OSError:
        pass  # A field missing from the store is read from its source.
    data = source.compact(knee, written)
    digest = hashlib.sha256(data).hexdigest()
    try:
        store.write_atomic(store.stored(digest), data)
        store.write_atomic(name, digest.encode())
    except OSError:
        # A read-only cache, as in the browser's memory file system, leaves the field uncached.
        if os.environ.get(store.STORE):
            raise
    return data


@lru_cache(maxsize=1)
def _encoder_digest():
    """Digest of the source that writes an encoded field, so an encoding change invalidates every cached field and no
    other edit to this module does.

    Returns:
        The hexadecimal SHA-256 of the source of ``CubeGrid.compact`` and ``CubeGrid.text``.
    """
    import inspect

    return hashlib.sha256((inspect.getsource(CubeGrid.compact) + inspect.getsource(CubeGrid.text)).encode()).hexdigest()


def _payload_key(source, encoding):
    """Cache name of one encoded field, by the grid it writes and the step, knee and unit of its encoding.

    Args:
        source: The grid to be written.
        encoding: The knee and unit that the encoding is written with.

    Returns:
        The hexadecimal SHA-256 of the grid's arrays, the encoding and the encoder's digest.
    """
    digest = hashlib.sha256()
    for array in (source.origin, source.axes, source.atoms, source.values):
        contiguous = np.ascontiguousarray(array)
        digest.update(f"{contiguous.dtype}-{contiguous.shape}-".encode())
        digest.update(contiguous.tobytes())
    digest.update(f"{encoding!r}-{_encoder_digest()}".encode())
    return digest.hexdigest()


@dataclass(frozen=True)
class CubeGrid:
    """A single scalar grid, with Gaussian cube coordinates in bohr.

    Attributes:
        origin: The position of the first grid point, three numbers in bohr.
        axes: The step between grid points along each axis, a 3 by 3 array in bohr with one row per axis.
        atoms: One row per atom: its atomic number, its charge column and its position in bohr.
        values: The scalar field at every grid point, an array of the grid's shape.
    """

    origin: np.ndarray
    axes: np.ndarray
    atoms: np.ndarray
    values: np.ndarray

    @classmethod
    def read(cls, path):
        """Read a positive-axis, single-field Gaussian cube without altering it.

        Args:
            path: The cube file, as a ``pathlib.Path``.

        Returns:
            The grid, with origin and axes in bohr.

        Raises:
            ValueError: If the cube has no atoms or a non-positive axis, or its values are incomplete or not finite.
        """
        # Parsing the text is the slow part, so each version of a cube, by its path, size and modification time, is
        # parsed once and kept in binary; a read-only cache, as in the browser, parses it every time.
        info = Path(path).stat()
        name = hashlib.sha256(f"{Path(path).resolve()}|{info.st_size}|{info.st_mtime_ns}".encode()).hexdigest()
        parsed = cache_folder("cubes") / f"{name}.npz"
        try:
            with np.load(parsed) as kept:
                return cls(kept["origin"], kept["axes"], kept["atoms"], kept["values"])
        except OSError:
            pass  # A missing or unreadable cache entry is read again.
        grid = cls._parse(Path(path))
        try:
            parsed.parent.mkdir(parents=True, exist_ok=True)
            partial = parsed.with_name(f".{parsed.name}.{os.getpid()}.part.npz")
            np.savez(partial, origin=grid.origin, axes=grid.axes, atoms=grid.atoms, values=grid.values)
            partial.replace(parsed)
        except OSError:
            pass  # A missing or unreadable cache entry is read again.
        return grid

    @classmethod
    def _parse(cls, path):
        """The grid of a Gaussian cube's text, as ``read`` describes it.

        Args:
            path: The cube file.

        Returns:
            The grid, with origin and axes in bohr.

        Raises:
            ValueError: If the cube has no atoms or a non-positive axis, or its values are incomplete or not finite.
        """
        with path.open() as stream:
            next(stream)
            next(stream)
            head = next(stream).split()
            count = int(head[0])
            origin = np.asarray(head[1:4], dtype=float)
            grid = np.asarray([next(stream).split() for _ in range(3)], dtype=float)
            if count <= 0 or (grid[:, 0] <= 0).any():
                raise ValueError("Expected a scalar Gaussian cube with positive bohr axes.")
            atoms = np.asarray([next(stream).split() for _ in range(count)], dtype=float)
            values = np.fromstring(stream.read(), sep=" ")
        shape = tuple(grid[:, 0].astype(int))
        if values.size != np.prod(shape) or not np.isfinite(values).all():
            raise ValueError("The cube has an incomplete or non-finite scalar grid.")
        return cls(origin, grid[:, 1:], atoms, values.reshape(shape))

    @classmethod
    def cached(cls, metadata, numbers, positions, function, *, spacing=0.3, margin=5.0, folder=None):
        """``from_function``, kept as an uncompressed single-precision file named by the SHA-256 of the grid's metadata as canonical JSON,
        the metadata stored in the file, so a later call reads the grid instead of sampling it again.

        Args:
            metadata: JSON-serializable mapping of what defines the field, such as the keys and indices of the orbitals
                it is drawn from; the atoms, positions and grid settings are added to it.
            numbers: Atomic numbers, as ``from_function`` takes them.
            positions: Atom positions in angstrom.
            function: The field, as ``from_function`` takes it.
            spacing: Distance between grid points in bohr.
            margin: Distance from the outermost atoms to the box's faces in bohr.
            folder: Where grids are kept; by default the ``grids`` cache folder.

        Returns:
            The sampled grid.
        """
        folder = Path(folder) if folder is not None else cache_folder("grids")
        described = {
            **metadata,
            "numbers": [int(number) for number in numbers],
            "positions": np.asarray(positions, dtype=float).tolist(),
            "spacing": spacing,
            "margin": margin,
        }
        text = json.dumps(described, sort_keys=True, separators=(",", ":"))
        path = folder / f"{hashlib.sha256(text.encode()).hexdigest()}.npz"
        if path.exists():
            with np.load(path) as kept:
                return cls(kept["origin"], kept["axes"], kept["atoms"], kept["values"])
        grid = cls.from_function(numbers, positions, function, spacing=spacing, margin=margin)
        # Single precision, far finer than a page shows, uncompressed, as a smooth field hardly compresses and
        # reading it back is then a copy; returned as stored, so a fresh and a cached grid are the same.
        grid = cls(grid.origin, grid.axes, grid.atoms, grid.values.astype(np.float32))
        folder.mkdir(parents=True, exist_ok=True)
        np.savez(path, origin=grid.origin, axes=grid.axes, atoms=grid.atoms, values=grid.values, metadata=text)
        return grid

    @classmethod
    def from_function(cls, numbers, positions, function, *, spacing=0.3, margin=5.0):
        """Sample any scalar field over the box around the atoms, such as an orbital or a density from any library.

        The grid is axis-aligned, ``spacing`` bohr apart, and reaches ``margin`` bohr beyond the atoms.

        Args:
            numbers: Atomic numbers of the atoms the viewer draws.
            positions: Atom positions in angstrom, one row per atom.
            function: Takes some of the grid points, an array of shape (N, 3) in bohr, and returns N values.
            spacing: Distance between grid points in bohr.
            margin: Distance from the outermost atoms to the box's faces in bohr.

        Returns:
            The sampled grid.
        """
        positions = (np.asarray(positions, dtype=float) * ureg.angstrom).to("bohr").magnitude
        lower, upper = positions.min(axis=0) - margin, positions.max(axis=0) + margin
        shape = np.ceil((upper - lower) / spacing).astype(int) + 1
        mesh = np.stack(
            np.meshgrid(*[lower[i] + spacing * np.arange(shape[i]) for i in range(3)], indexing="ij"), axis=-1
        )
        points = mesh.reshape(-1, 3)
        # In chunks, so a function that expands every point into many terms stays within memory.
        values = np.concatenate(
            [np.asarray(function(points[i : i + 100000]), dtype=float) for i in range(0, len(points), 100000)]
        ).reshape(tuple(shape))
        atoms = np.column_stack([numbers, numbers, positions]).astype(float)
        return cls(lower, np.diag([spacing] * 3), atoms, values)

    def text(self, *, values=True):
        """Serialize the grid in memory for Molstar's native cube parser, or only its header without ``values``.

        Args:
            values: Whether to write the field's values after the header.

        Returns:
            The cube text, with a Gaussian cube's header and six values to a line.
        """
        header = [
            "Molecular scalar field",
            "Coordinates in bohr",
            f"{len(self.atoms)} " + " ".join(f"{v:.9f}" for v in self.origin),
        ]
        header.extend(
            f"{size} " + " ".join(f"{v:.9f}" for v in axis)
            for size, axis in zip(self.values.shape, self.axes, strict=True)
        )
        header.extend(f"{int(row[0])} " + " ".join(f"{v:.9f}" for v in row[1:]) for row in self.atoms)
        header_text = "\n".join(header)
        if not values:
            return header_text + "\n"
        buffer = StringIO()
        samples = self.values.ravel()
        complete = samples.size // 6 * 6
        np.savetxt(buffer, samples[:complete].reshape(-1, 6), fmt="%.8E")
        if complete < samples.size:
            np.savetxt(buffer, samples[complete:][None, :], fmt="%.8E")
        template = dedent("""
            {header}
            {values}
            """).lstrip()
        return template.format(header=header_text, values=buffer.getvalue().rstrip())

    def compact(self, knee, unit):
        """The field as gzipped bytes for the viewer's ``decodeField``: its cube header, then integer samples.

        The viewer writes the decoded field in multiples of ``unit``, the units its settings use.

        Each sample is u = rint(asinh(v / knee) / step), so the rounding error is the same fraction of the value at
        every level above the knee, instead of the same absolute step, which leaves few steps below a low level. Samples
        are stored as 16-bit differences from the one before, in the grid's file order, where a smooth field compresses
        well; only these differences must fit 16 bits, not the samples. The step is ``RESOLUTION``, or the steepest
        change between neighbours over 2^15 - 2 where that is coarser, so the differences always fit. The differences
        are written as all their low bytes, then all their high bytes, which are nearly all 0 or 255 and gzip packs
        tightly.

        Args:
            knee: The magnitude below which the encoding is linear, usually half the lowest level to be shown.
            unit: The unit the viewer writes the decoded field in.

        Returns:
            The header length, the knee in units, the step and the header, followed by the differences, gzipped.
        """
        compressed = np.arcsinh(self.values.ravel() / knee)
        steepest = float(np.abs(np.diff(compressed, prepend=0)).max())
        # Rounding moves a difference by at most one step.
        step = max(max(steepest, 1e-12) / (2**15 - 2), RESOLUTION)
        differences = np.diff(np.rint(compressed / step).astype(np.int64), prepend=0).astype("<i2")
        header = self.text(values=False).encode()
        shuffled = differences.view(np.uint8).reshape(-1, 2).T.tobytes()
        return gzip.compress(
            np.uint32(len(header)).astype("<u4").tobytes()
            + np.asarray([knee / unit, step], "<f8").tobytes()
            + header
            + shuffled,
            compresslevel=9,
        )

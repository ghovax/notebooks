// Fields as the page carries them: compact encodings, inline or in the field store, decoded to cube text.
// The field of CubeGrid.compact as cube text for Molstar's parser. Done once per field in the browser, so the page
// carries compact integers; Molstar's shaders then extract the surface at any level from the full-precision values.
function decodeField(buffer) {
    const view = new DataView(buffer);
    const headerLength = view.getUint32(0, true), knee = view.getFloat64(4, true), step = view.getFloat64(12, true);
    const header = new TextDecoder().decode(new Uint8Array(buffer, 20, headerLength));
    // The 16-bit differences are stored as all their low bytes, then all their high bytes.
    const bytes = new Uint8Array(buffer, 20 + headerLength), count = bytes.length >> 1;
    const differences = new Int16Array(count);
    for (let index = 0; index < count; index++) differences[index] = bytes[index] | (bytes[count + index] << 8);
    // Each sample is the previous one, in the grid's file order, plus its stored difference.
    const lines = [header.trimEnd()];
    let row = [], sample = 0;
    for (let index = 0; index < differences.length; index++) {
        sample += differences[index];
        row.push((knee * Math.sinh(sample * step)).toExponential(8));
        if (row.length === 6) { lines.push(row.join(' ')); row = []; }
    }
    if (row.length) lines.push(row.join(' '));
    return lines.join('\n') + '\n';
}

// Snapshots whose fields stay built at once. Each holds its field, isosurfaces and fog in Molstar's state and on the
// GPU, about a dozen megabytes for an orbital, so a viewer of many snapshots keeps only the latest it showed; one shown
// again is rebuilt, its field read from the browser's cache.
const KEPT_SNAPSHOTS = 6;

// Data kept in the store is its address, which names its content, so the browser's cache keeps it for good. A viewer's
// fields are packed into a few files: an address ending in #start-end names those bytes of one, which is fetched whole,
// once at a time, and kept for the next fields among the few files used last.
const isStored = text => /^https:\/\//.test(text);
const storedFiles = new Map();
function storedFile(url) {
    let file = storedFiles.get(url);
    if (!file) {
        file = fetch(url).then(response => {
            if (!response.ok) throw new Error(`Viewer data could not be loaded (HTTP ${response.status}).`);
            return response.arrayBuffer();
        });
        file.catch(() => storedFiles.delete(url));
    }
    storedFiles.delete(url);
    storedFiles.set(url, file);
    while (storedFiles.size > 4) storedFiles.delete(storedFiles.keys().next().value);
    return file;
}
async function readStored(address) {
    const [url, range] = address.split('#');
    const file = await storedFile(url);
    if (!range) return file;
    const [start, end] = range.split('-').map(Number);
    return file.slice(start, end);
}

// An encoded field as cube text, inflated as a stream: read from the store, or base64 the page carries, decoded
// through a data URL.
async function readField(text) {
    const encoded = isStored(text) ? new Response(await readStored(text)) : await fetch('data:application/gzip;base64,' + text);
    return decodeField(await new Response(encoded.body.pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
}


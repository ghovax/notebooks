// Hover labels: atoms, measurements and field values in words and LaTeX instead of Molstar's codes.
function signedTeX(value) {
    if (Math.abs(value) < 1e-12) return '0';
    const text = Number(value.toPrecision(4)).toString();
    return (value > 0 ? '+' : '') + text.replace(/e([+-]?)(\d+)/, (_, sign, power) => `\\times10^{${sign === '-' ? '-' : ''}${power}}`);
}

// Map fog volumes back to their original field values for hover labels.
const fogFields = new WeakMap(), fogOriginals = new WeakMap();

// Replaces Molstar's highlight labels, which join chain, entity, model and instance codes with bars, by labels in
// words with LaTeX: the atom, bond, measurement, field value or surface under the pointer. Every loci kind Molstar
// defines is covered; shapes, segments and particles keep their own label text, joined with commas instead of bars.
// ``currentView`` gives the shown view of a volume viewer's field, whose quantity names field values; none for molecules.
// ``currentDetails`` gives the hover details of the atoms as now shown, such as each atom's share of the shown orbital.
function installLabels(plugin, model, currentView, currentDetails = () => model.get('atom_details') || []) {
    const {StructureElement, StructureProperties} = molstar.lib.structure;
    const {Loci} = molstar.lib.loci;
    const manager = plugin.managers.lociLabels;
    // Molstar's providers, including any registered later, feed only the kinds left to them.
    const native = manager.providers;
    manager.providers = [];
    manager.addProvider = provider => { native.push(provider); native.sort((a, b) => (b.priority || 0) - (a.priority || 0)); };
    manager.removeProvider = provider => { const at = native.indexOf(provider); if (at >= 0) native.splice(at, 1); };
    const nativeText = (loci, repr) => native.map(provider => provider.label(loci, repr)).filter(Boolean)
        .map(text => text.replace(/\s*\|\s*/g, ', ')).join('</br>');
    const groups = model.get('annotations') || [];
    // Earlier annotations take precedence for atoms in multiple groups.
    const atomGroups = new Map();
    groups.forEach(group => (group.atoms || []).forEach(index => {
        if (!atomGroups.has(index)) atomGroups.set(index, group);
    }));
    // Virtual points are named by their label wherever an atom's name would stand.
    const markerLabels = new Map((model.get('markers') || []).flatMap(marker => marker.label ? marker.atoms.map(atom => [atom, marker.label]) : []));
    const atom = location => {
        const unit = location.unit;
        const index = unit.model.atomicConformation.atomId.value(location.element) + 1;
        const symbol = StructureProperties.atom.type_symbol(location);
        return {index, symbol, position:[StructureProperties.atom.x(location), StructureProperties.atom.y(location),
                                         StructureProperties.atom.z(location)]};
    };
    // An atom as its element symbol with its one-based number as a subscript, such as C_{15}.
    const atomTeX = a => markerLabels.has(a.index) ? markerLabels.get(a.index) : `\\mathrm{${a.symbol}}_{${a.index}}`;
    const first = loci => atom(StructureElement.Loci.getFirstLocation(loci));
    const {Vec3} = molstar.lib.math.LinearAlgebra;
    const distance = Vec3.distance;
    const angle = (p, q, r) => Vec3.angle(Vec3.sub(Vec3(),p,q), Vec3.sub(Vec3(),r,q)) * 180 / Math.PI;
    // Preserve the existing displayed torsion convention, opposite to Molstar's signed angle.
    const dihedral = (a, b, c, d) => -Vec3.dihedralAngle(a,b,c,d) * 180 / Math.PI;
    const lines = parts => parts.filter(Boolean).join('</br>');
    const field = () => {
        const view = currentView();
        // A field named only by its symbol has no top line; the name may hold $...$ LaTeX.
        return {name:view?.field_name || (view?.field_symbol ? '' : 'Field'), symbol:view?.field_symbol, unit:view?.field_unit, scale:view?.field_scale || 1};
    };
    // The number is braced, so a leading sign reads as part of it rather than as an operator after the equals sign.
    const value = (f, v) => f.symbol ? richHTML(`$${f.symbol}={${signedTeX(v * f.scale)}}${f.unit ? '\\,' + f.unit : ''}$`)
        : richHTML(`value $${signedTeX(v * f.scale)}$`);
    function label(loci, repr) {
        switch (loci.kind) {
            case 'element-loci': {
                const size = StructureElement.Loci.size(loci);
                if (size !== 1) return `<b>${size} atoms</b>`;
                const a = first(loci);
                const group = atomGroups.get(a.index), details = currentDetails();
                return lines([`<b>${richHTML(`$${atomTeX(a)}$`)}</b>`, details[a.index - 1] && richHTML(details[a.index - 1]),
                              group && richHTML(group.text)]);
            }
            case 'bond-loci': {
                const bond = loci.bonds[0];
                if (!bond) return '';
                const end = (unit, index) => atom(StructureElement.Location.create(loci.structure, unit, unit.elements[index]));
                const a = end(bond.aUnit, bond.aIndex), b = end(bond.bUnit, bond.bIndex);
                return lines([`<b>${richHTML(`$${atomTeX(a)}\\text{–}${atomTeX(b)}$`)}</b>`,
                              richHTML(`$r=${distance(a.position, b.position).toFixed(3)}\\,\\text{\\AA}$`)]);
            }
            case 'data-loci': {
                // Native measurements: distances, angles and dihedrals between atoms.
                const parts = loci.elements?.[0]?.loci;
                if (Array.isArray(parts) && parts.length >= 2 && parts.length <= 4
                    && parts.every(part => part.kind === 'element-loci')) {
                    const atoms = parts.map(first), centres = parts.map(part => Array.from(Loci.getCenter(part)));
                    const chain = atoms.map(atomTeX).join('\\text{–}');
                    const quantity = parts.length === 2 ? `d=${distance(...centres).toFixed(3)}\\,\\text{\\AA}`
                        : parts.length === 3 ? `\\theta=${angle(...centres).toFixed(2)}^{\\circ}`
                        : `\\varphi=${dihedral(...centres).toFixed(2)}^{\\circ}`;
                    return lines([`<b>${richHTML(`$${chain}$`)}</b>`, richHTML(`$${quantity}$`)]);
                }
                return nativeText(loci, repr);
            }
            case 'cell-loci': {
                const f = field();
                const index = Number((nativeText(loci, repr).match(/Cell #(\d+)/) || [])[1]);
                if (!Number.isFinite(index)) return f.name ? `<b>${richHTML(f.name)}</b>` : '';
                const original = fogOriginals.get(loci.volume), stored = loci.volume.grid.cells.data[index], inverse = fogFields.get(loci.volume);
                return lines([f.name && `<b>${richHTML(f.name)}</b>`, value(f, original ? original[index] : inverse ? inverse(stored) : stored)]);
            }
            case 'isosurface-loci': {
                const f = field(), iso = loci.isoValue;
                const level = iso.kind === 'absolute' ? iso.absoluteValue
                    : iso.relativeValue * loci.volume.grid.stats.sigma + loci.volume.grid.stats.mean;
                return lines([f.name && `<b>${richHTML(f.name)} surface</b>`, value(f, level)]);
            }
            case 'volume-loci':
                return field().name ? `<b>${richHTML(field().name)}</b>` : '';
            case 'structure-loci':
                return '<b>Molecule</b>';
            case 'every-loci':
            case 'empty-loci':
                return '';
            default:
                // Shapes, shape groups (such as arrows with their tooltips), segments and particles.
                return nativeText(loci, repr);
        }
    }
    manager.providers.push({label, priority:0});
}


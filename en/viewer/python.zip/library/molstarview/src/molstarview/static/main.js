// The widget's entry point: viewers built as the page loads, stills for printing, Molstar fetched while idle.
// Every viewer is built as soon as the page loads. Printing cannot draw WebGL, so just before the page prints,
// each viewer leaves a still of its current view, which print styles show in its place.
function initialize({model, el}) {
    el.style.minHeight = model.get('height') + 'px';
    if (!document.getElementById('molstar-print-styles')) {
        const styles = document.createElement('style');
        styles.id = 'molstar-print-styles';
        styles.textContent = '.molstar-print-still{display:none;width:100%}'
            + '@media print{.molstar-notebook-viewer{display:none!important}.molstar-print-still{display:block!important}}';
        document.head.append(styles);
    }
    const image = document.createElement('img');
    image.className = 'molstar-print-still';
    image.alt = 'Molecular viewer';
    el.append(image);
    let viewer = null, disposed = false;
    const print = () => { if (viewer) image.src = viewer.still(); };
    addEventListener('beforeprint', print);
    // The scene, its trajectory upload and Molstar's own render targets are built only once the viewer approaches the
    // viewport, so a page holding many viewers, some of hundreds of frames, does not build them all at load; the
    // height reserved above keeps the layout still until then. A viewer in a closed tab pane mounts when it is shown.
    let started = false;
    const start = () => {
        if (started || disposed) return Promise.resolve();
        started = true;
        observer.disconnect();
        return mount({model, el}).then(result => {
            if (disposed) result.dispose(); else viewer = result;
        }, error => {
            model.set('error', error.message);
            model.save_changes();
            console.error('Molstar viewer:', error);
        });
    };
    const observer = new IntersectionObserver(entries => {
        if (entries.some(entry => entry.isIntersecting)) void start();
    }, {rootMargin: '200px'});
    observer.observe(el);
    // Shader linking can block on the first draw when parallel shader compilation is unavailable. Warm one nearby,
    // visible-tab viewer during idle time; it populates the shared program cache before the user scrolls to it.
    // The lock prevents a page with many viewers from mounting them all at once.
    const warm = () => {
        if (started || disposed || document.visibilityState !== 'visible' || globalThis.molstarSharedContext ||
            globalThis.molstarWarmMount || getComputedStyle(el).visibility === 'hidden' || !el.getClientRects().length ||
            el.getBoundingClientRect().top > 4 * innerHeight) return;
        globalThis.molstarWarmMount = true;
        void start().finally(() => { globalThis.molstarWarmMount = false; });
    };
    const idle = window.requestIdleCallback ? requestIdleCallback(warm, {timeout:2000}) : setTimeout(warm, 1500);
    return () => {
        disposed = true;
        if (window.cancelIdleCallback) cancelIdleCallback(idle); else clearTimeout(idle);
        observer.disconnect();
        removeEventListener('beforeprint', print);
        viewer?.dispose();
        el.replaceChildren();
    };
}

// One Molstar download and evaluation is shared by every viewer on the page. Started at the browser's first idle
// moment, it is ready long before a viewer scrolls into view or a tab is opened, so that interaction never waits for it.
const warmMolstar = () => loadMolstar().catch(() => {});
if (window.requestIdleCallback) requestIdleCallback(warmMolstar, {timeout:3000});
else setTimeout(warmMolstar, 1500);

export default {render: initialize};


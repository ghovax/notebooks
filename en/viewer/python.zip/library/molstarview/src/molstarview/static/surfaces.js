// Smooth isosurfaces: the spline of a field, its level set as a mesh, built in workers off the page's thread.
// A field's smooth interpolant: a cubic B-spline through every grid value, with continuous second derivatives, so its
// level sets and their gradient normals have no kink anywhere. The spline's coefficients come from one recursive filter
// per axis. ``inverse`` is the column-major matrix from Cartesian offsets to grid coordinates. ``sample`` writes the
// value and the Cartesian gradient at a point into ``out``; it allocates nothing, because a surface evaluates it often.
// An interpolating spline rings around a singularity, such as the potential or density at a nucleus, by about a quarter
// of the jump per voxel, so a cusp of hundreds of atomic units throws false level crossings several voxels away; a clamp
// near the level rings as well, as contour-like ripples beside the surface. The spline therefore interpolates
// u = asinh(v / ``scale``), which is monotonic and odd, so every level set of v is the level set of u at asinh(level /
// scale) and keeps its sign. With the scale near the level, u is linear in v around it, nearly linear in distance
// along a density's exponential tail, and only logarithmic at a nucleus, where the spline then hardly rings.
// ``toField`` and ``fromField`` map a value of the field to u and back.
function surfaceField({data, dimensions, strides, base, inverse, origin, scale:smallest}) {
    const total = dimensions[0] * dimensions[1] * dimensions[2];
    // Across a node, where a signed field changes sign within one voxel, u = asinh(v / scale) with a small scale turns the
    // gentle slope into a near step, and the spline rings on either side of it: the surfaces of the two signs, which lie
    // close together there, wrinkle and cross. The scale is therefore raised, by doubling, until no two neighbouring
    // samples of opposite sign are more than ``jump`` apart in u; a field with no node, or a gentle one, keeps the
    // level's own scale, and a cusp, whose neighbours share a sign, is compressed as before.
    const scale = (() => {
        const jump = 3;
        let top = 0;
        for (let g = 0; g < total; g++) top = Math.max(top, Math.abs(data[base + (Math.floor(g / (dimensions[1] * dimensions[2])) * strides[0]
            + (Math.floor(g / dimensions[2]) % dimensions[1]) * strides[1] + (g % dimensions[2]) * strides[2])]));
        let trial = smallest;
        while (trial < top) {
            let worst = 0;
            for (let i = 0; i < dimensions[0]; i++) for (let j = 0; j < dimensions[1]; j++) for (let k = 0; k < dimensions[2]; k++) {
                const here = data[base + i * strides[0] + j * strides[1] + k * strides[2]];
                for (let axis = 0; axis < 3; axis++) {
                    if ([i, j, k][axis] + 1 >= dimensions[axis]) continue;
                    const next = data[base + i * strides[0] + j * strides[1] + k * strides[2] + strides[axis]];
                    if (here * next < 0) worst = Math.max(worst, Math.abs(Math.asinh(here / trial)) + Math.abs(Math.asinh(next / trial)));
                }
            }
            if (worst <= jump) break;
            trial *= 2;
        }
        return trial;
    })();
    const coefficients = new Float64Array(total);
    for (let i = 0; i < dimensions[0]; i++) for (let j = 0; j < dimensions[1]; j++) for (let k = 0; k < dimensions[2]; k++) {
        const flat = (i * dimensions[1] + j) * dimensions[2] + k;
        coefficients[flat] = Math.asinh(data[base + i * strides[0] + j * strides[1] + k * strides[2]] / scale);
    }
    // The field's own samples in u, before the filter replaces them with coefficients, and how far each bends from a straight
    // line along its axes: the least a cell's spline can stray beyond its corner values.
    const samples = Float64Array.from(coefficients);
    const flatStrides = [dimensions[1] * dimensions[2], dimensions[2], 1];
    const bend = new Float64Array(total);
    for (let g = 0; g < total; g++) {
        const i = Math.floor(g / flatStrides[0]), j = Math.floor(g / flatStrides[1]) % dimensions[1], k = g % dimensions[2];
        let worst = 0;
        if (i > 0 && i < dimensions[0] - 1) worst = Math.max(worst, Math.abs(samples[g - flatStrides[0]] - 2 * samples[g] + samples[g + flatStrides[0]]));
        if (j > 0 && j < dimensions[1] - 1) worst = Math.max(worst, Math.abs(samples[g - flatStrides[1]] - 2 * samples[g] + samples[g + flatStrides[1]]));
        if (k > 0 && k < dimensions[2] - 1) worst = Math.max(worst, Math.abs(samples[g - 1] - 2 * samples[g] + samples[g + 1]));
        bend[g] = worst;
    }
    const pole = Math.sqrt(3) - 2, horizon = 24;
    for (let axis = 0; axis < 3; axis++) {
        const size = dimensions[axis], stride = flatStrides[axis];
        if (size < 2) continue;
        const line = new Float64Array(size);
        const others = [0, 1, 2].filter(other => other !== axis);
        for (let u = 0; u < dimensions[others[0]]; u++) for (let v = 0; v < dimensions[others[1]]; v++) {
            const start = u * flatStrides[others[0]] + v * flatStrides[others[1]];
            for (let n = 0; n < size; n++) line[n] = 6 * coefficients[start + n * stride];
            // Causal, then anticausal, with the mirror boundary starting each pass.
            let power = 1, sum = 0;
            for (let n = 0; n < Math.min(size, horizon); n++) { sum += power * line[n]; power *= pole; }
            line[0] = sum;
            for (let n = 1; n < size; n++) line[n] += pole * line[n - 1];
            line[size - 1] = pole / (pole * pole - 1) * (line[size - 1] + pole * line[size - 2]);
            for (let n = size - 2; n >= 0; n--) line[n] = pole * (line[n + 1] - line[n]);
            for (let n = 0; n < size; n++) coefficients[start + n * stride] = line[n];
        }
    }
    const w = [new Float64Array(4), new Float64Array(4), new Float64Array(4)];
    const d = [new Float64Array(4), new Float64Array(4), new Float64Array(4)];
    const at = [new Float64Array(4), new Float64Array(4), new Float64Array(4)];
    const place = (axis, coordinate) => {
        const size = dimensions[axis];
        const cell = Math.max(0, Math.min(size - 2, Math.floor(coordinate))), t = coordinate - cell, s = 1 - t;
        const weights = w[axis], slopes = d[axis], offsets = at[axis];
        weights[0] = s * s * s / 6; weights[1] = (4 + t * t * (3 * t - 6)) / 6;
        weights[2] = (1 + t * (3 + t * (3 - 3 * t))) / 6; weights[3] = t * t * t / 6;
        slopes[0] = -s * s / 2; slopes[1] = t * (3 * t - 4) / 2; slopes[2] = (1 + t * (2 - 3 * t)) / 2; slopes[3] = t * t / 2;
        for (let k = 0; k < 4; k++) {
            // Mirrored past the grid's ends, as the filter assumed.
            let index = cell - 1 + k;
            if (index < 0) index = -index; else if (index >= size) index = 2 * size - 2 - index;
            offsets[k] = index * flatStrides[axis];
        }
    };
    const sample = (x, y, z, out) => {
        const rx = x - origin[0], ry = y - origin[1], rz = z - origin[2];
        place(0, inverse[0] * rx + inverse[3] * ry + inverse[6] * rz);
        place(1, inverse[1] * rx + inverse[4] * ry + inverse[7] * rz);
        place(2, inverse[2] * rx + inverse[5] * ry + inverse[8] * rz);
        let value = 0, gi = 0, gj = 0, gk = 0;
        for (let a = 0; a < 4; a++) {
            const A = at[0][a];
            for (let b = 0; b < 4; b++) {
                const B = A + at[1][b];
                let along = 0, slope = 0;
                for (let c = 0; c < 4; c++) { const f = coefficients[B + at[2][c]]; along += f * w[2][c]; slope += f * d[2][c]; }
                const wab = w[0][a] * w[1][b];
                value += along * wab; gi += along * d[0][a] * w[1][b]; gj += along * w[0][a] * d[1][b]; gk += slope * wab;
            }
        }
        out[0] = value;
        // The gradient in grid coordinates to Cartesian, through the inverse's transpose.
        out[1] = inverse[0] * gi + inverse[1] * gj + inverse[2] * gk;
        out[2] = inverse[3] * gi + inverse[4] * gj + inverse[5] * gk;
        out[3] = inverse[6] * gi + inverse[7] * gj + inverse[8] * gk;
    };
    const toField = value => Math.asinh(value / scale), fromField = u => scale * Math.sinh(u);
    return {sample, toField, fromField, coefficients, samples, bend, dimensions};
}

// The level set of the spline as a closed triangle mesh, built only where the surface can be: every cell of the grid whose
// samples, widened by how far the spline can bend beyond them, bracket the level is evaluated on a lattice ``factor`` times
// finer (twice, which resolves the thin sheets of a surface as three times does, with a third of the triangles) and cut into tetrahedra, six to a lattice cube split the same way in every cube, so neighbours share their faces and no crack or ambiguous case arises, so the surface is as fine as that lattice while the cells away from it cost
// nothing. Vertices are shared across cells by their lattice edge. ``hand`` and ``side`` match Molstar's conventions;
// normals are left to settleMesh.
function sparseMesh(field, level, {hand, side}, toCartesian, toVector, groupOf, factor = 2) {
    const {coefficients, samples, bend, dimensions:[n0, n1, n2]} = field, F = factor, R = F + 1;
    const sgn = Math.sign(level) || 1, plane = n1 * n2, m1 = (n1 - 1) * F + 1, m2 = (n2 - 1) * F + 1;
    const total = ((n0 - 1) * F + 1) * m1 * m2;
    const weights = Array.from({length:R}, (_, r) => {
        const t = r / F, s = 1 - t;
        return [s * s * s / 6, (4 + t * t * (3 * t - 6)) / 6, (1 + t * (3 + t * (3 - 3 * t))) / 6, t * t * t / 6];
    });
    const mirror = (index, n) => index < 0 ? -index : index >= n ? 2 * n - 2 - index : index;
    const tmpX = new Float64Array(R * 4 * 4), tmpY = new Float64Array(R * R * 4), nodes = new Float64Array(R * R * R);
    const rowX = new Int32Array(4), rowY = new Int32Array(4), rowZ = new Int32Array(4);
    // The spline's values on the R by R by R lattice nodes of one cell, from the 4 by 4 by 4 coefficients around it.
    const evaluate = (i, j, k) => {
        for (let a = 0; a < 4; a++) {
            rowX[a] = mirror(i - 1 + a, n0) * plane; rowY[a] = mirror(j - 1 + a, n1) * n2; rowZ[a] = mirror(k - 1 + a, n2);
        }
        for (let b = 0; b < 4; b++) for (let c = 0; c < 4; c++) {
            const at = rowY[b] + rowZ[c];
            const c0 = coefficients[rowX[0] + at], c1 = coefficients[rowX[1] + at], c2 = coefficients[rowX[2] + at], c3 = coefficients[rowX[3] + at];
            for (let x = 0; x < R; x++) {
                const w = weights[x];
                tmpX[(x * 4 + b) * 4 + c] = w[0] * c0 + w[1] * c1 + w[2] * c2 + w[3] * c3;
            }
        }
        for (let x = 0; x < R; x++) for (let c = 0; c < 4; c++) for (let y = 0; y < R; y++) {
            const w = weights[y], at = x * 16 + c;
            tmpY[(x * R + y) * 4 + c] = w[0] * tmpX[at] + w[1] * tmpX[at + 4] + w[2] * tmpX[at + 8] + w[3] * tmpX[at + 12];
        }
        for (let x = 0; x < R; x++) for (let y = 0; y < R; y++) for (let z = 0; z < R; z++) {
            const w = weights[z], at = (x * R + y) * 4;
            nodes[(x * R + y) * R + z] = w[0] * tmpY[at] + w[1] * tmpY[at + 1] + w[2] * tmpY[at + 2] + w[3] * tmpY[at + 3];
        }
    };
    const P = [], N = [], G = [], I = [], edges = new Map();
    const point = new Float64Array(3), lattice = new Float64Array(3), outward = new Float64Array(3), cross = new Float64Array(3);
    const vertex = (ga, gb, va, vb, ax, ay, az, bx, by, bz) => {
        const key = ga < gb ? ga * total + gb : gb * total + ga;
        let v = edges.get(key);
        if (v !== undefined) return v;
        const t = (level - va) / (vb - va);
        lattice[0] = (ax + t * (bx - ax)) / F; lattice[1] = (ay + t * (by - ay)) / F; lattice[2] = (az + t * (bz - az)) / F;
        toCartesian(lattice, point);
        v = P.length / 3;
        P.push(point[0], point[1], point[2]);
        N.push(0, 0, 0);
        G.push(groupOf(lattice));
        edges.set(key, v);
        return v;
    };
    const triangle = (a, b, c) => {
        const ux = P[3 * b] - P[3 * a], uy = P[3 * b + 1] - P[3 * a + 1], uz = P[3 * b + 2] - P[3 * a + 2];
        const vx = P[3 * c] - P[3 * a], vy = P[3 * c + 1] - P[3 * a + 1], vz = P[3 * c + 2] - P[3 * a + 2];
        cross[0] = uy * vz - uz * vy; cross[1] = uz * vx - ux * vz; cross[2] = ux * vy - uy * vx;
        const facing = cross[0] * outward[0] + cross[1] * outward[1] + cross[2] * outward[2];
        if (facing * side * hand < 0) I.push(a, c, b); else I.push(a, b, c);
    };
    const tetrahedra = [[0, 1, 3, 7], [0, 3, 2, 7], [0, 2, 6, 7], [0, 6, 4, 7], [0, 4, 5, 7], [0, 5, 1, 7]];
    const value = new Float64Array(8), node = new Float64Array(8), cx = new Int32Array(8), cy = new Int32Array(8), cz = new Int32Array(8);
    const ins = [], outs = [], local = new Float64Array(3);
    for (let i = 0; i < n0 - 1; i++) for (let j = 0; j < n1 - 1; j++) for (let k = 0; k < n2 - 1; k++) {
        // The cell is cut if the level lies between its samples, widened by the most the spline can bend beyond them.
        const g = i * plane + j * n2 + k;
        let low = Infinity, high = -Infinity, pad = 0;
        for (let c = 0; c < 8; c++) {
            const at = g + (c & 1) * plane + ((c >> 1) & 1) * n2 + ((c >> 2) & 1), u = samples[at];
            if (u < low) low = u;
            if (u > high) high = u;
            if (bend[at] > pad) pad = bend[at];
        }
        pad *= 0.3;
        if (level < low - pad || level > high + pad) continue;
        evaluate(i, j, k);
        for (let a = 0; a < F; a++) for (let b = 0; b < F; b++) for (let c = 0; c < F; c++) {
            let count = 0;
            for (let q = 0; q < 8; q++) {
                const x = a + (q & 1), y = b + ((q >> 1) & 1), z = c + ((q >> 2) & 1);
                cx[q] = i * F + x; cy[q] = j * F + y; cz[q] = k * F + z;
                value[q] = nodes[(x * R + y) * R + z];
                node[q] = (cx[q] * m1 + cy[q]) * m2 + cz[q];
                if ((value[q] - level) * sgn > 0) count++;
            }
            if (count === 0 || count === 8) continue;
            for (const tet of tetrahedra) {
                ins.length = 0; outs.length = 0;
                for (const q of tet) ((value[q] - level) * sgn > 0 ? ins : outs).push(q);
                if (!ins.length || !outs.length) continue;
                local.fill(0);
                for (const q of outs) { local[0] += (q & 1) / outs.length; local[1] += ((q >> 1) & 1) / outs.length; local[2] += ((q >> 2) & 1) / outs.length; }
                for (const q of ins) { local[0] -= (q & 1) / ins.length; local[1] -= ((q >> 1) & 1) / ins.length; local[2] -= ((q >> 2) & 1) / ins.length; }
                toVector(local, outward);
                const at = (a2, b2) => vertex(node[a2], node[b2], value[a2], value[b2], cx[a2], cy[a2], cz[a2], cx[b2], cy[b2], cz[b2]);
                if (ins.length === 2) {
                    const [p, q] = ins, [r, s] = outs;
                    const pr = at(p, r), ps = at(p, s), qs = at(q, s), qr = at(q, r);
                    triangle(pr, ps, qs); triangle(pr, qs, qr);
                } else {
                    const [lone, others] = ins.length === 1 ? [ins[0], outs] : [outs[0], ins];
                    triangle(at(lone, others[0]), at(lone, others[1]), at(lone, others[2]));
                }
            }
        }
    }
    return {positions:Float32Array.from(P), normals:Float32Array.from(N), groups:Float32Array.from(G),
            indices:Uint32Array.from(I), vertices:P.length / 3, triangles:I.length / 3};
}

// Puts every vertex of a mesh on the level set, by Newton steps along the spline's gradient, and gives it that gradient as its
// normal, so shading is exact however the triangles lie. ``orient`` is +1 or -1: every normal is the gradient times it.
function settleMesh(field, mesh, level, step, orient) {
    const out = new Float64Array(4), P = mesh.positions, N = mesh.normals;
    for (let v = 0; v < mesh.vertices; v++) {
        let x = P[3 * v], y = P[3 * v + 1], z = P[3 * v + 2];
        for (let iteration = 0; iteration < 3; iteration++) {
            field.sample(x, y, z, out);
            const squared = out[1] * out[1] + out[2] * out[2] + out[3] * out[3];
            if (!(squared > 0)) break;
            let scale = (out[0] - level) / squared;
            const length = Math.abs(scale) * Math.sqrt(squared);
            if (length > step / 2) scale *= step / 2 / length;
            x -= scale * out[1]; y -= scale * out[2]; z -= scale * out[3];
            if (length < 1e-6 * step) break;
        }
        field.sample(x, y, z, out);
        const norm = Math.hypot(out[1], out[2], out[3]), scale = norm > 0 ? orient / norm : 0;
        P[3 * v] = x; P[3 * v + 1] = y; P[3 * v + 2] = z;
        N[3 * v] = scale * out[1]; N[3 * v + 1] = scale * out[2]; N[3 * v + 2] = scale * out[3];
    }
    return mesh;
}

// Molstar's winding (``hand``: whether a triangle's edges turn about its stored normal) and normal side (``side``: whether the
// stored normal points out of the region beyond the level), read by majority from the mesh it built.
function meshConvention(field, mesh, level) {
    const out = new Float64Array(4), P = mesh.positions, N = mesh.normals, I = mesh.indices, outward = -(Math.sign(level) || 1);
    let hand = 0, side = 0;
    for (let t = 0; t < Math.min(mesh.triangles, 200); t++) {
        const a = I[3 * t], b = I[3 * t + 1], c = I[3 * t + 2];
        const ux = P[3 * b] - P[3 * a], uy = P[3 * b + 1] - P[3 * a + 1], uz = P[3 * b + 2] - P[3 * a + 2];
        const vx = P[3 * c] - P[3 * a], vy = P[3 * c + 1] - P[3 * a + 1], vz = P[3 * c + 2] - P[3 * a + 2];
        const nx = N[3 * a], ny = N[3 * a + 1], nz = N[3 * a + 2];
        hand += Math.sign((uy * vz - uz * vy) * nx + (uz * vx - ux * vz) * ny + (ux * vy - uy * vx) * nz);
        field.sample(P[3 * a], P[3 * a + 1], P[3 * a + 2], out);
        side += Math.sign(outward * (nx * out[1] + ny * out[2] + nz * out[3]));
    }
    return {hand:hand < 0 ? -1 : 1, side:side < 0 ? -1 : 1};
}

// A colour list interpolated linearly over [lower, upper], clamped at its ends, as the legend draws it.
function colorScale(colors, [lower, upper]) {
    const span = upper - lower || 1, last = colors.length - 1;
    return value => {
        const x = Math.min(1, Math.max(0, (value - lower) / span)) * last, i = Math.min(Math.floor(x), Math.max(last - 1, 0)), u = x - i;
        const a = colors[i], b = colors[Math.min(i + 1, last)];
        const mix = shift => Math.round(((a >> shift) & 255) * (1 - u) + ((b >> shift) & 255) * u);
        return (mix(16) << 16) | (mix(8) << 8) | mix(0);
    };
}

// Refines one isosurface representation's new mesh in place, in the buffers Molstar draws, and returns its triangle count;
// a mesh already refined at this geometry is left alone.
const refinedMeshes = new WeakMap();
let viewerCount = 0;

// A field's spline kept for the meshes drawn from it, the ``limit`` most recently used: building it and its lattice is the
// larger part of a surface's cost, and one field serves both signs of a signed surface.
function fieldCache(limit) {
    const fields = new Map();
    return spec => {
        let field = fields.get(spec.key);
        if (field) fields.delete(spec.key); else field = surfaceField(spec.source);
        fields.set(spec.key, field);
        while (fields.size > limit) fields.delete(fields.keys().next().value);
        return field;
    };
}

// The colour of every vertex of a mesh, for a surface coloured by a field: a texture of three bytes a vertex, which reads
// the colour field through its own spline so colours vary as smoothly as the surface.
function vertexColors(mesh, job, fieldOf) {
    const colorField = fieldOf(job.colorField), colorOf = colorScale(job.coloring.colors, job.coloring.range);
    const width = Math.max(1, Math.ceil(Math.sqrt(mesh.vertices))), height = Math.max(1, Math.ceil(mesh.vertices / width));
    const array = new Uint8Array(width * height * 3), sampled = new Float64Array(4);
    for (let v = 0; v < mesh.vertices; v++) {
        colorField.sample(mesh.positions[3 * v], mesh.positions[3 * v + 1], mesh.positions[3 * v + 2], sampled);
        const rgb = colorOf(colorField.fromField(sampled[0]));
        array[3 * v] = (rgb >> 16) & 255; array[3 * v + 1] = (rgb >> 8) & 255; array[3 * v + 2] = rgb & 255;
    }
    return {array, width, height};
}

// One surface from a job, in one step: the level set of the field's spline, cut on a lattice twice as fine as the grid wherever
// the surface can be, with every vertex on the level set and the spline's gradient as its normal, so it
// is accurate at once. It reads nothing but the job, so it runs in a worker as well as on the page; ``fieldOf`` gives the
// spline of a field named by the job. Returns the mesh, its colour texture for a coloured surface and Molstar's winding for this sign.
function denseSurface(job, fieldOf) {
    const field = fieldOf(job.field), level = field.toField(job.value), matrix = job.matrix, strides = job.strides;
    const [d0, d1, d2] = job.dimensions;
    const toCartesian = (g, out) => {
        for (let k = 0; k < 3; k++) out[k] = matrix[k] * g[0] + matrix[4 + k] * g[1] + matrix[8 + k] * g[2] + matrix[12 + k];
    };
    const toVector = (g, out) => {
        for (let k = 0; k < 3; k++) out[k] = matrix[k] * g[0] + matrix[4 + k] * g[1] + matrix[8 + k] * g[2];
    };
    const groupOf = g => job.origin + Math.min(d0 - 1, Math.max(0, Math.round(g[0]))) * strides[0]
        + Math.min(d1 - 1, Math.max(0, Math.round(g[1]))) * strides[1] + Math.min(d2 - 1, Math.max(0, Math.round(g[2]))) * strides[2];
    // Molstar's winding is the same for every surface of a sign, so a job may carry it instead of a mesh to read it from.
    const convention = job.convention || meshConvention(field, job.original, level);
    // Normals point out of the region beyond the level, down the gradient for a positive level, on Molstar's side.
    const orient = convention.side * -(Math.sign(level) || 1);
    const mesh = settleMesh(field, sparseMesh(field, level, convention, toCartesian, toVector, groupOf), level, job.step, orient);
    return {mesh, color:job.colorField ? vertexColors(mesh, job, fieldOf) : null, convention};
}

// The source of the worker that builds surfaces, from the functions above, so that the page stays responsive while a surface is
// built. Work for the newest selection of a viewer comes first: a job of an older selection that has not started is dropped.
const meshWorkerSource = () => [surfaceField, sparseMesh, settleMesh, meshConvention, colorScale, fieldCache, vertexColors,
    denseSurface].map(String).join('\n') + `
const fieldOf = ${fieldCache.name}(3);
const queue = [], newestEpoch = new Map();
let running = false;
function handle(data) {
    try {
        const {mesh, color, convention} = ${denseSurface.name}(data, fieldOf);
        self.postMessage({id:data.id, stage:1, mesh, color, convention}, [mesh.positions.buffer, mesh.normals.buffer,
            mesh.groups.buffer, mesh.indices.buffer, ...(color ? [color.array.buffer] : [])]);
    } catch (error) {
        self.postMessage({id:data.id, stage:0, error:String(error && error.stack || error)});
    }
}
async function pump() {
    running = true;
    // Lets the jobs that are already waiting arrive, so that the newest of them is the one that starts.
    await new Promise(resolve => setTimeout(resolve, 0));
    while (queue.length) {
        const newest = new Map(newestEpoch);
        for (const job of queue) newest.set(job.scope, Math.max(newest.get(job.scope) ?? -1, job.epoch));
        for (let at = queue.length - 1; at >= 0; at--) {
            if (queue[at].epoch < newest.get(queue[at].scope)) self.postMessage({id:queue.splice(at, 1)[0].id, stage:-1});
        }
        if (queue.length) handle(queue.shift());
        // Lets a notice or a job that arrived meanwhile be seen before the next one starts.
        await new Promise(resolve => setTimeout(resolve, 0));
    }
    running = false;
}
self.onmessage = ({data}) => {
    // A notice that a viewer's selection changed, sent to every worker, so that a worker drops the older jobs it holds.
    if (data.notice) { newestEpoch.set(data.scope, Math.max(newestEpoch.get(data.scope) ?? -1, data.epoch)); return; }
    queue.push(data);
    if (!running) pump();
};`;

// Builds a surface in a worker, or on the page where a worker cannot be made. The surfaces at plus and minus a level, those of
// other snapshots and those of other viewers are built at once, in as many workers as the machine can spare. The promise resolves with the accurate surface, or
// with null if a newer selection of the viewer made the worker drop the job.
const meshWorker = {pool:[], failed:false, pending:new Map(), count:0, fields:null,
    // As many workers as the machine can spare, up to four, started as work needs them.
    size:Math.max(1, Math.min(4, (globalThis.navigator?.hardwareConcurrency ?? 2) - 1))};
function startMeshWorker() {
    const worker = new Worker(URL.createObjectURL(new Blob([meshWorkerSource()], {type:'text/javascript'})));
    // ``load`` counts the jobs given to the worker whose surface has not come back; ``keys`` are the fields whose splines it
    // holds, the latest first.
    const info = {worker, load:0, keys:[]};
    const fail = message => {
        for (const waiting of meshWorker.pending.values()) waiting.reject(new Error(message));
        meshWorker.pending.clear();
        info.load = 0;
    };
    worker.onmessage = ({data}) => {
        const waiting = meshWorker.pending.get(data.id);
        if (!waiting) return;
        meshWorker.pending.delete(data.id);
        waiting.info.load--;
        // 1: the surface; -1: the job was dropped for a newer selection; 0: it failed.
        if (data.stage === 1) waiting.resolve(data);
        else if (data.stage === -1) waiting.resolve(null);
        else waiting.reject(new Error(data.error));
    };
    worker.onerror = event => fail(event.message || 'The surface worker failed');
    return info;
}
// Tells every worker that a viewer's selection changed, so that none of them starts a job of an older one.
function announceSelection(selection) {
    for (const info of meshWorker.pool) info.worker.postMessage({notice:true, scope:selection.scope, epoch:selection.epoch});
}
// The worker for a job: the least loaded, preferring one that already holds the field's spline, and a new one while the machine has
// cores to spare and every worker is busy.
function workerFor(job) {
    let best = null;
    for (const info of meshWorker.pool) {
        const cost = info.load + (info.keys.includes(job.field.key) ? 0 : 0.5);
        if (!best || cost < best.cost) best = {info, cost};
    }
    if ((!best || best.info.load > 0) && meshWorker.pool.length < meshWorker.size) {
        const info = startMeshWorker();
        meshWorker.pool.push(info);
        best = {info};
    }
    const info = best.info;
    info.keys = [job.field.key, ...info.keys.filter(key => key !== job.field.key)].slice(0, 3);
    return info;
}
function buildSurface(job) {
    let info = null;
    if (!meshWorker.failed) {
        try {
            info = workerFor(job);
        } catch (error) {
            meshWorker.failed = true;
        }
    }
    if (!info) {
        meshWorker.fields ??= fieldCache(3);
        return Promise.resolve().then(() => denseSurface(job, meshWorker.fields));
    }
    return new Promise((resolve, reject) => {
        const id = ++meshWorker.count;
        meshWorker.pending.set(id, {resolve, reject, info});
        info.load++;
        info.worker.postMessage({...job, id});
    });
}

// The field of a volume as the worker takes it: its samples, grid and the scale of its spline, under a key naming them.
const volumeIds = new WeakMap();
function fieldSpec(volume, scale) {
    const grid = volume.grid;
    if (grid?.transform?.kind !== 'matrix') return null;
    const {Mat3} = molstar.lib.math.LinearAlgebra;
    const matrix = grid.transform.matrix, transform = Mat3.fromMat4(Mat3(), matrix);
    if (!Mat3.determinant(transform)) return null;
    if (!volumeIds.has(volume)) volumeIds.set(volume, (volumeIds.total = (volumeIds.total || 0) + 1));
    const {space, data} = grid.cells, origin = space.dataOffset(0, 0, 0);
    return {key:`${volumeIds.get(volume)}:${scale}`, source:{data, dimensions:[...space.dimensions], base:origin,
        origin:[matrix[12], matrix[13], matrix[14]],
        strides:[space.dataOffset(1, 0, 0) - origin, space.dataOffset(0, 1, 0) - origin, space.dataOffset(0, 0, 1) - origin],
        inverse:Array.from(Mat3.invert(Mat3(), transform)), scale}};
}

// How Molstar winds its meshes for the surfaces of each sign, read from the first one built and then known without a mesh.
const surfaceConventions = new Map();

// The job that builds the surface of a volume at ``value``: its fields as the worker takes them, with the spline's scale a
// power of two at or below the level, so that nearby levels share one spline and one lattice. ``original`` is Molstar's mesh
// of the surface, from which its winding is read when it is not yet known. Null where the volume has no matrix grid.
function surfaceJob(volume, coloring, value, original = null, selection = {scope:0, epoch:0}) {
    const grid = volume?.grid, floorPower = magnitude => 2 ** Math.floor(Math.log2(magnitude || 1));
    const field = grid && fieldSpec(volume, floorPower(Math.abs(value)));
    if (!field) return null;
    const colorField = coloring && fieldSpec(coloring.volume, floorPower(Math.max(...coloring.range.map(Math.abs))));
    const {Vec3} = molstar.lib.math.LinearAlgebra;
    const matrix = grid.transform.matrix, {space} = grid.cells, origin = space.dataOffset(0, 0, 0);
    const convention = surfaceConventions.get(Math.sign(value));
    if (!original && !convention) return null;
    return {field, colorField, value, matrix:Array.from(matrix),
        step:Math.min(...[0, 4, 8].map(offset => Vec3.magnitude(Vec3.fromArray(Vec3(), matrix, offset)))), origin,
        strides:[space.dataOffset(1, 0, 0) - origin, space.dataOffset(0, 1, 0) - origin, space.dataOffset(0, 0, 1) - origin],
        dimensions:[...space.dimensions], coloring:coloring && {colors:coloring.colors, range:coloring.range},
        convention, original:convention ? null : original, scope:selection.scope, epoch:selection.epoch};
}

// A mesh being refined, so that a request arriving meanwhile waits for it and then refines what Molstar built since.
const refining = new WeakMap();
function refineObject(object, work) {
    let entry = refining.get(object);
    if (entry) { entry.again = true; entry.work = work; return entry.promise; }
    entry = {again:false, work, result:0};
    entry.promise = (async () => {
        try {
            do { entry.again = false; entry.result = await entry.work(); } while (entry.again);
        } finally {
            refining.delete(object);
        }
        return entry.result;
    })();
    refining.set(object, entry);
    return entry.promise;
}

// Makes one isosurface representation's new mesh smooth, in the buffers Molstar draws, and resolves to its triangle count
// once the worker has built it; Molstar's own mesh shows meanwhile. A mesh already refined at this geometry is left alone.
// ``coloring`` is the registered colour field, its colours and range, for a surface coloured by one.
async function refineIsosurface(cell, volume, coloring, prefetched, selection) {
    const repr = cell?.obj?.data?.repr, iso = cell?.transform?.params?.type?.params?.isoValue, grid = volume?.grid;
    if (!repr || !iso) return 0;
    const value = iso.kind === 'absolute' ? iso.absoluteValue : iso.relativeValue * grid.stats.sigma + grid.stats.mean;
    if (!fieldSpec(volume, 1)) return 0;
    const set = (target, content) => { target.ref.value = content; target.ref.version += 1; };
    const tasks = [];
    for (const object of repr.renderObjects) {
        const values = object.values;
        if (values.dGeometryType?.ref.value !== 'mesh' || !values.aPosition || !values.aNormal) continue;
        tasks.push(refineObject(object, async () => {
            const array = values.aPosition.ref.value, version = values.aPosition.ref.version;
            if (refinedMeshes.get(array) === version) return values.drawCount.ref.value / 3;
            // The job may already be under way: the viewer starts it before Molstar's own mesh is ready.
            const started = prefetched?.get(String(value));
            prefetched?.delete(String(value));
            const result = await (started ?? buildSurface(surfaceJob(volume, coloring, value, {
                positions:values.aPosition.ref.value, normals:values.aNormal.ref.value, groups:values.aGroup.ref.value,
                indices:values.elements.ref.value, vertices:values.uVertexCount.ref.value, triangles:values.drawCount.ref.value / 3}, selection)));
            // A newer selection of the viewer made the worker drop this job: Molstar's own mesh stays until it is replaced.
            if (!result) return values.drawCount.ref.value / 3;
            const {mesh, color} = result;
            surfaceConventions.set(Math.sign(value), result.convention);
            // A mesh Molstar replaced while this one was built is refined by the request that follows its replacement.
            if (values.aPosition.ref.value !== array || values.aPosition.ref.version !== version) return values.drawCount.ref.value / 3;
            set(values.aPosition, mesh.positions); set(values.aNormal, mesh.normals); set(values.aGroup, mesh.groups);
            set(values.elements, mesh.indices); set(values.drawCount, 3 * mesh.triangles); set(values.uVertexCount, mesh.vertices);
            // A coloured surface takes one colour per vertex, so the colour texture covers every new vertex.
            if (color) {
                set(values.tColor, {array:color.array, width:color.width, height:color.height});
                set(values.uColorTexDim, new Float32Array([color.width, color.height]));
            }
            refinedMeshes.set(mesh.positions, values.aPosition.ref.version);
            return mesh.triangles;
        }));
    }
    return (await Promise.all(tasks)).reduce((sum, count) => sum + count, 0);
}


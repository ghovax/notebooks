// Controls added to Molstar's own: wheel zoom, toolbar labels, axis alignment, frame choices and view switches.
// Adapt wheel units while retaining Molstar's native camera and drag controls.
function installWheelInput(container) {
    const controller = new AbortController(), replayed = new WeakSet();
    let frame = 0, pending = 0, previous = 0, source = null, controlDown = false;
    function cancel() {
        cancelAnimationFrame(frame);
        frame = 0; pending = 0; previous = 0; source = null;
    }
    function advance(time) {
        frame = 0;
        if (!source?.target.isConnected) {cancel(); return;}
        const elapsed = previous ? Math.min(time - previous, 64) : 1000 / 60;
        previous = time;
        const portion = Math.abs(pending) < 0.001 ? pending : pending * (1 - Math.exp(-elapsed / 45));
        pending -= portion;
        const event = new WheelEvent('wheel', {
            deltaY:portion, deltaMode:0, ctrlKey:true,
            clientX:source.x, clientY:source.y, shiftKey:source.shift,
            bubbles:true, composed:true, cancelable:true
        });
        replayed.add(event); source.target.dispatchEvent(event);
        if (pending) frame = requestAnimationFrame(advance);
        else {previous = 0; source = null;}
    }
    container.addEventListener('wheel', event => {
        const target = event.composedPath().find(element => element.tagName === 'CANVAS');
        if (!target || event.metaKey || event.altKey) return;
        const unit = event.deltaMode === 1 ? 40 : event.deltaMode === 2 ? 800 : 1;
        // Ease only Ctrl-wheel trackpad pinches; regular scroll and dragging stay native.
        if (event.ctrlKey && !controlDown && !replayed.has(event)) {
            event.preventDefault(); event.stopImmediatePropagation();
            pending += event.deltaY * unit;
            source = {target, x:event.clientX, y:event.clientY, shift:event.shiftKey};
            if (!frame) frame = requestAnimationFrame(advance);
            return;
        }
        if (!event.ctrlKey) cancel();
        const pixels = event.deltaY * unit * (event.ctrlKey ? 2.5 : 1);
        // Native trackball multiplies spin by 0.075; preserve fractional vertical motion.
        const wheelDelta = -pixels * 120 / 750;
        Object.defineProperties(event, {
            wheelDelta: {value:wheelDelta, configurable:true},
            wheelDeltaY: {value:wheelDelta, configurable:true},
            wheelDeltaX: {value:0, configurable:true},
            deltaX: {value:0, configurable:true},
            deltaZ: {value:0, configurable:true}
        });
    }, {capture:true, passive:false, signal:controller.signal});
    container.addEventListener('pointerdown', cancel, {capture:true, signal:controller.signal});
    container.addEventListener('touchstart', cancel, {capture:true, passive:true, signal:controller.signal});
    window.addEventListener('keydown', event => {
        if (event.key === 'Control') {controlDown = true; cancel();}
    }, {signal:controller.signal});
    window.addEventListener('keyup', event => {
        if (event.key === 'Control') {controlDown = false; cancel();}
    }, {signal:controller.signal});
    window.addEventListener('blur', () => {controlDown = false; cancel();}, {signal:controller.signal});
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) cancel();
    }, {signal:controller.signal});
    return () => {cancel(); controller.abort();};
}

// Every icon control shows what it does on hover, in Molstar's own hover box, the markup of its Fullscreen entry, instead of
// the browser's slow tooltip. The box is fixed to the window, so it moves nothing. A control with a hover box keeps its own.
function installControlLabels(container) {
    const controller = new AbortController();
    const label = document.createElement('div');
    label.className = 'msp-hover-box-wrapper molstar-control-label';
    label.hidden = true;
    label.innerHTML = '<div class="msp-hover-box-body"><div class="msp-flex-column"><div class="msp-flex-row">'
        + '<button type="button" tabindex="-1" aria-hidden="true" class="msp-btn msp-btn-block"></button></div></div></div>';
    const text = label.querySelector('button');
    let shownFor = null;
    const named = element => {
        const button = element?.closest?.('button');
        if (!button || !container.contains(button) || button.closest('.molstarview-menu-list')) return null;
        if (button.closest('.msp-hover-box-wrapper')?.querySelector('.msp-hover-box-body')) return null;
        return button.title || button.getAttribute('aria-label') ? button : null;
    };
    const hide = () => { label.hidden = true; shownFor = null; };
    container.addEventListener('pointerover', event => {
        const button = named(event.target);
        if (!button) return hide();
        // An empty title on a child covering the button keeps the browser's own tooltip away; the button keeps its title.
        const cover = button.firstElementChild;
        if (cover) { cover.title = ''; cover.classList.add('molstar-control-cover'); }
        if (button.getAttribute('aria-expanded') === 'true') return hide();
        text.textContent = button.title || button.getAttribute('aria-label');
        // Inside Molstar's root, whose styles it takes.
        const root = button.closest('.msp-plugin') ?? container;
        if (label.parentElement !== root) root.append(label);
        label.hidden = false;
        shownFor = button;
        const box = button.getBoundingClientRect(), own = label.getBoundingClientRect();
        const bounds = root.getBoundingClientRect();
        const beside = button.closest('.msp-viewport-controls-buttons');
        const left = beside ? box.left - own.width - 4 : box.left;
        const top = beside ? box.top : box.bottom + 4;
        label.style.left = Math.max(bounds.left + 4, Math.min(left, bounds.right - own.width - 4)) + 'px';
        label.style.top = top + 'px';
    }, {signal:controller.signal});
    container.addEventListener('pointerout', event => {
        if (shownFor && named(event.relatedTarget) !== shownFor) hide();
    }, {signal:controller.signal});
    container.addEventListener('pointerdown', hide, {capture:true, signal:controller.signal});
    return () => { controller.abort(); label.remove(); };
}

function alignCameraToAxes(canvas) {
    const {Vec3} = molstar.lib.math.LinearAlgebra;
    const state = canvas.camera.state;
    const direction = Vec3.sub(Vec3(), Vec3.fromArray(Vec3(), state.position, 0), Vec3.fromArray(Vec3(), state.target, 0));
    const distance = Vec3.magnitude(direction);
    if (!distance) return;
    const normal = Vec3.normalize(Vec3(), Vec3.scale(direction, direction, 1 / distance));
    const cameraUp = Vec3.fromArray(Vec3(), state.up, 0);
    const rawUp = Vec3.scaleAndAdd(Vec3(), cameraUp, normal, -Vec3.dot(cameraUp, normal));
    const length = Vec3.magnitude(rawUp);
    if (!length) return;
    const up = Vec3.normalize(Vec3(), rawUp), right = Vec3.cross(Vec3(), up, normal);
    const axes = [[1,0,0], [-1,0,0], [0,1,0], [0,-1,0], [0,0,1], [0,0,-1]]
        .map(axis => Vec3.fromArray(Vec3(), axis, 0));
    let best = null, score = -Infinity;
    for (const axis of axes) for (const vertical of axes) {
        if (Vec3.dot(axis, vertical)) continue;
        const similarity = Vec3.dot(normal, axis) + Vec3.dot(up, vertical)
            + Vec3.dot(right, Vec3.cross(Vec3(), vertical, axis));
        if (similarity > score) { score = similarity; best = {axis, vertical}; }
    }
    const target = Array.from(state.target);
    canvas.requestCameraReset({snapshot:{target,
        position:Array.from(Vec3.scaleAndAdd(Vec3(), Vec3.fromArray(Vec3(), target, 0), best.axis, distance)),
        up:Array.from(best.vertical)}, durationMs:0});
}

// The one-based frame a Molstar trajectory button asks for, or undefined for any other control.
function stepFrame(title, frame) {
    return {'First Model':1, 'Previous Model':frame - 1, 'Next Model':frame + 1,
            'First Frame':1, 'Previous Frame':frame - 1, 'Next Frame':frame + 1}[title];
}

// A trajectory can name particular one-based frames without creating separate Molstar snapshots.
function createFrameChoices(labels, selectFrame) {
    const menu = document.createElement('div');
    menu.className = 'molstarview-menu molstar-frame-choices';
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'msp-btn molstarview-menu-button';
    button.setAttribute('aria-label', 'Choose Labelled Frame');
    button.setAttribute('aria-haspopup', 'true');
    button.setAttribute('aria-expanded', 'false');
    const icon = document.createElement('span');
    icon.className = 'molstar-frame-choice-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.innerHTML = '<svg viewBox="0 0 24 24"><path d="M6 3h2v2h10l-2 4 2 4H8v8H6z"></path></svg>';
    const arrow = document.createElement('span');
    arrow.className = 'molstarview-menu-arrow';
    arrow.setAttribute('aria-hidden', 'true');
    button.append(icon, arrow);
    const list = document.createElement('div');
    list.className = 'molstarview-menu-list';
    list.hidden = true;
    const close = () => { list.hidden = true; button.setAttribute('aria-expanded', 'false'); };
    const items = labels.map(({label, frame}) => {
        const item = document.createElement('button');
        item.type = 'button';
        item.className = 'msp-btn molstarview-menu-item';
        item.textContent = label;
        item.addEventListener('click', event => {
            event.stopPropagation();
            close();
            selectFrame(frame);
        });
        list.append(item);
        return item;
    });
    button.addEventListener('click', event => {
        event.stopPropagation();
        list.hidden = !list.hidden;
        button.setAttribute('aria-expanded', String(!list.hidden));
    });
    const escape = event => { if (event.key === 'Escape' && !list.hidden) { close(); button.focus(); } };
    document.addEventListener('click', close);
    document.addEventListener('keydown', escape);
    menu.append(button, list);
    return {element:menu, setRange(start, count) {
        items.forEach((item, index) => {
            const frame = labels[index].frame - 1;
            item.hidden = item.disabled = frame < start || frame >= start + count;
        });
        menu.hidden = !items.some(item => !item.disabled);
        if (menu.hidden) close();
    }, dispose() {
        document.removeEventListener('click', close);
        document.removeEventListener('keydown', escape);
    }};
}

// A button at the end of Molstar's right-hand toolbar, in its own style, that shows the viewer's next view.
function installViewSwitch(container, onClick) {
    const wrapper = document.createElement('div');
    wrapper.className = 'msp-hover-box-wrapper';
    const background = document.createElement('div');
    background.className = 'msp-semi-transparent-background';
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'msp-btn msp-btn-icon';
    // Material Design Icons "swap-horizontal" (Apache 2.0), from the family of Molstar's own material icons.
    button.innerHTML = '<span class="msp-icon msp-material-icon"><svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M21,9L17,5V8H10V10H17V13M7,11L3,15L7,19V16H14V14H7V11Z"></path></svg></span>';
    wrapper.append(background, button);
    button.addEventListener('click', onClick);
    const attach = () => {
        const buttons = container.querySelector('.msp-viewport-controls-buttons');
        if (buttons && buttons.lastElementChild !== wrapper) buttons.append(wrapper);
    };
    const toolbar = new MutationObserver(attach);
    toolbar.observe(container, {childList:true, subtree:true});
    attach();
    const title = text => { button.title = text; button.setAttribute('aria-label', text); };
    return {title, dispose:() => { toolbar.disconnect(); wrapper.remove(); }};
}

// A toggle at the end of Molstar's right-hand toolbar, styled and sized as its own icon toggles: the icon dark when on
// and light when off, with a constant title in their Title Case. Unlike the view switch it does not keep itself last, so the two never
// move each other.
function installFieldToggle(container, title, path, onClick, on) {
    const wrapper = document.createElement('div');
    wrapper.className = 'msp-hover-box-wrapper';
    const background = document.createElement('div');
    background.className = 'msp-semi-transparent-background';
    const button = document.createElement('button');
    button.type = 'button';
    button.title = title;
    button.setAttribute('aria-label', title);
    button.innerHTML = `<span class="msp-icon msp-material-icon"><svg width="24px" height="24px" viewBox="0 0 24 24" aria-hidden="true"><path d="${path}"></path></svg></span>`;
    wrapper.append(background, button);
    button.addEventListener('click', onClick);
    const look = shown => {
        button.className = 'msp-btn msp-btn-icon molstarview-field-toggle msp-btn-link-toggle-' + (shown ? 'on' : 'off');
        button.setAttribute('aria-pressed', String(shown));
    };
    look(on);
    const attach = () => {
        const buttons = container.querySelector('.msp-viewport-controls-buttons');
        if (buttons && wrapper.parentElement !== buttons) buttons.append(wrapper);
    };
    const toolbar = new MutationObserver(attach);
    toolbar.observe(container, {childList:true, subtree:true});
    attach();
    return {look, dispose:() => { toolbar.disconnect(); wrapper.remove(); }};
}

function installAxisAlignment(container, viewer) {
    const controller = new AbortController();
    const wrapper = document.createElement('div');
    wrapper.className = 'msp-hover-box-wrapper';
    const background = document.createElement('div');
    background.className = 'msp-semi-transparent-background';
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'msp-btn msp-btn-icon';
    button.title = 'Align to Nearest Coordinate Axes (Right-Click)';
    button.setAttribute('aria-label', button.title);
    // Material Design Icons "axis-arrow" (Apache 2.0), from the family of Molstar's own material icons.
    button.innerHTML = '<span class="msp-icon msp-material-icon"><svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path d="M12,2L16,6H13V13.85L19.53,17.61L21,15.03L22.5,20.5L17,21.96L18.53,19.35L12,15.58L5.47,19.35L7,21.96L1.5,20.5L3,15.03L4.47,17.61L11,13.85V6H8L12,2Z"></path></svg></span>';
    wrapper.append(background, button);
    const align = () => {
        const canvas = viewer.plugin.canvas3d;
        if (canvas) alignCameraToAxes(canvas);
    };
    button.addEventListener('click', align, {signal:controller.signal});
    const attach = () => {
        const buttons = container.querySelector('.msp-viewport-controls-buttons');
        if (!buttons) return;
        const reset = [...buttons.querySelectorAll('button')].find(node => /reset.*(?:camera|zoom)|(?:camera|zoom).*reset/i.test(node.title || node.getAttribute('aria-label') || ''));
        const neighbor = reset?.closest('.msp-hover-box-wrapper') || reset;
        // At the head of the control column, beside Molstar's reset button rather than among the view tools below it.
        if (neighbor?.parentElement === buttons) {
            if (neighbor.previousElementSibling !== wrapper) buttons.insertBefore(wrapper, neighbor);
        } else if (buttons.firstElementChild !== wrapper) buttons.prepend(wrapper);
    };
    const toolbar = new MutationObserver(attach);
    toolbar.observe(container, {childList:true, subtree:true});
    attach();
    let pressed = null;
    container.addEventListener('pointerdown', event => {
        if (event.button !== 2 || !event.target.closest('canvas')) return;
        pressed = {x:event.clientX, y:event.clientY, pointer:event.pointerId, reset:event.ctrlKey};
    }, {capture:true, signal:controller.signal});
    window.addEventListener('pointerup', event => {
        if (!pressed || event.pointerId !== pressed.pointer) return;
        const click = Math.hypot(event.clientX - pressed.x, event.clientY - pressed.y) < 5;
        if (click) {
            if (pressed.reset) viewer.plugin.canvas3d?.requestCameraReset({durationMs:0});
            else align();
            event.preventDefault(); event.stopImmediatePropagation();
        }
        pressed = null;
    }, {capture:true, signal:controller.signal});
    container.addEventListener('contextmenu', event => {
        if (event.target.closest('canvas')) { event.preventDefault(); event.stopImmediatePropagation(); }
    }, {capture:true, signal:controller.signal});
    return () => { controller.abort(); toolbar.disconnect(); wrapper.remove(); };
}


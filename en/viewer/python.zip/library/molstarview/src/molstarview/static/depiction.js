// The 2D structure below a viewer, drawn by RDKit.js from the depiction Python built (molstarview.depiction): the
// bonds of the shown frame, the atoms in the viewer's own colours, and each measurement's bonds highlighted with its
// value at that frame in a legend underneath. It follows every frame, snapshot and dropdown change, and hovering an atom
// in either view rings it in the drawing and highlights it in 3D.

// The pinned RDKit.js build, the release of the Python RDKit that lays out the depictions.
const RDKIT = 'https://cdn.jsdelivr.net/npm/@rdkit/rdkit@2026.9.1/dist/';
// Colours of measurements and groups, in order: Tableau 10, as the pages' charts use it.
const DEPICTION_MARKS = ['#4e79a7', '#f28e2b', '#59a14f', '#e15759', '#b07aa1', '#76b7b2', '#edc948', '#9c755f'];
// The LaTeX unit of each kind of measurement, and the decimals its value is shown with.
const DEPICTION_UNITS = {distance:['\\,\\text{\\AA}', 3], angle:['^\\circ', 1], dihedral:['^\\circ', 1]};

// One RDKit.js module for the page. Jupyter's RequireJS defines a global `define`, which would make the UMD script
// register itself as a module instead of setting `initRDKitModule`, so `define` is hidden while it evaluates.
function loadRDKit() {
    if (globalThis.molstarviewRDKit) return globalThis.molstarviewRDKit;
    globalThis.molstarviewRDKit = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        const saved = globalThis.define;
        globalThis.define = undefined;
        const restore = () => { if (saved !== undefined) globalThis.define = saved; };
        script.src = RDKIT + 'RDKit_minimal.js';
        script.onload = () => { restore(); resolve(); };
        script.onerror = () => { restore(); reject(new Error('Could not load RDKit')); };
        document.head.append(script);
    }).then(() => globalThis.initRDKitModule({locateFile: () => RDKIT + 'RDKit_minimal.wasm'}));
    return globalThis.molstarviewRDKit;
}

// RGB fractions of a #rrggbb colour, as RDKit's highlight options take them.
function depictionRGB(hex) {
    return [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16) / 255);
}

// RDKit.js drawing options for one frame: every coloured atom highlighted in its colour, then each mark's bonds (and
// its atoms not already coloured) in the mark's colour. `colors` holds one #rrggbb or empty per viewer atom.
function depictionDetails(data, drawing, colors, width, height, sizes = {}) {
    const atoms = [], atomColors = {}, bonds = [], bondColors = {}, radii = {};
    data.atoms.forEach((atom, index) => {
        const color = colors[atom];
        if (color) { atoms.push(index); atomColors[index] = depictionRGB(color); radii[index] = Math.max(0.4, sizes[index] || 0); }
    });
    const pairs = data.bonds[drawing];
    const bondOf = (a, b) => pairs.findIndex(([x, y]) => (x === a && y === b) || (x === b && y === a));
    data.marks.forEach((mark, number) => {
        const color = depictionRGB(DEPICTION_MARKS[number % DEPICTION_MARKS.length]);
        const members = mark.atoms;
        const links = mark.kind === 'group'
            ? members.flatMap((a, i) => members.slice(i + 1).map(b => [a, b]))
            : members.slice(1).map((b, i) => [members[i], b]);
        for (const [a, b] of links) {
            const bond = bondOf(a, b);
            if (bond >= 0 && !(bond in bondColors)) { bonds.push(bond); bondColors[bond] = color; }
        }
        for (const atom of members) {
            if (!(atom in atomColors)) { atoms.push(atom); atomColors[atom] = color; radii[atom] = Math.max(0.3, sizes[atom] || 0); }
        }
    });
    // A highlight is a circle on the atom itself, not an ellipse over its whole label, so the hydrogens written in an
    // NH3 or OH label are not coloured as if they were measured.
    return {width, height, atoms, bonds, highlightAtomColors:atomColors, highlightBondColors:bondColors,
        highlightAtomRadii:radii, atomHighlightsAreCircles:true, clearBackground:false, addStereoAnnotation:false,
        standardColoursForHighlightedAtoms:true};
}

// Legend entries of the marks at one frame: a colour and a label, for a measurement one LaTeX expression of its
// symbol, value and unit, such as $r_{1,6}=2.596\,\text{\AA}$; for a group its own Markdown label.
function depictionLegend(data, frame) {
    return data.marks.map((mark, number) => {
        const color = DEPICTION_MARKS[number % DEPICTION_MARKS.length];
        if (!mark.values) return {color, label:mark.label};
        const [unit, digits] = DEPICTION_UNITS[mark.kind];
        const value = mark.values[Math.min(frame, mark.values.length - 1)];
        return {color, label:`$${mark.symbol}=${value.toFixed(digits)}${unit}$`};
    }).filter(entry => entry.label);
}

// A molfile's 2D layout: each atom's (x, y) in layout units and element symbol, and each bond as [first, second, type],
// zero-based, with the molfile's bond type (1 single, 2 double, 3 triple, 9 dative). RDKit writes V2000, or V3000 for
// dative bonds.
function molblockLayout(block) {
    const lines = block.split('\n');
    if (lines[3].includes('V3000')) {
        const points = [], bonds = [], symbols = [];
        let part = null;
        for (const line of lines) {
            const words = line.replace(/^M {2}V30 /, '').trim().split(/\s+/);
            if (words[0] === 'BEGIN' || words[0] === 'END') { part = words[0] === 'BEGIN' ? words[1] : null; continue; }
            if (part === 'ATOM') { points.push([parseFloat(words[2]), parseFloat(words[3])]); symbols.push(words[1]); }
            if (part === 'BOND') bonds.push([parseInt(words[2]) - 1, parseInt(words[3]) - 1, parseInt(words[1])]);
        }
        return {points, bonds, symbols};
    }
    const atoms = parseInt(lines[3].slice(0, 3)), bonds = parseInt(lines[3].slice(3, 6));
    const points = lines.slice(4, 4 + atoms).map(line => [parseFloat(line.slice(0, 10)), parseFloat(line.slice(10, 20))]);
    const symbols = lines.slice(4, 4 + atoms).map(line => line.slice(31, 34).trim());
    const links = lines.slice(4 + atoms, 4 + atoms + bonds)
        .map(line => [parseInt(line.slice(0, 3)) - 1, parseInt(line.slice(3, 6)) - 1, parseInt(line.slice(6, 9))]);
    return {points, bonds:links, symbols};
}

// Where RDKit.js drew each atom of a layout, in the SVG's own units, read off the drawing itself as the scale s and
// offset (p, q) that map layout (x, y) to drawing (s x + p, q - s y). Two kinds of evidence fix them exactly, whatever
// the drawing's size, padding, labels or highlights:
// - a bond end at an atom without a label lies on that atom;
// - every end of a single or dative bond lies on the line through its two atoms, even where RDKit stops the bond short
//   of a label, so drawings whose atoms all carry labels, such as a metal complex, are placed exactly too.
// - a highlighted atom's circle, which RDKit draws centred on the atom with the radius asked, `radii` in layout units,
//   times the drawing's scale, so it fixes the atom's place and the scale at once, as for a metal whose bonds all meet
//   at it.
// Where the drawing alone does not fix them, as for lone molecules, `prior`, the places Python's RDKit found on the
// same canvas in the SVG's units, joins the fit with a small weight: the drawing still decides every direction it
// fixes, and the prior only the rest.
// Returns the places and the length of a 1.5-unit bond on the drawing, or null when nothing fixes them.
function depictionPlaces(svg, layout, prior = null, radii = {}) {
    // RDKit.js writes attributes in single quotes, a browser serializing the drawing in double quotes.
    const labelled = new Set([...svg.matchAll(/class=["']atom-(\d+)["']/g)].map(match => +match[1]));
    const kind = (a, b) => layout.bonds.find(([x, y]) => (x === a && y === b) || (x === b && y === a))?.[2];
    // Rows of the least-squares system in (s, p, q), with their right-hand sides.
    const rows = [], sides = [];
    for (const match of svg.matchAll(/class=["']bond-\d+ atom-(\d+) atom-(\d+)["'] d=["']M ([-\d.]+),([-\d.]+) L ([-\d.]+),([-\d.]+)["']/g)) {
        const [a, b] = [+match[1], +match[2]];
        const ends = [[a, +match[3], +match[4]], [b, +match[5], +match[6]]];
        const type = kind(a, b);
        if (type !== 1 && type !== 9) continue;
        const [xa, ya] = layout.points[a], [xb, yb] = layout.points[b];
        // The bond's direction on the drawing, y pointing down, and its normal.
        const length = Math.hypot(xb - xa, yb - ya);
        if (!(length > 0)) continue;
        const [nx, ny] = [(yb - ya) / length, (xb - xa) / length];
        for (const [atom, u, v] of ends) {
            // On the line: n . (u, v) = s n . (xa, -ya) + nx p + ny q.
            rows.push([nx * xa - ny * ya, nx, ny]); sides.push(nx * u + ny * v);
            if (!labelled.has(atom)) {
                // On the atom, weighted above the line rows, which it implies.
                const [x, y] = layout.points[atom];
                rows.push([10 * x, 10, 0]); sides.push(10 * u);
                rows.push([-10 * y, 0, 10]); sides.push(10 * v);
            }
        }
    }
    for (const tag of svg.matchAll(/<ellipse\b[^>]*>/g)) {
        const read = name => parseFloat((tag[0].match(new RegExp(`\\b${name}=["']([-\\d.]+)["']`)) || [])[1]);
        const atom = parseInt((tag[0].match(/class=["']atom-(\d+)["']/) || [])[1]);
        const [u, v, reach] = [read('cx'), read('cy'), read('rx')];
        if (!Number.isFinite(atom) || !layout.points[atom] || ![u, v].every(Number.isFinite)) continue;
        const [x, y] = layout.points[atom];
        rows.push([10 * x, 10, 0]); sides.push(10 * u);
        rows.push([-10 * y, 0, 10]); sides.push(10 * v);
        if (radii[atom] > 0 && Number.isFinite(reach)) { rows.push([10 * radii[atom], 0, 0]); sides.push(10 * reach); }
    }
    if (prior) {
        prior.forEach(([u, v], atom) => {
            const [x, y] = layout.points[atom];
            rows.push([1e-3 * x, 1e-3, 0]); sides.push(1e-3 * u);
            rows.push([-1e-3 * y, 0, 1e-3]); sides.push(1e-3 * v);
        });
    }
    // Normal equations of the least squares, solved by Cramer's rule; a near-singular system fixes nothing.
    const normal = [0, 1, 2].map(i => [0, 1, 2].map(j => rows.reduce((sum, row) => sum + row[i] * row[j], 0)));
    const right = [0, 1, 2].map(i => rows.reduce((sum, row, k) => sum + row[i] * sides[k], 0));
    const det = m => m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    const whole = det(normal);
    const size = Math.max(...normal.flat().map(Math.abs));
    if (!(Math.abs(whole) > 1e-15 * size ** 3)) return null;
    const [scale, p, q] = [0, 1, 2].map(column => det(normal.map((row, i) => row.map((value, j) => j === column ? right[i] : value))) / whole);
    if (!(scale > 0)) return null;
    return {places:layout.points.map(([x, y]) => [scale * x + p, -scale * y + q]), bond:1.5 * scale};
}

// The places Python's RDKit found for a drawing on the canvas this panel draws it on, which is the SVG's own units.
function depictionDrawn(data, drawing) {
    const points = data.points?.[drawing];
    return points ? {places:points} : null;
}

// The turn of a drawing that faces the molecule as the 3D view now shows it: the rotation, or the reflection when the
// view looks from the other side, that best maps the layout's points about their centre onto the atoms' projections
// on the screen, x right and y up (2D Kabsch). Points without a projection are left out. Returns the 2x2 matrix, the
// layout's centre and the turn's angle in degrees with the reflection flag, or null with fewer than two points.
function viewTurn(points, projected) {
    const pairs = points.map((point, index) => [point, projected[index]]).filter(([, seen]) => seen);
    if (pairs.length < 2) return null;
    const mean = list => list.reduce((sum, [x, y]) => [sum[0] + x / list.length, sum[1] + y / list.length], [0, 0]);
    const centre = mean(pairs.map(([point]) => point)), aim = mean(pairs.map(([, seen]) => seen));
    let [xx, xy, yx, yy] = [0, 0, 0, 0];
    for (const [[x, y], [u, v]] of pairs) {
        const [a, b, c, d] = [x - centre[0], y - centre[1], u - aim[0], v - aim[1]];
        xx += a * c; xy += a * d; yx += b * c; yy += b * d;
    }
    // The best rotation's and the best reflection's agreement with the projection, and their angles.
    const turning = Math.hypot(xx + yy, xy - yx), mirroring = Math.hypot(xx - yy, xy + yx);
    if (!(Math.max(turning, mirroring) > 0)) return null;
    const mirrored = mirroring > turning;
    const angle = mirrored ? Math.atan2(xy + yx, xx - yy) : Math.atan2(xy - yx, xx + yy);
    const [cos, sin] = [Math.cos(angle), Math.sin(angle)];
    // A rotation by the angle, after reflecting y for a mirrored turn.
    const matrix = mirrored ? [[cos, sin], [sin, -cos]] : [[cos, -sin], [sin, cos]];
    return {matrix, centre, degrees:Math.round(angle * 180 / Math.PI), mirrored};
}

// The drawing's points as the 3D view now shows the molecule: each separate molecule turned, or mirrored, onto its own
// projection (viewTurn) and set at its projected centre, in layout units, which are about the projection's angstrom,
// since a view that turns them moves separate molecules relative to one another; one molecule keeps its centre. A
// molecule that would overlap another is pushed off it along the line between their centres, a quarter bond at a
// time, until their nearest atoms are a bond and a half apart. Returns null when the view cannot orient the drawing.
function viewLayout(layout, projected) {
    const count = layout.points.length, left = new Set(layout.points.keys()), pieces = [];
    while (left.size) {
        const [first] = left;
        left.delete(first);
        const piece = [first];
        for (let index = 0; index < piece.length; index++) {
            for (const [a, b] of layout.bonds) {
                const other = a === piece[index] ? b : b === piece[index] ? a : null;
                if (other !== null && left.has(other)) { left.delete(other); piece.push(other); }
            }
        }
        pieces.push(piece);
    }
    const placed = layout.points.map(point => [...point]);
    const centre = atoms => atoms.reduce((sum, atom) => [sum[0] + placed[atom][0] / atoms.length, sum[1] + placed[atom][1] / atoms.length], [0, 0]);
    const turnOf = atoms => viewTurn(atoms.map(atom => layout.points[atom]), atoms.map(atom => projected[atom]));
    if (pieces.length === 1) {
        const turn = turnOf(pieces[0]);
        if (!turn) return null;
        return layout.points.map(([x, y]) => {
            const [a, b] = [x - turn.centre[0], y - turn.centre[1]];
            return [turn.matrix[0][0] * a + turn.matrix[0][1] * b + turn.centre[0], turn.matrix[1][0] * a + turn.matrix[1][1] * b + turn.centre[1]];
        });
    }
    if (projected.filter(Boolean).length < count) return null;
    for (const piece of pieces) {
        const turn = piece.length > 1 ? turnOf(piece) : null;
        const aim = piece.reduce((sum, atom) => [sum[0] + projected[atom][0] / piece.length, sum[1] + projected[atom][1] / piece.length], [0, 0]);
        const own = centre(piece);
        for (const atom of piece) {
            const [a, b] = [layout.points[atom][0] - own[0], layout.points[atom][1] - own[1]];
            placed[atom] = turn ? [turn.matrix[0][0] * a + turn.matrix[0][1] * b + aim[0], turn.matrix[1][0] * a + turn.matrix[1][1] * b + aim[1]]
                : [a + aim[0], b + aim[1]];
        }
    }
    // Larger molecules stay; each smaller one moves off any it overlaps.
    pieces.sort((a, b) => b.length - a.length);
    pieces.forEach((piece, number) => {
        const others = pieces.slice(0, number).flat();
        for (let step = 0; step < 200 && others.length; step++) {
            let nearest = Infinity;
            for (const atom of piece) for (const other of others) {
                nearest = Math.min(nearest, Math.hypot(placed[atom][0] - placed[other][0], placed[atom][1] - placed[other][1]));
            }
            if (nearest >= 2.25) break;
            const [from, to] = [centre(others), centre(piece)];
            const length = Math.hypot(to[0] - from[0], to[1] - from[1]);
            const [dx, dy] = length > 1e-9 ? [(to[0] - from[0]) / length, (to[1] - from[1]) / length] : [1, 0];
            for (const atom of piece) { placed[atom][0] += 0.25 * dx; placed[atom][1] += 0.25 * dy; }
        }
    });
    return placed;
}

// A molfile with its 2D coordinates replaced by the given points, V2000 or V3000, everything else unchanged.
function placedBlock(block, points) {
    const lines = block.split('\n');
    if (lines[3].includes('V3000')) {
        let atoms = false, index = 0;
        return lines.map(line => {
            if (/^M {2}V30 BEGIN ATOM/.test(line)) atoms = true;
            else if (/^M {2}V30 END ATOM/.test(line)) atoms = false;
            else if (atoms) {
                const words = line.split(' ');
                // 'M', '', 'V30', index, element, x, y, ...
                const at = words.indexOf('V30') + 3;
                const [x, y] = points[index++];
                words[at] = x.toFixed(6); words[at + 1] = y.toFixed(6);
                return words.join(' ');
            }
            return line;
        }).join('\n');
    }
    const count = parseInt(lines[3].slice(0, 3));
    for (let index = 4; index < 4 + count; index++) {
        const [x, y] = points[index - 4];
        lines[index] = x.toFixed(4).padStart(10) + y.toFixed(4).padStart(10) + lines[index].slice(20);
    }
    return lines.join('\n');
}

// RDKit's similarity map of a drawing, computed in the drawing's own frame: a Gaussian of each atom's weight at the
// atom's drawn place, of RDKit's width for a map (`settings.width` layout units, to the drawing's scale), evaluated on
// a grid over the atoms and three widths past them, so the field fades out instead of stopping at an edge. Returns the
// grid's corner and step in drawing pixels, its size, and its values, row by row.
function fieldGrid(places, bond, weights, settings) {
    const sigma = settings.width * bond / 1.5, reach = 3.2 * sigma, step = sigma / 4;
    const xs = places.map(([x]) => x), ys = places.map(([, y]) => y);
    const left = Math.min(...xs) - reach, top = Math.min(...ys) - reach;
    const columns = Math.ceil((Math.max(...xs) + reach - left) / step) + 1;
    const rows = Math.ceil((Math.max(...ys) + reach - top) / step) + 1;
    const values = new Float64Array(columns * rows), spread = 2 * sigma * sigma;
    places.forEach(([x, y], atom) => {
        const weight = weights[atom];
        if (!weight) return;
        // Each atom reaches only the cells within its three widths.
        const [c0, c1] = [Math.max(0, Math.floor((x - reach - left) / step)), Math.min(columns - 1, Math.ceil((x + reach - left) / step))];
        const [r0, r1] = [Math.max(0, Math.floor((y - reach - top) / step)), Math.min(rows - 1, Math.ceil((y + reach - top) / step))];
        for (let row = r0; row <= r1; row++) {
            const dy = top + row * step - y;
            for (let column = c0; column <= c1; column++) {
                const dx = left + column * step - x;
                values[row * columns + column] += weight * Math.exp(-(dx * dx + dy * dy) / spread);
            }
        }
    });
    return {left, top, step, columns, rows, values};
}

// RGB of a #rrggbb colour, 0 to 255.
function fieldRGB(hex) {
    return [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16));
}

// The field drawn under a drawing of `size` pixels: a canvas laid over the drawing's frame, reaching past it where the
// field does. Each value shows the colour of its end of the viewer's scale with an opacity of its fraction of the
// scale, so on the page it looks as RDKit's map does over white, and the field fades into the page where it is zero.
function depictionField(places, bond, weights, range, colors, settings, size) {
    const grid = fieldGrid(places, bond, weights, settings);
    const bound = Math.max(Math.abs(range[0]), Math.abs(range[1])) || 1, signed = range[0] < 0;
    const [low, high] = [fieldRGB(colors[0]), fieldRGB(colors[colors.length - 1])];
    // The values as an image of one pixel per grid point, drawn smoothed onto a canvas of four pixels per drawing pixel.
    const coarse = document.createElement('canvas');
    coarse.width = grid.columns; coarse.height = grid.rows;
    const image = coarse.getContext('2d').createImageData(grid.columns, grid.rows);
    grid.values.forEach((value, index) => {
        const fraction = Math.max(-1, Math.min(1, value / bound));
        const [r, g, b] = fraction < 0 && signed ? low : high;
        image.data.set([r, g, b, Math.round(255 * Math.abs(signed ? fraction : Math.max(0, fraction)))], 4 * index);
    });
    coarse.getContext('2d').putImageData(image, 0, 0);
    const scale = 4, canvas = document.createElement('canvas');
    const [width, height] = [(grid.columns - 1) * grid.step, (grid.rows - 1) * grid.step];
    canvas.width = Math.ceil(width * scale); canvas.height = Math.ceil(height * scale);
    canvas.className = 'molstarview-depiction-field';
    Object.assign(canvas.style, {left:`${grid.left / size[0] * 100}%`, top:`${grid.top / size[1] * 100}%`,
        width:`${width / size[0] * 100}%`, height:`${height / size[1] * 100}%`});
    const context = canvas.getContext('2d');
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = 'high';
    context.drawImage(coarse, 0, 0, canvas.width, canvas.height);
    return canvas;
}

// The highlight radius, in layout units, that wraps each labelled atom's element symbol in a drawing: the circle about
// the atom's place that holds the symbol's glyphs, with a margin of a twentieth of a bond. RDKit draws a label as one
// glyph per character; the symbol's are the full-height glyphs nearest the place, as many as its letters, so the
// hydrogens and charges written beside it, and the subscripts, stay outside. The glyphs scale with the drawing, so the
// radius holds whatever its size or turn. `found` gives the atoms' places, as depictionPlaces returns them.
function labelSizes(svg, layout, found) {
    const glyphs = new Map();
    for (const match of svg.matchAll(/<path class=["']atom-(\d+)["'] d=["']([^"']*)["']/g)) {
        // A glyph's outline as RDKit writes it, 'M 48.2 136.8 Q 48.2 134.8, 49.1 133.7 ...': its numbers in pairs.
        const values = (match[2].match(/-?\d+(?:\.\d+)?/g) || []).map(Number);
        const numbers = values.flatMap((value, index) => index % 2 ? [] : [[value, values[index + 1]]]).filter(([, y]) => Number.isFinite(y));
        if (!numbers.length) continue;
        const xs = numbers.map(([x]) => x), ys = numbers.map(([, y]) => y);
        const box = [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
        const atom = +match[1];
        if (!glyphs.has(atom)) glyphs.set(atom, []);
        glyphs.get(atom).push(box);
    }
    const sizes = {}, unit = found.bond / 1.5;
    for (const [atom, boxes] of glyphs) {
        const place = found.places[atom], letters = (layout.symbols?.[atom] || 'X').length;
        if (!place) continue;
        const tallest = Math.max(...boxes.map(([, top, , bottom]) => bottom - top));
        const centre = ([left, top, right, bottom]) => [(left + right) / 2, (top + bottom) / 2];
        const symbol = boxes.filter(([, top, , bottom]) => bottom - top > 0.75 * tallest)
            .sort((a, b) => Math.hypot(...centre(a).map((v, i) => v - place[i])) - Math.hypot(...centre(b).map((v, i) => v - place[i])))
            .slice(0, letters);
        const reach = Math.max(...symbol.flatMap(([left, top, right, bottom]) =>
            [[left, top], [right, top], [left, bottom], [right, bottom]].map(([x, y]) => Math.hypot(x - place[0], y - place[1]))));
        if (Number.isFinite(reach)) sizes[atom] = reach / unit + 0.075;
    }
    return sizes;
}

// The depicted atom nearest a point of the drawing, within half a bond, or -1.
function depictionNearest(found, x, y) {
    let best = -1, reach = found.bond / 2;
    found.places.forEach(([u, v], index) => {
        const gap = Math.hypot(u - x, v - y);
        if (gap < reach) { reach = gap; best = index; }
    });
    return best;
}

// The depicted atom that stands for a viewer atom: the atom itself, or the heavy atom a hidden hydrogen is counted on.
function depictedAtom(data, atom) {
    const index = data.atoms.indexOf(atom);
    if (index >= 0) return index;
    const counted = (data.hydrogens || []).find(([light]) => light === atom);
    return counted ? data.atoms.indexOf(counted[1]) : -1;
}

// The panel's own words, in the page's language where it has them, else English.
const DEPICTION_TEXT = {
    en: {'single-bonds':'RDKit could not assign bond orders to this structure, so all of its bonds are drawn single.',
        'browser-bonds':'Bond orders are assigned by the Python RDKit, which this page does not have, so all bonds are drawn single.'},
    ja: {'single-bonds':'RDKit がこの構造の結合次数を決められなかったため、結合はすべて単結合で描いています。',
        'browser-bonds':'結合次数は Python の RDKit が決めますが、このページにはないため、結合はすべて単結合で描いています。'},
};
function depictionText(key) {
    const language = (document.documentElement.lang || 'en').slice(0, 2);
    return (DEPICTION_TEXT[language] || DEPICTION_TEXT.en)[key];
}

// A yellow warning sign whose explanation shows in the page's Quarto popover on hover, or as its title without one.
function depictionWarning(text) {
    const sign = document.createElement('span');
    sign.className = 'molstarview-depiction-item molstarview-depiction-warning';
    sign.setAttribute('role', 'img');
    sign.setAttribute('aria-label', text);
    sign.innerHTML = '<svg viewBox="0 0 512 512" width="14" height="14" fill="#e0a800" aria-hidden="true"><path d="M256 32c14.2 0 27.3 '
        + '7.5 34.5 19.8l216 368c7.3 12.4 7.3 27.7 .2 40.1S486.3 480 472 480L40 480c-14.3 0-27.6-7.7-34.7-20.1s-7-27.8 .2-40.1l216-'
        + '368C228.7 39.5 241.8 32 256 32zm0 128c-13.3 0-24 10.7-24 24l0 112c0 13.3 10.7 24 24 24s24-10.7 24-24l0-112c0-13.3-10.7-'
        + '24-24-24zm32 224a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z"/></svg>';
    if (globalThis.tippy) {
        globalThis.tippy(sign, {content:text, delay:100, arrow:false, theme:'quarto', placement:'bottom',
            appendTo:() => document.body});
    } else {
        sign.title = text;
    }
    return sign;
}

// The panel below one viewer. `frame()` gives the zero-based model index, `snapshot()` the shown snapshot, and
// `watch(listener)` calls the listener on every change of either, returning its disposer. `hover` links the panel to
// the 3D view: `hover.listen(listener)` calls the listener with the zero-based viewer atom under the pointer in 3D, or
// null, returning its disposer, and `hover.show(atom)` highlights a viewer atom in 3D, or clears it for null; the atom
// hovered in either view is ringed in the drawing. `view` lets the drawing face the 3D view as it turns:
// `view.projected(atoms)` gives each viewer atom's place on the screen, x right and y up, and `view.listen(listener)`
// calls the listener whenever the camera moves, returning its disposer. A new drawing is prepared
// off screen, a map's image decoded first, and swapped in within one animation frame, so changing frames or
// snapshots never shows an empty or half-drawn panel; the panel keeps its height between drawings.
function installDepiction({model, el, frame, snapshot, watch, hover, view}) {
    const data = model.get('depiction');
    if (!data || !data.molblocks || !data.molblocks.length) return () => {};
    const panel = document.createElement('div');
    panel.className = 'molstarview-depiction';
    const picture = document.createElement('div');
    picture.className = 'molstarview-depiction-picture';
    const legend = document.createElement('div');
    legend.className = 'molstarview-depiction-legend';
    panel.append(picture, legend);
    el.append(panel);
    // RDKit.js molecules and parsed layouts, by drawing and its turn ('2:30m'), and the unturned layouts by drawing.
    const mols = {}, layouts = {};
    // Per drawing, the highlight radius that wraps each labelled atom's symbol, in layout units, the same at every turn.
    const sizesOf = {};
    // The molfiles drawn; those of a depiction built without RDKit are replaced by their RDKit.js layout.
    const blocks = [...data.molblocks];
    let disposed = false, shown = null, rdkit = null, ticket = 0;
    // The shown drawing's atom places and the viewer atom ringed in it.
    let found = null, ringed = null;
    const ring = () => {
        const svg = picture.querySelector('svg');
        svg?.querySelector('.molstarview-depiction-hover')?.remove();
        const atom = ringed === null || !found ? -1 : depictedAtom(data, ringed);
        if (!svg || atom < 0) return;
        const [x, y] = found.places[atom];
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('class', 'molstarview-depiction-hover');
        circle.setAttribute('cx', x); circle.setAttribute('cy', y); circle.setAttribute('r', 0.4 * found.bond);
        circle.setAttribute('stroke-width', 0.08 * found.bond);
        svg.append(circle);
    };
    const stopHover = hover ? hover.listen(atom => { ringed = atom; ring(); }) : () => {};
    // The atom under the pointer in the drawing is highlighted in 3D and ringed here.
    const point = event => {
        const svg = picture.querySelector('svg');
        if (!svg || !found || !hover) return;
        const matrix = svg.getScreenCTM()?.inverse();
        if (!matrix) return;
        const spot = new DOMPoint(event.clientX, event.clientY).matrixTransform(matrix);
        const atom = depictionNearest(found, spot.x, spot.y);
        const target = atom < 0 ? null : data.atoms[atom];
        if (target === ringed) return;
        ringed = target;
        hover.show(target);
        ring();
    };
    const leave = () => { if (ringed !== null && hover) { ringed = null; hover.show(null); ring(); } };
    picture.addEventListener('pointermove', point);
    picture.addEventListener('pointerleave', leave);
    // Legend entries: a swatch, the label and the value at the shown frame.
    const legendItems = index => {
        const items = depictionLegend(data, index).map(entry => {
            const item = document.createElement('span');
            item.className = 'molstarview-depiction-item';
            const swatch = document.createElement('span');
            swatch.className = 'molstarview-depiction-swatch';
            swatch.style.background = entry.color;
            const text = document.createElement('span');
            text.innerHTML = richHTML(entry.label);
            item.append(swatch, text);
            return item;
        });
        // A frame whose bond orders RDKit could not assign, as for an open-shell structure, shows single bonds, and
        // the legend a warning sign that explains it on hover.
        const drawing = data.frames.length ? data.frames[Math.min(index, data.frames.length - 1)] : 0;
        if (data.orders && !data.orders[drawing]) {
            items.push(depictionWarning(depictionText(data.layout === 'browser' ? 'browser-bonds' : 'single-bonds')));
        }
        return items;
    };
    const draw = async () => {
        if (disposed) return;
        const index = frame();
        const drawing = data.frames.length ? data.frames[Math.min(index, data.frames.length - 1)] : 0;
        const maps = data.maps || [];
        const set = maps.length > 1 ? snapshot() : 0;
        // A depiction Python built without RDKit, as in the calculation viewer, has each molfile laid out here once,
        // by RDKit.js's own 2D layout, before anything is drawn from it.
        if (data.layout === 'browser' && !layouts[drawing]) {
            if (!rdkit) return;
            const mol = rdkit.get_mol(blocks[drawing], JSON.stringify({removeHs:false, sanitize:false}));
            try { if (mol.set_new_coords()) blocks[drawing] = mol.get_molblock(); } finally { mol.delete(); }
        }
        layouts[drawing] ||= molblockLayout(blocks[drawing]);
        // The drawing as the view now shows the molecule; until the camera is known, or for a molecule the view cannot
        // orient, Python's layout, which faces the initial view.
        const turn = view ? viewLayout(layouts[drawing], view.projected(data.atoms) || []) : null;
        // The drawing changes only when an atom moves by a tenth of a bond or more.
        const facing = turn ? turn.map(([x, y]) => `${Math.round(x * 10)},${Math.round(y * 10)}`).join(' ') : '';
        const key = [drawing, index, set, maps[set] ? 'map' : snapshot(), facing].join(':');
        if (key === shown) return;
        const mine = ++ticket;
        if (!rdkit) return;
        const which = `${drawing}:${facing}`;
        if (!mols[which]) {
            // One turned molecule per drawing is kept: the one shown.
            for (const old of Object.keys(mols)) if (old.startsWith(`${drawing}:`)) { mols[old].delete(); delete mols[old]; }
            const block = turn ? placedBlock(blocks[drawing], turn) : blocks[drawing];
            mols[which] = rdkit.get_mol(block, JSON.stringify({removeHs:false, sanitize:false}));
            layouts[which] = molblockLayout(block);
        }
        const weights = maps[set]?.[drawing];
        const shares = (model.get('snapshot_atoms') || [])[snapshot()];
        const colors = weights ? [] : shares?.colors || model.get('atom_colors') || [];
        // RDKit sizes the canvas to the drawing as it is turned, at its own scale, the one Python's natural size and
        // the site's figures use, so the molecule keeps its size at every turn.
        const details = sizes => depictionDetails(data, drawing, colors, -1, -1, sizes);
        const drawn = sizes => mols[which].get_svg_with_highlights(JSON.stringify(details(sizes)));
        // Python's places are those of its own turn, so they help only a drawing shown with that turn.
        const placed = (text, sizes) => depictionPlaces(text, layouts[which], null, details(sizes).highlightAtomRadii)
            || (turn ? null : depictionPlaces(text, layouts[which], depictionDrawn(data, drawing)?.places, details(sizes).highlightAtomRadii));
        // The highlight of each labelled atom wraps its element symbol, measured on a first drawing of this molecule; a
        // drawing that cannot be placed is measured again at the next turn.
        if (!sizesOf[drawing]) {
            const first = drawn({});
            const found = placed(first, {});
            if (found) sizesOf[drawing] = labelSizes(first, layouts[which], found);
        }
        const text = drawn(sizesOf[drawing] || {});
        const places = placed(text, sizesOf[drawing] || {});
        // The drawing's canvas in pixels, as RDKit sized it.
        const size = (text.match(/viewBox=["']0 0 ([\d.]+) ([\d.]+)["']/) || [0, 1, 1]).slice(1).map(Number);
        const next = document.createElement('div');
        next.className = 'molstarview-depiction-drawing';
        next.innerHTML = text;
        // A quantity per atom, the viewer's atom values or the shown snapshot's shares, is RDKit's similarity map,
        // drawn here under the structure at the atoms' exact places, whatever the turn.
        if (weights && places) {
            next.prepend(depictionField(places.places, places.bond, weights, data.map_scales[set], data.map_colors, data.map, size));
        }
        // Only the latest request is shown, whichever finishes preparing first.
        if (disposed || mine !== ticket) return;
        const items = legendItems(index);
        requestAnimationFrame(() => {
            if (disposed || mine !== ticket) return;
            picture.style.minHeight = picture.offsetHeight ? picture.offsetHeight + 'px' : '';
            picture.replaceChildren(next);
            legend.replaceChildren(...items);
            shown = key;
            found = places;
            ring();
        });
    };
    const stop = watch(() => { void draw(); });
    // The camera moves many times a second while dragged; the drawing follows at most once per animation frame.
    let pending = false;
    const stopView = view ? view.listen(() => {
        if (pending) return;
        pending = true;
        requestAnimationFrame(() => { pending = false; void draw(); });
    }) : () => {};
    loadRDKit().then(module => { rdkit = module; void draw(); }, error => console.error('Structure drawing:', error));
    return () => {
        disposed = true;
        stop();
        stopView();
        stopHover();
        picture.removeEventListener('pointermove', point);
        picture.removeEventListener('pointerleave', leave);
        Object.values(mols).forEach(mol => mol?.delete());
        panel.remove();
    };
}

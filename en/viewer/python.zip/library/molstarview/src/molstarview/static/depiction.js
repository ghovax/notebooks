// The 2D structure below a viewer, drawn by RDKit.js from the depiction Python built (molstarview.depiction): the
// bonds of the shown frame, the atoms in the viewer's own colours, and each measurement's bonds highlighted with its
// value at that frame in a legend underneath. It follows every frame, snapshot and dropdown change, and hovering an atom
// in either view rings it in the drawing and highlights it in 3D.

// The pinned RDKit.js build, the release of the Python RDKit that lays out the depictions.
const RDKIT = 'https://cdn.jsdelivr.net/npm/@rdkit/rdkit@2026.9.1/dist/';
// A mark's highlight colour as RGB fractions: its own, as a notebook gives a group the colour its figure gives the
// same part, or else the shared style's colour of its place (molstarview.drawing), the colours the figures use.
function depictionMarkColor(data, number) {
    if (data.marks[number]?.color) return data.marks[number].color;
    const colors = data.drawing?.colors || [[0.8, 0.8, 0.8]];
    return colors[number % colors.length];
}

// A colour of RGB fractions as CSS, for a legend swatch.
function depictionCSS(color) {
    return `rgb(${color.map(value => Math.round(255 * value)).join(', ')})`;
}

// The LaTeX unit of each kind of measurement, and the decimals its value is shown with.
const DEPICTION_UNITS = {distance:['\\,\\text{\\AA}', 3], angle:['^\\circ', 1], dihedral:['^\\circ', 1]};

// One RDKit.js module for the page. Jupyter's RequireJS defines a global `define`, which would make the UMD script
// register itself as a module instead of setting `initRDKitModule`, so `define` is hidden while it evaluates.
function loadRDKit() {
    if (globalThis.molstarviewRDKit) return globalThis.molstarviewRDKit;
    globalThis.molstarviewRDKit = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        const saved = globalThis.define;
        globalThis.define = undefined;
        const restore = () => { if (saved !== undefined) globalThis.define = saved; };
        script.src = RDKIT + 'RDKit_minimal.js';
        script.onload = () => { restore(); resolve(); };
        script.onerror = () => { restore(); reject(new Error('Could not load RDKit')); };
        document.head.append(script);
    }).then(() => globalThis.initRDKitModule({locateFile: () => RDKIT + 'RDKit_minimal.wasm'}));
    return globalThis.molstarviewRDKit;
}

// RGB fractions of a #rrggbb colour, as RDKit's highlight options take them.
function depictionRGB(hex) {
    return [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16) / 255);
}

// RDKit.js drawing options for one frame: the shared style's options (molstarview.drawing), the same RDKit options the
// site's figures are drawn with, then every coloured atom highlighted in its colour and each mark's bonds and atoms in
// the mark's colour, as a figure highlights its parts; where anything is highlighted the style's highlighted options,
// black atom labels, are added, as in a figure. `colors` holds one #rrggbb or empty per viewer atom.
function depictionDetails(data, drawing, colors, width, height) {
    const atoms = [], atomColors = {}, bonds = [], bondColors = {};
    data.atoms.forEach((atom, index) => {
        const color = colors[atom];
        if (color) { atoms.push(index); atomColors[index] = depictionRGB(color); }
    });
    const pairs = data.bonds[drawing];
    const bondOf = (a, b) => pairs.findIndex(([x, y]) => (x === a && y === b) || (x === b && y === a));
    data.marks.forEach((mark, number) => {
        const color = depictionMarkColor(data, number);
        const members = mark.atoms;
        const links = mark.kind === 'group'
            ? members.flatMap((a, i) => members.slice(i + 1).map(b => [a, b]))
            : members.slice(1).map((b, i) => [members[i], b]);
        for (const [a, b] of links) {
            const bond = bondOf(a, b);
            if (bond >= 0 && !(bond in bondColors)) { bonds.push(bond); bondColors[bond] = color; }
        }
        for (const atom of members) {
            if (!(atom in atomColors)) { atoms.push(atom); atomColors[atom] = color; }
        }
    });
    const style = data.drawing || {};
    const highlighted = atoms.length || bonds.length ? style.highlighted : {};
    return {...style.options, ...highlighted, width, height, atoms, bonds, highlightAtomColors:atomColors,
        highlightBondColors:bondColors};
}

// Legend entries of the marks at one frame: a colour and a label, for a measurement one LaTeX expression of its
// symbol, value and unit, such as $r_{1,6}=2.596\,\text{\AA}$; for a group its own Markdown label.
function depictionLegend(data, frame) {
    return data.marks.map((mark, number) => {
        const color = depictionCSS(depictionMarkColor(data, number));
        if (!mark.values) return {color, label:mark.label};
        const [unit, digits] = DEPICTION_UNITS[mark.kind];
        const value = mark.values[Math.min(frame, mark.values.length - 1)];
        return {color, label:`$${mark.symbol}=${value.toFixed(digits)}${unit}$`};
    }).filter(entry => entry.label);
}

// A molfile's 2D layout: each atom's (x, y) in layout units and element symbol, and each bond as [first, second, type],
// zero-based, with the molfile's bond type (1 single, 2 double, 3 triple, 9 dative). RDKit writes V2000, or V3000 for
// dative bonds.
function molblockLayout(block) {
    const lines = block.split('\n');
    if (lines[3].includes('V3000')) {
        const points = [], bonds = [], symbols = [];
        let part = null;
        for (const line of lines) {
            const words = line.replace(/^M {2}V30 /, '').trim().split(/\s+/);
            if (words[0] === 'BEGIN' || words[0] === 'END') { part = words[0] === 'BEGIN' ? words[1] : null; continue; }
            if (part === 'ATOM') { points.push([parseFloat(words[2]), parseFloat(words[3])]); symbols.push(words[1]); }
            if (part === 'BOND') bonds.push([parseInt(words[2]) - 1, parseInt(words[3]) - 1, parseInt(words[1])]);
        }
        return {points, bonds, symbols};
    }
    const atoms = parseInt(lines[3].slice(0, 3)), bonds = parseInt(lines[3].slice(3, 6));
    const points = lines.slice(4, 4 + atoms).map(line => [parseFloat(line.slice(0, 10)), parseFloat(line.slice(10, 20))]);
    const symbols = lines.slice(4, 4 + atoms).map(line => line.slice(31, 34).trim());
    const links = lines.slice(4 + atoms, 4 + atoms + bonds)
        .map(line => [parseInt(line.slice(0, 3)) - 1, parseInt(line.slice(3, 6)) - 1, parseInt(line.slice(6, 9))]);
    return {points, bonds:links, symbols};
}

// Where RDKit.js drew each atom of a layout, in the SVG's own units, read off the drawing itself as the scale s and
// offset (p, q) that map layout (x, y) to drawing (s x + p, q - s y). Two kinds of evidence fix them exactly, whatever
// the drawing's size, padding, labels or highlights:
// - a bond end at an atom without a label lies on that atom;
// - every end of a single or dative bond lies on the line through its two atoms, even where RDKit stops the bond short
//   of a label, so drawings whose atoms all carry labels, such as a metal complex, are placed exactly too.
// - an unlabelled atom's highlight, which RDKit draws centred on the atom; a labelled atom's is fitted around its
//   label instead, off the atom, and is not used.
// Where the drawing alone does not fix them, as for lone molecules, `prior`, the places Python's RDKit found on the
// same canvas in the SVG's units, joins the fit with a small weight: the drawing still decides every direction it
// fixes, and the prior only the rest. `known`, the pixels per layout unit of an earlier drawing of the same molecule,
// joins the same way: RDKit keeps a molecule's scale as it turns, so a metal whose bonds all meet at it, whose lines
// fix its place but not the scale, is still placed exactly at every turn.
// Returns the places and the length of a 1.5-unit bond on the drawing, or null when nothing fixes them.
function depictionPlaces(svg, layout, prior = null, known = null) {
    // Atoms drawn with a label: RDKit writes each label glyph as a path of the atom's class alone; a highlight ellipse
    // carries the same class but is no label. RDKit.js writes attributes in single quotes, a browser serializing the
    // drawing in double quotes.
    const labelled = new Set([...svg.matchAll(/<path class=["']atom-(\d+)["']/g)].map(match => +match[1]));
    const kind = (a, b) => layout.bonds.find(([x, y]) => (x === a && y === b) || (x === b && y === a))?.[2];
    // Rows of the least-squares system in (s, p, q), with their right-hand sides.
    const rows = [], sides = [];
    // Each bond's segments in drawing order. RDKit draws a bond between two elements as two halves, each in its atom's
    // colour, both written from the first atom to the second under the same class: the first half starts at the first
    // atom, the last ends at the second, and the point they share is the bond's middle, on the line but at neither atom.
    const segments = new Map();
    for (const match of svg.matchAll(/class=["']bond-(\d+) atom-(\d+) atom-(\d+)["'] d=["']M ([-\d.]+),([-\d.]+) L ([-\d.]+),([-\d.]+)["']/g)) {
        const [, bond, a, b, ...ends] = match.map(Number);
        if (!segments.has(bond)) segments.set(bond, {a, b, points:[]});
        segments.get(bond).points.push(ends);
    }
    for (const {a, b, points} of segments.values()) {
        // The bond's two ends, then every other end of its segments, which lie on its line only.
        const [first, last] = [points[0], points[points.length - 1]];
        const ends = [[a, first[0], first[1]], [b, last[2], last[3]],
            ...points.flatMap(([u0, v0, u1, v1], index) => [index ? [null, u0, v0] : null, index < points.length - 1 ? [null, u1, v1] : null]).filter(Boolean)];
        const type = kind(a, b);
        if (type !== 1 && type !== 9) continue;
        const [xa, ya] = layout.points[a], [xb, yb] = layout.points[b];
        // The bond's direction on the drawing, y pointing down, and its normal.
        const length = Math.hypot(xb - xa, yb - ya);
        if (!(length > 0)) continue;
        const [nx, ny] = [(yb - ya) / length, (xb - xa) / length];
        for (const [atom, u, v] of ends) {
            // On the line: n . (u, v) = s n . (xa, -ya) + nx p + ny q.
            rows.push([nx * xa - ny * ya, nx, ny]); sides.push(nx * u + ny * v);
            if (atom !== null && !labelled.has(atom)) {
                // On the atom, weighted above the line rows, which it implies.
                const [x, y] = layout.points[atom];
                rows.push([10 * x, 10, 0]); sides.push(10 * u);
                rows.push([-10 * y, 0, 10]); sides.push(10 * v);
            }
        }
    }
    for (const tag of svg.matchAll(/<ellipse\b[^>]*>/g)) {
        const read = name => parseFloat((tag[0].match(new RegExp(`\\b${name}=["']([-\\d.]+)["']`)) || [])[1]);
        const atom = parseInt((tag[0].match(/class=["']atom-(\d+)["']/) || [])[1]);
        const [u, v] = [read('cx'), read('cy')];
        // RDKit fits a labelled atom's highlight around its label, so only an unlabelled atom's is centred on it.
        if (!Number.isFinite(atom) || labelled.has(atom) || !layout.points[atom] || ![u, v].every(Number.isFinite)) continue;
        const [x, y] = layout.points[atom];
        rows.push([10 * x, 10, 0]); sides.push(10 * u);
        rows.push([-10 * y, 0, 10]); sides.push(10 * v);
    }
    if (prior) {
        prior.forEach(([u, v], atom) => {
            const [x, y] = layout.points[atom];
            rows.push([1e-3 * x, 1e-3, 0]); sides.push(1e-3 * u);
            rows.push([-1e-3 * y, 0, 1e-3]); sides.push(1e-3 * v);
        });
    }
    if (known > 0) { rows.push([1e-3, 0, 0]); sides.push(1e-3 * known); }
    // Normal equations of the least squares, solved by Cramer's rule; a near-singular system fixes nothing.
    const normal = [0, 1, 2].map(i => [0, 1, 2].map(j => rows.reduce((sum, row) => sum + row[i] * row[j], 0)));
    const right = [0, 1, 2].map(i => rows.reduce((sum, row, k) => sum + row[i] * sides[k], 0));
    const det = m => m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    const whole = det(normal);
    const size = Math.max(...normal.flat().map(Math.abs));
    if (!(Math.abs(whole) > 1e-15 * size ** 3)) return null;
    const [scale, p, q] = [0, 1, 2].map(column => det(normal.map((row, i) => row.map((value, j) => j === column ? right[i] : value))) / whole);
    if (!(scale > 0)) return null;
    return {places:layout.points.map(([x, y]) => [scale * x + p, -scale * y + q]), bond:1.5 * scale};
}

// The places Python's RDKit found for a drawing on the canvas this panel draws it on, which is the SVG's own units.
function depictionDrawn(data, drawing) {
    const points = data.points?.[drawing];
    return points ? {places:points} : null;
}

// The turn of a drawing that faces the molecule as the 3D view now shows it: the rotation, or the reflection when the
// view looks from the other side, that best maps the layout's points about their centre onto the atoms' projections
// on the screen, x right and y up (2D Kabsch). Points without a projection are left out. Returns the 2x2 matrix, the
// layout's centre and the turn's angle in degrees with the reflection flag, or null with fewer than two points.
function viewTurn(points, projected) {
    const pairs = points.map((point, index) => [point, projected[index]]).filter(([, seen]) => seen);
    if (pairs.length < 2) return null;
    const mean = list => list.reduce((sum, [x, y]) => [sum[0] + x / list.length, sum[1] + y / list.length], [0, 0]);
    const centre = mean(pairs.map(([point]) => point)), aim = mean(pairs.map(([, seen]) => seen));
    let [xx, xy, yx, yy] = [0, 0, 0, 0];
    for (const [[x, y], [u, v]] of pairs) {
        const [a, b, c, d] = [x - centre[0], y - centre[1], u - aim[0], v - aim[1]];
        xx += a * c; xy += a * d; yx += b * c; yy += b * d;
    }
    // The best rotation's and the best reflection's agreement with the projection, and their angles.
    const turning = Math.hypot(xx + yy, xy - yx), mirroring = Math.hypot(xx - yy, xy + yx);
    if (!(Math.max(turning, mirroring) > 0)) return null;
    const mirrored = mirroring > turning;
    const angle = mirrored ? Math.atan2(xy + yx, xx - yy) : Math.atan2(xy - yx, xx + yy);
    const [cos, sin] = [Math.cos(angle), Math.sin(angle)];
    // A rotation by the angle, after reflecting y for a mirrored turn.
    const matrix = mirrored ? [[cos, sin], [sin, -cos]] : [[cos, -sin], [sin, cos]];
    return {matrix, centre, degrees:Math.round(angle * 180 / Math.PI), mirrored};
}

// The drawing's points as the 3D view now shows the molecule: each separate molecule turned, or mirrored, onto its own
// projection (viewTurn) and set at its projected centre, in layout units, which are about the projection's angstrom,
// since a view that turns them moves separate molecules relative to one another; one molecule keeps its centre. A
// molecule that would overlap another is pushed off it along the line between their centres, a quarter bond at a
// time, until their nearest atoms are a bond and a half apart. Returns null when the view cannot orient the drawing.
function viewLayout(layout, projected) {
    const count = layout.points.length, left = new Set(layout.points.keys()), pieces = [];
    while (left.size) {
        const [first] = left;
        left.delete(first);
        const piece = [first];
        for (let index = 0; index < piece.length; index++) {
            for (const [a, b] of layout.bonds) {
                const other = a === piece[index] ? b : b === piece[index] ? a : null;
                if (other !== null && left.has(other)) { left.delete(other); piece.push(other); }
            }
        }
        pieces.push(piece);
    }
    const placed = layout.points.map(point => [...point]);
    const centre = atoms => atoms.reduce((sum, atom) => [sum[0] + placed[atom][0] / atoms.length, sum[1] + placed[atom][1] / atoms.length], [0, 0]);
    const turnOf = atoms => viewTurn(atoms.map(atom => layout.points[atom]), atoms.map(atom => projected[atom]));
    if (pieces.length === 1) {
        const turn = turnOf(pieces[0]);
        if (!turn) return null;
        return layout.points.map(([x, y]) => {
            const [a, b] = [x - turn.centre[0], y - turn.centre[1]];
            return [turn.matrix[0][0] * a + turn.matrix[0][1] * b + turn.centre[0], turn.matrix[1][0] * a + turn.matrix[1][1] * b + turn.centre[1]];
        });
    }
    if (projected.filter(Boolean).length < count) return null;
    for (const piece of pieces) {
        const turn = piece.length > 1 ? turnOf(piece) : null;
        const aim = piece.reduce((sum, atom) => [sum[0] + projected[atom][0] / piece.length, sum[1] + projected[atom][1] / piece.length], [0, 0]);
        const own = centre(piece);
        for (const atom of piece) {
            const [a, b] = [layout.points[atom][0] - own[0], layout.points[atom][1] - own[1]];
            placed[atom] = turn ? [turn.matrix[0][0] * a + turn.matrix[0][1] * b + aim[0], turn.matrix[1][0] * a + turn.matrix[1][1] * b + aim[1]]
                : [a + aim[0], b + aim[1]];
        }
    }
    // Larger molecules stay; each smaller one moves off any it overlaps.
    pieces.sort((a, b) => b.length - a.length);
    pieces.forEach((piece, number) => {
        const others = pieces.slice(0, number).flat();
        for (let step = 0; step < 200 && others.length; step++) {
            let nearest = Infinity;
            for (const atom of piece) for (const other of others) {
                nearest = Math.min(nearest, Math.hypot(placed[atom][0] - placed[other][0], placed[atom][1] - placed[other][1]));
            }
            if (nearest >= 2.25) break;
            const [from, to] = [centre(others), centre(piece)];
            const length = Math.hypot(to[0] - from[0], to[1] - from[1]);
            const [dx, dy] = length > 1e-9 ? [(to[0] - from[0]) / length, (to[1] - from[1]) / length] : [1, 0];
            for (const atom of piece) { placed[atom][0] += 0.25 * dx; placed[atom][1] += 0.25 * dy; }
        }
    });
    return placed;
}

// A molfile with its 2D coordinates replaced by the given points, V2000 or V3000, everything else unchanged.
function placedBlock(block, points) {
    const lines = block.split('\n');
    if (lines[3].includes('V3000')) {
        let atoms = false, index = 0;
        return lines.map(line => {
            if (/^M {2}V30 BEGIN ATOM/.test(line)) atoms = true;
            else if (/^M {2}V30 END ATOM/.test(line)) atoms = false;
            else if (atoms) {
                const words = line.split(' ');
                // 'M', '', 'V30', index, element, x, y, ...
                const at = words.indexOf('V30') + 3;
                const [x, y] = points[index++];
                words[at] = x.toFixed(6); words[at + 1] = y.toFixed(6);
                return words.join(' ');
            }
            return line;
        }).join('\n');
    }
    const count = parseInt(lines[3].slice(0, 3));
    for (let index = 4; index < 4 + count; index++) {
        const [x, y] = points[index - 4];
        lines[index] = x.toFixed(4).padStart(10) + y.toFixed(4).padStart(10) + lines[index].slice(20);
    }
    return lines.join('\n');
}

// A map in the drawing's own frame: around each atom a Gaussian of RDKit's width for a similarity map
// (`settings.width` layout units, to the drawing's scale), evaluated on a grid over the atoms and three widths past
// them. Each point holds the atoms' coverage, the sum of their Gaussians, and the value they give it, their values
// averaged with those Gaussians as weights: at an atom its own value, between atoms a blend, never a sum of
// neighbours, so the map's colour at an atom is the colour the viewer gives that atom. It also holds RDKit's own
// similarity-map field, each atom's value times its Gaussian summed, which the contour lines follow as RDKit's do: it
// equals an atom's value at the atom, its neighbours adding under half a percent, and falls to zero away from them.
// Returns the grid's corner and step in drawing pixels, its size, and the coverage, value and field of each point, row
// by row.
function fieldGrid(places, bond, weights, settings) {
    const sigma = settings.width * bond / 1.5, reach = 3.2 * sigma, step = sigma / 4;
    const xs = places.map(([x]) => x), ys = places.map(([, y]) => y);
    const left = Math.min(...xs) - reach, top = Math.min(...ys) - reach;
    const columns = Math.ceil((Math.max(...xs) + reach - left) / step) + 1;
    const rows = Math.ceil((Math.max(...ys) + reach - top) / step) + 1;
    const cover = new Float64Array(columns * rows), sums = new Float64Array(columns * rows), spread = 2 * sigma * sigma;
    places.forEach(([x, y], atom) => {
        const weight = weights[atom];
        if (!Number.isFinite(weight)) return;
        // Each atom reaches only the cells within its three widths.
        const [c0, c1] = [Math.max(0, Math.floor((x - reach - left) / step)), Math.min(columns - 1, Math.ceil((x + reach - left) / step))];
        const [r0, r1] = [Math.max(0, Math.floor((y - reach - top) / step)), Math.min(rows - 1, Math.ceil((y + reach - top) / step))];
        for (let row = r0; row <= r1; row++) {
            const dy = top + row * step - y;
            for (let column = c0; column <= c1; column++) {
                const dx = left + column * step - x, gauss = Math.exp(-(dx * dx + dy * dy) / spread);
                cover[row * columns + column] += gauss;
                sums[row * columns + column] += weight * gauss;
            }
        }
    });
    const values = sums.map((sum, index) => cover[index] > 0 ? sum / cover[index] : 0);
    return {left, top, step, columns, rows, cover, values, field:sums};
}

// RGB of a #rrggbb colour, 0 to 255.
function fieldRGB(hex) {
    return [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16));
}

// The colour the viewer gives a value: the value's place between the ends of `range`, clipped to them, on the colours
// spaced evenly from the lower to the upper end, as molstarview.validation.color_atoms colours the atoms in 3D.
function scaleColor(value, range, colors) {
    const stops = colors.map(fieldRGB);
    const position = Math.max(0, Math.min(1, (value - range[0]) / (range[1] - range[0]))) * (stops.length - 1);
    const below = Math.min(Math.floor(position), stops.length - 2), part = position - below;
    return stops[below].map((channel, i) => channel + part * (stops[below + 1][i] - channel));
}

// The map drawn under a drawing of `size` pixels: a canvas laid over the drawing's frame, reaching past it where the
// map does. Each point takes the viewer's colour of its value (scaleColor), opaque where the atoms cover it and fading
// into the page past them, so each atom shows exactly its 3D colour whatever the scale's colours or range.
function depictionField(places, bond, weights, range, colors, settings, size) {
    const grid = fieldGrid(places, bond, weights, settings);
    // The values as an image of one pixel per grid point, drawn smoothed onto a canvas of four pixels per drawing pixel.
    const coarse = document.createElement('canvas');
    coarse.width = grid.columns; coarse.height = grid.rows;
    const image = coarse.getContext('2d').createImageData(grid.columns, grid.rows);
    grid.values.forEach((value, index) => {
        const [r, g, b] = scaleColor(value, range, colors);
        image.data.set([Math.round(r), Math.round(g), Math.round(b), Math.round(255 * Math.min(1, grid.cover[index]))], 4 * index);
    });
    coarse.getContext('2d').putImageData(image, 0, 0);
    const scale = 4, canvas = document.createElement('canvas');
    const [width, height] = [(grid.columns - 1) * grid.step, (grid.rows - 1) * grid.step];
    canvas.width = Math.ceil(width * scale); canvas.height = Math.ceil(height * scale);
    canvas.className = 'molstarview-depiction-field';
    Object.assign(canvas.style, {left:`${grid.left / size[0] * 100}%`, top:`${grid.top / size[1] * 100}%`,
        width:`${width / size[0] * 100}%`, height:`${height / size[1] * 100}%`});
    const context = canvas.getContext('2d');
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = 'high';
    context.drawImage(coarse, 0, 0, canvas.width, canvas.height);
    if (settings.contours) {
        // Contour lines at every round value inside the scale (depictionContours), each marked by a tick on the scale.
        const levels = depictionContours(range);
        // The molecule's own frame on the drawing, so each line's dashes start at the same place on the molecule
        // whatever its turn.
        const frame = moleculeFrame(places);
        context.lineWidth = settings['contour-width'] * scale;
        context.strokeStyle = 'rgba(0, 0, 0, 0.45)';
        for (const level of levels.filter(value => value > range[0] && value < range[1])) {
            // Every line dashed, as contour maps are traditionally drawn, a negative level's finer than a positive one's.
            context.setLineDash(settings[level < 0 ? 'contour-dash-negative' : 'contour-dash'].map(length => length * scale));
            // Each line is stroked as one path, its segments joined, so the dashes run along it instead of starting
            // again at every grid cell.
            context.beginPath();
            for (const line of contourLines(fieldContour(grid, level)).map(line => anchoredLine(line, frame))) {
                line.forEach(([x, y], index) => context[index ? 'lineTo' : 'moveTo']((x - grid.left) * scale, (y - grid.top) * scale));
            }
            context.stroke();
        }
    }
    return canvas;
}

// Two directions fixed to the molecule on its drawing, which turn and mirror with it: `along`, from the atoms' centre
// towards the first atom away from it, and `across`, the part of the direction to the next such atom square to it.
// Null for fewer than two atoms apart from the centre.
function moleculeFrame(places) {
    const centre = places.reduce(([x, y], [u, v]) => [x + u / places.length, y + v / places.length], [0, 0]);
    const offsets = places.map(([x, y]) => [x - centre[0], y - centre[1]]);
    const size = ([x, y]) => Math.hypot(x, y), scale = Math.max(...offsets.map(size)) || 1;
    const first = offsets.find(offset => size(offset) > 1e-3 * scale);
    if (!first) return null;
    const along = first.map(value => value / size(first));
    for (const offset of offsets) {
        const dot = offset[0] * along[0] + offset[1] * along[1];
        const square = [offset[0] - dot * along[0], offset[1] - dot * along[1]];
        if (size(square) > 1e-3 * scale) return {centre, along, across:square.map(value => value / size(square))};
    }
    // A straight molecule: across is the perpendicular, which still turns with it but cannot tell a mirror.
    return {centre, along, across:[-along[1], along[0]]};
}

// A contour line started and run in the molecule's own frame, so its dashes keep their place on the molecule as the
// drawing turns: a ring starts exactly where it crosses the ray from its own centre along `frame.along`, a point
// interpolated on the line rather than one of its traced vertices, and runs on towards `frame.across`; an open line
// starts at its end furthest along. The line's shape is unchanged.
function anchoredLine(line, frame) {
    if (!frame || line.length < 3) return line;
    const reach = ([x, y]) => (x - frame.centre[0]) * frame.along[0] + (y - frame.centre[1]) * frame.along[1];
    const closed = Math.hypot(line[0][0] - line[line.length - 1][0], line[0][1] - line[line.length - 1][1]) < 1e-3;
    if (!closed) return reach(line[0]) >= reach(line[line.length - 1]) ? line : [...line].reverse();
    const ring = line.slice(0, -1);
    const centre = ring.reduce(([x, y], [u, v]) => [x + u / ring.length, y + v / ring.length], [0, 0]);
    const [dx, dy] = frame.along;
    // The ray centre + r (dx, dy), r > 0, meets each edge a + t (b - a), 0 <= t < 1, where the cross products agree.
    let best = null;
    ring.forEach((a, index) => {
        const b = ring[(index + 1) % ring.length], [ex, ey] = [b[0] - a[0], b[1] - a[1]];
        const denominator = dx * ey - dy * ex;
        if (Math.abs(denominator) < 1e-12) return;
        const [ax, ay] = [a[0] - centre[0], a[1] - centre[1]];
        const r = (ax * ey - ay * ex) / denominator, s = (ax * dy - ay * dx) / denominator;
        if (r > 0 && s >= 0 && s < 1 && (!best || r > best.r)) best = {r, index, point:[a[0] + s * ex, a[1] + s * ey]};
    });
    if (!best) return line;
    // From the crossing round the ring and back to it, in the direction that heads towards `across`.
    const after = [...ring.slice(best.index + 1), ...ring.slice(0, best.index + 1)];
    let turned = [best.point, ...after, best.point];
    const side = ([x, y]) => (x - best.point[0]) * frame.across[0] + (y - best.point[1]) * frame.across[1];
    if (side(turned[1]) < side(turned[turned.length - 2])) turned = [...turned].reverse();
    return turned;
}

// The segments of a contour joined into lines: chains of segments that meet end to end, a closed ring returning to its
// first point. Ends meet when they agree to a thousandth of a pixel, as the two cells beside a grid edge place its
// crossing alike up to rounding. Returns each line as its points in order.
function contourLines(segments) {
    const key = ([x, y]) => `${Math.round(x * 1000)},${Math.round(y * 1000)}`;
    const ends = new Map();
    segments.forEach((segment, index) => segment.forEach(point => {
        const name = key(point);
        if (!ends.has(name)) ends.set(name, []);
        ends.get(name).push(index);
    }));
    const used = new Set(), lines = [];
    // From a point, the unused segment there and its other end.
    const next = point => {
        const index = (ends.get(key(point)) || []).find(other => !used.has(other));
        if (index === undefined) return null;
        used.add(index);
        const [a, b] = segments[index];
        return key(a) === key(point) ? b : a;
    };
    // Open lines start at an end only one segment reaches, then rings anywhere.
    const order = [...segments.keys()].sort((a, b) => Math.min(...segments[a].map(p => ends.get(key(p)).length))
        - Math.min(...segments[b].map(p => ends.get(key(p)).length)));
    for (const start of order) {
        if (used.has(start)) continue;
        used.add(start);
        let [first, last] = segments[start];
        if (ends.get(key(last)).length === 1) [first, last] = [last, first];
        const line = [first, last];
        for (let point = next(last); point; point = next(point)) line.push(point);
        lines.push(line);
    }
    return lines;
}

// The segments of the contour of a map's similarity-map field at `level`, by marching squares on its grid with each
// crossing placed by linear interpolation along the cell's edge, in drawing pixels: a ring around each atom whose value
// passes the level, as RDKit's similarity maps draw their contour lines; the caller dashes them. A saddle cell is split by its centre's value.
function fieldContour(grid, level) {
    const segments = [], {columns, rows, step, left, top} = grid, values = grid.field;
    const point = (row, column) => [left + column * step, top + row * step];
    const cross = (a, b, va, vb) => {
        const t = (level - va) / (vb - va);
        return [a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])];
    };
    for (let row = 0; row < rows - 1; row++) {
        for (let column = 0; column < columns - 1; column++) {
            const indices = [row * columns + column, row * columns + column + 1, (row + 1) * columns + column + 1, (row + 1) * columns + column];
            const v = indices.map(index => values[index]);
            const corners = [point(row, column), point(row, column + 1), point(row + 1, column + 1), point(row + 1, column)];
            // The crossings on the four edges, top, right, bottom, left, where the level lies between their ends.
            const edges = [0, 1, 2, 3].map(edge => {
                const [a, b] = [edge, (edge + 1) % 4];
                return (v[a] < level) !== (v[b] < level) ? cross(corners[a], corners[b], v[a], v[b]) : null;
            });
            const found = [0, 1, 2, 3].filter(edge => edges[edge]);
            if (found.length === 2) segments.push([edges[found[0]], edges[found[1]]]);
            else if (found.length === 4) {
                // A saddle: the centre's side of the level decides which corners the lines cut off.
                const centre = (v[0] + v[1] + v[2] + v[3]) / 4;
                const pairs = (centre < level) === (v[0] < level) ? [[0, 1], [2, 3]] : [[3, 0], [1, 2]];
                for (const [a, b] of pairs) segments.push([edges[a], edges[b]]);
            }
        }
    }
    return segments;
}

// Values a gradient legend labels between `low` and `high`, as Vega labels a scale: about `count` round steps of one,
// two or five times a power of ten, d3's rule, so the 2D map's scale reads as the pages' Altair legends do. Returns the
// values and the decimals that write the step.
function depictionTicks(low, high, count = 5) {
    const rough = (high - low) / count;
    if (!(rough > 0)) return {values:[low], decimals:0};
    const power = Math.floor(Math.log10(rough)), error = rough / 10 ** power;
    const step = (error >= Math.sqrt(50) ? 10 : error >= Math.sqrt(10) ? 5 : error >= Math.sqrt(2) ? 2 : 1) * 10 ** power;
    const values = [];
    for (let k = Math.ceil(low / step - 1e-9); k * step <= high + 1e-9 * step; k++) values.push(k * step);
    return {values, decimals:Math.max(0, -Math.floor(Math.log10(step) + 1e-9))};
}

// The 2D map's colour scale: its bar's length in pixels, the font of its labels, as the pages' Altair legends set them,
// and the least gap between two labels.
const DEPICTION_SCALE = {length:200, font:'14px system-ui', gap:6};

// The width in pixels of a scale label in the scale's font, measured on a canvas as the page draws it; an estimate of
// eight pixels a character where no canvas can measure, as outside a browser.
function depictionTextWidth(text) {
    try {
        depictionTextWidth.context ||= document.createElement('canvas').getContext('2d');
        depictionTextWidth.context.font = DEPICTION_SCALE.font;
        return depictionTextWidth.context.measureText(text).width;
    } catch {
        return 8 * text.length;
    }
}

// A round value written as the scale writes it between its ends: with the step's decimals and d3's minus sign.
function depictionRound(value, decimals) {
    return (Math.abs(value) < 1e-12 ? 0 : value).toFixed(decimals).replace('-', '−');
}

// The levels of a 2D map's contour lines: every round value of depictionTicks strictly inside the scale's range, so a
// map keeps its lines however few labels fit on its scale, which marks each with a tick. Zero is no level: the field
// falls to zero everywhere away from the atoms, so its zero contour is only noise.
function depictionContours(range) {
    return Array.from(depictionTicks(range[0], range[1]).values)
        .filter(value => value > range[0] && value < range[1] && Math.abs(value) > 1e-12);
}

// The round values a 2D map's scale labels between its exact ends: each value of
// depictionTicks whose label, measured in the scale's font, fits on the bar clear of the end labels, flush with the
// bar's ends, and of the labels already kept by DEPICTION_SCALE.gap, zero first, as Vega drops overlapping legend labels.
function depictionLevels(range) {
    const [low, high] = range, {values, decimals} = depictionTicks(low, high);
    const {length, gap} = DEPICTION_SCALE;
    const taken = [[0, depictionTextWidth(depictionEnd(low)) + gap],
        [length - depictionTextWidth(depictionEnd(high)) - gap, length]];
    const kept = [];
    for (const value of [...values].sort((a, b) => (Math.abs(a) > 1e-12) - (Math.abs(b) > 1e-12))) {
        const x = (value - low) / (high - low) * length, half = depictionTextWidth(depictionRound(value, decimals)) / 2;
        const span = [x - half - gap, x + half + gap];
        if (x - half < 0 || x + half > length || taken.some(([a, b]) => span[0] < b && span[1] > a)) continue;
        taken.push(span);
        kept.push(value);
    }
    return {values:kept.sort((a, b) => a - b), decimals};
}

// A scale end written as the 3D view's colour scale writes it, to three significant figures with a true minus sign, so
// the two scales show the same limits in the same digits.
function depictionEnd(value) {
    return Math.abs(value) < 1e-12 ? '0' : Number(value.toPrecision(3)).toString().replace('-', '\u2212');
}

// The colour scale of a 2D map, drawn as Vega-Lite draws a gradient legend at the bottom of the pages' Altair charts:
// the quantity above in bold, a bar 16 pixels high as long as DEPICTION_SCALE sets, its labels below, the end ones flush with the bar,
// in the charts' font and 14-pixel text. The bar is the map's own scale, the viewer's colours spaced evenly over its
// range, the same the 3D view colours by, and its ends are labelled with the 3D scale's exact limits; each contour
// level has a tick under the bar, and its round value is written where it fits. `label` is the quantity and unit,
// $...$ LaTeX allowed.
function depictionScale(label, range, colors) {
    const [low, high] = range;
    const scale = document.createElement('div');
    scale.className = 'molstarview-depiction-scale';
    const title = document.createElement('div');
    title.className = 'molstarview-depiction-scale-title';
    title.innerHTML = richHTML(label || '');
    const bar = document.createElement('div');
    bar.className = 'molstarview-depiction-scale-bar';
    bar.style.background = `linear-gradient(to right, ${colors.map((color, i) => `${color} ${(100 * i / (colors.length - 1)).toFixed(3)}%`).join(', ')})`;
    const labels = document.createElement('div');
    labels.className = 'molstarview-depiction-scale-labels';
    const {values, decimals} = depictionLevels(range);
    // The exact ends, then the round values that fit between them.
    const marks = [[low, depictionEnd(low)], ...values.map(value => [value, depictionRound(value, decimals)]),
        [high, depictionEnd(high)]];
    bar.style.width = labels.style.width = `${DEPICTION_SCALE.length}px`;
    for (const [value, written] of marks) {
        const fraction = (value - low) / (high - low);
        const text = document.createElement('span');
        text.textContent = written;
        text.style.left = `${100 * fraction}%`;
        text.style.transform = fraction < 1e-9 ? 'none' : fraction > 1 - 1e-9 ? 'translateX(-100%)' : 'translateX(-50%)';
        labels.append(text);
    }
    // A tick under the bar at each contour level, so every line of the map has its place on the scale.
    const ticks = document.createElement('div');
    ticks.className = 'molstarview-depiction-scale-ticks';
    ticks.style.width = `${DEPICTION_SCALE.length}px`;
    for (const level of depictionContours(range)) {
        const tick = document.createElement('span');
        tick.style.left = `${100 * (level - low) / (high - low)}%`;
        ticks.append(tick);
    }
    scale.append(...(label ? [title] : []), bar, ticks, labels);
    return scale;
}

// The depicted atom nearest a point of the drawing, within half a bond, or -1.
function depictionNearest(found, x, y) {
    let best = -1, reach = found.bond / 2;
    found.places.forEach(([u, v], index) => {
        const gap = Math.hypot(u - x, v - y);
        if (gap < reach) { reach = gap; best = index; }
    });
    return best;
}

// The depicted atom that stands for a viewer atom: the atom itself, or the heavy atom a hidden hydrogen is counted on.
function depictedAtom(data, atom) {
    const index = data.atoms.indexOf(atom);
    if (index >= 0) return index;
    const counted = (data.hydrogens || []).find(([light]) => light === atom);
    return counted ? data.atoms.indexOf(counted[1]) : -1;
}

// The panel's own words, in the page's language where it has them, else English.
const DEPICTION_TEXT = {
    en: {'single-bonds':'RDKit could not assign bond orders to this structure, so all of its bonds are drawn single.',
        'browser-bonds':'Bond orders are assigned by the Python RDKit, which this page does not have, so all bonds are drawn single.'},
    ja: {'single-bonds':'RDKit がこの構造の結合次数を決められなかったため、結合はすべて単結合で描いています。',
        'browser-bonds':'結合次数は Python の RDKit が決めますが、このページにはないため、結合はすべて単結合で描いています。'},
};
function depictionText(key) {
    const language = (document.documentElement.lang || 'en').slice(0, 2);
    return (DEPICTION_TEXT[language] || DEPICTION_TEXT.en)[key];
}

// A yellow warning sign whose explanation shows in the page's Quarto popover on hover, or as its title without one.
function depictionWarning(text) {
    const sign = document.createElement('span');
    sign.className = 'molstarview-depiction-item molstarview-depiction-warning';
    sign.setAttribute('role', 'img');
    sign.setAttribute('aria-label', text);
    sign.innerHTML = '<svg viewBox="0 0 512 512" width="14" height="14" fill="#e0a800" aria-hidden="true"><path d="M256 32c14.2 0 27.3 '
        + '7.5 34.5 19.8l216 368c7.3 12.4 7.3 27.7 .2 40.1S486.3 480 472 480L40 480c-14.3 0-27.6-7.7-34.7-20.1s-7-27.8 .2-40.1l216-'
        + '368C228.7 39.5 241.8 32 256 32zm0 128c-13.3 0-24 10.7-24 24l0 112c0 13.3 10.7 24 24 24s24-10.7 24-24l0-112c0-13.3-10.7-'
        + '24-24-24zm32 224a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z"/></svg>';
    if (globalThis.tippy) {
        globalThis.tippy(sign, {content:text, delay:100, arrow:false, theme:'quarto', placement:'bottom',
            appendTo:() => document.body});
    } else {
        sign.title = text;
    }
    return sign;
}

// The panel below one viewer. `frame()` gives the zero-based model index, `snapshot()` the shown snapshot, and
// `watch(listener)` calls the listener on every change of either, returning its disposer. `hover` links the panel to
// the 3D view: `hover.listen(listener)` calls the listener with the zero-based viewer atom under the pointer in 3D, or
// null, returning its disposer, and `hover.show(atom)` highlights a viewer atom in 3D, or clears it for null; the atom
// hovered in either view is ringed in the drawing. `view` lets the drawing face the 3D view as it turns:
// `view.projected(atoms)` gives each viewer atom's place on the screen, x right and y up, and `view.listen(listener)`
// calls the listener whenever the camera moves, returning its disposer. A new drawing is prepared
// off screen, a map's image decoded first, and swapped in within one animation frame, so changing frames or
// snapshots never shows an empty or half-drawn panel; the panel's height follows the drawing shown.
function installDepiction({model, el, frame, snapshot, watch, hover, view}) {
    const data = model.get('depiction');
    if (!data || !data.molblocks || !data.molblocks.length) return () => {};
    const panel = document.createElement('div');
    panel.className = 'molstarview-depiction';
    const picture = document.createElement('div');
    picture.className = 'molstarview-depiction-picture';
    const legend = document.createElement('div');
    legend.className = 'molstarview-depiction-legend';
    // The colour scale of the map shown, if any, between the drawing and the legend of its marks.
    const scaleBox = document.createElement('div');
    panel.append(picture, scaleBox, legend);
    el.append(panel);
    // The drawing a map is shown on: the depiction's own, or, for a map that draws some hydrogens besides, the variant
    // Python built with them (molstarview.depiction), with the depiction's other keys; by its number, 0 for the own.
    const variantOf = set => {
        const number = data.map_variants?.[set] || 0;
        return {number, look:number ? {...data, ...data.variants[number - 1]} : data};
    };
    // RDKit.js molecules and parsed layouts, by variant, drawing and turn ('1/2:30m'), and the unturned layouts by variant
    // and drawing.
    const mols = {}, layouts = {};
    // Per variant and drawing, its pixels per layout unit as last placed, which the next turn of it keeps.
    const scaleOf = {};
    // Per variant, the molfiles drawn; those of a depiction built without RDKit are replaced by their RDKit.js layout.
    const blocksOf = {};
    let disposed = false, shown = null, rdkit = null, ticket = 0;
    // The shown drawing's atom places, the depiction or variant it draws, and the viewer atom ringed in it.
    let found = null, current = data, ringed = null;
    const ring = () => {
        const svg = picture.querySelector('svg');
        svg?.querySelector('.molstarview-depiction-hover')?.remove();
        const atom = ringed === null || !found ? -1 : depictedAtom(current, ringed);
        if (!svg || atom < 0) return;
        const [x, y] = found.places[atom];
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('class', 'molstarview-depiction-hover');
        circle.setAttribute('cx', x); circle.setAttribute('cy', y); circle.setAttribute('r', 0.4 * found.bond);
        circle.setAttribute('stroke-width', 0.08 * found.bond);
        svg.append(circle);
    };
    const stopHover = hover ? hover.listen(atom => { ringed = atom; ring(); }) : () => {};
    // The atom under the pointer in the drawing is highlighted in 3D and ringed here.
    const point = event => {
        const svg = picture.querySelector('svg');
        if (!svg || !found || !hover) return;
        const matrix = svg.getScreenCTM()?.inverse();
        if (!matrix) return;
        const spot = new DOMPoint(event.clientX, event.clientY).matrixTransform(matrix);
        const atom = depictionNearest(found, spot.x, spot.y);
        const target = atom < 0 ? null : current.atoms[atom];
        if (target === ringed) return;
        ringed = target;
        hover.show(target);
        ring();
    };
    const leave = () => { if (ringed !== null && hover) { ringed = null; hover.show(null); ring(); } };
    picture.addEventListener('pointermove', point);
    picture.addEventListener('pointerleave', leave);
    // Legend entries: a swatch, the label and the value at the shown frame.
    const legendItems = (look, index) => {
        const items = depictionLegend(look, index).map(entry => {
            const item = document.createElement('span');
            item.className = 'molstarview-depiction-item';
            const swatch = document.createElement('span');
            swatch.className = 'molstarview-depiction-swatch';
            swatch.style.background = entry.color;
            const text = document.createElement('span');
            text.innerHTML = richHTML(entry.label);
            item.append(swatch, text);
            return item;
        });
        // A frame whose bond orders RDKit could not assign, as for an open-shell structure, shows single bonds, and
        // the legend a warning sign that explains it on hover.
        const drawing = look.frames.length ? look.frames[Math.min(index, look.frames.length - 1)] : 0;
        if (look.orders && !look.orders[drawing]) {
            items.push(depictionWarning(depictionText(look.layout === 'browser' ? 'browser-bonds' : 'single-bonds')));
        }
        return items;
    };
    const draw = async () => {
        if (disposed) return;
        const index = frame();
        const maps = data.maps || [];
        const set = maps.length > 1 ? snapshot() : 0;
        const {number, look} = maps.length ? variantOf(set) : {number:0, look:data};
        const drawing = look.frames.length ? look.frames[Math.min(index, look.frames.length - 1)] : 0;
        const blocks = blocksOf[number] ||= [...look.molblocks];
        const base = `${number}/${drawing}`;
        // A depiction Python built without RDKit, as in the calculation viewer, has each molfile laid out here once,
        // by RDKit.js's own 2D layout, before anything is drawn from it.
        if (look.layout === 'browser' && !layouts[base]) {
            if (!rdkit) return;
            const mol = rdkit.get_mol(blocks[drawing], JSON.stringify({removeHs:false, sanitize:false}));
            try { if (mol.set_new_coords()) blocks[drawing] = mol.get_molblock(); } finally { mol.delete(); }
        }
        layouts[base] ||= molblockLayout(blocks[drawing]);
        // The drawing as the view now shows the molecule; until the camera is known, or for a molecule the view cannot
        // orient, Python's layout, which faces the initial view.
        const turn = view ? viewLayout(layouts[base], view.projected(look.atoms) || []) : null;
        // The drawing changes only when an atom moves by a tenth of a bond or more.
        const facing = turn ? turn.map(([x, y]) => `${Math.round(x * 10)},${Math.round(y * 10)}`).join(' ') : '';
        const key = [number, drawing, index, set, maps[set] ? 'map' : snapshot(), facing].join(':');
        if (key === shown) return;
        const mine = ++ticket;
        if (!rdkit) return;
        const which = `${base}:${facing}`;
        if (!mols[which]) {
            // One turned molecule per drawing is kept: the one shown.
            for (const old of Object.keys(mols)) if (old.startsWith(`${base}:`)) { mols[old].delete(); delete mols[old]; }
            const block = turn ? placedBlock(blocks[drawing], turn) : blocks[drawing];
            mols[which] = rdkit.get_mol(block, JSON.stringify({removeHs:false, sanitize:false}));
            layouts[which] = molblockLayout(block);
        }
        const weights = maps[set]?.[drawing];
        const shares = (model.get('snapshot_atoms') || [])[snapshot()];
        const colors = weights ? [] : shares?.colors || model.get('atom_colors') || [];
        // RDKit sizes the canvas to the drawing as it is turned, at its own scale, the one Python's natural size and
        // the site's figures use, so the molecule keeps its size at every turn.
        const details = depictionDetails(look, drawing, colors, -1, -1);
        const text = mols[which].get_svg_with_highlights(JSON.stringify(details));
        // Python's places are those of its own turn, so they help only a drawing shown with that turn.
        const places = depictionPlaces(text, layouts[which], null, scaleOf[base])
            || (turn ? null : depictionPlaces(text, layouts[which], depictionDrawn(look, drawing)?.places, scaleOf[base]));
        if (places) scaleOf[base] = places.bond / 1.5;
        // The drawing's canvas in pixels, as RDKit sized it.
        const size = (text.match(/viewBox=["']0 0 ([\d.]+) ([\d.]+)["']/) || [0, 1, 1]).slice(1).map(Number);
        const next = document.createElement('div');
        next.className = 'molstarview-depiction-drawing';
        next.innerHTML = text;
        // A quantity per atom, the viewer's atom values or the shown snapshot's shares, is RDKit's similarity map,
        // drawn here under the structure at the atoms' exact places, whatever the turn.
        if (weights && places) {
            next.prepend(depictionField(places.places, places.bond, weights, data.map_scales[set], data.map_colors, data.map, size));
        }
        // Only the latest request is shown, whichever finishes preparing first.
        if (disposed || mine !== ticket) return;
        const items = legendItems(look, index);
        const scale = weights ? [depictionScale(data.map_labels?.[set] || '', data.map_scales[set], data.map_colors)] : [];
        requestAnimationFrame(() => {
            if (disposed || mine !== ticket) return;
            // The new drawing is complete, so it replaces the old one within this frame without an empty moment; the
            // panel then takes the new drawing's own height, shrinking again when a turn makes the drawing shorter.
            picture.replaceChildren(next);
            scaleBox.replaceChildren(...scale);
            legend.replaceChildren(...items);
            shown = key;
            found = places;
            current = look;
            ring();
        });
    };
    const stop = watch(() => { void draw(); });
    // The camera moves many times a second while dragged; the drawing follows at most once per animation frame.
    let pending = false;
    const stopView = view ? view.listen(() => {
        if (pending) return;
        pending = true;
        requestAnimationFrame(() => { pending = false; void draw(); });
    }) : () => {};
    loadRDKit().then(module => { rdkit = module; void draw(); }, error => console.error('Structure drawing:', error));
    return () => {
        disposed = true;
        stop();
        stopView();
        stopHover();
        picture.removeEventListener('pointermove', point);
        picture.removeEventListener('pointerleave', leave);
        Object.values(mols).forEach(mol => mol?.delete());
        panel.remove();
    };
}

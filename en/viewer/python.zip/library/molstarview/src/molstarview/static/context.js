// One WebGL context for every viewer of a page, its render targets given storage only when drawn to.

// Molstar allocates every render target of every pass when a viewer starts, illumination, depth peeling, bloom
// and the rest included, though a viewer draws with only a few: hundreds of megabytes of GPU memory per viewer at
// a Retina pixel ratio. In every WebGL context of the page, a texture or renderbuffer given storage without data
// receives it only when a draw, clear, blit, copy or read first uses it, as a framebuffer attachment or a bound
function installLazyTargets() {
    if (globalThis.molstarLazyTargets) return;
    globalThis.molstarLazyTargets = true;
    const getContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (type, ...rest) {
        const gl = getContext.call(this, type, ...rest);
        if (gl && /^(webgl2?|experimental-webgl)$/.test(type) && !gl.lazyTargets) deferStorage(gl);
        return gl;
    };
}

function deferStorage(gl) {
    gl.lazyTargets = true;
    const FRAMEBUFFER = gl.FRAMEBUFFER, DRAW = 0x8CA9, READ = 0x8CA8;
    // Deferred storage calls by object, the textures bound to each unit and target, and each framebuffer's attachments.
    const pending = new Map(), units = [{}], attachments = new Map();
    let unit = 0, renderbuffer = null, draw = null, read = null;
    const call = (name, args) => gl.constructor.prototype[name].apply(gl, args);
    const own = (name, wrapper) => { const original = gl[name].bind(gl); gl[name] = (...args) => wrapper(original, ...args); };
    function realize(object) {
        const deferred = pending.get(object);
        if (!deferred) return;
        pending.delete(object);
        if (deferred.texture) {
            const previous = units[unit][deferred.target] ?? null;
            call('bindTexture', [deferred.target, object]);
            call(deferred.name, deferred.args);
            call('bindTexture', [deferred.target, previous]);
        } else {
            call('bindRenderbuffer', [gl.RENDERBUFFER, object]);
            call(deferred.name, deferred.args);
            call('bindRenderbuffer', [gl.RENDERBUFFER, renderbuffer]);
        }
    }
    const realizeFramebuffer = framebuffer => { for (const object of attachments.get(framebuffer)?.values() ?? []) realize(object); };
    const realizeBound = () => { for (const targets of units) if (targets) for (const object of Object.values(targets)) if (object) realize(object); };
    const use = (reads, draws) => () => { if (!pending.size) return; if (draws) { realizeFramebuffer(draw); realizeBound(); } if (reads) realizeFramebuffer(read); };
    own('activeTexture', (original, texture) => { unit = texture - gl.TEXTURE0; units[unit] ??= {}; original(texture); });
    own('bindTexture', (original, target, texture) => { units[unit][target] = texture; original(target, texture); });
    own('bindRenderbuffer', (original, target, object) => { renderbuffer = object; original(target, object); });
    own('bindFramebuffer', (original, target, framebuffer) => {
        if (target === FRAMEBUFFER || target === DRAW) draw = framebuffer;
        if (target === FRAMEBUFFER || target === READ) read = framebuffer;
        original(target, framebuffer);
    });
    const attach = (target, attachment, object) => {
        const framebuffer = target === READ ? read : draw;
        if (!framebuffer) return;
        if (!attachments.has(framebuffer)) attachments.set(framebuffer, new Map());
        attachments.get(framebuffer).set(attachment, object);
    };
    own('framebufferTexture2D', (original, target, attachment, textarget, texture, level) => { attach(target, attachment, texture); original(target, attachment, textarget, texture, level); });
    own('framebufferRenderbuffer', (original, target, attachment, rbtarget, object) => { attach(target, attachment, object); original(target, attachment, rbtarget, object); });
    // Storage without data is deferred; uploads of data and any partial update first realize it.
    own('texImage2D', (original, ...args) => {
        const texture = units[unit][args[0] === gl.TEXTURE_2D ? gl.TEXTURE_2D : gl.TEXTURE_CUBE_MAP];
        if (args.length === 9 && args[8] == null && args[0] === gl.TEXTURE_2D && texture && args[1] === 0) {
            // Render targets in 32-bit float hold accumulated colour and blend weights; half floats, which every
            // float-capable GPU blends, hold them at half the memory.
            if (args[2] === 0x8814) args = [args[0], args[1], 0x881A, ...args.slice(3)];
            pending.set(texture, {texture: true, target: gl.TEXTURE_2D, name: 'texImage2D', args});
            return;
        }
        if (texture) pending.delete(texture);
        original(...args);
    });
    for (const name of ['renderbufferStorage', 'renderbufferStorageMultisample']) if (gl[name]) own(name, (original, ...args) => {
        if (renderbuffer) { pending.set(renderbuffer, {texture: false, name, args}); return; }
        original(...args);
    });
    for (const name of ['texSubImage2D', 'copyTexSubImage2D', 'generateMipmap']) own(name, (original, ...args) => {
        const texture = units[unit][args[0]];
        if (texture) realize(texture);
        if (name === 'copyTexSubImage2D') realizeFramebuffer(read);
        original(...args);
    });
    // An attachment still waiting for storage would make its framebuffer incomplete; it will be complete when used.
    own('checkFramebufferStatus', (original, target) => {
        const framebuffer = target === READ ? read : draw;
        for (const object of attachments.get(framebuffer)?.values() ?? []) if (pending.has(object)) return gl.FRAMEBUFFER_COMPLETE;
        return original(target);
    });
    for (const name of ['drawArrays', 'drawElements', 'drawArraysInstanced', 'drawElementsInstanced', 'drawRangeElements', 'clear', 'clearBufferfv', 'clearBufferiv', 'clearBufferuiv', 'clearBufferfi'])
        if (gl[name]) { const before = use(false, true); own(name, (original, ...args) => { before(); return original(...args); }); }
    for (const name of ['readPixels', 'copyTexImage2D']) { const before = use(true, false); own(name, (original, ...args) => { before(); return original(...args); }); }
    if (gl.blitFramebuffer) { const before = use(true, true); own('blitFramebuffer', (original, ...args) => { before(); return original(...args); }); }
    own('deleteTexture', (original, texture) => { pending.delete(texture); original(texture); });
    own('deleteRenderbuffer', (original, object) => { pending.delete(object); original(object); });
}
installLazyTargets();

// All viewers of a page share one WebGL context, its compiled shaders and one set of Molstar's render targets,
// instead of one of each per viewer. Molstar keeps its context factory and input observer private, so the pinned
// build is fetched and patched to expose them; each viewer then gets a context of its own visible 2D canvas and
// input, around the shared WebGL context and passes. Before a viewer draws or picks, the shared canvas takes its
// size; after each draw, the frame is copied onto its canvas.
const MOLSTAR = 'https://cdn.jsdelivr.net/npm/molstar@5.13.1/build/viewer/molstar.js';
function loadMolstar() {
    if (globalThis.molstarNotebookAssets) return globalThis.molstarNotebookAssets;
    const loading = (async () => {
        let source = await (await fetch(MOLSTAR)).text();
        // Literal searches; a pattern opening on an identifier would rescan the 5 MB source at every position.
        const call = source.indexOf(',preventGestures:!0})'), dot = source.lastIndexOf('.fromElement(', call);
        const input = call > 0 && dot > 0 && /[\w$]+$/.exec(source.slice(Math.max(0, dot - 40), dot));
        const factory = source.indexOf('.fromCanvas=') > 0 && /\.fromCanvas=[\w$]+\}\)\(([\w$]+)\|\|=\{\}\);/.exec(source);
        if (input && factory) source = source.replace(factory[0], factory[0]
            + `globalThis.molstarInternals={Canvas3DContext:${factory[1]},InputObserver:${input[0]}};`);
        // Each text label uploads its own copy of the font atlas, sized for 350 glyphs at the highest font quality:
        // 43 MB of GPU memory per label set. Labels here use printable ASCII and the angstrom sign; a glyph beyond the
        // smaller atlas falls back to Molstar's placeholder.
        source = source.replace(/(this\.texture=[\w$]+\()350(\*this\.lineHeight\*this\.maxWidth)/, (match, start, end) => start + '96' + end);
        // Molstar's depth-of-field parameter has a description but no label, so its UI otherwise renders "Dof".
        source = source.replace('description:"DOF"', 'label:"DOF",description:"DOF"');
        const script = document.createElement('script');
        script.src = URL.createObjectURL(new Blob([source], {type:'text/javascript'}));
        await new Promise((resolve, reject) => {
            script.onload = resolve;
            script.onerror = () => reject(new Error('Could not load Molstar'));
            document.head.appendChild(script);
        });
        URL.revokeObjectURL(script.src);
        const internals = globalThis.molstarInternals, Plugin = globalThis.molstar.lib.plugin.PluginContext;
        if (internals) {
            const initContainer = Plugin.prototype._initContainer;
            Plugin.prototype._initContainer = function (options) {
                if (this.container || options?.canvas3dContext) return initContainer.call(this, options);
                const context = sharedContext(this, internals);
                const done = initContainer.call(this, {...options, canvas3dContext:context});
                // Molstar does not place a canvas it is given; its holder fills Molstar's own container.
                if (done) this.container.parent.append(context.holder);
                return done;
            };
        }
        return globalThis.molstar;
    })();
    globalThis.molstarNotebookAssets = loading;
    loading.catch(() => {
        if (globalThis.molstarNotebookAssets === loading) delete globalThis.molstarNotebookAssets;
    });
    return loading;
}

function sharedContext(plugin, {Canvas3DContext, InputObserver}) {
    const shared = globalThis.molstarSharedContext ??= (() => {
        const canvas = document.createElement('canvas'), holder = document.createElement('div');
        // Set the first drawing-buffer size before acquiring WebGL. Resizing a live context can synchronously flush
        // its initial GPU work, which otherwise causes a long stall as the first viewer enters the viewport.
        const initial = globalThis.molstarInitialCanvasSize;
        if (initial?.width > 0 && initial?.height > 0) {
            canvas.width = initial.width;
            canvas.height = initial.height;
        }
        delete globalThis.molstarInitialCanvasSize;
        // Molstar watches the canvas's parent for size changes; the shared canvas sits in a hidden empty holder.
        Object.assign(holder.style, {position:'fixed', width:'0', height:'0', overflow:'hidden', visibility:'hidden'});
        holder.append(canvas);
        document.body.append(holder);
        // Molstar draws into its own targets and smooths edges in post-processing, so the canvas needs no
        // multisampled buffer, and each frame is copied out as soon as it is drawn.
        const context = Canvas3DContext.fromCanvas(canvas, plugin.managers.asset,
            {antialias:false, preserveDrawingBuffer:false, handleResize:() => {}});
        return {canvas, context, owner:null};
    })();
    const base = shared.context, canvas = document.createElement('canvas'), holder = document.createElement('div');
    // Molstar's input observer watches the canvas's parent for size changes, so the canvas has its holder from the start.
    Object.assign(holder.style, {position:'absolute', inset:'0'});
    Object.assign(canvas.style, {display:'block', width:'100%', height:'100%'});
    holder.append(canvas);
    const input = InputObserver.fromElement(canvas, {pixelScale:base.pixelScale, preventGestures:true});
    return {
        canvas, input, webgl:base.webgl, passes:base.passes, attribs:base.attribs, assetManager:base.assetManager,
        contextLost:base.contextLost, contextRestored:base.contextRestored, changed:base.changed,
        get props() { return base.props; }, get pixelScale() { return base.pixelScale; },
        syncPixelScale: () => { base.syncPixelScale(); input.setPixelScale(base.pixelScale); },
        setProps: props => base.setProps(props),
        dispose: () => input.dispose(),
        shared, holder, view:canvas.getContext('2d'),
    };
}

// Route one viewer's drawing and picking through the shared context and copy each frame it draws to its canvas.
function shareCanvas(canvas3d, context) {
    const {shared, view, canvas} = context;
    if (!shared) return;
    const activate = () => {
        shared.owner = canvas3d;
        if (shared.canvas.width === canvas.width && shared.canvas.height === canvas.height) return;
        shared.canvas.width = canvas.width;
        shared.canvas.height = canvas.height;
        canvas3d.handleResize(false);
        // The frame on the viewer's canvas was drawn at the old size; without a new one it would stay, cut off or
        // stretched, until something else redrew the view.
        canvas3d.requestDraw();
    };
    for (const name of ['tick', 'commit', 'identify', 'asyncIdentify']) {
        const original = canvas3d[name];
        canvas3d[name] = (...args) => {
            // Off-screen animation ticks must not resize or claim the shared GPU canvas.
            if (name === 'tick' && context.visible === false) return;
            activate();
            return original(...args);
        };
    }
    // Molstar can redraw only the hover/selection overlay over its last frame. The underlying colour target is shared,
    // so after another viewer drew it belongs to that viewer; force a full draw before applying this viewer's marking.
    const mark = canvas3d.mark;
    canvas3d.mark = (...args) => {
        if (shared.lastRendered && shared.lastRendered !== canvas3d) canvas3d.requestDraw();
        return mark(...args);
    };
    view.globalCompositeOperation = 'copy';
    canvas3d.notifyDidDraw = true;
    canvas3d.didDraw.subscribe(() => {
        if (shared.owner === canvas3d) { view.drawImage(shared.canvas, 0, 0); shared.lastRendered = canvas3d; }
    });
}

// A large view on a high-density display draws four times the pixels of its CSS size or more. While it is being
// turned, moved or zoomed it draws at its CSS size, Molstar's "scaled" resolution, and once still for a moment it
// sharpens again to the display's own, so interaction keeps its frame rate and the resting view stays crisp.
function installAdaptiveResolution(container, plugin) {
    const context = plugin.canvas3dContext, controller = new AbortController();
    // Drawing pixels above which a view is drawn coarser while it moves: about a 1600 px square.
    const budget = 2.5e6;
    let lowered = false, timer = 0;
    const set = mode => {
        context.setProps({resolutionMode:mode});
        context.syncPixelScale();
        plugin.canvas3d.handleResize();
        plugin.canvas3d.requestDraw();
    };
    const start = () => {
        clearTimeout(timer);
        const ratio = window.devicePixelRatio || 1;
        if (lowered || ratio <= 1 || container.clientWidth * container.clientHeight * ratio * ratio <= budget) return;
        lowered = true;
        set('scaled');
    };
    const settle = delay => {
        clearTimeout(timer);
        timer = setTimeout(() => { if (lowered) { lowered = false; set('auto'); } }, delay);
    };
    const onCanvas = event => event.composedPath().some(element => element.tagName === 'CANVAS');
    container.addEventListener('pointerdown', event => { if (onCanvas(event)) start(); }, {capture:true, signal:controller.signal});
    window.addEventListener('pointerup', () => { if (lowered) settle(150); }, {signal:controller.signal});
    window.addEventListener('pointercancel', () => { if (lowered) settle(150); }, {signal:controller.signal});
    container.addEventListener('wheel', event => { if (onCanvas(event)) { start(); settle(250); } },
                               {capture:true, passive:true, signal:controller.signal});
    return () => { clearTimeout(timer); controller.abort(); };
}


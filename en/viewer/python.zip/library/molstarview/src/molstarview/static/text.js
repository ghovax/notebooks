// Text of labels and legends: inline Markdown with LaTeX typeset by the page's KaTeX.
// texture; WebGL zero-fills new storage either way, so drawing is unchanged.
// Inline Markdown (bold, italic, code) with $...$ LaTeX typeset by KaTeX by the page's KaTeX; without KaTeX the
// formulas keep their source, without dollars.
function escapeHTML(text) {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function richHTML(text) {
    const math = globalThis.katex;
    return text.split(/(\$[^$]+\$)/).map(part => {
        if (part.length > 2 && part.startsWith('$') && part.endsWith('$')) {
            return math ? math.renderToString(part.slice(1, -1), {throwOnError:false}) : escapeHTML(part.slice(1, -1));
        }
        return escapeHTML(part).replace(/`([^`]+)`/g, '<code>$1</code>')
            .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/\*([^*]+)\*/g, '<em>$1</em>');
    }).join('');
}


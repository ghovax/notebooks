"""The scalar-field viewer widget: isosurfaces of one field or many, as snapshots, views and dropdown choices."""

import re

import anywidget
import numpy as np
import traitlets
from runflow.checkpoints import ELEMENTS
from runflow.results import ureg, xyz_frames

from molstarview import store
from molstarview.depiction import depiction as depicted
from molstarview.scene import build_scene
from molstarview.surface import VolumeSurface
from molstarview.validation import check_distances, choice_axes, color_atoms
from molstarview.viewer import MolstarViewer


class VolumeViewer(MolstarViewer):
    """Display one scalar surface, or several as native Molstar snapshots, in the native viewport.

    ``surface`` is one ``VolumeSurface`` or a mapping from snapshot titles to surfaces of the
    same molecule. Titles may contain ``$...$`` LaTeX, typeset in the snapshot selector and its list.
    Each snapshot shows its own geometry and surface, and the camera is shared. ``field_name``,
    ``field_symbol`` (LaTeX) and ``field_unit`` (LaTeX) name the field's quantity in hover labels; ``field_name`` may hold
    ``$...$`` LaTeX, and is left empty where the symbol already says it.
    """

    # The views of the field, each with its title, fields (``field`` and ``color_field`` for one surface, ``fields`` and
    # ``color_fields`` for snapshots), level, look and quantity; a toolbar button switches between several.
    views = traitlets.List(traitlets.Dict()).tag(sync=True)

    # The initial view fits the molecule; the field's box sets clipping.
    fit_atoms = traitlets.Bool(True).tag(sync=True)

    # Per snapshot, the colour and hover text of every atom shown by the composition button; empty for no button.
    snapshot_atoms = traitlets.List(traitlets.Dict()).tag(sync=True)

    # Label of the dropdown that chooses among the views.
    view_label = traitlets.Unicode("View").tag(sync=True)

    # The colour scale of those atoms: its range, colours, label and description.
    atom_scale = traitlets.Dict().tag(sync=True)

    # Per snapshot, the colour-scale label and hover symbol of its field, when it differs from the view's; empty for none.
    snapshot_fields = traitlets.List(traitlets.Dict()).tag(sync=True)

    def __init__(
        self,
        surface,
        *,
        color_range=(-1.0, 1.0),
        colors=("#ff0000", "#ffffff", "#0000ff"),
        opacity=0.6,
        height=440,
        distances=(),
        camera_bounds=None,
        color_label="",
        field_name="",
        field_symbol="",
        field_unit="",
        title="",
        alternates=(),
        choices=(),
        atom_shares=None,
        atom_label="",
        atom_colors=("#efedf5", "#9e9ac8", "#3f007d"),
        display_label="Show",
        display_options=("Surfaces", "Surfaces and atom shares", "Atom shares"),
        view_label="View",
        snapshot_fields=None,
        charge=None,
        depiction=True,
    ):
        """Embed a scalar field with optional shared lower/upper clipping bounds in angstrom.

        A coloured surface shows its colour scale in the viewport, from the lower to the upper end of ``color_range``,
        with ``color_label``, the quantity and its unit, above it.

        Args:
            surface: One ``VolumeSurface``, or a mapping from snapshot titles to surfaces of the same molecule, each
                snapshot showing its own geometry and surface under one shared camera. Titles may contain ``$...$``
                LaTeX, typeset in the snapshot selector and its list. With ``choices`` the keys are tuples of one value
                per choice.
            color_range: The values at the lower and upper end of the colour scale.
            colors: Hexadecimal colours of the scale, from its lower to its upper end, at least two.
            opacity: Opacity of the surfaces, above zero and at most one.
            height: Viewer height in pixels.
            distances: Pairs of one-based atom numbers measured in the scene.
            camera_bounds: Lower and upper corners in angstrom that clip the scene, shared by viewers that are compared;
                by default the box of every view's field.
            color_label: The quantity and its unit above the colour scale, ``$...$`` LaTeX allowed. A label carrying a
                ``description``, as page quantities do, offers it from an info button.
            field_name: The name on the first line of a hover label, ``$...$`` LaTeX allowed; empty where the symbol
                already says it.
            field_symbol: The symbol of the field, in LaTeX, before its value in hover labels.
            field_unit: The unit of the field, in LaTeX, after its value in hover labels.
            title: The title of this view, its entry in the View dropdown when there are alternates.
            alternates: Further views of the same molecule, chosen from a View dropdown in the row of the viewer's other
                dropdowns, in place and with
                the camera kept. Each is a mapping of ``title``, ``surface`` (one ``VolumeSurface``, or a mapping with the
                same snapshot titles as ``surface``) and the look and quantity arguments of this view, as
                ``color_field_view`` builds them.
            choices: Pairs of ``(label, {value: text})``, or triples with flags, that replace the snapshot menu by one
                dropdown or field per axis, as in ``MolstarViewer``. ``surface`` then maps a tuple of one value per choice to each snapshot's surface, and
                each alternate maps the same tuples to its own surfaces.
            atom_shares: Per snapshot, in the order of ``surface``, one share per atom, such as its share of the
                snapshot's orbital, one hover text per atom with ``$...$`` LaTeX and optionally the key of its colour
                scale; snapshots with one key share a scale. A toolbar toggle then colours
                the atoms by their shares, from zero to the largest of any snapshot, another hides or shows the
                surfaces, and hovering an atom adds its text.
            atom_label: The quantity and unit above the atoms' colour scale, with its optional ``description``, or a
                mapping of each scale's key to its own.
            atom_colors: Hexadecimal colours of the atoms' scale, from zero to the largest share.
            display_label: The label of the dropdown that chooses what a field with atom shares shows.
            display_options: Its three options, in order: the surfaces, the surfaces with the atoms coloured by their
                shares, and the shares alone.
            view_label: The label of the dropdown that chooses among the views when there are alternates.
            snapshot_fields: Per snapshot, in the order of ``surface``, a pair of the colour-scale label and the hover
                symbol (LaTeX) of its field while it is shown, such as one atom's part of an orbital; the view's own
                label and symbol otherwise.
            charge: Total charge of the molecule, from which the 2D drawing assigns bond orders and formal charges; None
                lets the drawing find the smallest charge that gives a valid structure.
            depiction: Whether to draw the molecule's 2D structure below the viewer, following the shown snapshot with
                its atom shares; see ``molstarview.depiction``.

        Raises:
            ValueError: If choices are given without a mapping of surfaces, the camera bounds are not finite corners with
                positive extent, the views differ in snapshots or atoms, or the surfaces, colours, opacity or color range
                are invalid.
            TypeError: If a view's surface is not a ``VolumeSurface`` or a non-empty mapping of them.
            ValueError: If atom shares are given without snapshots, or are not one finite share and one text per atom of
                each snapshot, or the snapshot fields are not one pair per snapshot.
        """
        axes, indices = None, None
        if choices:
            if not isinstance(surface, dict):
                raise ValueError("Choices select among the snapshots of one view.")
            axes, indices, titles = choice_axes(surface, choices)
            # Each alternate keys its snapshots as the first view does, and takes the same titles.
            alternates = [
                {
                    **view,
                    "surface": dict(zip(titles, view["surface"].values()))
                    if isinstance(view["surface"], dict) and list(view["surface"]) == list(surface)
                    else view["surface"],
                }
                for view in alternates
            ]
            surface = dict(zip(titles, surface.values()))
        if camera_bounds is not None:
            camera_bounds = np.asarray(camera_bounds, dtype=float)
            if (
                camera_bounds.shape != (2, 3)
                or not np.isfinite(camera_bounds).all()
                or np.any(camera_bounds[0] >= camera_bounds[1])
            ):
                raise ValueError("Camera bounds must be finite lower/upper XYZ corners with positive extent.")
        first = {
            "title": title,
            "surface": surface,
            "color_range": color_range,
            "colors": colors,
            "opacity": opacity,
            "color_label": color_label,
            "field_name": field_name,
            "field_symbol": field_symbol,
            "field_unit": field_unit,
        }
        shown = [_surfaces(view["surface"]) for view in (first, *alternates)]
        if any(list(each) != list(shown[0]) for each in shown) or (
            isinstance(surface, dict) and any(not isinstance(view["surface"], dict) for view in alternates)
        ):
            raise ValueError("Every view must have the same snapshots as the first.")
        atoms = [next(iter(each.values())).display_grids[0].atoms for each in shown]
        if any(not np.array_equal(a, atoms[0]) for a in atoms):
            raise ValueError("Every view must describe the same atoms.")
        snapshots = isinstance(surface, dict)
        settings = (
            _snapshot_scene(shown[0], height=height, distances=distances)
            if snapshots
            else surface.scene(height=height, distances=distances)
        )
        views = _packed(
            [_view(each, snapshots, **view) for each, view in zip(shown, (first, *alternates), strict=True)]
        )
        # The camera's clipping covers every view's field, unless bounds are given.
        bounds = np.stack([np.asarray(_bounds(each)) for each in shown])
        settings["bounds"] = (
            camera_bounds.tolist()
            if camera_bounds is not None
            else [bounds[:, 0].min(axis=0).tolist(), bounds[:, 1].max(axis=0).tolist()]
        )
        if axes:
            settings.update(
                choices=[dict(label=label, options=list(options.values()), **flags) for label, options, flags in axes],
                snapshot_choices=indices,
            )
        if atom_shares is not None:
            settings.update(
                _atom_shares(atom_shares, len(shown[0]) if snapshots else 0, len(atoms[0]), atom_label, atom_colors)
            )
            settings["atom_scale"].update(
                display={"label": str(display_label), "options": [str(o) for o in display_options]}
            )
        if snapshot_fields is not None:
            if not snapshots or len(snapshot_fields) != len(shown[0]):
                raise ValueError("Give one field label and symbol per snapshot.")
            settings["snapshot_fields"] = [
                {"label": str(label), "symbol": str(symbol)} for label, symbol in snapshot_fields
            ]
        if depiction:
            # One frame per snapshot, as the scene orders them, each the atoms of its first view's grid in angstrom.
            grids = [each.display_grids[0].atoms for each in shown[0].values()]
            elements = [ELEMENTS[int(number) - 1] for number in grids[0][:, 0]]
            geometries = [(grid[:, 2:5] * ureg.bohr).to("angstrom").magnitude for grid in grids]
            marks = [dict(kind="distance", atoms=list(pair)) for pair in check_distances(distances, len(elements))]
            # Each snapshot's atom shares, when given, are drawn as a similarity map on its scale.
            shared = [np.asarray(item[0], dtype=float) for item in atom_shares] if atom_shares is not None else []
            ranges = settings.get("atom_scale", {}).get("scales", {})
            keys = [entry["scale"] for entry in settings.get("snapshot_atoms", [])]
            settings["depiction"] = depicted(
                elements,
                geometries,
                charge=charge,
                marks=marks,
                values=shared,
                scales=[tuple(ranges[key]["color_range"]) for key in keys],
                colors=list(atom_colors),
            )
        anywidget.AnyWidget.__init__(self, views=views, view_label=str(view_label), **settings)


def _atom_shares(shares, snapshots, count, label, colors):
    """The colours and hover texts of the atoms of each snapshot, and the colour scale of each kind of share.

    Args:
        shares: Per snapshot, one share per atom and one hover text per atom, and optionally the key of its colour
            scale, such as one per part of an orbital; snapshots with one key share a scale from zero to their
            largest share.
        snapshots: The number of snapshots, zero for a single surface.
        count: The number of atoms.
        label: The quantity and unit above the colour scale, with its optional ``description``, or a mapping of
            each scale's key to its own.
        colors: Hexadecimal colours of the scales, from zero to the largest share.

    Returns:
        The settings ``snapshot_atoms``, the colours, texts and scale of each snapshot's atoms, and ``atom_scale``
        with each scale's range, colours and label under ``scales``.

    Raises:
        ValueError: If there are no snapshots, the shares do not match them, or a snapshot does not give one finite
            share and one text per atom.
    """
    shares = [
        (np.asarray(item[0], dtype=float), [str(text) for text in item[1]], str(item[2]) if len(item) > 2 else "")
        for item in shares
    ]
    if not snapshots or len(shares) != snapshots:
        raise ValueError("Give one pair of atom shares and texts per snapshot.")
    if any(
        values.shape != (count,) or not np.isfinite(values).all() or len(texts) != count for values, texts, _ in shares
    ):
        raise ValueError("Give one finite share and one text per atom.")
    labels = label if isinstance(label, dict) else {}
    scales = {}
    for key in dict.fromkeys(key for *_, key in shares):
        upper = max(float(values.max()) for values, _, other in shares if other == key)
        name = labels.get(key, label if not isinstance(label, dict) else "")
        scales[key] = {
            "color_range": [0.0, upper if upper > 0 else 1.0],
            "colors": list(colors),
            "color_label": str(name),
            "color_description": getattr(name, "description", "") or "",
        }
    return {
        "snapshot_atoms": [
            {
                "colors": color_atoms(values, count, tuple(scales[key]["color_range"]), colors)[0],
                "details": texts,
                "scale": key,
            }
            for values, texts, key in shares
        ],
        "atom_scale": {"scales": scales},
    }


def _surfaces(surface):
    """One surface or a mapping of snapshot titles to surfaces, as a mapping, checked.

    Args:
        surface: A ``VolumeSurface`` or a mapping of titles to them.

    Returns:
        The mapping, with a single surface under the empty title.

    Raises:
        TypeError: If the surface is neither a ``VolumeSurface`` nor a non-empty mapping of them.
        ValueError: If a snapshot title is empty.
    """
    if isinstance(surface, dict):
        if not surface or not all(isinstance(s, VolumeSurface) for s in surface.values()):
            raise TypeError("Supply a non-empty mapping of titles to VolumeSurface objects.")
        if not all(isinstance(title, str) and title.strip() for title in surface):
            raise ValueError("Each snapshot needs a non-empty title.")
        return dict(surface)
    if not isinstance(surface, VolumeSurface):
        raise TypeError("Supply one VolumeSurface or a mapping of titles to them.")
    return {"": surface}


def _bounds(surfaces):
    """Lower and upper corners enclosing every surface's displayed field.

    Args:
        surfaces: A mapping of snapshot titles to surfaces.

    Returns:
        The lower and upper corner in angstrom, as lists of three numbers.
    """
    bounds = np.stack([surface.bounds for surface in surfaces.values()])
    return [bounds[:, 0].min(axis=0).tolist(), bounds[:, 1].max(axis=0).tolist()]


def _packed(views):
    """The views with their stored fields packed into few files (``molstarview.store.pack``), in the order the
    viewer shows them: each snapshot's field and colour field in every view, so the snapshots a reader steps
    through and the views of one snapshot share their files.

    Args:
        views: The views, as ``_view`` returns them.

    Returns:
        The same views with packed addresses.
    """
    count = max(len(view["fields"]) for view in views)
    order = [view[key] for view in views for key in ("field", "color_field")]
    order += [
        view[key][index]
        for index in range(count)
        for view in views
        for key in ("fields", "color_fields")
        if index < len(view[key])
    ]
    packed = store.pack(order)
    swap = lambda text: packed.get(text, text)
    return [
        dict(
            view,
            field=swap(view["field"]),
            color_field=swap(view["color_field"]),
            fields=[swap(text) for text in view["fields"]],
            color_fields=[swap(text) for text in view["color_fields"]],
        )
        for view in views
    ]


def _view(
    surfaces,
    snapshots,
    *,
    title,
    surface,
    color_range,
    colors,
    opacity,
    color_label="",
    field_name="",
    field_symbol="",
    field_unit="",
):
    """One view: its title, the encoded fields of its surfaces, its level settings, look and quantity.

    Args:
        surfaces: A mapping of snapshot titles to surfaces.
        snapshots: Whether the surfaces are snapshots, each with its own encoded field.
        title: The view's title.
        surface: The view's surface or surfaces, as given by the caller.
        color_range: The values at the lower and upper end of the colour scale.
        colors: Hexadecimal colours of the scale.
        opacity: Opacity of the surfaces.
        color_label: The quantity and unit above the colour scale, with its optional ``description``.
        field_name: The name on the first line of a hover label.
        field_symbol: The symbol of the field in hover labels.
        field_unit: The unit of the field in hover labels.

    Returns:
        The view as the browser takes it, with the first surface's encoding, the fields of every snapshot, the level range
        that every snapshot can reach, and the labels.

    Raises:
        ValueError: If the opacity or colour range is invalid, fewer than two colours are given or one is not
            hexadecimal, or only some snapshot surfaces have an adjustable level.
    """
    if not 0 < opacity <= 1 or len(color_range) != 2 or not color_range[0] < color_range[1]:
        raise ValueError("Specify a positive opacity and an increasing color range.")
    if len(colors) < 2 or any(re.fullmatch(r"#[0-9a-fA-F]{6}", c) is None for c in colors):
        raise ValueError("Supply at least two hexadecimal colors.")
    encoded = [each.view(color_range=color_range, colors=colors, opacity=opacity) for each in surfaces.values()]
    view = dict(encoded[0])
    if snapshots:
        ranges = [item["level_range"] for item in encoded]
        if any(ranges) and not all(ranges):
            raise ValueError("Either every snapshot surface has an adjustable level or none has.")
        # Every snapshot's floor is reachable, and the strongest field sets the top.
        view.update(
            level_range=[max(r[0] for r in ranges), max(r[1] for r in ranges)] if all(ranges) else [],
            field="",
            color_field="",
            fields=[item["field"] for item in encoded],
            color_fields=[item["color_field"] for item in encoded],
        )
    view.update(
        title=title,
        color_label=str(color_label),
        color_description=getattr(color_label, "description", "") or "",
        field_name=field_name,
        field_symbol=field_symbol,
        field_unit=field_unit,
    )
    return view


def _snapshot_scene(surfaces, *, height, distances):
    """The molecule of several surfaces as frames of one trajectory, one native snapshot each.

    Args:
        surfaces: A mapping of snapshot titles to surfaces of the same atoms.
        height: Viewer height in pixels.
        distances: Pairs of one-based atom numbers measured in the scene.

    Returns:
        The viewer's scene settings, a mapping of the scene archive, frame count, requested frame, distances, height
        and snapshot titles.

    Raises:
        ValueError: If the surfaces do not describe the same atoms in the same order.
    """
    atoms = [surface.display_grids[0].atoms for surface in surfaces.values()]
    if any(not np.array_equal(a[:, 0], atoms[0][:, 0]) for a in atoms):
        raise ValueError("Snapshot surfaces must describe the same atoms in the same order.")
    # Each geometry becomes one frame, so native distances follow the displayed snapshot.
    frames = xyz_frames(atoms[0][:, 0].astype(int), (np.stack([a[:, 2:] for a in atoms]) * ureg.bohr).to("angstrom"))
    return {
        "scene": build_scene(frames),
        "frame_count": len(surfaces),
        "requested": 1,
        "distances": check_distances(distances, len(atoms[0])),
        "height": height,
        "snapshots": [title.strip() for title in surfaces],
    }

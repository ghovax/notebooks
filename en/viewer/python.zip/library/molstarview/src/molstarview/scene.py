"""The molecular scene a viewer loads: a MolViewSpec state of its XYZ frames, and the frames its motion trail copies."""

import base64
import io
import zipfile
from datetime import datetime, timezone
from textwrap import dedent

import molviewspec as mvs
import numpy as np
from molviewspec.nodes import ComponentExpression

from molstarview import store

# A scene archive larger than this many bytes is kept in the store, when one is set, instead of in the page.
INLINE_SCENE = 32 * 1024


# The time written into every scene archive, the earliest a zip entry can hold.
FIXED_TIME = datetime(1980, 1, 1, tzinfo=timezone.utc)


def build_scene(frames, arrows=(), atom_colors=(), markers=(), elements=()):
    """Load one native XYZ trajectory, with coloured atoms drawn as balls and sticks in their own colours.

    Args:
        frames: Complete XYZ strings of the same atoms.
        arrows: Validated arrows, drawn as MolViewSpec primitives.
        atom_colors: The colour of every atom, or empty for Molstar's element colours.
        markers: Validated markers, drawn as small spheres without bonds.
        elements: The element symbols of the atoms, whose number places the markers among them.

    Returns:
        The MolViewSpec archive of the scene: its address in the store (``molstarview.store``) when it is larger
        than ``INLINE_SCENE`` bytes and a store is set, otherwise base64-encoded with a ``base64,`` prefix.
    """
    builder = mvs.create_builder()
    builder.canvas(background_color="white")
    template = dedent("""
        {frame}
        """).lstrip()
    trajectory = "".join(template.format(frame=frame.rstrip()) for frame in frames)
    structure = builder.download(url="trajectory.xyz").parse(format="xyz").model_structure(model_index=0)
    if atom_colors:
        representation = structure.component(selector="all").representation(type="ball_and_stick")
        for color in dict.fromkeys(atom_colors):
            representation.color(
                color=color,
                selector=[
                    ComponentExpression(atom_index=index) for index, value in enumerate(atom_colors) if value == color
                ],
            )
    if markers:
        virtual = {atom - 1 for marker in markers for atom in marker["atoms"]}
        body = [index for index in range(len(elements)) if index not in virtual]
        # The viewer colours these atoms like the native preset; only the virtual points are coloured here.
        structure.component(selector=[ComponentExpression(atom_index=index) for index in body]).representation(
            type="ball_and_stick"
        )
        for marker in (marker for marker in markers if marker["visible"]):
            component = structure.component(
                selector=[ComponentExpression(atom_index=atom - 1) for atom in marker["atoms"]]
            )
            if marker["label"]:
                component.tooltip(text=marker["label"])
            component.representation(type="spacefill", size_factor=marker["size"]).color(color=marker["color"])
    if arrows:
        primitives = builder.primitives()
        for arrow in arrows:
            length = float(np.linalg.norm(np.subtract(arrow["end"], arrow["start"])))
            # Short arrows keep a visible head without the head exceeding the shaft.
            cap = min(0.25, 0.45 * length)
            primitives.arrow(
                start=arrow["start"],
                end=arrow["end"],
                show_end_cap=True,
                end_cap_length=cap,
                end_cap_radius=0.5 * cap + 0.02,
                tube_radius=0.035,
                color=arrow["color"],
                tooltip=arrow["tooltip"],
            )
    state = builder.get_state()
    # A scene depends only on what it shows, so equal scenes are equal bytes and keep one name in the store: a
    # fixed time stands in for the time of building, in the state and in the archive's entries.
    state.metadata.timestamp = FIXED_TIME.isoformat()
    archive = io.BytesIO()
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        for name, data in (
            ("index.mvsj", state.model_dump_json(exclude_none=True).encode()),
            ("trajectory.xyz", trajectory.encode()),
        ):
            entry = zipfile.ZipInfo(name, date_time=FIXED_TIME.timetuple()[:6])
            entry.compress_type = zipfile.ZIP_DEFLATED
            bundle.writestr(entry, data)
    archive = archive.getvalue()
    # A large scene, such as a long trajectory, loads only when its viewer first mounts; a small one stays in the
    # page, where it costs less than a request.
    return (len(archive) > INLINE_SCENE and store.address(archive)) or "base64," + base64.b64encode(archive).decode()


def trail_copies(geometries, ranges, virtual, density):
    """The frames each range draws as trail copies: both its ends, and each frame where some real atom has moved
    0.1 / ``density`` angstrom from the last copy, so the copies follow the motion rather than the frame count.

    Args:
        geometries: Coordinates of every frame, one array of shape (atoms, 3) per frame.
        ranges: The number of frames of each snapshot, or of the whole trajectory.
        virtual: Zero-based indices of the virtual atoms, which are left out of the motion.
        density: Copies per 0.1 angstrom moved by the fastest atom.

    Returns:
        For each range, the zero-based frame numbers drawn as copies, in order.
    """
    step = 0.1 / density
    real = np.setdiff1d(np.arange(len(geometries[0])), virtual)
    chosen, start = [], 0
    for count in ranges:
        kept = [start]
        for frame in range(start + 1, start + count):
            if np.linalg.norm(geometries[frame][real] - geometries[kept[-1]][real], axis=1).max() >= step:
                kept.append(frame)
        if kept[-1] != start + count - 1:
            kept.append(start + count - 1)
        chosen.append(kept)
        start += count
    return chosen

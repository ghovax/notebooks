"""The molecular viewer widget: XYZ frames with measurements, overlays and a motion trail, drawn by Molstar."""

from collections.abc import Mapping
from numbers import Integral
from pathlib import Path

import anywidget
import numpy as np
import traitlets

from molstarview.scene import build_scene, trail_copies
from molstarview.validation import (
    check_angles,
    check_arrows,
    check_distances,
    check_groups,
    check_markers,
    check_readouts,
    choice_axes,
    color_atoms,
)

# The front end's scripts, in the order they are joined: shared helpers first, then a viewer, then the entry point.
SCRIPTS = ("text.js", "fields.js", "surfaces.js", "labels.js", "context.js", "controls.js", "mount.js", "main.js")


class MolstarViewer(anywidget.AnyWidget):
    """Display XYZ frames with native atom-pair distances and one persistent camera.

    Atom pairs and frames are one-based. ``frame`` confirms the displayed frame;
    ``error`` reports a browser-side load failure. Distances use angstrom.

    ``groups`` is a sequence of mappings with ``label`` (inline Markdown with optional
    ``$...$`` LaTeX, drawn as a text overlay at the group's centroid and shown when hovering its atoms) and ``atoms``
    (one-based, disjoint atom numbers). Atom colours and representations stay Molstar's defaults.

    Hovering shows the viewer's own labels in Molstar's highlight box: the atom, bond, measurement or field value
    under the pointer, written in words with ``$...$`` LaTeX.

    ``arrows`` is a sequence of mappings with ``start`` and ``end`` (angstrom, in the
    frames' coordinates) and optional ``color`` (``#rrggbb``) and ``tooltip`` (plain
    text). Each becomes a native MolViewSpec arrow primitive, for example a
    displacement field drawn on a structure.

    ``atom_values`` gives one number per atom, such as a partial charge. Atoms are then drawn as balls and sticks
    coloured on the ``colors`` scale from the lower to the upper end of ``color_range`` (symmetric about zero by
    default), with ``color_label``, the quantity and its unit, above a colour scale in the viewport. Each atom's
    hover label adds its entry of ``atom_details`` (text with ``$...$`` LaTeX), such as its charge.
    """

    # The front end: the scripts of static/ joined, in the order their declarations need, into one module.
    _esm = "".join((Path(__file__).parent / "static" / name).read_text() for name in SCRIPTS)

    _css = Path(__file__).parent / "static" / "viewer.css"

    scene = traitlets.Unicode().tag(sync=True)

    frame_count = traitlets.Int().tag(sync=True)

    distances = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)

    # One-based atom triples of native angle measurements, the vertex in the middle.
    angles = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)

    # Virtual atoms drawn as small spheres: atoms, colour, size and label of each group.
    markers = traitlets.List(traitlets.Dict()).tag(sync=True)

    # Measurements whose native number is replaced by a readout drawn in front of the scene: their kind and atoms.
    readouts = traitlets.List(traitlets.Dict()).tag(sync=True)

    bounds = traitlets.List(traitlets.List(traitlets.Float())).tag(sync=True)

    height = traitlets.Int(440).tag(sync=True)

    requested = traitlets.Int(1).tag(sync=True)

    frame = traitlets.Int(0).tag(sync=True)

    error = traitlets.Unicode("").tag(sync=True)

    annotations = traitlets.List(traitlets.Dict()).tag(sync=True)

    snapshots = traitlets.List(traitlets.Unicode()).tag(sync=True)

    segments = traitlets.List(traitlets.Int()).tag(sync=True)

    # Dropdowns that together select a snapshot: each has a label and its option texts, and ``snapshot_choices`` gives
    # every snapshot's option index on each of them.
    choices = traitlets.List(traitlets.Dict()).tag(sync=True)

    snapshot_choices = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)

    # Named, one-based frames available from the trajectory controls.
    frame_labels = traitlets.List(traitlets.Dict()).tag(sync=True)

    # Whether faded copies of the frames behind the shown one follow it, toggled from the toolbar.
    trail = traitlets.Bool(False).tag(sync=True)

    # Trail copies per 0.1 angstrom moved by the fastest atom.
    trail_density = traitlets.Float(1.0).tag(sync=True)

    # The zero-based frames each frame range draws as trail copies.
    trail_frames = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)

    # Per-atom colours of an atom-valued quantity, with its colour scale; empty for Molstar's element colours.
    atom_colors = traitlets.List(traitlets.Unicode()).tag(sync=True)

    color_range = traitlets.List(traitlets.Float()).tag(sync=True)

    colors = traitlets.List(traitlets.Unicode()).tag(sync=True)

    # Quantity and unit of the colour scale, shown above it.
    color_label = traitlets.Unicode("").tag(sync=True)

    # Explanation of that quantity, Markdown with $...$ LaTeX, opened from an info button beside the label; empty for
    # none. A label carrying a ``description``, as page quantities do, supplies it.
    color_description = traitlets.Unicode("").tag(sync=True)

    # Hover details of each atom, LaTeX allowed; empty for none.
    atom_details = traitlets.List(traitlets.Unicode()).tag(sync=True)

    def __init__(
        self,
        frames,
        *,
        distances=(),
        height=440,
        groups=(),
        arrows=(),
        trail=None,
        trail_density=1.0,
        atom_values=None,
        atom_details=None,
        color_range=None,
        colors=("#d7301f", "#ffffff", "#2b6cb0"),
        color_label="",
        frame_labels=None,
        choices=None,
        snapshot_frame_labels=None,
        angles=(),
        markers=(),
        readouts=(),
    ):
        """Validate matching XYZ frames and prepare one native trajectory.

        Atom numbers are one-based and lengths are in angstrom.

        Args:
            frames: Complete XYZ strings of the same atoms in the same order. A mapping of snapshot titles to such
                sequences gives one native snapshot per title, each playing its frames alone; titles may contain ``$...$``
                LaTeX, typeset in the selector and its list. With ``choices`` the keys are tuples of one value per choice.
            distances: Atom pairs measured with Molstar's measurement tool.
            height: Viewer height in pixels, at least 200.
            groups: Mappings with ``label`` (inline Markdown with optional ``$...$`` LaTeX, drawn at the group's centroid
                and shown when hovering its atoms) and ``atoms`` (disjoint atom numbers).
            arrows: Mappings with ``start`` and ``end`` (angstrom, in the frames' coordinates) and optional ``color``
                (``#rrggbb``) and ``tooltip`` (plain text), each drawn as a native MolViewSpec arrow.
            trail: Whether faded copies of the molecule along the shown range follow it as a motion blur, shown by a
                Motion trail toggle that starts off. None offers it whenever there is more than one frame; ``False`` leaves
                it out.
            trail_density: Copies per 0.1 angstrom moved by the fastest atom, so a path that lingers gets few and a large
                motion many.
            atom_values: One number per atom, such as a partial charge. Atoms are then drawn as balls and sticks coloured
                on the ``colors`` scale; cannot be combined with ``markers``.
            atom_details: One hover text per atom, LaTeX allowed, such as its charge.
            color_range: Lower and upper end of the colour scale, symmetric about zero over ``atom_values`` by default.
            colors: Hexadecimal colours of the scale from its lower to its upper end, at least two.
            color_label: The quantity and its unit, shown above the colour scale; ``$...$`` is LaTeX. A label carrying a
                ``description``, as page quantities do, offers it from an info button.
            frame_labels: Descriptive labels mapped to frame numbers, for the frame selector. An input sequence may carry
                a ``frame_labels`` mapping, which an explicit argument overrides.
            choices: Pairs of ``(label, options)`` that replace the snapshot menu by one dropdown per axis: ``label`` is
                inline Markdown with optional LaTeX and ``options`` maps each value to its text. ``frames`` then maps a
                tuple of one value per choice to that snapshot's frames. Choosing a value shows the snapshot that keeps the
                earlier dropdowns and agrees with the later ones on most of them, and an earlier dropdown limits the later
                ones to combinations that exist. A triple adds the flags ``input`` (a text field where an option's
                text is typed, a number clamped to the nearest allowed) and ``collapse`` (hidden while its first option
                is the only one allowed), as in ``choice_axes``.
            snapshot_frame_labels: Names of frames within snapshots: a mapping of labels to frame numbers, negative
                counting from the end, the same for every snapshot, or a mapping of each snapshot's key to its own. The
                frame menu offers the labels of the shown snapshot only.
            angles: Atom triples, the vertex in the middle, registered as native angle measurements like the distances.
            markers: Virtual atoms, such as a pivot appended to every frame, drawn as small spheres without bonds:
                mappings with ``atoms``, ``color`` (``#rrggbb``), optional ``visible`` (``False`` for a point that only
                anchors a measurement and is not drawn), optional ``size`` (a fraction of the van der Waals radius, default
                0.09) and ``label`` (hover text, a LaTeX symbol naming its atom).
            readouts: Labels drawn in front of the scene at every frame in place of a native measurement's number:
                mappings with ``kind`` (``"distance"`` or ``"angle"``), the measurement's ``atoms``, a LaTeX ``label``
                symbol, for a distance its ``unit`` and optionally the ``position`` along it of the label (default 0.5),
                ``offset`` as ``(across, down)`` in label heights to keep close readouts apart, and ``size``, the label's
                height in angstrom (default 0.28). The label reads, for example, r = 1.70 Å or θ = 90°, an angle without
                trailing zeros and standing inside the angle a third of the way along its shorter arm; an arm shorter than
                1e-6 angstrom counts as perpendicular to the other.

        Raises:
            ValueError: If the frames, snapshot titles, labels, choices, distances, angles, groups, arrows, markers,
                readouts, atom values, details, height or trail density are invalid, or markers are combined with atom
                values.
        """
        frame_labels = getattr(frames, "frame_labels", {}) if frame_labels is None else frame_labels
        snapshots, axes, snapshot_choices = {}, [], []
        if choices and not isinstance(frames, dict):
            raise ValueError("Choices select among snapshots: map each combination of values to its frame sequence.")
        if isinstance(frames, dict):
            if choices:
                axes, snapshot_choices, titles = choice_axes(frames, choices)
                snapshot_keys = [key if isinstance(key, tuple) else (key,) for key in frames]
                frames = dict(zip(titles, frames.values()))
            snapshots = {title.strip(): list(sequence) for title, sequence in frames.items()}
            snapshot_keys = snapshot_keys if choices else list(snapshots)
            if not snapshots or not all(title and sequence for title, sequence in snapshots.items()):
                raise ValueError("Each snapshot needs a non-empty title and at least one frame.")
            frames = [frame for sequence in snapshots.values() for frame in sequence]
        frames = list(frames)
        if not frames:
            raise ValueError("Supply at least one XYZ frame.")
        if not hasattr(frame_labels, "items"):
            raise ValueError("Frame labels must map names to one-based frame numbers.")
        labels = []
        for label, index in frame_labels.items():
            if (
                not isinstance(label, str)
                or not label.strip()
                or not isinstance(index, Integral)
                or isinstance(index, bool)
                or not 1 <= index <= len(frames)
            ):
                raise ValueError("Each frame label needs a name and a valid one-based frame number.")
            labels.append({"label": label.strip(), "frame": int(index)})
        if len({entry["label"] for entry in labels}) != len(labels):
            raise ValueError("Frame labels must be unique.")
        if snapshot_frame_labels:
            if not snapshots:
                raise ValueError("Snapshot frame labels need snapshots.")
            start = 0
            # One mapping for every snapshot, or a mapping of each snapshot's key to its own.
            each = all(isinstance(entry, Mapping) for entry in snapshot_frame_labels.values())
            for key, sequence in zip(snapshot_keys, snapshots.values()):
                for label, number in (snapshot_frame_labels.get(key, {}) if each else snapshot_frame_labels).items():
                    if (
                        not isinstance(label, str)
                        or not label.strip()
                        or not isinstance(number, Integral)
                        or isinstance(number, bool)
                        or number == 0
                        or abs(number) > len(sequence)
                    ):
                        raise ValueError(
                            "Each snapshot frame label needs a name and a frame number within every snapshot."
                        )
                    labels.append(
                        {
                            "label": label.strip(),
                            "frame": start + (number if number > 0 else len(sequence) + number + 1),
                        }
                    )
                start += len(sequence)
        if not isinstance(height, Integral) or height < 200:
            raise ValueError("Viewer height must be an integer of at least 200 pixels.")
        geometries, elements = [], None
        for number, frame in enumerate(frames, 1):
            lines = frame.strip().splitlines()
            if len(lines) < 3:
                raise ValueError(f"XYZ frame {number} is incomplete.")
            count = int(lines[0])
            rows = [line.split() for line in lines[2:]]
            if count < 1 or len(rows) != count or any(len(row) != 4 for row in rows):
                raise ValueError(f"XYZ frame {number} has an invalid atom table.")
            symbols = tuple(row[0] for row in rows)
            if elements is not None and symbols != elements:
                raise ValueError("XYZ frames must preserve atom identities and order.")
            elements = symbols
            xyz = np.asarray([row[1:] for row in rows], dtype=float)
            if not np.isfinite(xyz).all():
                raise ValueError(f"XYZ frame {number} contains non-finite coordinates.")
            geometries.append(xyz)
        pairs = check_distances(distances, len(elements))
        groups = check_groups(groups, len(elements))
        annotations = [
            dict(
                text=group["label"],
                atoms=group["atoms"],
                centers=[frame[np.asarray(group["atoms"]) - 1].mean(axis=0).tolist() for frame in geometries],
            )
            for group in groups
        ]
        arrows = check_arrows(arrows)
        atom_colors, color_range = color_atoms(atom_values, len(elements), color_range, colors)
        angles = check_angles(angles, len(elements))
        readouts = check_readouts(readouts, geometries, len(elements))
        annotations += readouts["annotations"]
        markers = check_markers(markers, len(elements))
        if markers and atom_colors:
            raise ValueError("Markers cannot be combined with atom values.")
        atom_details = list(atom_details or [])
        if atom_details and len(atom_details) != len(elements):
            raise ValueError("Give one hover detail per atom.")
        coordinates = np.concatenate(
            [np.reshape(geometries, (-1, 3))] + [np.asarray([arrow["start"], arrow["end"]]) for arrow in arrows]
        )
        bounds = [coordinates.min(axis=0) - 0.7, coordinates.max(axis=0) + 0.7]
        if not trail_density > 0:
            raise ValueError("The trail density must be positive.")
        # Every animated viewer offers the motion trail, hidden until toggled on, unless asked not to.
        trail = len(frames) > 1 if trail is None else bool(trail)
        virtual = [atom - 1 for marker in markers for atom in marker["atoms"]]
        trail_frames = (
            trail_copies(
                geometries, [len(sequence) for sequence in snapshots.values()] or [len(frames)], virtual, trail_density
            )
            if trail
            else []
        )
        super().__init__(
            scene=build_scene(frames, arrows, atom_colors, markers, elements),
            atom_details=atom_details,
            atom_colors=atom_colors,
            color_range=list(color_range),
            colors=list(colors),
            color_label=str(color_label),
            color_description=getattr(color_label, "description", "") or "",
            frame_count=len(frames),
            trail=bool(trail),
            trail_density=float(trail_density),
            trail_frames=trail_frames,
            distances=pairs,
            angles=angles,
            markers=markers,
            readouts=readouts["measurements"],
            bounds=[bound.tolist() for bound in bounds],
            height=int(height),
            annotations=annotations,
            frame_labels=labels,
            snapshots=list(snapshots),
            choices=[dict(label=label, options=list(options.values()), **flags) for label, options, flags in axes],
            snapshot_choices=snapshot_choices,
            segments=[len(sequence) for sequence in snapshots.values()],
        )

    def set_frame(self, frame):
        """Request a one-based frame, retaining camera orientation and native distances.

        Args:
            frame: The frame to show, from 1 to ``frame_count``.

        Raises:
            ValueError: If ``frame`` is not an integer within that range.
        """
        if not isinstance(frame, Integral) or isinstance(frame, bool) or not 1 <= frame <= self.frame_count:
            raise ValueError(f"Frame must be an integer between 1 and {self.frame_count}.")
        self.requested = int(frame)

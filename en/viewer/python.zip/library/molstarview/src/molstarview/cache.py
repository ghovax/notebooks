"""Where molstarview keeps what it can always recompute: parsed cubes and encoded fields."""

import os
from pathlib import Path


def cache_folder(name):
    """Folder of one kind of cached result, below ``$MOLSTARVIEW_CACHE`` or else ``~/.cache/molstarview``.

    Args:
        name: Kind of result, such as ``cubes`` or ``volumes``.

    Returns:
        The folder's path, which may not exist yet.
    """
    return Path(os.environ.get("MOLSTARVIEW_CACHE") or Path.home() / ".cache/molstarview") / name

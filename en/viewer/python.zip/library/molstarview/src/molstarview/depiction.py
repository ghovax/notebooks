r"""Two-dimensional depictions drawn below a viewer: RDKit's structure drawing of the viewer's own atoms.

Every viewer carries one depiction of its molecule, which its front end redraws with RDKit.js as the shown frame or
snapshot changes: the bonds the frame's geometry implies, the atoms coloured as the viewer colours them, and the
measured bonds and angles with their value at that frame. Python decides everything about the drawing that must
stay the same between viewers, so the browser only colours and labels it:

- bonds come from the geometry of each frame by RDKit's covalent-radius rule, for all frames at once, and bond orders and formal
  charges from RDKit's ``DetermineBondOrders`` for the molecule's total charge; frames whose bonds differ, as along
  a reaction path, get a drawing each, laid out by RDKit for its own bonds and turned onto the most common one;
- each set of bonds gets RDKit's own 2D depiction laid out to mimic the 3D structure of a frame with those bonds
  (``GenerateDepictionMatching3DStructure``), so an s-cis diene or a folded chain is drawn as it is shaped, and the
  layout follows the geometry rather than the calculation's atom order; it is then turned, and mirrored where that
  fits, onto the molecule as the 3D view first shows it, looking down z with y up, so each atom sits on the side of
  the drawing where it sits in the view above; separate molecules, as before a reaction, each face the view and keep
  their places in it. A structure RDKit cannot match is laid out in its canonical orientation instead and turned by
  quarter turns only, which keep that orientation's upright rings;
- without RDKit, as in the calculation viewer's in-browser Python, the bonds are still found here, by the same rule
  from ``data/covalent-radii.yaml``, and RDKit.js lays each set out on the page with its own 2D layout, all bonds
  single, since only the Python RDKit assigns bond orders;
- hydrogens are drawn only where they matter: on an atom a measurement or group names, or where a frame's bonds to
  them change; the others are counted on their heavy atom, as an ordinary structure drawing shows them.

Atom numbers given to and returned by this module are zero-based in the depiction and one-based where they name a
viewer's atoms, as everywhere else in molstarview.
"""

import hashlib
import importlib.util
import json
import logging
from collections import Counter
from importlib.resources import files
from pathlib import Path

import numpy as np
import yaml

from molstarview.cache import cache_folder

LOGGER = logging.getLogger(__name__)
# How depictions are built and maps drawn, from data/depiction.yaml; see that file for each setting.
SETTINGS = yaml.safe_load(files(__package__).joinpath("data", "depiction.yaml").read_text())
# RDKit's covalent radius of each element, from data/covalent-radii.yaml, so bonds are found by its rule without it.
RADII = yaml.safe_load(files(__package__).joinpath("data", "covalent-radii.yaml").read_text())


def _xyz(elements, coordinates):
    """XYZ block of one frame.

    Args:
        elements: Element symbols in atom order.
        coordinates: (N, 3) positions in angstrom.

    Returns:
        The XYZ text.
    """
    rows = "".join(f"{s} {x:.6f} {y:.6f} {z:.6f}\n" for s, (x, y, z) in zip(elements, coordinates))
    return f"{len(elements)}\n\n{rows}"


def _connectivities(elements, geometries):
    """The bonds of every frame, by RDKit's covalent-radius rule, evaluated for all frames at once.

    Args:
        elements: Element symbols.
        geometries: (F, N, 3) positions in angstrom.

    Returns:
        One tuple of sorted zero-based pairs per frame.
    """
    radii = np.array([RADII[symbol] for symbol in elements])
    limit = SETTINGS["bonds"]["covalent-factor"] * (radii[:, None] + radii[None, :])
    first, second = np.triu_indices(len(elements), k=1)
    # (F, pairs) distances of every atom pair in every frame.
    distances = np.linalg.norm(geometries[:, first] - geometries[:, second], axis=-1)
    bonded = distances < limit[first, second]
    # A contact between two hydrogens is a bond only when neither has another partner, as in H2; a large
    # vibration otherwise brings hydrogens close enough to count.
    light = np.array([symbol == "H" for symbol in elements])
    pairs = light[first] & light[second]
    found = []
    for row in bonded:
        other = np.zeros(len(elements), dtype=int)
        np.add.at(other, first[row & ~pairs], 1)
        np.add.at(other, second[row & ~pairs], 1)
        keep = row & ~(pairs & ((other[first] > 0) | (other[second] > 0)))
        found.append(tuple(zip(first[keep].tolist(), second[keep].tolist())))
    return found


def _assign(elements, coordinates, charge, bonds):
    """RDKit's bond orders for a connectivity, with every bond single to start.

    Args:
        elements: Element symbols.
        coordinates: Positions in angstrom.
        charge: Total charge.
        bonds: Zero-based pairs.

    Returns:
        The molecule with orders and formal charges.

    Raises:
        ValueError: If RDKit finds no valid assignment.
    """
    from rdkit import Chem
    from rdkit.Chem import rdDetermineBonds

    mol = Chem.RWMol(Chem.MolFromXYZBlock(_xyz(elements, coordinates)))
    for a, b in bonds:
        mol.AddBond(a, b, Chem.BondType.SINGLE)
    rdDetermineBonds.DetermineBondOrders(mol, charge=charge, allowChargedFragments=True, embedChiral=False)
    return mol


def _coordination(elements, bonds):
    """Bonds RDKit's assignment cannot place: every bond to a metal, and for a main-group atom with more bonds than
    its largest valence, its bonds to neighbours that can donate a lone pair.

    Args:
        elements: Element symbols.
        bonds: Zero-based pairs.

    Returns:
        A pair: the bonds to metals, always set apart, and per over-coordinated main-group atom its candidate
        (acceptor, donor) bonds, one of which is set apart as a dative bond.
    """
    from rdkit import Chem

    table = Chem.GetPeriodicTable()
    numbers = [table.GetAtomicNumber(symbol) for symbol in elements]
    # RDKit gives metals no default valence; their bonds to ligands are coordination bonds.
    metal = [table.GetDefaultValence(number) == -1 for number in numbers]
    # Atoms with a lone pair to give: an element with more valence electrons than its default valence uses.
    donor = [
        not metal[i] and table.GetNOuterElecs(n) > table.GetDefaultValence(n) and n != 1 for i, n in enumerate(numbers)
    ]
    degree = np.zeros(len(elements), dtype=int)
    for a, b in bonds:
        degree[[a, b]] += 1
    metallic = [pair for pair in bonds if metal[pair[0]] or metal[pair[1]]]
    choices = []
    for atom, number in enumerate(numbers):
        if metal[atom] or number == 1:
            continue
        excess = degree[atom] - max(table.GetValenceList(number))
        if excess == 1:
            # Each candidate as (acceptor, donor).
            choices.append(
                [
                    (atom, pair[0] if pair[1] == atom else pair[1])
                    for pair in bonds
                    if atom in pair and donor[pair[0] if pair[1] == atom else pair[1]]
                ]
            )
    return metallic, [choice for choice in choices if choice]


def _orders(elements, coordinates, charge, bonds):
    """Bond orders and formal charges of one connectivity, or None when RDKit cannot assign them.

    RDKit's assignment knows no dative or coordination bonds. Bonds to metals are therefore assigned without them and
    drawn as RDKit's dative arrows from the ligand. For a main-group atom with one bond more than its largest valence,
    such as the boron of a difluoroboron chelate or an ammonia-borane, each of its bonds to a lone-pair donor is left
    out in turn, the rest assigned, and the bond put back as a single bond from a positive donor to a negative
    acceptor, the zwitterion a structure drawing shows. Without a given charge, the smallest that gives a valid
    assignment is used.

    Args:
        elements: Element symbols.
        coordinates: (N, 3) positions in angstrom of a frame with these bonds.
        charge: Total charge of the molecule, or None to find it.
        bonds: The frame's bonds as zero-based pairs.

    Returns:
        A triple of the order of each bond in the order of ``bonds`` (0 for a dative arrow), the formal charge of each
        atom and the charge used; None if no assignment is found, as for an open-shell or unusual structure.
    """
    import itertools

    from rdkit import Chem

    metallic, choices = _coordination(elements, bonds)
    ordinary = [pair for pair in bonds if pair not in metallic]
    # Metals take no part in the assignment: it runs on the other atoms, whose charge, the ligands', is then unknown
    # even when the molecule's is given, so it is found like a missing one.
    table = Chem.GetPeriodicTable()
    ligands = [i for i, s in enumerate(elements) if table.GetDefaultValence(table.GetAtomicNumber(s)) != -1]
    if len(ligands) < len(elements):
        charge = None
    index = {atom: number for number, atom in enumerate(ligands)}
    sub_elements, sub_coordinates = [elements[i] for i in ligands], np.asarray(coordinates)[ligands]
    datives = (
        [()] + list(itertools.islice(itertools.product(*choices), SETTINGS["bonds"]["attempts"])) if choices else [()]
    )
    for total in SETTINGS["bonds"]["charges"] if charge is None else (charge,):
        for chosen in datives:
            left = {tuple(sorted(link)) for link in chosen}
            kept = [pair for pair in ordinary if pair not in left]
            try:
                mol = _assign(sub_elements, sub_coordinates, total, [(index[a], index[b]) for a, b in kept])
            except (ValueError, RuntimeError):
                # RDKit raises for a structure with no valid assignment; the next attempt, or single bonds, follow.
                continue
            for acceptor, donor in chosen:
                mol.AddBond(index[donor], index[acceptor], Chem.BondType.SINGLE)
                for atom, change in ((index[donor], 1), (index[acceptor], -1)):
                    mol.GetAtomWithIdx(atom).SetFormalCharge(mol.GetAtomWithIdx(atom).GetFormalCharge() + change)
            orders = [
                0
                if pair in metallic
                else int(round(mol.GetBondBetweenAtoms(index[pair[0]], index[pair[1]]).GetBondTypeAsDouble()))
                for pair in bonds
            ]
            charges = [0] * len(elements)
            for atom, number in index.items():
                charges[atom] = mol.GetAtomWithIdx(number).GetFormalCharge()
            return orders, charges, total
    LOGGER.info("No bond orders for a depiction", extra={"metadata": {"atoms": len(elements), "bonds": len(bonds)}})
    return None


def _graph(elements, kept, bonds):
    """The kept atoms joined by the given bonds, all single, as an RDKit molecule with its rings found.

    Args:
        elements: Element symbols of every atom.
        kept: Zero-based atoms drawn, in depiction order.
        bonds: Zero-based pairs among the kept atoms.

    Returns:
        The molecule, its atoms in the order of ``kept``.
    """
    from rdkit import Chem

    position = {atom: index for index, atom in enumerate(kept)}
    graph = Chem.RWMol()
    for atom in kept:
        graph.AddAtom(Chem.Atom(elements[atom]))
    for a, b in bonds:
        graph.AddBond(position[a], position[b], Chem.BondType.SINGLE)
    graph = graph.GetMol()
    graph.UpdatePropertyCache(strict=False)
    Chem.FastFindRings(graph)
    return graph


def _matched(elements, kept, bonds, coordinates):
    """RDKit's 2D coordinates of the kept atoms joined by the given bonds, laid out to mimic their 3D structure.

    Args:
        elements: Element symbols of every atom.
        kept: Zero-based atoms drawn, in depiction order.
        bonds: Zero-based pairs among the kept atoms.
        coordinates: (N, 3) positions of every atom in angstrom, of a frame with these bonds.

    Returns:
        (len(kept), 2) coordinates in RDKit's units, a bond of about 1.5, or None when RDKit cannot match the
        structure.
    """
    from rdkit import Chem
    from rdkit.Chem import rdDepictor

    graph = _graph(elements, kept, bonds)
    reference = Chem.Mol(graph)
    conformer = Chem.Conformer(len(kept))
    for index, atom in enumerate(kept):
        conformer.SetAtomPosition(index, [float(value) for value in coordinates[atom]])
    reference.AddConformer(conformer, assignId=True)
    drawn = Chem.Mol(graph)
    try:
        rdDepictor.GenerateDepictionMatching3DStructure(drawn, reference)
    except (ValueError, RuntimeError):
        return None
    points = drawn.GetConformer().GetPositions()[:, :2]
    return points if np.isfinite(points).all() else None


def _layout(elements, kept, bonds):
    """RDKit's 2D coordinates of the kept atoms joined by the given bonds, in canonical order and orientation.

    Args:
        elements: Element symbols of every atom.
        kept: Zero-based atoms drawn, in depiction order.
        bonds: Zero-based pairs among the kept atoms.

    Returns:
        (len(kept), 2) coordinates in RDKit's units, a bond of about 1.5.
    """
    from rdkit import Chem
    from rdkit.Chem import rdDepictor

    graph = _graph(elements, kept, bonds)
    # Canonical ranks make the layout independent of the calculation's atom order.
    ranks = list(Chem.CanonicalRankAtoms(graph, breakTies=True))
    order = sorted(range(len(kept)), key=ranks.__getitem__)
    canonical = Chem.RenumberAtoms(graph, order)
    canonical.UpdatePropertyCache(strict=False)
    Chem.FastFindRings(canonical)
    rdDepictor.Compute2DCoords(canonical, canonOrient=True)
    conformer = canonical.GetConformer()
    points = np.zeros((len(kept), 2))
    for new, old in enumerate(order):
        point = conformer.GetAtomPosition(new)
        points[old] = (point.x, point.y)
    return points


def _aligned(points, reference):
    """A depiction turned, mirrored if that fits better, and moved onto another of the same atoms (2D Kabsch).

    Args:
        points: (N, 2) positions to move.
        reference: (N, 2) positions of the same atoms to fit.

    Returns:
        The moved positions; their shape is unchanged.
    """
    moved, target = points - points.mean(axis=0), reference - reference.mean(axis=0)
    left, _, right = np.linalg.svd(moved.T @ target)
    # The best orthogonal map, a rotation or a reflection, as a depiction may be drawn either way round.
    return moved @ (left @ right) + reference.mean(axis=0)


def _faced(points, target, classes):
    """The quarter turn and mirroring of a depiction that brings it closest to a projection of the same atoms.

    Only these eight keep RDKit's canonical orientation, rings upright and ring systems along x, so the drawing still
    looks as RDKit draws it; any rotation would fit closer but tilt it.

    Args:
        points: (N, 2) positions of a depiction.
        target: (N, 2) positions of the same atoms to face, in any units.
        classes: Symmetry class of each atom; atoms of one class are compared with their class's mean target, since
            the layout may place any of them at any of their places, so the choice never depends on the atom order.

    Returns:
        The turned positions, about the same centre.
    """
    centre = points.mean(axis=0)
    moved, aim = points - centre, target - target.mean(axis=0)
    classes = np.asarray(classes)
    aim = np.array([aim[classes == each].mean(axis=0) for each in classes])
    turns = [np.array([[c, -s], [s, c]]) for c, s in ((1, 0), (0, 1), (-1, 0), (0, -1))]
    maps = [turn @ np.diag((mirror, 1.0)) for turn in turns for mirror in (1.0, -1.0)]
    # The agreement of each map with the target: the overlap of the two point sets, which needs no common scale.
    best = max(maps, key=lambda each: float(np.sum((moved @ each.T) * aim)))
    return moved @ best.T + centre


def _arranged(points, shown, bonds):
    """A matched drawing put in the arrangement of the 3D view: each fragment, a set of atoms joined by bonds, turned
    and mirrored onto its own projection and centred where the projection has it, since RDKit lays fragments out side
    by side whatever their places in space. Fragments that would overlap are pushed apart along the line between their
    centres until their nearest atoms are a bond and a half apart.

    Args:
        points: (N, 2) positions of the drawing, a bond of about 1.5.
        shown: (N, 2) projected positions of the same atoms in angstrom, a bond of about 1.5 too.
        bonds: Zero-based pairs among the N atoms.

    Returns:
        The arranged positions.
    """
    pieces, left = [], set(range(len(points)))
    while left:
        stack, piece = [left.pop()], set()
        while stack:
            atom = stack.pop()
            piece.add(atom)
            for a, b in bonds:
                other = b if a == atom else a if b == atom else None
                if other is not None and other in left:
                    left.discard(other)
                    stack.append(other)
        pieces.append(sorted(piece))
    if len(pieces) == 1:
        return _aligned(points, shown)
    placed = np.array(points, dtype=float)
    for piece in pieces:
        placed[piece] = _aligned(placed[piece], shown[piece]) if len(piece) > 1 else shown[piece]
    # Larger fragments stay; each smaller one moves off any it overlaps.
    pieces.sort(key=len, reverse=True)
    for number, piece in enumerate(pieces[1:], start=1):
        for _ in range(100):
            others = [atom for earlier in pieces[:number] for atom in earlier]
            gaps = np.linalg.norm(placed[piece][:, None] - placed[others][None], axis=-1)
            if gaps.min() >= 2.25:
                break
            direction = placed[piece].mean(axis=0) - placed[others].mean(axis=0)
            norm = np.linalg.norm(direction)
            placed[piece] += (direction / norm if norm > 1e-9 else np.array([1.0, 0.0])) * 0.25
    return placed


def _molblock(elements, kept, points, bonds, assigned, hydrogens):
    """Molfile of one connectivity on the shared layout.

    Args:
        elements: Element symbols of every atom.
        kept: Zero-based atoms drawn, in depiction order.
        points: Their 2D coordinates.
        bonds: Every bond of the connectivity as zero-based pairs.
        assigned: Bond orders and formal charges from ``_orders``, or None for single bonds.
        hydrogens: Hydrogens counted on each kept atom rather than drawn.

    Returns:
        The molfile text and the depicted bonds as pairs of depiction indices, in its bond order.
    """
    from rdkit import Chem

    position = {atom: index for index, atom in enumerate(kept)}
    mol = Chem.RWMol()
    for index, atom in enumerate(kept):
        drawn = Chem.Atom(elements[atom])
        drawn.SetNoImplicit(True)
        drawn.SetNumExplicitHs(hydrogens[index])
        if assigned:
            drawn.SetFormalCharge(assigned[1][atom])
        mol.AddAtom(drawn)
    types = {0: Chem.BondType.DATIVE, 1: Chem.BondType.SINGLE, 2: Chem.BondType.DOUBLE, 3: Chem.BondType.TRIPLE}
    table = Chem.GetPeriodicTable()
    pairs = []
    for number, (a, b) in enumerate(bonds):
        if a in position and b in position:
            order = assigned[0][number] if assigned else 1
            # A dative arrow points from the ligand to the metal, which has no default valence.
            if order == 0 and table.GetDefaultValence(table.GetAtomicNumber(elements[a])) == -1:
                a, b = b, a
            mol.AddBond(position[a], position[b], types.get(order, Chem.BondType.SINGLE))
            pairs.append([position[a], position[b]])
    conformer = Chem.Conformer(len(kept))
    conformer.Set3D(False)
    for index, (x, y) in enumerate(points):
        conformer.SetAtomPosition(index, (float(x), float(y), 0.0))
    mol = mol.GetMol()
    mol.UpdatePropertyCache(strict=False)
    mol.AddConformer(conformer, assignId=True)
    return Chem.MolToMolBlock(mol, kekulize=False), pairs


def _measure(kind, atoms, geometries):
    """Value of a measurement at every frame: a distance in angstrom, an angle or dihedral in degrees.

    Args:
        kind: ``distance``, ``angle`` or ``dihedral``.
        atoms: Zero-based atoms.
        geometries: (F, N, 3) frames in angstrom.

    Returns:
        One value per frame.
    """
    p = geometries[:, list(atoms)]
    if kind == "distance":
        return np.linalg.norm(p[:, 0] - p[:, 1], axis=-1).tolist()
    if kind == "angle":
        u, v = p[:, 0] - p[:, 1], p[:, 2] - p[:, 1]
        cosine = (u * v).sum(-1) / np.linalg.norm(u, axis=-1) / np.linalg.norm(v, axis=-1)
        return np.degrees(np.arccos(np.clip(cosine, -1, 1))).tolist()
    b1, b2, b3 = p[:, 1] - p[:, 0], p[:, 2] - p[:, 1], p[:, 3] - p[:, 2]
    n1, n2 = np.cross(b1, b2), np.cross(b2, b3)
    along = (np.cross(n1, n2) * b2).sum(-1) / np.linalg.norm(b2, axis=-1)
    return np.degrees(np.arctan2(along, (n1 * n2).sum(-1))).tolist()


def _rgb(color):
    """RGB fractions of a #rrggbb colour.

    Args:
        color: The colour.

    Returns:
        Three fractions.
    """
    return tuple(int(color[i : i + 2], 16) / 255 for i in (1, 3, 5))


def natural_size(blocks):
    """The canvas RDKit sizes for a molecule by itself, as the site's figures are drawn, for the largest of the
    depiction's molfiles, so the panel keeps one size across frames.

    Args:
        blocks: The molfiles, on one layout.

    Returns:
        Width and height in pixels.
    """
    from rdkit import Chem
    from rdkit.Chem.Draw import rdMolDraw2D

    sizes = []
    for block in blocks:
        trial = rdMolDraw2D.MolDraw2DSVG(-1, -1)
        trial.DrawMolecule(Chem.MolFromMolBlock(block, sanitize=False, removeHs=False))
        sizes.append((trial.Width(), trial.Height()))
    return max(w for w, _ in sizes), max(h for _, h in sizes)


def drawn_points(blocks, size, marks, pairs):
    """Where RDKit draws each atom of each molfile on the canvas the front end draws it on, with the marks highlighted
    as the front end highlights them: the same drawing, by the same RDKit release, so the places are the drawing's own.
    The front end reads places off its drawing itself where the drawing's bonds fix them, and adds these where they do
    not, as for lone molecules or a metal whose bonds all meet at it.

    Args:
        blocks: The molfiles.
        size: The canvas in pixels.
        marks: The depiction's marks, with depiction-index ``atoms`` and their ``kind``.
        pairs: Per molfile, its bonds as depiction-index pairs in molfile order.

    Returns:
        Per molfile, the (x, y) pixel position of each depicted atom, rounded to a tenth of a pixel.
    """
    from rdkit import Chem
    from rdkit.Chem.Draw import rdMolDraw2D

    found = []
    for block, bonds in zip(blocks, pairs):
        mol = Chem.MolFromMolBlock(block, sanitize=False, removeHs=False)
        atoms, links = set(), set()
        for mark in marks:
            members = mark["atoms"]
            atoms.update(members)
            chain = (
                [(a, b) for i, a in enumerate(members) for b in members[i + 1 :]]
                if mark["kind"] == "group"
                else list(zip(members, members[1:]))
            )
            for a, b in chain:
                for number, pair in enumerate(bonds):
                    if sorted(pair) == sorted((a, b)):
                        links.add(number)
        drawer = rdMolDraw2D.MolDraw2DSVG(*size)
        drawer.drawOptions().clearBackground = False
        drawer.drawOptions().atomHighlightsAreCircles = True
        # The front end's highlight radius of a marked atom.
        drawer.DrawMolecule(
            mol,
            highlightAtoms=sorted(atoms),
            highlightBonds=sorted(links),
            highlightAtomRadii={atom: 0.3 for atom in atoms},
        )
        points = [drawer.GetDrawCoords(index) for index in range(mol.GetNumAtoms())]
        found.append([[round(point.x, 1), round(point.y, 1)] for point in points])
    return found


def depiction(elements, geometries, *, charge=None, marks=(), values=(), scales=(), colors=()):
    """The depiction a viewer's front end draws below it, cached by the frames, charge and marks.

    Args:
        elements: Element symbols in atom order.
        geometries: Frames as (N, 3) arrays in angstrom, all of the same atoms.
        charge: Total charge of the molecule, for the bond orders and formal charges; None finds the smallest charge
            that gives a valid structure.
        marks: Mappings with ``kind`` (``distance``, ``angle``, ``dihedral`` or ``group``), one-based ``atoms`` and
            an optional LaTeX ``label``; measured kinds are evaluated at every frame.
        values: Sets of one value per viewer atom, such as charges or each snapshot's orbital shares, each drawn as
            RDKit's similarity map of every molfile; a hidden hydrogen's value is added to its heavy atom's.
        scales: The (lower, upper) colour range of each set, as the viewer colours its atoms.
        colors: The viewer's colours from the lower to the upper end of the scale.

    Returns:
        The depiction, keyed as commented below; empty when RDKit cannot draw the molecule, so the viewer still shows.
    """
    geometries = np.asarray(geometries, dtype=float)
    key = hashlib.sha256(
        json.dumps(
            [
                list(elements),
                charge,
                [dict(mark) for mark in marks],
                [np.round(np.asarray(each, dtype=float), 6).tolist() for each in values],
                [list(map(float, scale)) for scale in scales],
                list(colors),
            ],
            sort_keys=True,
            default=str,
        ).encode()
        + np.round(geometries, 4).tobytes()
        # The code and settings that draw it, so a change to either never serves an old depiction.
        + Path(__file__).read_bytes()
        + files(__package__).joinpath("data", "depiction.yaml").read_bytes()
    ).hexdigest()
    cached = cache_folder("depictions") / f"{key}.json"
    if cached.exists():
        return json.loads(cached.read_text())
    try:
        if importlib.util.find_spec("rdkit"):
            found = _depiction(list(elements), geometries, None if charge is None else int(charge), list(marks))
        else:
            # Without RDKit, as in the calculation viewer's in-browser Python, the bonds are found here and RDKit.js
            # lays them out on the page.
            found = _unlaid(list(elements), geometries, list(marks))
        if len(values):
            # Per value set, each depicted atom's weight on each molfile; the range of its colours; the colours, from
            # the lower to the upper end; and how the field is drawn, from data/depiction.yaml.
            found["maps"] = _maps(found, values)
            found["map_scales"] = [[float(low), float(high)] for low, high in scales]
            found["map_colors"] = list(colors)
            found["map"] = dict(SETTINGS["map"])
    except Exception as error:  # noqa: BLE001
        # A depiction is an addition to the viewer: a molecule RDKit cannot draw leaves the 3D view working.
        LOGGER.warning("No depiction for a viewer", extra={"metadata": {"reason": repr(error)}})
        return {}
    cached.parent.mkdir(parents=True, exist_ok=True)
    cached.write_text(json.dumps(found))
    return found


def _maps(found, values):
    """The weights of every value set on every molfile of a depiction, which the front end draws as RDKit's
    similarity map: a Gaussian of each depicted atom's weight, filled, in the drawing's own frame.

    Args:
        found: The depiction.
        values: Sets of one value per viewer atom.

    Returns:
        Per value set, the weight of each depicted atom on each molfile, a hidden hydrogen's value added to the heavy
        atom it is counted on.
    """
    kept = found["atoms"]
    position = {atom: index for index, atom in enumerate(kept)}
    maps = []
    for chosen in values:
        chosen = np.asarray(chosen, dtype=float)
        weights = chosen[kept].copy()
        for light, heavy in found["hydrogens"]:
            weights[position[heavy]] += chosen[light]
        rounded = [round(float(weight), 6) for weight in weights]
        maps.append([rounded for _ in found["molblocks"]])
    return maps


def _marks(marks, kept, geometries):
    """A depiction's marks: each measurement or group on the drawn atoms, measured at every frame.

    Args:
        marks: Measurements and groups, one-based viewer atoms.
        kept: The drawn atoms, zero-based.
        geometries: Frames in angstrom.

    Returns:
        The marks, keyed as commented.
    """
    keep = set(kept)
    found_marks = []
    for mark in marks:
        atoms = [atom - 1 for atom in mark["atoms"]]
        entry = {
            # What the mark is: a measured distance, angle or dihedral, or a named group of atoms.
            "kind": mark["kind"],
            # Its atoms as depiction indices.
            "atoms": [kept.index(atom) for atom in atoms if atom in keep],
            # Its label: Markdown with $...$ LaTeX for a group, empty for none.
            "label": mark.get("label", "") if mark["kind"] == "group" else "",
        }
        if mark["kind"] in ("distance", "angle", "dihedral"):
            # Its LaTeX symbol without dollar signs: the one given, or the kind's own with the viewer's one-based atom
            # numbers as subscript, so two distances never read alike.
            given = mark.get("label", "").strip().strip("$")
            base = {"distance": "r", "angle": r"\theta", "dihedral": r"\varphi"}[mark["kind"]]
            entry["symbol"] = given or f"{base}_{{{','.join(str(atom) for atom in mark['atoms'])}}}"
            # Its value at every frame, in angstrom or degrees.
            entry["values"] = [round(v, 4) for v in _measure(mark["kind"], atoms, geometries)]
        found_marks.append(entry)
    return found_marks


def _drawn(elements, every, marks):
    """Which atoms a depiction draws, and where the hydrogens it does not draw are counted.

    Args:
        elements: Element symbols.
        every: The bonds of every frame, from ``_connectivities``.
        marks: Measurements and groups, one-based.

    Returns:
        The drawn atoms, zero-based in atom order, and each undrawn hydrogen's heavy atom.
    """
    connectivities = list(dict.fromkeys(every))
    marked = {atom - 1 for mark in marks for atom in mark["atoms"]}
    hydrogen = {i for i, e in enumerate(elements) if e == "H"}
    # Each hydrogen's usual heavy-atom partner, the one it is bonded to in most frames. A hydrogen is drawn when some
    # frame bonds it to another heavy atom without its usual one, as in a proton transfer; one that only stretches away,
    # or touches a second atom while keeping its own, as a large vibration makes it, is counted on its usual partner.
    tally = {i: Counter() for i in hydrogen}
    for bonds in every:
        for a, b in bonds:
            for light, heavy in ((a, b), (b, a)):
                if light in hydrogen and heavy not in hydrogen:
                    tally[light][heavy] += 1
    usual = {i: tally[i].most_common(1)[0][0] for i in hydrogen if tally[i]}

    def transferred(light):
        """Whether some frame bonds a hydrogen to another heavy atom without its usual one."""
        for bonds in connectivities:
            heavy = {b if a == light else a for a, b in bonds if light in (a, b)} - hydrogen
            if heavy and usual[light] not in heavy:
                return True
        return False

    moving = {i for i in usual if transferred(i)}
    # A hydrogen bonded to no heavy atom, as in H2 or a lone H atom, stays drawn too.
    kept = [i for i in range(len(elements)) if i not in hydrogen or i in marked or i in moving or i not in usual]
    return kept, {light: usual[light] for light in sorted(hydrogen - set(kept))}


def _depiction(elements, geometries, charge, marks):
    """Build the depiction; see ``depiction``.

    Args:
        elements: Element symbols.
        geometries: Frames in angstrom.
        charge: Total charge.
        marks: Measurements and groups, one-based.

    Returns:
        The depiction.
    """
    every = _connectivities(elements, geometries)
    connectivities = list(dict.fromkeys(every))
    frames = [connectivities.index(bonds) for bonds in every]
    # The bonds most frames share set the orientation every drawing is turned onto.
    common = Counter(every).most_common(1)[0][0]
    kept, counted = _drawn(elements, every, marks)
    keep = set(kept)
    # Each set of bonds gets its own depiction, since bonds that differ, as along a reaction or between snapshots of
    # different structures, cannot share one set of 2D positions; each is then turned onto the depiction of the most
    # common bonds, so every drawing of the viewer keeps one orientation.
    drawn_bonds = lambda bonds: [(a, b) for a, b in bonds if a in keep and b in keep]
    # The 3D view first shows a frame's x and y, looking down z: the drawing faces that projection of the first frame
    # with the most common bonds, so the structure and its drawing face the same way.
    shown = geometries[every.index(common)][kept, :2]

    def laid_out(bonds):
        """The drawing of one set of bonds, mimicking the first frame that has them, or None."""
        return _matched(elements, kept, drawn_bonds(bonds), geometries[every.index(bonds)])

    matched = laid_out(common)
    if matched is not None:
        position = {atom: index for index, atom in enumerate(kept)}
        reference = _arranged(matched, shown, [(position[a], position[b]) for a, b in drawn_bonds(common)])
    else:
        from rdkit import Chem

        classes = list(Chem.CanonicalRankAtoms(_graph(elements, kept, drawn_bonds(common)), breakTies=False))
        reference = _faced(_layout(elements, kept, drawn_bonds(common)), shown, classes)
    drawings, pairs, assigned_all = [], [], []
    for number, bonds in enumerate(connectivities):
        own = None if bonds == common else laid_out(bonds)
        if own is None and bonds != common:
            own = _layout(elements, kept, drawn_bonds(bonds))
        points = reference if bonds == common else _aligned(own, reference)
        first = frames.index(number)
        assigned = _orders(elements, geometries[first], charge, bonds)
        counts = [0] * len(kept)
        position = {atom: index for index, atom in enumerate(kept)}
        for heavy in counted.values():
            counts[position[heavy]] += 1
        block, drawn = _molblock(elements, kept, points, bonds, assigned, counts)
        drawings.append(block)
        pairs.append(drawn)
        assigned_all.append(assigned is not None)
    size = natural_size(drawings)
    found_marks = _marks(marks, kept, geometries)
    return {
        # One molfile per distinct set of bonds, all on one layout.
        "molblocks": drawings,
        # Each molfile's bonds as depiction-index pairs, in molfile order.
        "bonds": pairs,
        # The molfile of each frame, by index; empty when every frame shares one.
        "frames": frames if len(connectivities) > 1 else [],
        # The viewer's zero-based atom of each depicted atom.
        "atoms": kept,
        # The canvas RDKit sizes for the molecule by itself, in pixels, as the site's figures are drawn.
        "size": list(size),
        # Per molfile, the pixel position of each depicted atom on that canvas.
        "points": drawn_points(drawings, size, found_marks, pairs),
        # Measurements and groups, as described above.
        "marks": found_marks,
        # Each hydrogen not drawn and the heavy atom it is counted on, as viewer atoms.
        "hydrogens": [[light, heavy] for light, heavy in counted.items()],
        # Whether each molfile has assigned bond orders; one without is drawn with single bonds.
        "orders": assigned_all,
    }


def _unlaid(elements, geometries, marks):
    """The depiction without RDKit, for RDKit.js to lay out on the page: the bonds of each frame by the same rule,
    each set written as a molfile of single bonds placed on the projection the 3D view first shows, looking down z,
    which the front end replaces with RDKit.js's own layout; see ``depiction`` for the keys.

    Args:
        elements: Element symbols.
        geometries: Frames in angstrom.
        marks: Measurements and groups, one-based.

    Returns:
        The depiction, with ``layout`` set to ``browser``.
    """
    every = _connectivities(elements, geometries)
    connectivities = list(dict.fromkeys(every))
    kept, counted = _drawn(elements, every, marks)
    position = {atom: index for index, atom in enumerate(kept)}
    counts = Counter(position[heavy] for heavy in counted.values())
    drawings, pairs = [], []
    for bonds in connectivities:
        drawn = [[position[a], position[b]] for a, b in bonds if a in position and b in position]
        points = geometries[every.index(bonds)][kept, :2]
        degree = Counter(index for pair in drawn for index in pair)
        # Each atom's valence, its drawn bonds and the hydrogens counted on it, is written in the molfile's valence
        # field, 15 for none, so RDKit.js labels the hydrogens there are rather than those a default valence implies.
        valence = [degree[index] + counts[index] or 15 for index in range(len(kept))]
        atoms = "".join(
            f"{x:10.4f}{y:10.4f}{0:10.4f} {elements[atom]:<3} 0  0  0  0  0{valence[index]:3d}  0  0  0  0  0  0\n"
            for index, (atom, (x, y)) in enumerate(zip(kept, points))
        )
        links = "".join(f"{a + 1:3d}{b + 1:3d}  1  0\n" for a, b in drawn)
        drawings.append(
            f"\n     molstarview\n\n{len(kept):3d}{len(drawn):3d}  0  0  0  0  0  0  0  0999 V2000\n"
            f"{atoms}{links}M  END\n"
        )
        pairs.append(drawn)
    return {
        "molblocks": drawings,
        "bonds": pairs,
        "frames": [connectivities.index(bonds) for bonds in every] if len(connectivities) > 1 else [],
        "atoms": kept,
        "marks": _marks(marks, kept, geometries),
        "hydrogens": [[light, heavy] for light, heavy in counted.items()],
        # No bond orders are assigned: every bond is drawn single.
        "orders": [False] * len(drawings),
        # The front end lays each molfile out with RDKit.js before drawing it.
        "layout": "browser",
    }

"""Isosurfaces of scalar fields, coloured or not by a second field, and the views a viewer shows of them."""

import base64
from dataclasses import dataclass
from functools import cached_property
from itertools import product

import numpy as np
from runflow.results import ureg, xyz_frames

from molstarview import store
from molstarview.grid import CubeGrid, _encoded
from molstarview.scene import build_scene
from molstarview.validation import check_distances


@dataclass(frozen=True, kw_only=True)
class VolumeSurface:
    """A scalar isosurface with an optional registered field for color mapping.

    Attributes:
        grid: The field whose level set is drawn.
        isovalue: The level of the surface in the field's units; for a signed surface, the magnitude of both levels.
        color_grid: A second field on the same grid that colours the surface, or None for a uniform colour.
        color_factor: The factor that converts ``color_grid`` to the units of the colour scale.
        signed: Whether the surface is drawn at both +isovalue and -isovalue, in the negative and positive end colours.
        floor: The smallest level the viewer's settings may choose, which keeps every point at or above it in the
            displayed box; None fixes the surface at ``isovalue``.
    """

    grid: CubeGrid
    isovalue: float
    color_grid: CubeGrid | None = None
    color_factor: float = 1.0
    # Whether the surface is drawn at both +isovalue and -isovalue of a signed field such as an orbital, in the
    # negative and positive end colours, instead of at one isovalue.
    signed: bool = False
    # Smallest contour level the viewer's settings may choose, which keeps every point at or above it in the
    # displayed box; None fixes the surface at ``isovalue``.
    floor: float | None = None

    def __post_init__(self):
        """Require finite contour parameters and matched source grids for scalar coloring.

        Raises:
            ValueError: If the isovalue or colour factor is not finite, the floor is not between zero and the isovalue, or
                the colour grid differs from the surface's grid in origin, axes, atoms or shape.
        """
        if not np.isfinite(self.isovalue) or not np.isfinite(self.color_factor):
            raise ValueError("Contour level and color conversion must be finite.")
        if self.floor is not None and not 0 < self.floor <= abs(self.isovalue):
            raise ValueError("An adjustable level needs a floor between zero and the isovalue.")
        if self.color_grid is not None:
            for attribute in ("origin", "axes", "atoms"):
                if not np.array_equal(getattr(self.grid, attribute), getattr(self.color_grid, attribute)):
                    raise ValueError(f"Surface and color field have different {attribute}.")
            if self.grid.values.shape != self.color_grid.values.shape:
                raise ValueError("Surface and color fields must share their source grid.")

    @classmethod
    def enclosing(cls, grid, share=0.9, power=1, **options):
        r"""A signed surface at the level whose region of larger magnitude holds ``share`` of
        :math:`\int|f|^p\,\mathrm{d}V` over the grid, with the settings' floor an eighth of that level. With ``power``
        :math:`p=2` an orbital's surfaces enclose that share of its density, whatever its size or how diffuse it is;
        with :math:`p=1` a density or a product of orbitals encloses that share of its magnitude.

        Args:
            grid: The field.
            share: Share of the integral the surface encloses, above zero and below one.
            power: The power of the magnitude that is integrated.
            **options: Further fields of the surface, such as a colour grid.

        Returns:
            The surface.
        """
        magnitudes = np.sort(np.abs(grid.values).ravel())[::-1]
        total = np.cumsum(magnitudes**power)
        level = float(magnitudes[min(np.searchsorted(total, share * total[-1]), len(magnitudes) - 1)])
        return cls(grid=grid, isovalue=level, signed=True, floor=level / 8, **options)

    @cached_property
    def lowest_level(self):
        """The smallest level the settings may choose, in the field's units. It is the floor, raised just above the largest
        magnitude near the source grid's faces when the field there exceeds it, so no chosen surface or fog reaches the
        grid's edge, or None for a fixed level.

        Returns:
            float or None
        """
        if self.floor is None:
            return None
        # The outer three layers: the displayed box adds two layers around the chosen region and must stay inside.
        values = np.abs(self.grid.values)
        faces = max(float(values.take(layers, axis).max()) for axis in range(3) for layers in ([0, 1, 2], [-3, -2, -1]))
        return min(max(self.floor, 1.05 * faces), abs(self.isovalue))

    @cached_property
    def display_grids(self):
        """Crop vacuum and retain the original coloring samples; the viewer makes the surface smooth from this grid.

        The box holds every point a level at or above the lowest level can reach, with four layers around it. The value
        is the cropped grid of the field and the matching grid of the colour field, or None without one.

        Returns:
            tuple

        Raises:
            ValueError: If the grid holds no point at the level, or the surface reaches the original cube's boundary.
        """
        # The box holds every point a chosen level can reach: those at or above the floor of an adjustable one.
        level = self.isovalue if self.floor is None else np.copysign(self.lowest_level, self.isovalue)
        if self.signed:
            mask = np.abs(self.grid.values) >= abs(level)
        else:
            mask = self.grid.values >= level if level >= 0 else self.grid.values <= level
        # Project the mask onto each axis instead of allocating coordinates for every occupied voxel.
        occupied = [np.flatnonzero(mask.any(axis=tuple(j for j in range(3) if j != axis))) for axis in range(3)]
        if not len(occupied[0]):
            raise ValueError("The grid does not contain the requested isosurface.")
        # Four layers beyond the region where the cube has them, so the viewer's spline, mirrored at the box's faces,
        # does not fold the surface back near them.
        if any(
            axis[0] == 0 or axis[-1] == size - 1 for axis, size in zip(occupied, self.grid.values.shape, strict=True)
        ):
            raise ValueError("The isosurface reaches the original cube boundary.")
        lower = np.maximum([axis[0] - 4 for axis in occupied], 0)
        upper = np.minimum([axis[-1] + 5 for axis in occupied], self.grid.values.shape)
        window = tuple(slice(int(a), int(b)) for a, b in zip(lower, upper, strict=True))
        origin = self.grid.origin + lower @ self.grid.axes
        contour = CubeGrid(origin, self.grid.axes, self.grid.atoms, self.grid.values[window])
        color = (
            None
            if self.color_grid is None
            else CubeGrid(origin, self.grid.axes, self.grid.atoms, self.color_grid.values[window] * self.color_factor)
        )
        return contour, color

    @cached_property
    def bounds(self):
        """The lower and upper Cartesian corners of the displayed field, as an array of shape (2, 3) in angstrom.

        Returns:
            numpy.ndarray
        """
        grid, _ = self.display_grids
        corners = np.asarray(list(product(*[(0, size - 1) for size in grid.values.shape])))
        positions = ((grid.origin + corners @ grid.axes) * ureg.bohr).to("angstrom").magnitude
        return np.asarray([positions.min(axis=0), positions.max(axis=0)])

    def color_limits(self):
        """The smallest and largest colour on the surface.

        Returns:
            The smallest and largest colour value on the surface, as floats in the colour field's units.

        Raises:
            ValueError: If the surface has no colour field, or no contour crossing is found.
        """
        values = self.color_samples()
        return float(values.min()), float(values.max())

    def color_quantile(self, share):
        """The magnitude of colour that ``share`` of the surface stays within, a scale that a few extreme points, as the
        potential near a nucleus, do not set.

        Args:
            share: Share of the surface's samples, from zero to one.

        Returns:
            The ``share`` quantile of the colour's magnitude on the surface, in the colour field's units.

        Raises:
            ValueError: If the surface has no colour field, or no contour crossing is found.
        """
        return float(np.quantile(np.abs(self.color_samples()), share))

    def color_samples(self):
        """Sample the color field at contour crossings using native trilinear interpolation.

        Returns:
            The colour at every crossing of the surface with the grid's edges, in the colour field's units.

        Raises:
            ValueError: If the surface has no colour field, or no contour crossing is found.
        """
        from scipy.ndimage import map_coordinates

        grid, color = self.display_grids
        if color is None:
            raise ValueError("A scalar color field is required to derive color limits.")
        samples = []
        for axis in range(3):
            lower, upper = [slice(None)] * 3, [slice(None)] * 3
            lower[axis], upper[axis] = slice(None, -1), slice(1, None)
            first, second = grid.values[tuple(lower)], grid.values[tuple(upper)]
            mask = (first < self.isovalue) != (second < self.isovalue)
            coordinates = np.asarray(np.nonzero(mask), dtype=float)
            coordinates[axis] += (self.isovalue - first[mask]) / (second[mask] - first[mask])
            samples.append(map_coordinates(color.values, coordinates, order=1, mode="nearest", prefilter=False))
        values = np.concatenate(samples)
        if not len(values):
            raise ValueError("No isosurface crossings were found.")
        return values

    def scene(self, *, height, distances):
        """The molecule and box a viewer of this surface shows, shared by all its views.

        Args:
            height: Viewer height in pixels.
            distances: Pairs of one-based atom numbers measured in the scene.

        Returns:
            The viewer's scene settings, a mapping of the scene archive, frame count, requested frame, distances, height
            and bounds.
        """
        atoms = self.display_grids[0].atoms
        return {
            "scene": build_scene(xyz_frames(atoms[:, 0].astype(int), (atoms[None, :, 2:] * ureg.bohr).to("angstrom"))),
            "frame_count": 1,
            "requested": 1,
            "distances": check_distances(distances, len(atoms)),
            "height": height,
            "bounds": self.bounds.tolist(),
        }

    def view(self, *, color_range, colors, opacity):
        """Encode the surface's fields and look for one view of a viewer, without writing derived files.

        Args:
            color_range: The values at the lower and upper end of the colour scale.
            colors: Hexadecimal colours of the scale, from its lower to its upper end.
            opacity: Opacity of the surface, above zero and at most one.

        Returns:
            A mapping with the encoded ``field`` and ``color_field``, the ``isovalue`` and ``field_scale`` of the units
            the field is written in, ``signed``, the adjustable ``level_range`` (empty for a fixed level), ``opacity``,
            ``color_range`` and ``colors``.
        """
        grid, color = self.display_grids
        # A contour field is written so its isovalue is a round number, the units the viewer's fog is tuned in.
        unit = abs(self.isovalue) / 200

        def payload(source, knee, written):
            """A compressed field for the viewer to decode: its address in the store (``molstarview.store``), or
            without a store the base64 text of the bytes themselves.

            Args:
                source: The grid to encode.
                knee: The magnitude below which the encoding is linear.
                written: The unit the decoded field is written in.

            Returns:
                The field's address in the store, or its base64 text.
            """
            data = _encoded(source, knee, written)
            return store.address(data) or base64.b64encode(data).decode()

        return {
            "field": payload(grid, (self.lowest_level or abs(self.isovalue)) / 2, unit),
            # A colour field has no level, so its knee follows its own range.
            "color_field": payload(color, max(float(np.abs(color.values).max()), 1e-30) / 1000, 1.0)
            if color is not None
            else "",
            # In the units the field is written in.
            "isovalue": self.isovalue / unit,
            "field_scale": unit,
            "signed": self.signed,
            # The levels the settings may choose, in the units the field is written in: from the floor to just below
            # the largest magnitude, where the surface vanishes; empty for a fixed level.
            "level_range": []
            if self.floor is None
            else [self.lowest_level / unit, 0.98 * float(np.abs(self.display_grids[0].values).max()) / unit],
            "opacity": opacity,
            "color_range": list(color_range),
            "colors": list(colors),
            "fields": [],
            "color_fields": [],
        }


def color_field_view(
    surfaces,
    *,
    isovalue=None,
    title,
    colors=("#d7301f", "#2b6cb0"),
    opacity=0.85,
    color_label="",
    field_name="",
    field_symbol="",
    field_unit="",
):
    """A view of the field that colours ``surfaces``, drawn in space as signed surfaces, for ``VolumeViewer``'s ``alternates``.

    The surfaces are at -``isovalue`` and +``isovalue`` in the colour field's units, in the end ``colors``; the
    settings lower the level to an eighth, as far as each field's box allows. An electrostatic potential on a density
    surface thus also shows where it is strongly negative or positive. Without an ``isovalue`` the level is the median
    magnitude of the colour over the surfaces, so the surfaces in space reach about as far as the surfaces it colours
    and bulge out where the field is stronger than over most of them.

    Args:
        surfaces: One ``VolumeSurface`` or a mapping of snapshot titles to them, each with a colour grid.
        isovalue: The level of the signed surfaces, in the colour field's units; by default the median colour
            magnitude over ``surfaces``.
        title: The title of the view, on the toolbar button that switches to it.
        colors: Hexadecimal colours of the negative and positive surfaces.
        opacity: Opacity of the surfaces, above zero and at most one.
        color_label: The quantity and unit shown above the colour scale.
        field_name: The name shown on the first line of a hover label; may hold ``$...$`` LaTeX.
        field_symbol: The symbol of the field, in LaTeX, before its value in hover labels.
        field_unit: The unit of the field, in LaTeX, after its value in hover labels.

    Returns:
        A mapping of the arguments ``VolumeViewer`` takes for an alternate view.
    """

    def in_space(surface):
        """The colour field of one surface as a signed surface of its own.

        Args:
            surface: A ``VolumeSurface`` with a colour grid.

        Returns:
            A signed, adjustable surface of the colour field in its units.
        """
        grid = surface.color_grid
        return VolumeSurface(
            grid=CubeGrid(grid.origin, grid.axes, grid.atoms, grid.values * surface.color_factor),
            isovalue=isovalue,
            signed=True,
            floor=isovalue / 8,
        )

    every = list(surfaces.values()) if isinstance(surfaces, dict) else [surfaces]
    if isovalue is None:
        isovalue = float(
            np.median(np.abs(np.concatenate([each.color_samples() * each.color_factor for each in every])))
        )
    shown = (
        {name: in_space(each) for name, each in surfaces.items()} if isinstance(surfaces, dict) else in_space(surfaces)
    )
    return {
        "title": title,
        "surface": shown,
        "color_range": (-isovalue, isovalue),
        "colors": colors,
        "opacity": opacity,
        "color_label": color_label,
        "field_name": field_name,
        "field_symbol": field_symbol,
        "field_unit": field_unit,
    }

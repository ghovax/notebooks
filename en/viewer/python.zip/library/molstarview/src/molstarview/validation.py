"""Checks of every viewer argument, which raise ``ValueError`` with the reason before anything reaches the browser."""

from numbers import Integral

import numpy as np


def choice_axes(keys, choices):
    """The dropdown axes of ``choices``, each snapshot key's option index on every axis, and its title.

    Each key is one value per choice, or a single value for one choice. The title joins the option texts. Every option
    of every choice must belong to some key.

    Args:
        keys: The snapshot keys, tuples of one value per choice, or single values when there is one choice.
        choices: Pairs of ``(label, {value: text})``, one per dropdown: its label and the text shown for each value,
            or triples with a mapping of flags: ``input`` makes it a text field in Molstar's form-control markup, where
            an option's text is typed, a number clamped to the nearest option allowed, for long runs such as atom
            numbers; ``collapse`` hides it while its first option, a placeholder such as "all atoms", is the only one
            that can be chosen.

    Returns:
        The axes as a list of triples of a label, its options and its flags; the indices, one list per key giving its
        option index on every axis; and the titles, one per key, joining its option texts with commas.

    Raises:
        ValueError: If the option texts of a choice are not distinct, a key does not give one listed option for every
            choice, or an option of a choice belongs to no key.
    """
    axes = [(str(choice[0]), dict(choice[1]), dict(choice[2]) if len(choice) > 2 else {}) for choice in choices]
    if any(set(flags) - {"input", "collapse"} for _, _, flags in axes):
        raise ValueError("A choice's flags are input and collapse.")
    if any(len(set(options.values())) != len(options) for _, options, _ in axes):
        raise ValueError("The options of one choice need distinct texts.")
    indices, titles = [], []
    for key in keys:
        key = key if isinstance(key, tuple) else (key,)
        if len(key) != len(axes) or any(value not in options for value, (_, options, _) in zip(key, axes)):
            raise ValueError("Each snapshot key needs one listed option for every choice.")
        indices.append([list(options).index(value) for value, (_, options, _) in zip(key, axes)])
        titles.append(", ".join(options[value] for value, (_, options, _) in zip(key, axes)))
    if any(len({index[axis] for index in indices}) != len(options) for axis, (_, options, _) in enumerate(axes)):
        raise ValueError("Every option of a choice needs at least one snapshot.")
    return axes, indices, titles


def check_distances(distances, count):
    """Validate unique one-based atom pairs for native distance measurements.

    Args:
        distances: Pairs of one-based atom numbers.
        count: The number of atoms.

    Returns:
        The pairs as lists of two integers.

    Raises:
        ValueError: If a pair is not two distinct atoms of the structure, or a pair repeats.
    """
    pairs = [list(pair) for pair in distances]
    for pair in pairs:
        if (
            len(pair) != 2
            or any(
                not isinstance(atom, Integral) or isinstance(atom, bool) or atom < 1 or atom > count for atom in pair
            )
            or pair[0] == pair[1]
        ):
            raise ValueError("Each distance must identify two distinct one-based atoms.")
    if len({tuple(sorted(pair)) for pair in pairs}) != len(pairs):
        raise ValueError("Distance pairs must be unique.")
    return pairs


def check_angles(angles, count):
    """Validate one-based atom triples of three distinct atoms, the vertex in the middle.

    Args:
        angles: Triples of one-based atom numbers.
        count: The number of atoms.

    Returns:
        The triples as lists of three integers.

    Raises:
        ValueError: If a triple is not three distinct atoms of the structure, or a triple repeats.
    """
    triples = [list(triple) for triple in angles]
    for triple in triples:
        if (
            len(triple) != 3
            or any(
                not isinstance(atom, Integral) or isinstance(atom, bool) or atom < 1 or atom > count for atom in triple
            )
            or len(set(triple)) != 3
        ):
            raise ValueError("Each angle must identify three distinct one-based atoms.")
    if len({tuple(triple) for triple in triples}) != len(triples):
        raise ValueError("Angle triples must be unique.")
    return [[int(atom) for atom in triple] for triple in triples]


def check_readouts(readouts, geometries, count):
    """Validate readouts and the label each draws at every frame, as the measurements and annotations they make.

    Args:
        readouts: Mappings with ``kind``, ``atoms``, ``label`` and the optional ``unit``, ``position``, ``size`` and
            ``offset``, as ``MolstarViewer`` takes them.
        geometries: Coordinates of every frame, one array of shape (atoms, 3) per frame, in angstrom.
        count: The number of atoms.

    Returns:
        A mapping with ``measurements`` (the kind and atoms of each readout) and ``annotations`` (each readout's
        LaTeX text and centre at every frame, with its size and offset).

    Raises:
        ValueError: If a readout is not a distance of two or an angle of three distinct atoms of the structure.
    """
    measurements, annotations = [], []
    for readout in readouts:
        kind = readout["kind"]
        atoms = [int(atom) for atom in readout["atoms"]]
        need = {"distance": 2, "angle": 3}.get(kind)
        if (
            need is None
            or len(atoms) != need
            or len(set(atoms)) != need
            or any(atom < 1 or atom > count for atom in atoms)
        ):
            raise ValueError("A readout is a distance of two or an angle of three distinct one-based atoms.")
        label, unit = str(readout["label"]), str(readout.get("unit", ""))
        position = float(readout.get("position", 0.5))
        size = float(readout.get("size", 0.28))
        offset = [float(value) for value in readout.get("offset", (0, 0))]
        texts, centers = [], []
        for xyz in geometries:
            points = xyz[np.asarray(atoms) - 1]
            if kind == "distance":
                texts.append(f"${label}={np.linalg.norm(points[1] - points[0]):.2f}\\,{unit}$")
                centers.append((points[0] + position * (points[1] - points[0])).tolist())
                continue
            arms = [points[0] - points[1], points[2] - points[1]]
            lengths = [float(np.linalg.norm(arm)) for arm in arms]
            real = [arm / length for arm, length in zip(arms, lengths) if length > 1e-6]
            value = 90.0 if len(real) < 2 else float(np.degrees(np.arccos(np.clip(real[0] @ real[1], -1, 1))))
            direction = sum(real) if real else np.zeros(3)
            norm = float(np.linalg.norm(direction))
            direction = direction / norm if norm > 1e-9 else (real[0] if real else direction)
            reach = min(length for length in lengths if length > 1e-6) if real else 0.0
            text = f"{value:.1f}".rstrip("0").rstrip(".")
            texts.append(f"${label}={text}^\\circ$")
            centers.append((points[1] + 0.3 * reach * direction).tolist())
        measurements.append(dict(kind=kind, atoms=atoms))
        annotations.append(dict(text=texts[0], texts=texts, atoms=[], centers=centers, size=size, offset=offset))
    return dict(measurements=measurements, annotations=annotations)


def check_markers(markers, count):
    """Validate groups of virtual atoms with a colour, size and optional hover label.

    Args:
        markers: Mappings with ``atoms``, ``color`` and the optional ``size``, ``label`` and ``visible``.
        count: The number of atoms.

    Returns:
        The markers with their atom numbers as integers, colour in lower case and every optional entry filled in.

    Raises:
        ValueError: If a marker has no valid atoms, shares an atom with another, has a colour not written #rrggbb or a
            size that is not positive.
    """
    checked, seen = [], set()
    for marker in markers:
        atoms, color = list(marker["atoms"]), marker["color"]
        size, label = float(marker.get("size", 0.09)), str(marker.get("label", ""))
        if not atoms or any(
            not isinstance(atom, Integral) or isinstance(atom, bool) or atom < 1 or atom > count for atom in atoms
        ):
            raise ValueError("Each marker must list valid one-based atoms.")
        if len(set(atoms)) != len(atoms) or seen & set(atoms):
            raise ValueError("Marker atoms must be unique and disjoint.")
        if not (isinstance(color, str) and len(color) == 7 and color.startswith("#") and int(color[1:], 16) >= 0):
            raise ValueError("A marker colour must be written #rrggbb.")
        if not size > 0:
            raise ValueError("A marker size must be positive.")
        seen |= set(atoms)
        checked.append(
            dict(
                atoms=[int(atom) for atom in atoms],
                color=color.lower(),
                size=size,
                label=label,
                visible=bool(marker.get("visible", True)),
            )
        )
    return checked


def check_groups(groups, count):
    """Validate labelled, disjoint one-based atom groups.

    Args:
        groups: Mappings with ``label`` and ``atoms``.
        count: The number of atoms.

    Returns:
        The groups with their labels stripped and their atom numbers as integers.

    Raises:
        ValueError: If a label is empty, a group has no valid atoms, or two groups share an atom.
    """
    checked, seen = [], set()
    for group in groups:
        label, atoms = group["label"], list(group["atoms"])
        if not isinstance(label, str) or not label.strip():
            raise ValueError("Each group needs a non-empty label.")
        if not atoms or any(
            not isinstance(atom, Integral) or isinstance(atom, bool) or atom < 1 or atom > count for atom in atoms
        ):
            raise ValueError("Each group must list valid one-based atoms.")
        if len(set(atoms)) != len(atoms) or seen & set(atoms):
            raise ValueError("Group atoms must be unique and disjoint.")
        seen |= set(atoms)
        checked.append(dict(label=label.strip(), atoms=[int(atom) for atom in atoms]))
    return checked


def color_atoms(values, count, color_range, colors):
    """Map one finite value per atom linearly onto the colour scale.

    Args:
        values: One number per atom, or None for none.
        count: The number of atoms.
        color_range: The values at the ends of the scale, or None for the largest magnitude of ``values`` either side
            of zero.
        colors: Hexadecimal colours of the scale, from its lower to its upper end.

    Returns:
        The colour of every atom as ``#rrggbb`` (empty without values) and the range used.

    Raises:
        ValueError: If ``values`` is not one finite number per atom, or the range does not increase or fewer than two
            colours are given.
    """
    if values is None:
        return [], color_range or (-1.0, 1.0)
    values = np.asarray(values, dtype=float)
    if values.shape != (count,) or not np.isfinite(values).all():
        raise ValueError("Give one finite value per atom.")
    if color_range is None:
        bound = float(np.abs(values).max()) or 1.0
        color_range = (-bound, bound)
    lower, upper = map(float, color_range)
    if not lower < upper or len(colors) < 2:
        raise ValueError("Give an increasing colour range and at least two colours.")
    stops = np.asarray([[int(c[i : i + 2], 16) for i in (1, 3, 5)] for c in colors], dtype=float)
    positions = np.clip((values - lower) / (upper - lower), 0, 1) * (len(colors) - 1)
    below = np.minimum(positions.astype(int), len(colors) - 2)
    mixed = stops[below] + (positions - below)[:, None] * (stops[below + 1] - stops[below])
    return ["#" + "".join(f"{round(v):02x}" for v in rgb) for rgb in mixed], (lower, upper)


def check_arrows(arrows):
    """Validate finite arrow end points with optional hex colours and tooltips.

    Args:
        arrows: Mappings with ``start`` and ``end`` and the optional ``color`` and ``tooltip``.

    Returns:
        The arrows with their end points as lists, a colour (default red) and a tooltip or None.

    Raises:
        ValueError: If an end point is not three finite numbers, a colour is not written #rrggbb or a tooltip is not
            text.
    """
    checked = []
    for arrow in arrows:
        start, end = (np.asarray(arrow[key], dtype=float) for key in ("start", "end"))
        if start.shape != (3,) or end.shape != (3,) or not np.isfinite([start, end]).all():
            raise ValueError("Each arrow needs finite three-component start and end points.")
        color, tooltip = arrow.get("color", "#d62728"), arrow.get("tooltip")
        if not (
            isinstance(color, str)
            and len(color) == 7
            and color.startswith("#")
            and all(c in "0123456789abcdefABCDEF" for c in color[1:])
        ):
            raise ValueError("Arrow colours must be #rrggbb strings.")
        if tooltip is not None and not isinstance(tooltip, str):
            raise ValueError("Arrow tooltips must be plain text.")
        checked.append(dict(start=start.tolist(), end=end.tolist(), color=color, tooltip=tooltip))
    return checked

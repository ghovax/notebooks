"""Gaussian route sections: keywords with their options, the request each linked job makes, and the input
sections it asks for.

A route is read the way Gaussian reads it, so job types and their options come from Gaussian's own keywords
instead of labels typed beside the input.
"""

import re

from .text import split_items, unwrap

# Gaussian's job-type keywords; a route without one is a single point.
JOB_TYPES = ("opt", "freq", "irc", "ircmax", "scan", "polar", "admp", "bomd", "force", "stable", "volume")


# Excited-state methods whose NStates and Root select the states.
EXCITED_METHODS = ("td", "tda", "cis")


# Gaussian's defaults when NStates or Root is not given.
DEFAULT_STATES, DEFAULT_ROOT = 3, 1


def route_keywords(route):
    """Route keywords in Gaussian's syntax, without the leading #, #p, #n or #t.

    Options attach to their keyword as keyword=option, keyword(option), keyword=(options) or
    keyword (options), with optional spaces around the equals sign. A model chemistry, method/basis,
    has its slash before any option and comes back whole, with no option.

    Args:
        route: Route text of one linked job.

    Returns:
        (name, options) pairs in route order; options are empty for a bare keyword.
    """
    route = re.sub(r"\s*=\s*", "=", route.strip())
    route = re.sub(r"(\w)\s+\(", r"\1(", route)
    keywords = []
    for item in split_items(route):
        item = re.sub(r"^#[pPnNtT]?", "", item)
        if not item:
            continue
        if re.match(r"^[^=(]+/", item):
            keywords.append((item, ""))
            continue
        name, _, value = re.sub(r"^([^=(]+)\((.*)\)$", r"\1=(\2)", item).partition("=")
        keywords.append((name, value))
    return keywords


def keyword_options(options):
    """Options of one keyword as lowercase names mapped to their values.

    Args:
        options: Option text of one keyword, with or without parentheses.

    Returns:
        Lowercase option names mapped to their values, empty for a bare option.
    """
    pairs = (option.partition("=") for option in split_items(unwrap(options)))
    return {name.lower(): value for name, _, value in pairs}


def request(route):
    """What one linked job asks Gaussian to do, read from its route.

    Args:
        route: Route text of one linked job.

    Returns:
        ``jobs``, the job types in route order, ``["sp"]`` without one; ``options``, each job type's options,
        such as ``{"opt": {"ts": "", "calcfc": ""}}``; ``excited``, the excited-state method with its number of
        states and selected root, Gaussian's defaults filled in, or None for the ground state.
    """
    keywords = {}
    for name, options in route_keywords(route):
        if "/" not in name or options:
            keywords[name.lower()] = keyword_options(options)
    jobs = [name for name in keywords if name in JOB_TYPES]
    method = next((name for name in keywords if name in EXCITED_METHODS), None)
    excited = None
    if method:
        settings = keywords[method]
        excited = {
            # Excited-state method keyword, such as td.
            "method": method,
            # Number of excited states solved.
            "states": int(settings.get("nstates") or DEFAULT_STATES),
            # One-based state followed by optimizations, frequencies and properties.
            "root": int(settings.get("root") or DEFAULT_ROOT),
        }
    return {
        # Job types in route order; a route without one is a single point.
        "jobs": jobs or ["sp"],
        # Options of each job type as lowercase names mapped to their values.
        "options": {name: keywords[name] for name in jobs},
        # Excited-state method, states and root, or None for the ground state.
        "excited": excited,
    }


def input_routes(text):
    """Route of every linked job in a Gaussian input, in order.

    Args:
        text: Gaussian input text.

    Returns:
        One route per linked job, with lines joined by spaces.
    """
    routes = []
    for section in text.split("--Link1--"):
        lines = section.splitlines()
        start = next((index for index, line in enumerate(lines) if line.lstrip().startswith("#")), None)
        if start is None:
            continue
        end = next((index for index in range(start, len(lines)) if not lines[index].strip()), len(lines))
        routes.append(" ".join(line.strip() for line in lines[start:end]))
    return routes


def _asks(names, option, shortest):
    """Whether a set of route options names one, written in full or abbreviated as Gaussian accepts.

    Args:
        names: Lower-case option names.
        option: The option in full, lower case.
        shortest: Fewest letters an abbreviation may have.

    Returns:
        True when some name is the option or an abbreviation of it.
    """
    return any(option.startswith(name) and len(name) >= shortest for name in names)


def route_sections(route):
    """Which of these sections a route asks for, from the options of its Opt and Geom keywords.

    Args:
        route: Route text of one linked job.

    Returns:
        ``connectivity`` (``Geom=Connectivity`` or ``ModConnectivity``), ``read_optimize`` (``ReadOptimize`` of Opt
        or Geom, or the older ``ReadFreeze``), ``modredundant`` (``ModRedundant`` of Opt or Geom) and ``structures``
        (3 for ``Opt=QST3``, 2 for ``QST2``, else 1); the first three are booleans.
    """
    names = dict(opt=set(), geom=set())
    for name, options in route_keywords(route):
        if name.lower() in names:
            names[name.lower()] |= {item.partition("=")[0].strip().lower() for item in split_items(unwrap(options))}
    both = names["opt"] | names["geom"]
    return dict(
        connectivity=any(_asks(names["geom"], option, 7) for option in ("connectivity", "modconnectivity")),
        read_optimize=any(_asks(both, option, 5) for option in ("readoptimize", "readfreeze"))
        or bool({"rdopt", "rdfreeze"} & both),
        modredundant=_asks(both, "modredundant", 6),
        structures=3 if "qst3" in names["opt"] else 2 if "qst2" in names["opt"] else 1,
    )


# What a route asks of the GIC machinery: the option that builds or reads coordinates, by Gaussian's own option name.
GIC_OPTIONS = dict(readallgic="read-all", addgic="add", gic="automatic", gicold="old")


# Modes whose job reads a GIC input section after its geometry.
SECTION_MODES = ("read-all", "add")


def gic_mode(route):
    """How a route builds its generalized internal coordinates.

    Options of ``Opt`` and ``Geom`` are read together: ``ModRedundant`` combined with ``GIC`` is ``AddGIC``, as the
    manual says, and ``ReadAllGIC`` outranks the others.

    Args:
        route: Route text of one linked job.

    Returns:
        ``read-all`` (the section defines every coordinate), ``add`` (the section changes the default ones),
        ``automatic`` (``GIC`` builds them without a section), ``old`` (``GICOld``), or None without any GIC option.
    """
    found = set()
    for name, options in route_keywords(route):
        if name.lower() in ("opt", "geom"):
            names = {item.partition("=")[0].lower() for item in split_items(unwrap(options))}
            found |= {GIC_OPTIONS[item] for item in names if item in GIC_OPTIONS}
            if "modredundant" in names and "gic" in names:
                found.add("add")
    for mode in ("read-all", "add", "old", "automatic"):
        if mode in found:
            return mode
    return None

"""Point groups of molecular geometries, and the symmetry of orbitals and excited states in them.

Gaussian labels orbitals and states in the largest Abelian subgroup of the point group it detects, and only when the
input coordinates are symmetric within its own tolerance; coordinates read back from an optimization often miss it, so
a symmetric molecule is labelled in a small subgroup or not at all. This module finds the full point group of the
geometry itself and labels in it.

Every finite point group is handled the same way:

- Operations: every symmetry operation maps the inertia tensor onto itself, so rotation axes and mirror normals are
  sought among the principal axes for an asymmetric top, the unique axis and directions perpendicular to it for a
  symmetric top, and directions through atoms, pair midpoints and their cross products for a spherical top. Proper and
  improper rotations of every order about each direction are tested, and the operations found are closed under
  multiplication. A linear molecule's infinite group is represented by a finite fan of its operations.
- Character table: every irreducible representation occurs among the polynomials of some degree in x, y and z, with or
  without the determinant of the operation as a factor. Those representations are made orthogonal with their
  invariant inner product and split through an operator that commutes with every operation, until the squared
  dimensions add up to the group order. A pair of complex-conjugate representations is kept together as one real
  representation, as Mulliken's E.
- Names: Mulliken's rules. A, B, E, T, G and H by dimension; A or B by the principal rotation, or by S_2n when it
  outranks the proper axis and the group has no inversion; with several principal axes, all C2 as in D2, B1, B2 and B3
  by the axis each is symmetric to, otherwise A; subscripts 1 and 2 by the primary perpendicular C2 axis, else the
  primary vertical plane, else the first operation that separates them; E indices from the character of the
  principal rotation, T1 for the representation of rotations; g and u by inversion, primes by the horizontal plane;
  Sigma, Pi and Delta for linear molecules.
- Axes (Mulliken, 1955): the primary perpendicular C2 axis or vertical plane passes through the most atoms; in a planar
  molecule with C2v or D2h symmetry the x axis is perpendicular to the plane.
"""

from dataclasses import dataclass, field
from itertools import combinations

import numpy as np

# Letters of the representations by dimension.
LETTERS = {1: "A", 2: "E", 3: "T", 4: "G", 5: "H"}


# Greek names of the linear-molecule representations by angular momentum about the axis.
LINEAR = {1: r"\Pi", 2: r"\Delta", 3: r"\Phi", 4: r"\Gamma"}


# Highest rotation order sought, and the finite order standing for a linear molecule's infinite axis.
MAXIMUM_ORDER, LINEAR_ORDER = 12, 8


@dataclass
class Irrep:
    """An irreducible representation: its LaTeX Mulliken label, dimension and character under each operation."""

    label: str
    dimension: int
    characters: np.ndarray

    def orbital(self):
        r"""Lower-case label for orbitals, such as :math:`e_{1g}` for :math:`E_{1g}`.

        Returns:
            The label in LaTeX, with Greek capitals of linear molecules in lower case, such as \sigma for \Sigma.
        """
        return _lower(self.label)


@dataclass
class PointGroup:
    """Point group of a geometry: its LaTeX Schoenflies name, the operations as 3x3 matrices in the input frame with
    the atom each atom moves to, the frame whose rows are the x, y and z axes, the irreducible representations, the
    normal of the molecular plane (None unless planar), and the representations of the dipole components.
    """

    name: str
    operations: list
    permutations: list
    frame: np.ndarray
    irreps: list
    planar: np.ndarray = None
    linear: bool = False
    dipole: dict = field(default_factory=dict)

    @property
    def order(self):
        """Number of symmetry operations of the group.

        Returns:
            The group order, the length of ``operations``.
        """
        return len(self.operations)

    def reduce(self, characters):
        """Multiplicity of every irreducible representation in a representation of these characters.

        Args:
            characters: Character of the representation under each operation, in the order of ``operations``.

        Returns:
            One multiplicity per irreducible representation, in the order of ``irreps``; integers up to numerical noise
            for a genuine representation.
        """
        return [
            float(np.dot(irrep.characters, characters) / np.dot(irrep.characters, irrep.characters))
            for irrep in self.irreps
        ]

    def assign(self, characters, dimension, tolerance=0.2):
        """The irreducible representation of these characters, or None when they are not one within ``tolerance``.

        Args:
            characters: Character under each operation, in the order of ``operations``.
            dimension: Dimension the representation must have, which separates a real pair from a one-dimensional one.
            tolerance: Largest distance of a multiplicity from one, and from zero for the others.

        Returns:
            The matching irreducible representation, or None.
        """
        counts = self.reduce(characters)
        best = int(np.argmax(counts))
        rest = [count for index, count in enumerate(counts) if index != best]
        if (
            abs(counts[best] - 1) < tolerance
            and all(abs(count) < tolerance for count in rest)
            and self.irreps[best].dimension == dimension
        ):
            return self.irreps[best]
        return None


def _rotation(axis, angle):
    """Proper rotation about an axis.

    Args:
        axis: Direction of the axis, of shape (3,); it need not be normalized.
        angle: Rotation angle in radians, counter-clockwise about the axis.

    Returns:
        The 3 x 3 rotation matrix, by Rodrigues' formula.
    """
    axis = axis / np.linalg.norm(axis)
    k = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
    return np.eye(3) + np.sin(angle) * k + (1 - np.cos(angle)) * k @ k


def _reflection(normal):
    """Reflection through the plane of a normal.

    Args:
        normal: Normal of the mirror plane, of shape (3,); it need not be normalized.

    Returns:
        The 3 x 3 reflection matrix.
    """
    normal = normal / np.linalg.norm(normal)
    return np.eye(3) - 2 * np.outer(normal, normal)


def _permutation(matrix, numbers, coordinates, tolerance):
    """Atom each atom moves to under the operation, or None when it does not map the molecule onto itself.

    Args:
        matrix: 3 x 3 orthogonal matrix of the operation, acting on column vectors.
        numbers: Atomic numbers, of shape (N,); an atom only moves to one of the same element.
        coordinates: Atom positions, of shape (N, 3), relative to the centre of the operation.
        tolerance: Largest distance between a moved atom and the atom it lands on.

    Returns:
        Index of the target atom of every atom, of shape (N,), or None when an atom lands farther than the tolerance or
        two atoms land on one.
    """
    moved = coordinates @ matrix.T
    distances = np.linalg.norm(moved[:, None, :] - coordinates[None, :, :], axis=2)
    distances[numbers[:, None] != numbers[None, :]] = np.inf
    target = distances.argmin(axis=1)
    if distances[np.arange(len(numbers)), target].max() > tolerance or len(set(target)) != len(target):
        return None
    return target


def _unit(vectors):
    """Distinct unit directions of the nonzero vectors, a direction and its opposite counted once, in first-seen order.

    Args:
        vectors: Vectors, of any shape ending in 3; those shorter than 1e-6 are dropped.

    Returns:
        List of unit vectors, each with its first clearly nonzero component positive.
    """
    vectors = np.asarray(vectors, dtype=float).reshape(-1, 3)
    norms = np.linalg.norm(vectors, axis=1)
    vectors = vectors[norms > 1e-6] / norms[norms > 1e-6, None]
    if not len(vectors):
        return []
    # A sign that makes the first clearly nonzero component positive, so opposite directions coincide.
    lead = np.argmax(np.abs(vectors) > 1e-4, axis=1)
    vectors = vectors * np.sign(vectors[np.arange(len(vectors)), lead])[:, None]
    _, first = np.unique(np.round(vectors, 4), axis=0, return_index=True)
    return list(vectors[np.sort(first)])


def describe(matrix):
    """Kind, axis and angle of an operation.

    ('rotation', axis, angle) is a proper rotation by the angle, and ('improper', axis, angle) the reflection through
    the plane normal to the axis after rotation by the angle: angle 0 is a mirror plane, pi the inversion. Angles lie in
    [0, pi]; the identity has no axis.

    Args:
        matrix: 3 x 3 orthogonal matrix of the operation.

    Returns:
        The kind, 'rotation' or 'improper'; the unit axis, or None for the identity and for the inversion's rotation
        part; and the angle in radians.
    """
    proper = np.linalg.det(matrix) > 0
    rotation = matrix if proper else -matrix
    angle = float(np.arccos(np.clip((np.trace(rotation) - 1) / 2, -1, 1)))
    if angle < 1e-6:
        axis = None
    else:
        values, vectors = np.linalg.eig(rotation)
        axis = np.real(vectors[:, np.argmin(abs(values - 1))])
        axis /= np.linalg.norm(axis)
    return ("rotation", axis, angle) if proper else ("improper", axis, np.pi - angle)


def _directions(numbers, coordinates, moments, axes, linear):
    """Directions that may carry a rotation axis or mirror normal, from the shape of the inertia tensor.

    Args:
        numbers: Atomic numbers, of shape (N,).
        coordinates: Atom positions relative to the centre of mass, of shape (N, 3).
        moments: Principal moments of inertia, of shape (3,), in ascending order.
        axes: Principal axes as the columns of a 3 x 3 matrix, in the order of the moments.
        linear: Whether the molecule is linear, whose infinite group is represented by a finite fan of directions.

    Returns:
        Candidate directions: the principal axes of an asymmetric top, the unique axis with directions perpendicular to
        it for a symmetric top, and directions through atoms, pair midpoints and their cross products for a spherical
        top.
    """
    scale = max(moments.max(), 1e-9)
    same = lambda a, b: abs(a - b) < 1e-3 * scale
    if linear:
        start = axes[:, 1]
        return [axes[:, 0]] + [_rotation(axes[:, 0], np.pi * m / LINEAR_ORDER) @ start for m in range(LINEAR_ORDER)]
    pairs = [(i, j) for i, j in combinations(range(len(numbers)), 2) if numbers[i] == numbers[j]]
    midpoints = [(coordinates[i] + coordinates[j]) / 2 for i, j in pairs]
    differences = [coordinates[i] - coordinates[j] for i, j in pairs]
    if not same(moments[0], moments[1]) and not same(moments[1], moments[2]):
        return list(axes.T)
    if same(moments[0], moments[1]) != same(moments[1], moments[2]):
        unique = axes[:, 2] if same(moments[0], moments[1]) else axes[:, 0]
        flat = [v - (v @ unique) * unique for v in list(coordinates) + midpoints + differences]
        flat = _unit(flat)
        return [unique] + _unit(flat + [np.cross(unique, d) for d in flat])
    found = _unit(list(axes.T) + list(coordinates) + midpoints + differences)
    return _unit(found + [np.cross(a, b) for a, b in combinations(_unit(list(coordinates) + midpoints), 2)])


def _distinct(matrices, tolerance=1e-2):
    """Indices of the first of each group of matrices equal within the tolerance.

    Args:
        matrices: Array of shape (n, 3, 3).
        tolerance: Largest element-wise difference at which two matrices count as equal.

    Returns:
        Indices of the matrices kept, in order.
    """
    flat = np.asarray(matrices).reshape(len(matrices), 9)
    kept = []
    for index in range(len(flat)):
        if not kept or np.abs(flat[kept] - flat[index]).max(axis=1).min() > tolerance:
            kept.append(index)
    return kept


def _close(found, numbers, coordinates, tolerance):
    """The operations closed under multiplication, as (matrix, permutation) pairs.

    Args:
        found: (matrix, permutation) pairs of the operations found so far.
        numbers: Atomic numbers, of shape (N,).
        coordinates: Atom positions, of shape (N, 3).
        tolerance: Distance tolerance of the geometry; products are accepted within four times it.

    Returns:
        (matrix, permutation) pairs of the closed set, keeping only the operations that map the molecule onto itself.

    Raises:
        ValueError: The operations do not close into a group of at most 120 operations.
    """
    matrices = np.asarray([m for m, _ in found])
    # Near-symmetric geometries give near-exact operations, so products match within a loose tolerance; no point
    # group exceeds 120 operations, and a linear molecule's finite fan stays below that too.
    while len(matrices) <= 120:
        products = np.einsum("aij,bjk->abik", matrices, matrices).reshape(-1, 3, 3)
        distance = np.abs(products.reshape(-1, 1, 9) - matrices.reshape(1, -1, 9)).max(axis=2).min(axis=1)
        new = products[distance > 1e-2]
        if not len(new):
            break
        new = new[_distinct(new)]
        matrices = np.concatenate([matrices, new])
    if len(matrices) > 120:
        raise ValueError("The operations found do not close into a finite point group.")
    result = []
    for matrix in matrices:
        permutation = _permutation(matrix, numbers, coordinates, 4 * tolerance)
        if permutation is not None:
            result.append((matrix, permutation))
    return result


def _idealize(found, coordinates, rounds=6):
    """Operations made exact for the symmetrized geometry.

    The geometry is averaged over the operations, and each operation is refitted to it as the orthogonal matrix of its
    own handedness that best maps the geometry onto its permuted self, a few times over. Near-symmetric input gives
    operations whose products would otherwise drift.

    Args:
        found: (matrix, permutation) pairs of the operations.
        coordinates: Atom positions, of shape (N, 3).
        rounds: Number of averaging and refitting rounds.

    Returns:
        (matrix, permutation) pairs with the refitted matrices and the same permutations.
    """
    matrices = [m for m, _ in found]
    for _ in range(rounds):
        # Each operation maps atom i onto atom target[i]: X[target] = X R^T, so X = X[target] R.
        average = sum(coordinates[target] @ m for m, (_, target) in zip(matrices, found)) / len(found)
        refitted = []
        for m, (_, target) in zip(matrices, found):
            u, _, vt = np.linalg.svd(average.T @ average[target])
            sign = np.sign(np.linalg.det(m)) * np.sign(np.linalg.det(u @ vt))
            refitted.append((u @ np.diag([1, 1, sign]) @ vt).T)
        matrices = refitted
    return [(m, target) for m, (_, target) in zip(matrices, found)]


def point_group(numbers, coordinates, tolerance=0.02):
    """Point group of a geometry.

    Args:
        numbers: Atomic numbers.
        coordinates: Cartesian coordinates in bohr, shape (atoms, 3).
        tolerance: Largest distance in bohr by which an operation may miss an equivalent atom.

    Returns:
        The :class:`PointGroup`, operations in the frame of ``coordinates``.
    """
    numbers = np.asarray(numbers, dtype=int)
    weights = numbers.astype(float)
    coordinates = np.asarray(coordinates, dtype=float)
    coordinates = coordinates - weights @ coordinates / weights.sum()
    if len(numbers) == 1:
        # A lone atom has the full rotation-reflection group K_h, which no finite set of operations represents;
        # it is described by the identity alone.
        return PointGroup(
            name="K_{h}",
            operations=[np.eye(3)],
            permutations=[np.zeros(1, dtype=int)],
            frame=np.eye(3),
            irreps=[Irrep("A", 1, np.ones(1))],
        )
    tensor = sum(w * (np.dot(r, r) * np.eye(3) - np.outer(r, r)) for w, r in zip(weights, coordinates))
    moments, axes = np.linalg.eigh(tensor)
    linear = len(numbers) > 1 and moments[0] < 1e-6 * max(moments.max(), 1e-9)
    candidates = [np.eye(3), -np.eye(3)]
    for index, direction in enumerate(_directions(numbers, coordinates, moments, axes, linear)):
        # A linear molecule's fan: rotations of the finite order about the axis, twofold ones across it.
        orders = ((LINEAR_ORDER,) if index == 0 else (2,)) if linear else range(2, MAXIMUM_ORDER + 1)
        candidates.append(_reflection(direction))
        for n in orders:
            candidates += [
                _rotation(direction, 2 * np.pi / n),
                _reflection(direction) @ _rotation(direction, 2 * np.pi / n),
            ]
    candidates = [candidates[i] for i in _distinct(candidates, 1e-6)]
    found = []
    for matrix in candidates:
        permutation = _permutation(matrix, numbers, coordinates, tolerance)
        if permutation is not None:
            found.append((matrix, permutation))
    found = [found[i] for i in _distinct([m for m, _ in found])]
    found = _close(found, numbers, coordinates, tolerance)
    if not linear:
        found = _idealize(found, coordinates)
    spread = np.linalg.svd(coordinates, full_matrices=False)[2] if len(numbers) > 2 else None
    normal = spread[-1] if spread is not None and np.abs(coordinates @ spread[-1]).max() < tolerance else None
    operations = [matrix for matrix, _ in found]
    frame = _frame(numbers, coordinates, operations, normal, axes, tolerance)
    local = [frame @ matrix @ frame.T for matrix in operations]
    group = PointGroup(
        name=_schoenflies(local, linear),
        operations=operations,
        permutations=[permutation for _, permutation in found],
        frame=frame,
        irreps=_irreps(local),
        planar=normal,
        linear=linear,
    )
    group.irreps = _name(group.irreps, local, linear)
    group.dipole = _dipole(group, local)
    return group


def _order(angle):
    """Order n of a rotation by 2 pi / n.

    Args:
        angle: Rotation angle in radians, in (0, pi]; smaller angles stand for the identity.

    Returns:
        The order n, 1 for the identity.
    """
    return int(round(2 * np.pi / angle)) if angle > 1e-6 else 1


def _on_line(numbers, coordinates, direction, tolerance):
    """Number of atoms on the line through the centre along a direction.

    Args:
        numbers: Atomic numbers; not used, so that the geometry helpers take the same leading arguments.
        coordinates: Atom positions relative to the centre, of shape (N, 3).
        direction: Unit direction of the line.
        tolerance: Largest distance from the line at which an atom counts as on it.

    Returns:
        The number of atoms on the line.
    """
    distances = np.linalg.norm(coordinates - np.outer(coordinates @ direction, direction), axis=1)
    return int((distances < tolerance).sum())


def _frame(numbers, coordinates, operations, normal, axes, tolerance):
    """Rows x, y, z of the conventional frame: z a principal axis, x along the primary perpendicular C2 axis or in the
    primary vertical plane.

    Args:
        numbers: Atomic numbers, of shape (N,).
        coordinates: Atom positions relative to the centre, of shape (N, 3).
        operations: 3 x 3 matrices of the point-group operations.
        normal: Unit normal of the molecular plane, or None for a molecule that is not planar.
        axes: Principal axes of inertia as columns, the fallback for a group without rotations or mirrors.
        tolerance: Largest distance from an axis at which an atom counts as on it.

    Returns:
        A 3 x 3 array whose rows are the x, y and z unit vectors.
    """
    described = [describe(m) for m in operations]
    rotations = [(axis, _order(angle)) for kind, axis, angle in described if kind == "rotation" and axis is not None]
    mirrors = [axis for kind, axis, angle in described if kind == "improper" and axis is not None and angle < 1e-6]
    atoms = lambda d: _on_line(numbers, coordinates, d, tolerance)
    if rotations:
        n = max(order for _, order in rotations)
        principal = _unit([axis for axis, order in rotations if order == n])
        if normal is not None and len(principal) > 1:
            # Several equivalent axes of a planar molecule, as in D2h: x perpendicular to the plane, z through the
            # most atoms of the others.
            principal = [d for d in principal if abs(d @ normal) < 1 - 1e-3] or principal
        z = max(principal, key=atoms)
    elif mirrors:
        z = mirrors[0]
    else:
        z = axes[:, 0]
    perpendicular = lambda d: abs(d @ z) < 1e-3
    lines = _unit([axis for axis, order in rotations if order == 2 and perpendicular(axis)])
    lines = lines or _unit([np.cross(z, axis) for axis in mirrors if perpendicular(axis)])
    if lines:
        planar = normal is not None and perpendicular(normal)
        x = max(lines, key=lambda d: (planar and abs(d @ normal) > 1 - 1e-3, atoms(d)))
    else:
        x = np.cross(z, [1, 0, 0]) if abs(z[0]) < 0.9 else np.cross(z, [0, 1, 0])
    x = x - (x @ z) * z
    x /= np.linalg.norm(x)
    return np.array([x, np.cross(z, x), z])


def _irreps(local):
    """Irreducible characters of the operations, split out of the polynomial representations.

    Args:
        local: 3 x 3 matrices of the operations in the conventional frame.

    Returns:
        The irreducible representations, with their dimensions and characters and empty labels, before they are named.

    Raises:
        ValueError: The squared dimensions found up to the highest degree do not add up to the group order.
    """
    order = len(local)
    found = []
    total = 0.0
    mixing = None
    # Every representation of a point group of rotation order up to MAXIMUM_ORDER occurs by this degree.
    for degree in range(0, MAXIMUM_ORDER // 2 + 3):
        powers = _all_powers(degree)
        base = _polynomial_representation(local, powers)
        for twisted in (False, True):
            matrices = [b * np.sign(np.linalg.det(m)) if twisted else b for b, m in zip(base, local)]
            # Orthogonal form through the invariant inner product.
            gram = sum(d.T @ d for d in matrices)
            root = np.linalg.cholesky(gram).T
            matrices = [root @ d @ np.linalg.inv(root) for d in matrices]
            size = len(powers)
            if mixing is None or len(mixing) != size:
                mixing = np.diag(np.arange(1.0, size + 1)) + np.triu(np.ones((size, size)), 1) * 0.1
                mixing = mixing + mixing.T
            commuting = sum(d @ mixing @ d.T for d in matrices)
            values, vectors = np.linalg.eigh(commuting)
            start = 0
            while start < size:
                stop = start + 1
                while stop < size and abs(values[stop] - values[start]) < 1e-6 * max(abs(values).max(), 1):
                    stop += 1
                space = vectors[:, start:stop]
                characters = np.array([np.trace(space.T @ d @ space) for d in matrices])
                norm = characters @ characters / order
                if not any(np.allclose(characters, other, atol=1e-5) for other, _ in found):
                    found.append((characters, stop - start))
                    total += (stop - start) ** 2 / norm
                start = stop
            if abs(total - order) < 1e-6:
                return [Irrep("", dimension, characters) for characters, dimension in found]
    raise ValueError(f"Incomplete character table: {total:.3f} of {order}.")


def _name(irreps, local, linear):
    """Irreducible representations named by Mulliken's rules, ordered by type.

    The labels are set on the representations in place.

    Args:
        irreps: Unnamed irreducible representations, as ``_irreps`` returns them.
        local: 3 x 3 matrices of the operations in the conventional frame.
        linear: Whether the molecule is linear, whose representations are named Sigma, Pi and Delta.

    Returns:
        The representations sorted by type (A, B, E, T, G, H) and label; for a linear molecule without the
        one-dimensional parts that are odd under the finite axis.
    """
    described = [describe(m) for m in local]
    z = np.array([0.0, 0.0, 1.0])
    x = np.array([1.0, 0.0, 0.0])
    along = lambda axis, d: axis is not None and abs(axis @ d) > 1 - 1e-3
    across = lambda axis: axis is not None and abs(axis @ z) < 1e-3
    find = lambda test: next((i for i, entry in enumerate(described) if test(*entry)), None)
    rotations = [_order(angle) for kind, axis, angle in described if kind == "rotation" and axis is not None]
    n = max(rotations, default=1)
    principal_axes = _unit(
        [axis for kind, axis, angle in described if kind == "rotation" and axis is not None and _order(angle) == n]
    )
    inversion = find(lambda kind, axis, angle: kind == "improper" and np.isclose(angle, np.pi))
    horizontal = find(lambda kind, axis, angle: kind == "improper" and angle < 1e-6 and along(axis, z))
    principal = find(
        lambda kind, axis, angle: kind == "rotation" and along(axis, z) and np.isclose(angle, 2 * np.pi / n)
    )
    improper = [
        _order(angle)
        for kind, axis, angle in described
        if kind == "improper" and along(axis, z) and 1e-6 < angle < np.pi - 1e-6
    ]
    s2n = max(improper, default=0)
    if s2n > n and inversion is None:
        principal = find(
            lambda kind, axis, angle: kind == "improper" and along(axis, z) and np.isclose(angle, 2 * np.pi / s2n)
        )
    # Primary perpendicular C2 along x, else the primary vertical plane, the xz plane.
    primary = find(lambda kind, axis, angle: kind == "rotation" and along(axis, x) and np.isclose(angle, np.pi))
    if primary is None:
        primary = find(lambda kind, axis, angle: kind == "improper" and angle < 1e-6 and along(axis, [0, 1, 0]))
    several = len(principal_axes) > 1
    reference = principal
    if inversion is not None or horizontal is not None:
        reference = find(
            lambda kind, axis, angle: kind == "rotation" and along(axis, z) and np.isclose(angle, 2 * np.pi / n)
        )
    reference_order = _order(described[reference][2]) if reference is not None else 1
    rotation_characters = np.array([np.linalg.det(m) * np.trace(m) for m in local])
    proper = np.array([kind == "rotation" for kind, _, _ in described])

    def k(irrep):
        """Index of a pair from its character under the reference rotation, 2 cos(2 pi k / n).

        Args:
            irrep: A two-dimensional irreducible representation.

        Returns:
            The integer k, 1 when the group has no reference rotation.
        """
        if reference is None:
            return 1
        return int(round(np.arccos(np.clip(irrep.characters[reference] / 2, -1, 1)) * reference_order / (2 * np.pi)))

    def parity(irrep):
        """Parity label of a representation: g or u under inversion, otherwise one or two primes under the horizontal
        plane.

        Args:
            irrep: An irreducible representation.

        Returns:
            'g', 'u', "'", "''", or an empty string when the group has neither inversion nor a horizontal plane.
        """
        if inversion is not None:
            return "g" if irrep.characters[inversion] > 0 else "u"
        if horizontal is not None:
            return "'" if irrep.characters[horizontal] > 0 else "''"
        return ""

    def is_rotation_like(irrep):
        """Whether it carries the rotations: on every operation, or on the proper ones when inversion pairs it with a g or
        u partner.

        Args:
            irrep: An irreducible representation.

        Returns:
            True when its characters equal those of the rotations on the operations compared.
        """
        kept = proper if inversion is not None else np.ones(len(local), dtype=bool)
        return np.allclose(irrep.characters[kept], rotation_characters[kept], atol=1e-5)

    names = []
    for irrep in irreps:
        c, d = irrep.characters, irrep.dimension
        letter = LETTERS.get(d, "?")
        index = ""
        if linear:
            if d == 1:
                vertical = find(lambda kind, axis, angle: kind == "improper" and angle < 1e-6 and across(axis))
                letter = r"\Sigma" + ("^{+}" if vertical is None or c[vertical] > 0 else "^{-}")
            else:
                letter = LINEAR.get(k(irrep), "E")
        elif d == 1:
            if several and n == 2:
                symmetric = [
                    str(i)
                    for i, axis in ((1, z), (2, [0, 1, 0]), (3, x))
                    if c[find(lambda kind, a, angle, axis=axis: kind == "rotation" and along(a, axis))] > 0
                ]
                letter, index = ("A", "") if len(symmetric) == 3 else ("B", symmetric[0])
            elif not several:
                letter = "A" if principal is None or c[principal] > 0 else "B"
        names.append([irrep, letter, index])
    # Subscripts that separate representations otherwise named alike, judged on the names before any is added.
    before = [(letter, index) for _, letter, index in names]
    for entry, (letter, index) in zip(names, before):
        irrep = entry[0]
        alike = [
            other for other, name in zip(names, before) if name == (letter, index) and parity(other[0]) == parity(irrep)
        ]
        # Linear molecules are named by Sigma, Pi, Delta and their signs alone.
        if len(alike) < 2 or linear:
            continue
        if irrep.dimension == 1:
            separating = (
                primary if primary is not None and len({round(o[0].characters[primary]) for o in alike}) > 1 else None
            )
            if separating is None:
                separating = next(
                    (
                        i
                        for i in range(len(local))
                        if described[i][0] == "rotation"
                        and np.isclose(described[i][2], np.pi)
                        and len({round(o[0].characters[i]) for o in alike}) > 1
                    ),
                    None,
                )
            if separating is None:
                separating = next(
                    (i for i in range(len(local)) if len({round(o[0].characters[i]) for o in alike}) > 1), None
                )
            entry[2] = "1" if separating is None or irrep.characters[separating] > 0 else "2"
        elif irrep.dimension == 2:
            entry[2] = str(k(irrep))
        else:
            entry[2] = "1" if is_rotation_like(irrep) else "2"
    for irrep, letter, index in names:
        subscript = index + ("" if parity(irrep) in ("'", "''") else parity(irrep))
        irrep.label = (
            letter
            + (f"_{{{subscript}}}" if subscript else "")
            + (parity(irrep) if parity(irrep) in ("'", "''") else "")
        )
    if linear:
        # A finite order stands for the infinite axis; one-dimensional parts odd under it have no linear counterpart.
        irreps = [
            irrep for irrep in irreps if irrep.dimension == 2 or principal is None or irrep.characters[principal] > 0
        ]
    rank = lambda irrep: ("ABETGH".find(irrep.label[0]) if irrep.label[0] in "ABETGH" else 6, irrep.label)
    return sorted(irreps, key=rank)


def _schoenflies(local, linear):
    r"""Schoenflies name of the operations in LaTeX, such as :math:`D_{6h}` or :math:`O_{h}`.

    Args:
        local: 3 x 3 matrices of the operations in the conventional frame.
        linear: Whether the molecule is linear.

    Returns:
        The name, with C_{\infty v} and D_{\infty h} for linear molecules.
    """
    described = [describe(m) for m in local]
    rotations = [(axis, _order(angle)) for kind, axis, angle in described if kind == "rotation" and axis is not None]
    n = max((order for _, order in rotations), default=1)
    principal_axes = _unit([axis for axis, order in rotations if order == n])
    z = np.array([0.0, 0.0, 1.0])
    has = lambda test: any(test(*entry) for entry in described)
    inversion = has(lambda kind, axis, angle: kind == "improper" and np.isclose(angle, np.pi))
    mirror = has(lambda kind, axis, angle: kind == "improper" and angle < 1e-6)
    if linear:
        return r"D_{\infty h}" if inversion else r"C_{\infty v}"
    threefold = len(_unit([axis for axis, order in rotations if order == 3]))
    if threefold > 1:
        # Several threefold axes: tetrahedral, octahedral or icosahedral.
        family = "I" if n == 5 else ("O" if n == 4 else "T")
        if inversion:
            return f"{family}_{{h}}"
        return "T_{d}" if family == "T" and mirror else family
    if (
        len(principal_axes) > 1
        or n > 1
        and has(
            lambda kind, axis, angle: (
                kind == "rotation" and axis is not None and np.isclose(angle, np.pi) and abs(axis @ z) < 1e-3
            )
        )
    ):
        horizontal = has(lambda kind, axis, angle: kind == "improper" and angle < 1e-6 and abs(axis @ z) > 1 - 1e-3)
        return f"D_{{{n}h}}" if horizontal else (f"D_{{{n}d}}" if mirror else f"D_{{{n}}}")
    if n == 1:
        return "C_{s}" if mirror else ("C_{i}" if inversion else "C_{1}")
    horizontal = has(lambda kind, axis, angle: kind == "improper" and angle < 1e-6 and abs(axis @ z) > 1 - 1e-3)
    if horizontal:
        return f"C_{{{n}h}}"
    if mirror:
        return f"C_{{{n}v}}"
    if has(lambda kind, axis, angle: kind == "improper"):
        return f"S_{{{2 * n}}}"
    return f"C_{{{n}}}"


def _dipole(group, local):
    """Dipole-component directions carried by each irreducible representation, from projectors onto the vector
    representation.

    Args:
        group: The point group, whose irreducible representations are tested.
        local: 3 x 3 matrices of the operations in the conventional frame.

    Returns:
        Mapping from a representation's label to the axes among x, y and z, joined by commas, along which a dipole
        transforms like it; representations without a dipole component are left out.
    """
    result = {}
    for irrep in group.irreps:
        projector = sum(c * m for c, m in zip(irrep.characters, local))
        axes = [name for name, column in zip("xyz", projector.T) if np.linalg.norm(column) > 1e-6]
        if axes:
            result[irrep.label] = ",".join(axes)
    return result


def _lower(label):
    r"""Lower-case Mulliken label of an orbital: the capital letter in lower case, and Greek letters as lower-case.

    Args:
        label: Label of an irreducible representation in LaTeX, such as :math:`E_{1g}` or :math:`\Sigma^{+}`.

    Returns:
        The orbital label, such as e_{1g} or \sigma^{+}.
    """
    for upper, lower in (
        (r"\Sigma", r"\sigma"),
        (r"\Pi", r"\pi"),
        (r"\Delta", r"\delta"),
        (r"\Phi", r"\phi"),
        (r"\Gamma", r"\gamma"),
    ):
        if label.startswith(upper):
            return lower + label[len(upper) :]
    return label[0].lower() + label[1:]


def _monomials(points, powers):
    """Monomials of the given powers at the points, one column each.

    Args:
        points: Points, of shape (N, 3).
        powers: Exponents (a, b, c) of x, y and z, one triple per monomial.

    Returns:
        Array of shape (N, number of monomials).
    """
    return np.prod(points[:, None, :] ** np.asarray(powers)[None, :, :], axis=2)


# Sample points on the unit sphere at which polynomials are compared; more than the largest monomial count used.
_POINTS = np.random.default_rng(20261102).normal(size=(200, 3))


_POINTS /= np.linalg.norm(_POINTS, axis=1)[:, None]


def _polynomial_representation(matrices, powers):
    """Matrices U with U[q, p] the coefficient of monomial q in monomial p evaluated at R^T u, for every R.

    They are found by least squares on sample points of the unit sphere, which is exact, since the images lie in the
    span of monomials of one degree.

    Args:
        matrices: 3 x 3 orthogonal matrices R of the operations.
        powers: Exponents of the monomials of one degree, as ``_all_powers`` returns them.

    Returns:
        One square matrix per operation, of the size of ``powers``.
    """
    basis = _monomials(_POINTS, powers)
    inverse = np.linalg.pinv(basis)
    return [inverse @ _monomials(_POINTS @ m, powers) for m in matrices]


def _rotated_monomials(matrix, powers):
    """Coefficients U[q, p] of monomial q in monomial p evaluated at R^T u, for monomials of one degree.

    Args:
        matrix: 3 x 3 orthogonal matrix R of one operation.
        powers: Exponents of the monomials of one degree.

    Returns:
        Square matrix of the size of ``powers``, expanded exactly as a polynomial rather than fitted.
    """
    position = {power: index for index, power in enumerate(powers)}
    result = np.zeros((len(powers), len(powers)))
    for p, power in enumerate(powers):
        # Product over x, y, z of (sum_j R[j, i] u_j) ** power[i], expanded as a polynomial.
        terms = {(0, 0, 0): 1.0}
        for i, exponent in enumerate(power):
            for _ in range(exponent):
                expanded = {}
                for term, value in terms.items():
                    for j in range(3):
                        if abs(matrix[j, i]) > 1e-14:
                            key = tuple(t + (1 if k == j else 0) for k, t in enumerate(term))
                            expanded[key] = expanded.get(key, 0.0) + value * matrix[j, i]
                terms = expanded
        for term, value in terms.items():
            result[position[term], p] += value
    return result


def _all_powers(degree):
    """Every Cartesian power of one degree.

    Args:
        degree: Total degree a + b + c.

    Returns:
        The exponent triples (a, b, c) with a + b + c equal to the degree, in descending order of a, then b.
    """
    return [(a, b, degree - a - b) for a in range(degree, -1, -1) for b in range(degree - a, -1, -1)]

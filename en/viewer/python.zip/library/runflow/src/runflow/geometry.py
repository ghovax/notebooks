"""Internal coordinates measured on Cartesian geometries."""

import math

import numpy as np


def measure(function, atoms, coordinates):
    """Value of one coordinate function in bohr, radians or bohr squared.

    Args:
        function: Canonical function name.
        atoms: Its atom list.
        coordinates: Array of positions in bohr.

    Returns:
        The value.

    Raises:
        ValueError: A function this evaluator does not support, or a wildcard.
    """
    if any(not isinstance(atom, int) for atom in atoms):
        raise ValueError(f"{function} with {atoms} cannot be evaluated")
    point = lambda number: coordinates[number - 1]
    if function == "R":
        return float(np.linalg.norm(point(atoms[0]) - point(atoms[1])))
    if function == "A":
        first, second = point(atoms[0]) - point(atoms[1]), point(atoms[2]) - point(atoms[1])
        return float(math.acos(np.clip(first @ second / np.linalg.norm(first) / np.linalg.norm(second), -1, 1)))
    if function == "D":
        b1, b2, b3 = (point(atoms[k + 1]) - point(atoms[k]) for k in range(3))
        n1, n2 = np.cross(b1, b2), np.cross(b2, b3)
        return float(math.atan2(np.cross(n1, n2) @ b2 / np.linalg.norm(b2), n1 @ n2))
    if function in ("X", "Y", "Z"):
        return float(point(atoms[0])["XYZ".index(function)])
    if function in ("XCntr", "YCntr", "ZCntr"):
        chosen = coordinates if not atoms else coordinates[[atom - 1 for atom in atoms]]
        return float(chosen.mean(axis=0)["XYZ".index(function[0])])
    if function == "DotDiff":
        # The manual's a = r_i - r_j and b = r_k - r_l.
        return float((point(atoms[0]) - point(atoms[1])) @ (point(atoms[2]) - point(atoms[3])))
    raise ValueError(f"{function} is not evaluated")


def dihedral(coordinates, atoms):
    r"""Dihedral angle of four atoms in degrees, from :math:`-180` to :math:`180`, Gaussian's sign convention.

    Args:
        coordinates: (N, 3) positions in any one length unit.
        atoms: Four one-based atom numbers.

    Returns:
        The angle in degrees.

    Raises:
        ValueError: If there are not four distinct atoms.
    """
    atoms = [int(atom) for atom in atoms]
    if len(set(atoms)) != 4:
        raise ValueError(f"a dihedral needs four distinct atoms, not {atoms}")
    return math.degrees(measure("D", atoms, np.asarray(coordinates, dtype=float)))


def plane_angle(coordinates, first, second):
    r"""Angle between the least-squares planes of two atom sets in degrees, from :math:`0` (coplanar) to :math:`90`.

    For two aromatic rings joined by a single bond this is the twist about that bond without choosing which ring
    atoms define a dihedral, and it is insensitive to ring puckering.

    Args:
        coordinates: (N, 3) positions in any one length unit.
        first: One-based atom numbers of the first set, at least three.
        second: Those of the second set, at least three.

    Returns:
        The angle in degrees.

    Raises:
        ValueError: If a set has fewer than three atoms.
    """
    coordinates = np.asarray(coordinates, dtype=float)

    def normal(atoms):
        """Unit normal of a set's least-squares plane, the singular vector of least variance."""
        atoms = [int(atom) for atom in atoms]
        if len(atoms) < 3:
            raise ValueError(f"a plane needs at least three atoms, not {atoms}")
        points = coordinates[np.asarray(atoms) - 1]
        return np.linalg.svd(points - points.mean(axis=0))[2][-1]

    cosine = abs(float(normal(first) @ normal(second)))
    return math.degrees(math.acos(min(1.0, cosine)))

"""Internal coordinates measured on Cartesian geometries."""

import math

import numpy as np


def measure(function, atoms, coordinates):
    """Value of one coordinate function in bohr, radians or bohr squared.

    Args:
        function: Canonical function name.
        atoms: Its atom list.
        coordinates: Array of positions in bohr.

    Returns:
        The value.

    Raises:
        ValueError: A function this evaluator does not support, or a wildcard.
    """
    if any(not isinstance(atom, int) for atom in atoms):
        raise ValueError(f"{function} with {atoms} cannot be evaluated")
    point = lambda number: coordinates[number - 1]
    if function == "R":
        return float(np.linalg.norm(point(atoms[0]) - point(atoms[1])))
    if function == "A":
        first, second = point(atoms[0]) - point(atoms[1]), point(atoms[2]) - point(atoms[1])
        return float(math.acos(np.clip(first @ second / np.linalg.norm(first) / np.linalg.norm(second), -1, 1)))
    if function == "D":
        b1, b2, b3 = (point(atoms[k + 1]) - point(atoms[k]) for k in range(3))
        n1, n2 = np.cross(b1, b2), np.cross(b2, b3)
        return float(math.atan2(np.cross(n1, n2) @ b2 / np.linalg.norm(b2), n1 @ n2))
    if function in ("X", "Y", "Z"):
        return float(point(atoms[0])["XYZ".index(function)])
    if function in ("XCntr", "YCntr", "ZCntr"):
        chosen = coordinates if not atoms else coordinates[[atom - 1 for atom in atoms]]
        return float(chosen.mean(axis=0)["XYZ".index(function[0])])
    if function == "DotDiff":
        # The manual's a = r_i - r_j and b = r_k - r_l.
        return float((point(atoms[0]) - point(atoms[1])) @ (point(atoms[2]) - point(atoms[3])))
    raise ValueError(f"{function} is not evaluated")

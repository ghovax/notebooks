"""Shared text reporting for calculation, analysis and viewer scripts."""

import ast
import logging
import os
import re
from datetime import UTC, datetime
from pathlib import Path


def format_metadata(fields):
    """Render searchable key=value fields, quoting whitespace and nested values.

    Args:
        fields: Metadata names mapped to their values.

    Returns:
        The fields as one line of ``key=value`` pairs.
    """

    def value_text(value):
        """Quote metadata values when needed to preserve searchable field boundaries.

        Args:
            value: One metadata value.

        Returns:
            Its text, quoted when it would otherwise split.
        """
        if isinstance(value, (str, Path)):
            text = str(value)
            return text if re.fullmatch(r"[\w./:+-]+", text) else repr(text)
        return repr(value)

    return " ".join(f"{key}={value_text(value)}" for key, value in fields.items())


def _metadata_fields(text):
    """Decode the key=value fields written by format_metadata.

    Values that are not Python literals stay text.

    Args:
        text: Text after a record's message.

    Returns:
        Names mapped to values, or None if the text is not only fields.
    """
    fields, position = {}, 0
    while match := re.compile(r"\s*(\w+)=").match(text, position):
        start = position = match.end()
        opening = text[start : start + 1]
        if opening in ("'", '"'):
            # Quoted repr: advance past escaped characters to the matching quote.
            position += 1
            while position < len(text) and text[position] != opening:
                position += 2 if text[position] == "\\" else 1
            position += 1
        elif opening and opening in "[({":
            # Unquoted repr of a container may contain spaces; read to the balancing bracket.
            depth = 0
            for position in range(start, len(text)):
                depth += (text[position] in "[({") - (text[position] in "])}")
                if depth == 0:
                    break
            position += 1
        else:
            position = text.find(" ", start) if " " in text[start:] else len(text)
        value = text[start:position]
        try:
            fields[match[1]] = ast.literal_eval(value)
        except (ValueError, SyntaxError):
            fields[match[1]] = value
    return fields if fields and not text[position:].strip() else None


def read_log(path):
    """Records of a runflow text log, the inverse of :class:`TextFormatter`.

    Args:
        path: Text log to read.

    Returns:
        One record per entry, with the UTC ``time``, ``level``, ``message``, decoded metadata ``fields`` and
        ``detail``, the lines that follow it without a prefix, such as a traceback or a program's own output.
    """
    prefix = re.compile(r"^(\d{4}-\d\d-\d\dT[\d:.]+\+00:00) \[([A-Z]+)\] (.*)$")
    records = []
    for line in Path(path).read_text().splitlines():
        if match := prefix.match(line):
            # The fields follow the message; older logs lack the leading logger field, so the message
            # ends where the rest of the line first decodes entirely as fields.
            text = match[3]
            split = next(
                (
                    start
                    for start in (field.start() for field in re.finditer(r" (?=\w+=)", text))
                    if _metadata_fields(text[start:]) is not None
                ),
                len(text),
            )
            records.append(
                {
                    # Time the record was written, in UTC.
                    "time": datetime.fromisoformat(match[1]),
                    # Python logging level name.
                    "level": match[2],
                    # Human-readable message without its metadata.
                    "message": text[:split],
                    # Decoded metadata fields, including the execution context.
                    "fields": _metadata_fields(text[split:]) or {},
                    # Following unprefixed lines.
                    "detail": [],
                }
            )
        elif records:
            records[-1]["detail"].append(line)
    return records


class TextFormatter(logging.Formatter):
    """Use standard log prefixes, metadata and ordinary Python tracebacks.

    Args:
        script: Path of the entry-point script, recorded with every message.
    """

    def __init__(self, script):
        """Bind the log format and run metadata to the calling script.

        Args:
            script: Path of the entry-point script.
        """
        super().__init__("%(timestamp)s [%(levelname)s] %(message)s %(metadata_text)s")
        self.script = Path(script).resolve()

    def format(self, record):
        """Prefix UTC time and append run context before formatting any traceback.

        Args:
            record: Logging record to format.

        Returns:
            The formatted entry.
        """
        record.timestamp = datetime.fromtimestamp(record.created, UTC).isoformat()
        fields = {
            # Name of the emitting Python logger.
            "logger": record.name,
            # Calculation directory name associated with the entry point.
            "run_folder": self.script.parent.parent.name,
            # Entry-point filename associated with the log record.
            "script": self.script.name,
        }
        if job_id := os.environ.get("SLURM_JOB_ID"):
            # Slurm allocation identifier, present only inside an allocation.
            fields["job_id"] = job_id
        fields.update(getattr(record, "metadata", None) or {})
        record.metadata_text = format_metadata(fields)
        return super().format(record)


def run_script(main):
    """Run an entry point with consistent logging and failure exit codes.

    Args:
        main: Entry-point function without arguments.

    Returns:
        What ``main`` returns.

    Raises:
        SystemExit: Status 1 after an uncaught exception, 130 after an interruption.
    """
    handler = logging.StreamHandler()
    handler.setFormatter(TextFormatter(main.__globals__["__file__"]))
    logger = logging.getLogger()
    logger.handlers[:] = [handler]
    logger.setLevel(logging.INFO)
    try:
        return main()
    except KeyboardInterrupt:
        logger.warning("Interrupted")
        raise SystemExit(130) from None
    except Exception as error:
        logger.exception(
            "Script failed",
            extra={
                # Scientific or execution fields appended to the log message.
                "metadata": {
                    # Python exception class name at the single reporting boundary.
                    "error_type": type(error).__name__
                }
            },
        )
        raise SystemExit(1) from None

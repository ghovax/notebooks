"""Symmetry of canonical orbitals and excited states in the point group of their geometry.

An orbital set, its degenerate orbitals together, carries the representation its coefficients span: each operation
moves basis functions to the equivalent atom and rotates their angular parts. An excited state's symmetry follows
from its configurations through the product of the orbital representations. Supported shells: s, sp, p and Cartesian
or pure d and f.
"""

from dataclasses import dataclass
from itertools import product

import numpy as np

from .basis import CARTESIAN, PURE
from .checkpoints import spin_record
from .symmetry import (
    Irrep,
    PointGroup,
    _all_powers,
    _polynomial_representation,
    _reflection,
    _rotated_monomials,
    point_group,
)


def _shell_matrix(matrix, kind):
    """Matrix moving the coefficients of a shell's functions under an operation: D[q, p] is the share of function q in the
    image of function p.

    Args:
        matrix: 3 x 3 orthogonal matrix of the operation.
        kind: Gaussian shell type: 0 for s, 1 for p, -1 for sp, 2 and 3 for Cartesian d and f, -2 and -3 for pure d and
            f.

    Returns:
        Square matrix over the functions of the shell: 1, 3 or 4 for s, p and sp, and the Cartesian or pure count
        otherwise.
    """
    if kind == -1:
        return np.block([[np.ones((1, 1)), np.zeros((1, 3))], [np.zeros((3, 1)), _shell_matrix(matrix, 1)]])
    degree = abs(kind)
    if kind >= 0:
        powers = CARTESIAN[degree]
        u = _rotated_monomials(matrix, powers)
        # Each Cartesian function is normalized on its own: N_p is proportional to 1/sqrt(prod (2 p_i - 1)!!).
        norm = np.array(
            [1 / np.sqrt(np.prod([float(np.prod(np.arange(2 * e - 1, 0, -2))) for e in power])) for power in powers]
        )
        return u * norm[None, :] / norm[:, None]
    powers = _all_powers(degree)
    u = _rotated_monomials(matrix, powers)
    harmonics = np.array([[polynomial.get(power, 0.0) for polynomial in PURE[degree]] for power in powers])
    return np.linalg.pinv(harmonics) @ u @ harmonics


def basis_operations(records, group):
    """For each operation, a function moving MO coefficient columns, from formatted-checkpoint records.

    Args:
        records: Formatted-checkpoint records, read for 'Shell types' and 'Shell to atom map'.
        group: The point group, with its ``operations`` and atom ``permutations``.

    Returns:
        One function per operation, taking an array of coefficient columns of shape (basis functions, columns) and
        returning them moved; None when a shell type is not supported or equivalent atoms carry different shells.
    """
    types = np.asarray(records["Shell types"], dtype=int)
    if any(kind not in (0, 1, -1, 2, 3, -2, -3) for kind in types):
        return None
    atoms = np.asarray(records["Shell to atom map"], dtype=int) - 1
    sizes = [4 if kind == -1 else (len(CARTESIAN[kind]) if kind >= 0 else 2 * abs(kind) + 1) for kind in types]
    starts = np.concatenate([[0], np.cumsum(sizes)])
    # The shells of each atom, in order: equivalent atoms carry the same shells.
    shells = {}
    for shell, atom in enumerate(atoms):
        shells.setdefault(atom, []).append(shell)
    movers = []
    for matrix, permutation in zip(group.operations, group.permutations):
        blocks = {}
        groups = {}
        for atom, own in shells.items():
            target = shells[permutation[atom]]
            if [types[s] for s in own] != [types[s] for s in target]:
                return None
            for source, destination in zip(own, target):
                kind = types[source]
                if kind not in blocks:
                    blocks[kind] = _shell_matrix(matrix, kind)
                sources, destinations = groups.setdefault(kind, ([], []))
                sources.append(np.arange(starts[source], starts[source + 1]))
                destinations.append(np.arange(starts[destination], starts[destination + 1]))
        # Shells of one kind move together: each batch applies its shell matrix to every source shell at once.
        batches = [
            (blocks[kind], np.concatenate(sources), np.concatenate(destinations))
            for kind, (sources, destinations) in groups.items()
        ]

        def mover(columns, batches=batches):
            """Move the coefficient columns of one operation.

            Args:
                columns: MO coefficient columns, of shape (basis functions, columns).
                batches: Precomputed (shell matrix, source indices, destination indices) triples of the operation, bound
                    when it is defined.

            Returns:
                The columns after the operation, with every function moved to the equivalent atom and its angular part
                rotated.
            """
            result = np.zeros_like(columns)
            for block, source, destination in batches:
                shell = block.shape[0]
                moved = block @ columns[source].reshape(-1, shell, columns.shape[1])
                result[destination.reshape(-1, shell)] = moved
            return result

        movers.append(mover)
    return movers


@dataclass
class OrbitalSet:
    """Degenerate canonical orbitals together: zero-based indices, energy in hartree, occupied or not, irreducible
    representation (None when unassigned), its number among sets of that representation from the lowest, sigma or
    pi character in a planar molecule, and the representation matrices of the operations on the set.
    """

    indices: list
    energy: float
    occupied: bool
    irrep: Irrep = None
    number: int = 0
    character: str = None
    matrices: list = None
    # Per degenerate component, the Cartesian function it transforms like, in LaTeX, and the orthogonal matrix whose
    # columns combine the canonical orbitals into those components; None for a single orbital or when none is found.
    components: list = None
    rotation: np.ndarray = None

    def label(self):
        r"""LaTeX label such as 1e_{1g}, or the orbital number when unassigned.

        Returns:
            The label, or :math:`\psi` with the one-based orbital numbers as its subscript when the set has no irreducible
            representation.
        """
        if self.irrep is None:
            return r"\psi_{" + ",".join(str(i + 1) for i in self.indices) + "}"
        return f"{self.number}{self.irrep.orbital()}"

    def character_label(self):
        r"""Orbital character, :math:`\sigma`, :math:`\pi`, :math:`\sigma^*` or :math:`\pi^*`, in LaTeX, or None.

        Returns:
            The bonding or antibonding character as a LaTeX symbol, starred when the orbital is unoccupied; None when it
            has none.
        """
        if self.character is None:
            return None
        return "\\" + self.character + ("" if self.occupied else "^{*}")


@dataclass
class OrbitalSymmetry:
    """Point group of a checkpoint's geometry and the canonical alpha orbital sets in it."""

    group: PointGroup
    sets: list

    def set_of(self, index):
        """The set holding a zero-based orbital index.

        Args:
            index: Zero-based orbital index.

        Returns:
            The orbital set that contains it.

        Raises:
            StopIteration: No set holds the index.
        """
        return next(s for s in self.sets if index in s.indices)


def orbital_symmetry(records, tolerance=0.02, degeneracy=1e-4, spin="alpha"):
    """Symmetry of the canonical orbitals of one spin channel of a formatted checkpoint.

    Args:
        records: Records from ``read_fchk_records``.
        tolerance: Geometric tolerance in bohr for the point group.
        degeneracy: Largest orbital-energy difference in hartree within one degenerate set.
        spin: The spin channel, ``"alpha"`` or ``"beta"``; a restricted checkpoint's beta orbitals are its alpha ones.

    Returns:
        The :class:`OrbitalSymmetry`; sets keep None as representation when the basis is not supported or an orbital
        set does not carry one irreducible representation.
    """
    numbers = np.asarray(records["Atomic numbers"], dtype=int)
    coordinates = np.asarray(records["Current cartesian coordinates"], dtype=float).reshape(-1, 3)
    group = point_group(numbers, coordinates, tolerance)

    energies = np.asarray(spin_record(records, spin, "{Spin} Orbital Energies"), dtype=float)
    basis = int(records["Number of basis functions"])
    coefficients = np.asarray(spin_record(records, spin, "{Spin} MO coefficients"), dtype=float).reshape(-1, basis).T
    occupied = int(spin_record(records, spin, "Number of {spin} electrons"))
    sets = []
    for index, energy in enumerate(energies):
        last = sets[-1] if sets else None
        if last and (index < occupied) == last.occupied and abs(energy - energies[last.indices[-1]]) < degeneracy:
            last.indices.append(index)
        else:
            sets.append(OrbitalSet([index], float(energy), index < occupied))
    movers = basis_operations(records, group)
    plane = None
    if group.planar is not None:
        # The molecular plane is a mirror of every planar geometry; it fixes sigma or pi character.
        plane = next(
            (i for i, m in enumerate(group.operations) if np.allclose(m, _reflection(group.planar), atol=1e-6)), None
        )
    counts, partner_cache = {}, {}
    for orbital_set in sets:
        orbital_set.energy = float(np.mean(energies[orbital_set.indices]))
        if movers is None:
            continue
        columns = coefficients[:, orbital_set.indices]
        inverse = np.linalg.pinv(columns)
        orbital_set.matrices = [inverse @ mover(columns) for mover in movers]
        characters = np.array([np.trace(m) for m in orbital_set.matrices])
        orbital_set.irrep = group.assign(characters, len(orbital_set.indices))
        if orbital_set.irrep is not None:
            counts[orbital_set.irrep.label] = counts.get(orbital_set.irrep.label, 0) + 1
            orbital_set.number = counts[orbital_set.irrep.label]
            if orbital_set.irrep.dimension > 1:
                label = orbital_set.irrep.label
                if label not in partner_cache:
                    partner_cache[label] = partners(group, orbital_set.irrep)
                if partner_cache[label] is not None:
                    names, matrices = partner_cache[label]
                    orbital_set.components = names
                    orbital_set.rotation = _intertwiner(orbital_set.matrices, matrices)
        if plane is not None:
            mirror = characters[plane] / len(orbital_set.indices)
            orbital_set.character = "sigma" if mirror > 0.8 else ("pi" if mirror < -0.8 else None)
    return OrbitalSymmetry(group, sets)


def _polynomial(vector, powers):
    """A polynomial's coefficients over monomials as LaTeX, scaled so its smallest coefficient is one and its first is
    positive, such as :math:`x^{2}z-y^{2}z`.

    Args:
        vector: Coefficients of the monomials.
        powers: Exponents (a, b, c) of the monomials, in the order of ``vector``.

    Returns:
        The polynomial in LaTeX.
    """
    vector = np.asarray(vector, dtype=float)
    kept = [
        i for i in np.argsort([-sum(p[:1]) for p in powers], kind="stable") if abs(vector[i]) > 1e-6 * abs(vector).max()
    ]
    scale = min(abs(vector[i]) for i in kept) * np.sign(vector[kept[0]])
    text = ""
    for i in kept:
        value = vector[i] / scale
        rounded = round(value)
        number = (
            ""
            if abs(abs(value) - 1) < 1e-3
            else (str(abs(rounded)) if abs(value - rounded) < 1e-3 else f"{abs(value):.3g}")
        )
        monomial = "".join(axis + (f"^{{{e}}}" if e > 1 else "") for axis, e in zip("xyz", powers[i]) if e)
        text += ("-" if value < 0 else ("+" if text else "")) + number + monomial
    return text


def partners(group, irrep, max_degree=4):
    """Cartesian functions that the components of a degenerate representation transform like, as in character tables, such
    as (xz, yz) for E1g of D6h, in the conventional frame.

    The lowest degree whose polynomials hold the representation is used: the sparsest projected monomial fixes one copy
    of it, and the sparsest projections of monomials onto that copy are its components.

    Args:
        group: The point group, with its operations, frame and order.
        irrep: The degenerate irreducible representation.
        max_degree: Highest polynomial degree searched.

    Returns:
        The LaTeX functions and, per operation, the orthogonal matrix of the representation on them; None when no
        polynomial up to ``max_degree`` carries the representation.
    """
    local = [group.frame @ m @ group.frame.T for m in group.operations]
    d = irrep.dimension
    norm = irrep.characters @ irrep.characters / group.order
    for degree in range(1, max_degree + 1):
        powers = _all_powers(degree)
        representation = _polynomial_representation(local, powers)
        projector = d / (group.order * norm) * sum(c * r for c, r in zip(irrep.characters, representation))
        if np.linalg.matrix_rank(projector, tol=1e-8) < d:
            continue
        sparsity = lambda v: (int((np.abs(v) > 1e-8 * np.abs(v).max()).sum()), 0)
        images = [projector[:, q] for q in range(len(powers)) if np.abs(projector[:, q]).max() > 1e-8]
        first = min(images, key=sparsity)
        orbit = np.array([r @ first for r in representation]).T
        u, s, _ = np.linalg.svd(orbit, full_matrices=False)
        basis = u[:, s > 1e-8 * s.max()]
        if basis.shape[1] != d:
            continue
        candidates = sorted((basis @ (basis.T @ np.eye(len(powers))[:, q]) for q in range(len(powers))), key=sparsity)
        chosen = []
        for candidate in candidates:
            if np.abs(candidate).max() > 1e-8 and np.linalg.matrix_rank(
                np.array(chosen + [candidate]).T, tol=1e-8
            ) > len(chosen):
                chosen.append(candidate)
            if len(chosen) == d:
                break
        functions = np.array(chosen).T
        inverse = np.linalg.pinv(functions)
        matrices = [inverse @ r @ functions for r in representation]
        # The orthogonal form, through the invariant inner product; for components that character tables list it is
        # the identity up to scale, so the names still hold.
        gram = sum(m.T @ m for m in matrices)
        values, vectors = np.linalg.eigh(gram)
        root, inverse_root = (vectors * np.sqrt(values)) @ vectors.T, (vectors / np.sqrt(values)) @ vectors.T
        return [_polynomial(f, powers) for f in functions.T], [root @ m @ inverse_root for m in matrices]
    return None


def _intertwiner(orbital_matrices, partner_matrices):
    """The orthogonal matrix T with M(g) T = T D(g) for every operation.

    It turns degenerate orbitals with representation matrices M into components that transform like the partner
    functions of matrices D.

    Args:
        orbital_matrices: Matrices M(g) of the degenerate orbitals under each operation.
        partner_matrices: Matrices D(g) of the partner functions under each operation.

    Returns:
        The orthogonal matrix T, of the dimension of the representation.
    """
    size = len(partner_matrices[0])
    mixing = np.random.default_rng(0).normal(size=(size, size))
    total = sum(m @ mixing @ d.T for m, d in zip(orbital_matrices, partner_matrices))
    u, _, vt = np.linalg.svd(total)
    return u @ vt


def state_symmetry(symmetry, configurations, tolerance=0.2):
    """Irreducible representation of a set of degenerate excited states from their configurations.

    Args:
        symmetry: The :class:`OrbitalSymmetry` of the ground state.
        configurations: Per state, its (occupied, virtual, amplitude) excitations with one-based orbital indices.
        tolerance: Largest distance of a multiplicity from one, and from zero for the others, with which the characters
            are assigned to one irreducible representation.

    Returns:
        The :class:`Irrep`, or None when the orbital sets are unassigned or the printed configurations, which omit
        small amplitudes, do not carry one irreducible representation.
    """
    if any(s.matrices is None for s in symmetry.sets):
        return None
    occupied = sorted({i - 1 for state in configurations for i, _, _ in state})
    virtual = sorted({a - 1 for state in configurations for _, a, _ in state})
    occupied_sets = list(dict.fromkeys(id(symmetry.set_of(i)) for i in occupied))
    virtual_sets = list(dict.fromkeys(id(symmetry.set_of(a)) for a in virtual))
    by_id = {id(s): s for s in symmetry.sets}
    occupied_indices = [i for key in occupied_sets for i in by_id[key].indices]
    virtual_indices = [a for key in virtual_sets for a in by_id[key].indices]
    pairs = {(i, a): row for row, (i, a) in enumerate(product(occupied_indices, virtual_indices))}
    vectors = np.zeros((len(pairs), len(configurations)))
    for column, state in enumerate(configurations):
        for i, a, amplitude in state:
            vectors[pairs[(i - 1, a - 1)], column] += amplitude
    inverse = np.linalg.pinv(vectors)
    characters = []
    for g in range(symmetry.group.order):
        blocks = lambda keys: _block_diagonal([by_id[key].matrices[g] for key in keys])
        moved = np.kron(blocks(occupied_sets), blocks(virtual_sets)) @ vectors
        characters.append(np.trace(inverse @ moved))
    return symmetry.group.assign(np.array(characters), len(configurations), tolerance=tolerance)


def _block_diagonal(matrices):
    """Block-diagonal matrix of square blocks.

    Args:
        matrices: Square arrays, placed along the diagonal in order.

    Returns:
        The block-diagonal array.
    """
    size = sum(len(m) for m in matrices)
    result = np.zeros((size, size))
    start = 0
    for m in matrices:
        result[start : start + len(m), start : start + len(m)] = m
        start += len(m)
    return result

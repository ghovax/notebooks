r"""How far an excitation moves charge: descriptors of difference densities, fragment charges and dipole changes.

Every function here takes plain arrays, so it serves a single excitation, the states along a scan or a pair of
relaxed minima alike, and needs only NumPy.

The density descriptors split the difference density :math:`\Delta\rho=\rho_\mathrm{p}-\rho_\mathrm{h}` into its
gain :math:`\rho_+` and loss :math:`\rho_-` (Le Bahers, Adamo and Ciofini, J. Chem. Theory Comput. 7, 2498 (2011)):
the transferred charge :math:`q_\mathrm{CT}=\int\rho_+\,\mathrm{d}\mathbf{r}` and the distance
:math:`d_\mathrm{CT}` between the centroids of :math:`\rho_+` and :math:`\rho_-`. The same paper's :math:`H` index is
half the sum of the two densities' spreads along the line joining their centroids, and
:math:`t=d_\mathrm{CT}-H` (Ciofini, Le Bahers, Adamo, Odobel and Jacquemin, J. Phys. Chem. C 116, 11946 (2012))
is positive when the gain and loss are separated beyond their own extent.

Caveats that hold for every result: the descriptors depend on which densities are given (unrelaxed hole and
particle densities, or relaxed excited-state densities), on the grid covering both densities, and they reduce a
three-dimensional redistribution to centroids, so two lobes of gain on either side of the loss give a short
:math:`d_\mathrm{CT}` for a real transfer. Fragment charges depend on the partition (Mulliken, Hirshfeld, CM5) and
on where the fragment boundary is drawn.
"""

import numpy as np

from .units import ureg

# Angstrom per bohr, through the registry every runflow quantity shares.
BOHR = (1 * ureg.bohr).to("angstrom").magnitude


def _centroid(coordinates, density):
    """Centroid of a non-negative density on an axis-aligned grid.

    Args:
        coordinates: The three axes' point coordinates in bohr.
        density: Values on the grid.

    Returns:
        The centroid in bohr.
    """
    return (
        np.array([coordinates[k] @ density.sum(axis=tuple(j for j in range(3) if j != k)) for k in range(3)])
        / density.sum()
    )


def _spread(coordinates, density, centre, direction):
    r"""Root-mean-square extent of a density along a unit direction about a point, :math:`\sigma`.

    Args:
        coordinates: The three axes' point coordinates in bohr.
        density: Non-negative values on the grid.
        centre: The point in bohr, normally the density's centroid.
        direction: Unit vector.

    Returns:
        The extent in bohr.
    """
    projected = sum(
        np.reshape(coordinates[k] - centre[k], [-1 if j == k else 1 for j in range(3)]) * direction[k] for k in range(3)
    )
    return float(np.sqrt((density * projected**2).sum() / density.sum()))


def descriptors(origin, axes, hole, particle):
    r"""Charge-transfer descriptors of hole and particle densities on one axis-aligned grid.

    Args:
        origin: Grid origin in bohr, shape (3,).
        axes: Grid step vectors in bohr as rows of a diagonal (3, 3) array.
        hole: Density removed by the excitation, :math:`\rho_\mathrm{h}`, in :math:`a_0^{-3}`, non-negative.
        particle: Density added, :math:`\rho_\mathrm{p}`, on the same grid.

    Returns:
        A dict with the transferred charge :math:`q_\mathrm{CT}`, the distances in angstrom and the indices, keyed as
        commented below.

    Raises:
        ValueError: If the grids differ in shape, the axes are not diagonal, or a density is empty.
    """
    hole, particle = np.asarray(hole).astype(float), np.asarray(particle).astype(float)
    axes = np.asarray(axes, dtype=float)
    if hole.shape != particle.shape or hole.ndim != 3:
        raise ValueError(f"hole {hole.shape} and particle {particle.shape} must be one three-dimensional grid")
    if np.count_nonzero(axes - np.diag(np.diag(axes))):
        raise ValueError("descriptors need an axis-aligned grid")
    step = np.diag(axes)
    coordinates = [origin[k] + step[k] * np.arange(hole.shape[k]) for k in range(3)]
    volume = np.prod(step)
    difference = particle - hole
    gain, loss = np.clip(difference, 0, None), np.clip(-difference, 0, None)
    if not gain.sum() or not loss.sum():
        raise ValueError("the difference density has no gain or no loss")
    plus, minus = _centroid(coordinates, gain), _centroid(coordinates, loss)
    vector = plus - minus
    length = float(np.linalg.norm(vector))
    # Along the line between the centroids; for coinciding centroids no direction exists and H is left out.
    if length > 0:
        direction = vector / length
        spread = (_spread(coordinates, gain, plus, direction) + _spread(coordinates, loss, minus, direction)) / 2
    else:
        spread = None
    return dict(
        # Transferred charge q_CT, the gain integrated, in elementary charges.
        transferred=gain.sum() * volume,
        # Distance d_CT between the centroids of the gain and the loss, in angstrom.
        transfer_distance=np.linalg.norm(_centroid(coordinates, gain) - _centroid(coordinates, loss)) * BOHR,
        # Distance D between the hole and particle centroids, in angstrom.
        separation=np.linalg.norm(_centroid(coordinates, particle) - _centroid(coordinates, hole)) * BOHR,
        # Hole-particle overlap, the integral of the square root of their product, dimensionless.
        overlap=np.sqrt(hole * particle).sum() * volume,
        # Vector from the loss centroid to the gain centroid, in angstrom.
        transfer_vector=vector * BOHR,
        # H index, half the summed extents of the gain and the loss along that vector, in angstrom; None without one.
        spread=None if spread is None else spread * BOHR,
        # t index, d_CT minus H, in angstrom: positive when the gain and loss are separated beyond their extent.
        separation_index=None if spread is None else (length - spread) * BOHR,
    )


def fragment_charges(charges, fragments):
    """Sum of atomic charges over each fragment.

    Args:
        charges: One charge per atom in elementary charges, in atom order.
        fragments: Mapping of fragment names to one-based atom numbers; together they need not cover the molecule.

    Returns:
        Mapping of each fragment name to its total charge.

    Raises:
        ValueError: If an atom number is outside the molecule or appears in two fragments.
    """
    charges = np.asarray(charges, dtype=float)
    seen = set()
    totals = {}
    for name, atoms in fragments.items():
        atoms = list(atoms)
        if any(not 1 <= atom <= len(charges) for atom in atoms):
            raise ValueError(f"fragment {name} names an atom outside 1..{len(charges)}")
        if seen & set(atoms):
            raise ValueError(f"fragment {name} shares atoms {sorted(seen & set(atoms))} with another")
        seen |= set(atoms)
        totals[name] = float(charges[np.asarray(atoms) - 1].sum())
    return totals


def dipole_change(first, second):
    r"""Change of a dipole vector between two states, :math:`\Delta\boldsymbol{\mu}=\boldsymbol{\mu}_2-\boldsymbol{\mu}_1`.

    Both dipoles must be in one molecular frame and one origin convention; for a charged molecule the dipole depends
    on the origin, so only a neutral one's change is origin-free.

    Args:
        first: Dipole x, y, z of the first state, in debye; a fourth entry, the printed total, is ignored.
        second: Dipole of the second state, the same way.

    Returns:
        The change as a (3,) array in debye and its magnitude.
    """
    change = np.asarray(second[:3], dtype=float) - np.asarray(first[:3], dtype=float)
    return change, float(np.linalg.norm(change))

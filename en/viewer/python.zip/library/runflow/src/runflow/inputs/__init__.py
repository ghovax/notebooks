"""Gaussian inputs: every linked job, shaped like the jobs runflow reads from a log where the input defines them."""

import re
from pathlib import Path

from ..route import SECTION_MODES, gic_mode, request, route_keywords, route_sections
from ..text import NUMBER, parse_float
from ..units import ATOMIC_NUMBERS
from .gic import parse_gic_section, validate
from .sections import (
    parse_atom_selection,
    parse_connectivity,
    parse_modredundant_section,
    resolve_atom_selection,
    validate_modredundant,
)


def read_gaussian_input(path):
    """Every linked job of a Gaussian input, shaped like the jobs runflow reads from a log where the input defines them.

    Args:
        path: Gaussian input (``.gjf`` or ``.com``), jobs separated by ``--Link1--``.

    Returns:
        One mapping per job with ``links`` (the Link 0 commands as the first link's ``commands``), ``route`` (its
        lines joined), ``request`` (the parsed route), ``archive`` (a mapping holding the ``title``, or None),
        ``charge`` and ``multiplicity`` (None when read from the checkpoint), ``geometries`` (one mapping of
        ``atomic_numbers`` and Cartesian ``vectors`` in angstrom, or none for a checkpoint geometry or a Z-matrix)
        and ``timing`` (None, as nothing has run); then the sections read after the molecule, each None when the
        route asks for none: ``gic`` (its ``mode``, the ``entries`` of the GIC section and the ``problems`` found in
        it), ``connectivity`` (one record per line, from ``parse_connectivity``), ``read_optimize`` (its ``rules`` and
        the optimized ``atoms``, None when they cannot be resolved) and ``modredundant`` (its ``entries`` and
        ``problems``); and ``structures``, the further structures of ``Opt=QST2`` or ``QST3``, each with its
        ``title``, ``charge``, ``multiplicity``, ``geometry``, ``connectivity``, ``read_optimize`` and
        ``modredundant``, empty otherwise.
    """
    jobs = []
    text = Path(path).read_text(errors="replace").replace("\r\n", "\n")
    for section in re.split(r"(?im)^\s*--link1--\s*$", text):
        lines, index, commands = section.split("\n"), 0, {}
        while index < len(lines) and (not lines[index].strip() or lines[index].lstrip().startswith("%")):
            if lines[index].strip():
                key, _, value = lines[index].strip().partition("=")
                commands[key.strip()] = value.strip()
            index += 1
        if index >= len(lines) or not lines[index].lstrip().startswith("#"):
            continue
        route = []
        while index < len(lines) and lines[index].strip():
            route.append(lines[index].strip())
            index += 1
        route = " ".join(route)
        geometry = {name.lower(): options.lower() for name, options in route_keywords(route)}.get("geom", "")
        asked, mode = route_sections(route), gic_mode(route)
        # Every structure in the manual's order: title, molecule, connectivity, frozen atoms, then the modifications,
        # which are the GIC section when the route reads one; Geom=AllCheck takes the first two from the checkpoint.
        structures = []
        for position in range(1 if "allcheck" in geometry else asked["structures"]):
            structure, index = _structure_sections(lines, index, geometry, asked, mode, position == 0)
            structures.append(structure)
        first = structures[0] if structures else _structure_sections(lines, index, geometry, asked, mode, True)[0]
        index = first.pop("end", index)
        numbers = first["geometry"]["atomic_numbers"]
        entries = parse_gic_section(first.pop("gic_lines"))
        gic = (
            None
            if mode is None
            else {
                # How the route builds the coordinates: read-all, add, automatic or old.
                "mode": mode,
                # One entry per line of the section, as parse_gic_section reads them.
                "entries": entries,
                # Problems found in the section against the molecule's atom count; empty when the atoms are unknown.
                "problems": validate(entries, len(numbers) if numbers else 10**9),
            }
        )
        first_link = {
            # Link 0 commands by name, with their values as written.
            "commands": commands,
        }
        archive = (
            {
                # The input's title section, joined into one line as Gaussian archives it.
                "title": first["title"],
            }
            if first["title"]
            else None
        )
        for structure in structures[1:]:
            structure.pop("gic_lines")
            structure.pop("end", None)
        jobs.append(
            dict(
                links=[first_link],
                route=route,
                request=request(route),
                archive=archive,
                charge=first["charge"],
                multiplicity=first["multiplicity"],
                geometries=[first["geometry"]] if numbers else [],
                timing=None,
                gic=gic,
                connectivity=first["connectivity"],
                read_optimize=first["read_optimize"],
                modredundant=first["modredundant"],
                structures=structures[1:],
            )
        )
    return jobs


def _block(lines, index):
    """The next section of one linked job: the nonblank lines after the blank line that closes the previous one.

    Args:
        lines: Lines of the linked job.
        index: Index of the blank line, or the end, that closes the previous section.

    Returns:
        The section's lines and the index of the blank line, or the end, that closes it.
    """
    index += 1
    start = index
    while index < len(lines) and lines[index].strip():
        index += 1
    return lines[start:index], index


def _molecule(rows):
    """Atoms of the rows of a molecule specification after its charge and multiplicity line.

    Args:
        rows: The rows, one atom each.

    Returns:
        The atomic numbers and the Cartesian coordinates in angstrom, both empty for a Z-matrix or a row not
        understood, and the names of the variables the rows use, which a following section defines.
    """
    numbers, vectors, names, cartesian = [], [], set(), True
    for row in rows:
        fields = row.replace(",", " ").split()
        symbol = re.match(r"[A-Za-z]+|\d+", fields[0])
        element = symbol and (int(symbol[0]) if symbol[0].isdigit() else ATOMIC_NUMBERS.get(symbol[0].casefold()))
        names |= {value.lstrip("-+").lower() for value in fields[1:] if re.fullmatch(r"[-+]?[A-Za-z]\w*", value)}
        # Cartesian rows only, with an optional freeze flag; a Z-matrix is left for Gaussian to convert.
        if not element or len(fields) not in (4, 5) or not all(re.fullmatch(NUMBER, value) for value in fields[-3:]):
            cartesian = False
        elif cartesian:
            numbers.append(element)
            vectors.append([parse_float(value) for value in fields[-3:]])
    return (numbers, vectors, names) if cartesian else ([], [], names)


def _structure_sections(lines, index, geometry, asked, mode, first):
    """One structure of a linked job and the sections that follow it, read in the manual's order.

    Args:
        lines: Lines of the linked job.
        index: Index of the blank line, or the end, that closes the previous section.
        geometry: Options of the route's Geom keyword, lower case.
        asked: Sections the route asks for, from ``route_sections``.
        mode: GIC mode of the route, from ``gic_mode``.
        first: Whether this is the job's first structure, the only one a GIC section follows.

    Returns:
        The structure, with ``title``, ``charge``, ``multiplicity``, ``geometry``, ``connectivity``,
        ``read_optimize``, ``modredundant`` and ``gic_lines`` (the GIC section's lines, empty without one) and
        ``end``, and the index of the blank line that closes its last section.
    """
    title, charge, multiplicity, numbers, vectors = "", None, None, [], []
    if "allcheck" not in geometry:
        heading, index = _block(lines, index)
        title = " ".join(line.strip() for line in heading)
        rows, index = _block(lines, index)
        if rows:
            fields = rows[0].replace(",", " ").split()
            if len(fields) >= 2 and all(re.fullmatch(r"[-+]?\d+", value) for value in fields[:2]):
                charge, multiplicity = int(fields[0]), int(fields[1])
            if "check" not in geometry:
                numbers, vectors, names = _molecule(rows[1:])
                # Z-matrix variables, and constants after them, are sections that define the names the rows use.
                if names:
                    variables, index = _block(lines, index)
                    following, end = _block(lines, index)
                    if following and all(
                        line.split() and re.split(r"[\s=]+", line.strip())[0].lower() in names for line in following
                    ):
                        index = end
    connectivity = read_optimize = modredundant = None
    if asked["connectivity"]:
        section, index = _block(lines, index)
        connectivity = parse_connectivity(section)
    if asked["read_optimize"]:
        section, index = _block(lines, index)
        rules = parse_atom_selection(section)
        read_optimize = dict(rules=rules, atoms=resolve_atom_selection(rules, numbers) if numbers else None)
    gic_lines = []
    if first and mode in SECTION_MODES:
        gic_lines, index = _block(lines, index)
    elif asked["modredundant"]:
        section, index = _block(lines, index)
        entries = parse_modredundant_section(section)
        modredundant = dict(entries=entries, problems=validate_modredundant(entries, len(numbers) if numbers else None))
    structure = dict(
        title=title,
        charge=charge,
        multiplicity=multiplicity,
        geometry=dict(atomic_numbers=numbers, vectors=vectors),
        connectivity=connectivity,
        read_optimize=read_optimize,
        modredundant=modredundant,
        gic_lines=gic_lines,
        end=index,
    )
    return structure, index

"""Harmonic analyses and thermochemistry of one linked job."""

import re

from ..text import NUMBER, parse_float


def frequency_sets(text):
    """Read distinct harmonic analyses, preferring matching high-precision vectors.

    Args:
        text: Native text of one linked job.

    Returns:
        The frequencies, reduced masses, force constants, IR intensities and mode sets.
    """
    pattern = r"^[ \t]*Frequencies[ \t]+(-{2,3})[ \t]+([^\n]+)"
    markers = list(re.finditer(pattern, text, re.MULTILINE))
    groups = []
    current = []
    precision = None
    for position, match in enumerate(markers):
        kind = "high" if match[1] == "---" else "standard"
        preceding = text[: match.start()].splitlines()[-3:]
        indices = next(
            (
                [int(n) for n in line.split()]
                for line in preceding
                if line.split() and all(n.isdigit() for n in line.split())
            ),
            [],
        )
        symmetry = preceding[-1].split() if preceding else []
        frequencies = [parse_float(value) for value in re.findall(NUMBER, match[2])]
        if current and (precision != kind or indices and indices[0] == 1):
            groups.append((precision, current))
            current = []
        precision = kind
        stop = markers[position + 1].start() if position + 1 < len(markers) else len(text)
        section = text[match.end() : stop]
        boundary = re.search(
            r"^[ \t]*(?:Thermochemistry|Harmonic frequencies|Zero-point correction|-----)",
            section,
            re.MULTILINE,
        )
        if boundary:
            section = section[: boundary.start()]
        properties = {}
        labels = [
            ("reduced_mass", r"(?:Red\. masses|Reduced masses)"),
            ("force_constant", r"(?:Frc consts|Force constants)"),
            ("ir_intensity", r"(?:IR Inten|IR Intensities)"),
            ("raman_activity", r"(?:Raman Activ|Raman Activities)"),
            ("depolarization_plane", r"(?:Depolar \(P\)|Depol\. \(Plane\))"),
            ("depolarization_unpolarized", r"(?:Depolar \(U\)|Depol\. \(Unpol\))"),
        ]
        for key, label in labels:
            values = re.search(label + r"[ \t]+-{2,3}([^\n]+)", section)
            properties[key] = [parse_float(value) for value in re.findall(NUMBER, values[1])] if values else []
        centers = []
        atoms = []
        vectors = [[] for _ in frequencies]
        if kind == "high":
            header = re.search(r"^[ \t]*Coord[ \t]+Atom[ \t]+Element:[^\n]*\n", section, re.MULTILINE)
            components = {}
            if header:
                for line in section[header.end() :].splitlines():
                    words = line.split()
                    if len(words) != 3 + len(frequencies) or not all(w.isdigit() for w in words[:3]):
                        break
                    component, center, number = map(int, words[:3])
                    component = (component - 1) % 3 + 1
                    components[center, component] = [parse_float(v) for v in words[3:]]
                    if center not in centers:
                        centers.append(center)
                        atoms.append(number)
                if all((center, component) in components for center in centers for component in (1, 2, 3)):
                    vectors = [
                        [[components[center, component][mode] for component in (1, 2, 3)] for center in centers]
                        for mode in range(len(frequencies))
                    ]
        else:
            header = re.search(
                r"^[ \t]*Atom[ \t]+AN[ \t]+X[ \t]+Y[ \t]+Z[^\n]*\n",
                section,
                re.MULTILINE,
            )
            if header:
                for line in section[header.end() :].splitlines():
                    words = line.split()
                    if len(words) != 2 + 3 * len(frequencies) or not all(w.isdigit() for w in words[:2]):
                        break
                    centers.append(int(words[0]))
                    atoms.append(int(words[1]))
                    for mode in range(len(frequencies)):
                        vectors[mode].append([parse_float(v) for v in words[2 + 3 * mode : 5 + 3 * mode]])
        for mode, frequency in enumerate(frequencies):
            record = {
                # One-based native normal-mode index; None if the header is absent.
                "mode": indices[mode] if mode < len(indices) else None,
                # Printed irreducible-representation label, when available.
                "symmetry": symmetry[mode] if mode < len(symmetry) else None,
                # Projected frequency in inverse centimetres; negative flags imaginary.
                "frequency": frequency,
                # Native center indices, in displacement-table order.
                "centers": centers.copy(),
                # Atomic numbers in displacement-table order.
                "atomic_numbers": atoms.copy(),
                # Normalized Cartesian direction vectors; dimensionless, not an amplitude.
                "displacements": vectors[mode],
                # Whether retained vectors use the high-precision or standard native format.
                "vector_precision": kind if vectors[mode] else None,
            }
            # Reduced mass uses amu; force constant mDyne/angstrom; IR intensity km/mol.
            # Raman activity uses angstrom**4/amu; both depolarization ratios are dimensionless.
            for key, _ in labels:
                record[key] = properties[key][mode] if mode < len(properties[key]) else None
            current.append(record)
    if current:
        groups.append((precision, current))
    analyses = []
    previous_kind = None
    for kind, modes in groups:
        if kind == "standard" and previous_kind == "high" and analyses and len(analyses[-1]) == len(modes):
            high = analyses[-1]
            if all(
                a["mode"] == b["mode"] and abs(a["frequency"] - b["frequency"]) < 0.001
                for a, b in zip(high, modes, strict=True)
            ):
                for standard, precise in zip(modes, high, strict=True):
                    if precise["displacements"] and precise["centers"] == standard["centers"]:
                        standard["displacements"] = precise["displacements"]
                        standard["vector_precision"] = "high"
                analyses[-1] = modes
                previous_kind = kind
                continue
        analyses.append(modes)
        previous_kind = kind
    return analyses


def thermochemistry(block):
    """Read thermal corrections and native partition contributions.

    Args:
        block: Native text of one linked job.

    Returns:
        The thermochemistry summary and its partition contributions.
    """
    thermo = {}
    # Every correction and summed thermochemical energy below is in hartree.
    for label, key in [
        # Harmonic zero-point vibrational correction.
        ("Zero-point correction", "zero_point"),
        # Finite-temperature internal-energy correction, including zero point.
        ("Thermal correction to Energy", "thermal_energy"),
        # Finite-temperature enthalpy correction.
        ("Thermal correction to Enthalpy", "thermal_enthalpy"),
        # Finite-temperature Gibbs free-energy correction.
        ("Thermal correction to Gibbs Free Energy", "thermal_gibbs"),
        # Electronic plus zero-point energy.
        ("Sum of electronic and zero-point Energies", "energy_zero_point"),
        # Electronic plus thermal internal energy.
        ("Sum of electronic and thermal Energies", "energy_thermal"),
        # Electronic plus thermal enthalpy.
        ("Sum of electronic and thermal Enthalpies", "enthalpy"),
        # Electronic plus thermal Gibbs free energy.
        ("Sum of electronic and thermal Free Energies", "gibbs"),
    ]:
        values = re.findall(re.escape(label) + r"=\s*(" + NUMBER + r")", block)
        if values:
            thermo[key] = parse_float(values[-1])
    conditions = re.search(
        r"Temperature\s+(" + NUMBER + r") Kelvin\.\s+Pressure\s+(" + NUMBER + r") Atm",
        block,
    )
    if conditions:
        thermo.update(
            # Ideal-gas analysis temperature in kelvin.
            temperature=parse_float(conditions[1]),
            # Ideal-gas analysis pressure in atmospheres.
            pressure=parse_float(conditions[2]),
        )
    symmetry = re.findall(r"Rotational symmetry number\s+(\d+)", block)
    if symmetry:
        # Rotational symmetry number used in the native entropy calculation.
        thermo["symmetry_number"] = int(symmetry[-1])
    components = []
    thermal_table = re.search(r"E \(Thermal\)\s+CV\s+S\n[^\n]+\n(.*?)\n\s+Q\s+Log10", block, re.DOTALL)
    if thermal_table:
        for name, energy, heat, entropy in re.findall(
            r"^\s*([A-Za-z]+(?:\s+\d+)?)\s+(" + NUMBER + r")\s+(" + NUMBER + r")\s+(" + NUMBER + r")\s*$",
            thermal_table[1],
            re.MULTILINE,
        ):
            components.append(
                {
                    # Native thermochemical contribution, such as rotational or vibrational.
                    "component": " ".join(name.lower().split()),
                    # Thermal energy contribution in kcal/mol.
                    "energy": parse_float(energy),
                    # Native constant-volume heat capacity in cal/(mol K).
                    "heat_capacity": parse_float(heat),
                    # Native thermochemical entropy in cal/(mol K).
                    "entropy": parse_float(entropy),
                }
            )
    return (thermo, components)

"""Settings, links, diagnostics and the archive entry of one linked job."""

import hashlib
import re
import tomllib
from functools import cache
from importlib.resources import files

from ..route import request
from ..text import NUMBER, line_of, parse_float


@cache
def catalogue():
    """What runflow recognizes in Gaussian output: error and warning patterns, indexed headings and result categories.

    Returns:
        The parsed ``catalogue.toml`` beside this module.
    """
    return tomllib.loads(files(__package__).joinpath("catalogue.toml").read_text())


def route_text(block):
    """Read the first route section of a linked job.

    Gaussian echoes the route in fixed-width lines after one leading space and wraps them anywhere,
    also inside a keyword, so the lines are concatenated as printed rather than joined with spaces.

    Args:
        block: Native text of one linked job.

    Returns:
        The route text, empty when none is printed.
    """
    lines = block.splitlines()
    route = []
    for index, line in enumerate(lines):
        if line.strip().startswith("#"):
            for item in lines[index:]:
                if item.strip().startswith("---"):
                    break
                route.append(item.removeprefix(" "))
            break
    return " ".join("".join(route).split())


def _links(block):
    """Gaussian's links of one linked job in execution order: Link 0, then each executable link as it finished.

    Link 0 holds the commands echoed before the route. Every other link is one of Gaussian's executables, such
    as l101 or l502; the log records each when it leaves, with its time, memory limit and timing. A link left
    several times, such as l502 during an optimization, appears once per exit.

    Args:
        block: Native text of one linked job.

    Returns:
        One record per link, each with its ``index`` and its details.
    """
    links = [
        {
            # Gaussian's link number; Link 0 reads the commands before the route.
            "index": 0,
            # Literal Link 0 commands by name, in their native units and spelling. Commands without a value,
            # such as %Save, map to an empty string, and %KJob keeps its space-separated arguments.
            "commands": {
                name: value.strip()
                for name, value in re.findall(
                    r"^[ \t]*(%[A-Za-z0-9]+)(?:[ \t]*=[ \t]*|[ \t]+|(?=[ \t]*$))(.*)$",
                    block.split("\n #", 1)[0],
                    re.MULTILINE,
                )
            },
        }
    ]
    # Only Link 1 prints its executable and process when it starts.
    entering = {
        int(match[1]): (match[2], int(match[3]))
        for match in re.finditer(r"Entering Link\s+(\d+)\s*=\s*(\S+)\s+PID=\s*(\d+)", block)
    }
    for match in re.finditer(
        r"^ Leave Link\s+(\d+) at (.+?), MaxMem=\s*(\d+)\s+cpu:\s*(" + NUMBER + r")\s+elap:\s*(" + NUMBER + r")",
        block,
        re.MULTILINE,
    ):
        index = int(match[1])
        program, process = entering.get(index, (None, None))
        links.append(
            {
                # Gaussian's link number, such as 101 for the input reader or 502 for the SCF.
                "index": index,
                # One-based line of the exit record within the linked job.
                "line": line_of(block, match.start()),
                # Executable path, printed only for Link 1.
                "program": program,
                # Process ID, printed only for Link 1.
                "process": process,
                # Local time the link finished, as printed.
                "finished": match[2].strip(),
                # Memory limit in 8-byte words.
                "memory_limit": int(match[3]),
                # CPU time spent in the link, in seconds.
                "cpu_time": parse_float(match[4]),
                # Elapsed time spent in the link, in seconds.
                "wall_time": parse_float(match[5]),
            }
        )
    return links


def settings(block, route):
    """Read job settings, basis diagnostics and termination markers.

    Args:
        block: Native text of one linked job.
        route: The job's route text.

    Returns:
        The job's settings, counts, request and termination fields.
    """
    basis = re.findall(r"NBasis=\s*(\d+)", block)
    independent = re.findall(r"NBsUse=\s*(\d+)", block)
    electrons = re.findall(r"(\d+) alpha electrons\s+(\d+) beta electrons", block)
    methods = re.findall(r"SCF Done:\s+E\(([^)]+)\)", block)
    closed_shell = None
    if electrons:
        if electrons[-1][0] != electrons[-1][1]:
            closed_shell = False
        elif methods:
            method = methods[-1].upper()
            if method.startswith("RO"):
                closed_shell = False
            elif method.startswith("R"):
                closed_shell = True
    core = re.findall(r"NFC=\s*(\d+)", block)
    overlap = re.findall(r"EigKep=\s*(" + NUMBER + r")", block)
    coefficients = re.findall(r"largest alpha MO coefficient is\s+(" + NUMBER + r")", block, re.IGNORECASE)
    rotation = re.findall(r"Rotational constants \(GHZ\):([^\n]+)", block)
    repulsion = re.findall(r"nuclear repulsion energy\s+(" + NUMBER + r")", block)
    exchange = re.findall(r"ScaHFX=\s*(" + NUMBER + r")", block)
    charge = re.findall(r"Charge\s*=\s*(-?\d+)\s+Multiplicity\s*=\s*(\d+)", block)
    atoms = re.findall(r"NAtoms=\s*(\d+)", block)
    versions = re.findall(r"Gaussian\s+\d+:\s*([^\n]+)", block)
    cpus = re.findall(r"Will use up to\s+(\d+) processors", block)
    point_groups = re.findall(r"Full point group\s+(\S+)", block)
    masses = re.findall(r"Molecular mass:\s*(" + NUMBER + r")", block)
    atomic_masses = []
    for marker in re.finditer(r"AtmWgt=([^\n]*)", block):
        values = [parse_float(v) for v in re.findall(NUMBER, marker[1])]
        for line in block[marker.end() :].splitlines()[1:]:
            words = line.split()
            if not words or not all(re.fullmatch(NUMBER, w) for w in words):
                break
            values.extend(parse_float(v) for v in words)
        atomic_masses = values
    timing = {}
    for label, key in [("Job cpu time", "cpu_time"), ("Elapsed time", "wall_time")]:
        records = re.findall(
            re.escape(label) + r":\s*(\d+) days\s*(\d+) hours\s*(\d+) minutes\s*(" + NUMBER + r") seconds",
            block,
        )
        if records:
            days, hours, minutes, seconds = records[-1]
            # Native accumulated CPU and elapsed wall time are both reported in seconds.
            timing[key] = 86400 * int(days) + 3600 * int(hours) + 60 * int(minutes) + parse_float(seconds)
    lines = block.splitlines()

    def diagnostic(index, code):
        """Retain a native line without Gaussian's leading bullet, its position and its diagnostic code.

        Args:
            index: Zero-based index of the line in the linked job.
            code: Stable identifier of the message, or of the unclassified context.

        Returns:
            Mapping with the 'code', the one-based 'line' and the 'message' with repeated spaces collapsed.
        """
        text = re.sub(r"^[-–—]{1,2}\s+", "", lines[index].strip())
        return {
            # Stable identifier of the native message or unclassified context.
            "code": code,
            # One-based position in the linked job.
            "line": index + 1,
            # Native text without its leading bullet, with repeated spaces collapsed.
            "message": re.sub(r"\s{2,}", " ", text),
        }

    errors = []
    context = []
    error_lines = set()
    for index, line in enumerate(lines):
        code = next(
            (name for name, pattern in catalogue()["errors"].items() if re.search(pattern, line, re.IGNORECASE)), None
        )
        if code:
            errors.append(diagnostic(index, f"gaussian.error.{code}"))
            error_lines.add(index + 1)
        if re.search(r"Error termination", line, re.IGNORECASE):
            for position in range(max(0, index - 6), index):
                text = lines[position].strip()
                if text and not re.fullmatch(r"[-*= ]+", text):
                    context.append(diagnostic(position, "gaussian.error.termination-context"))

    # Gaussian restates one failure on adjacent lines; keep the most specific message.
    if any(error["message"].startswith("Number of steps exceeded") for error in errors):
        errors = [error for error in errors if not error["code"].endswith("optimization-stopped")]
    # An error termination is the consequence of a specific failure, not a second cause.
    if any(not error["code"].endswith("termination") for error in errors):
        errors = [error for error in errors if not error["code"].endswith("termination")]
    # Context repeats across overlapping windows and must not restate an error.
    context = list({entry["line"]: entry for entry in context if entry["line"] not in error_lines}.values())
    return {
        # Native Gaussian release/platform identification, when printed.
        "version": versions[-1].strip() if versions else None,
        # Printed shared-memory processor allocation, not an assumed scheduler request.
        "processors": int(cpus[-1]) if cpus else None,
        # Gaussian's links in execution order: Link 0's commands, then each executable link as it finished.
        "links": _links(block),
        # Printed point-group label; it is not a claim that constraints were removed.
        "point_group": point_groups[-1] if point_groups else None,
        # Native molecular mass in atomic mass units.
        "molecular_mass": parse_float(masses[-1]) if masses else None,
        # Native atom masses in atomic mass units, preserving isotope order.
        "atomic_masses": atomic_masses,
        # Accumulated native CPU and elapsed wall-time fields, in seconds.
        "timing": timing,
        # Explicit scientific or execution failure messages, including unconverged SCF.
        "errors": errors,
        # Unclassified text preceding a native error termination, preserved as context.
        "error_context": context,
        # Molecular integer charge in elementary-charge units.
        "charge": int(charge[-1][0]) if charge else None,
        # Printed spin multiplicity, 2S+1.
        "multiplicity": int(charge[-1][1]) if charge else None,
        # Printed number of atoms, or None when unavailable.
        "atom_count": int(atoms[-1]) if atoms else None,
        # Job types, their options and the excited state this linked job requests; not certification of a result.
        "request": request(route),
        # First printed route section for this linked job, rejoined at Gaussian's line wraps.
        "route": route,
        # Whether this linked job printed normal termination; not physical validation.
        "normal_termination": "Normal termination of Gaussian" in block,
        # Whether this linked job printed an error termination.
        "error_termination": "Error termination" in block,
        # Native scientific warnings retained without dismissing them.
        "warnings": _warnings(block),
        # Stable diagnostic code for each native warning, in the same order.
        "warning_codes": [warning_code(text) for text in _warnings(block)],
        # Number of AO basis functions in this record.
        "basis_count": int(basis[-1]) if basis else None,
        # Printed number of linearly independent basis functions used.
        "independent_count": int(independent[-1]) if independent else None,
        # Printed alpha and beta electron counts, respectively.
        "electron_counts": list(map(int, electrons[-1])) if electrons else None,
        # Restricted doubly occupied reference or known open shell; equal-spin unrestricted cases stay unknown.
        "closed_shell": closed_shell,
        # Smallest retained AO-overlap eigenvalue; dimensionless.
        "overlap_minimum": parse_float(overlap[-1]) if overlap else None,
        # Largest alpha MO coefficient reported in a warning; dimensionless.
        "coefficient_maximum": parse_float(coefficients[-1]) if coefficients else None,
        # Printed number of frozen core orbitals in the TD treatment.
        "frozen_core": int(core[-1]) if core else None,
        # Applied HF exchange fraction; dimensionless.
        "exact_exchange": parse_float(exchange[-1]) if exchange else None,
        # Printed rotational constants in gigahertz; unresolved tokens remain None.
        "rotational_constants": [
            parse_float(value) if re.fullmatch(NUMBER, value) else None for value in rotation[-1].split()
        ]
        if rotation
        else [],
        # Printed nuclear repulsion energy in hartree.
        "nuclear_repulsion": parse_float(repulsion[-1]) if repulsion else None,
        # Whether any optimization-completion marker occurs in this linked job.
        "optimization_complete": "Optimization completed" in block,
    }


def _warnings(text):
    """Retain each scientific warning with its indented continuation lines.

    Args:
        text: Native text to search.

    Returns:
        One string per warning.
    """
    lines = text.splitlines()
    messages = []
    for index, line in enumerate(lines):
        if not re.search(r"\bwarn(?:ing)?\b", line, re.IGNORECASE) or "may not be used" in line:
            continue
        parts = [line.strip()]
        indentation = len(line) - len(line.lstrip())
        for continuation in lines[index + 1 :]:
            if not continuation.strip() or len(continuation) - len(continuation.lstrip()) <= indentation:
                break
            parts.append(continuation.strip())
        messages.append(" ".join(parts))
    return messages


def warning_code(text, program="gaussian"):
    """Identify recurring native warnings, with a stable fingerprint for unclassified messages.

    Args:
        text: Warning text as printed.
        program: Program that printed it, 'gaussian' or 'runflow', which selects the known patterns.

    Returns:
        A code such as gaussian.warning.checkpoint-basis for a known warning, or program.warning.other- followed by a
        digest of the text with its numbers masked.
    """
    text = re.sub(r"^[*\s]*warning\W*", "", " ".join(text.split()), flags=re.IGNORECASE)
    rules = catalogue()["warnings"].get(program, {}).items()
    for code, pattern in rules:
        if re.search(pattern, text, re.IGNORECASE):
            return f"{program}.warning.{code}"
    normalized = re.sub(NUMBER, "#", " ".join(text.casefold().split()))
    digest = hashlib.sha256(normalized.encode()).hexdigest()[:12]
    return f"{program}.warning.other-{digest}"


def _archive_value(text):
    """Archive value: a number, a list of numbers, or the text when it is not numeric.

    Args:
        text: One archive field value.

    Returns:
        The decoded value.
    """
    parts = text.split(",")
    try:
        numbers = [int(part) if re.fullmatch(r"[+-]?\d+", part) else float(part) for part in parts]
    except ValueError:
        return text
    return numbers[0] if len(numbers) == 1 else numbers


def archive(block):
    """Decode the archive entry Gaussian prints when a linked job ends normally.

    The entry is printed in fixed-width lines after one leading space and wrapped anywhere, so the
    lines are concatenated as printed. Fields are separated by a backslash (a vertical bar in some
    builds) and sections by two separators: header, route, title, molecule, then key=value property
    sections.

    Args:
        block: Native text of one linked job.

    Returns:
        The decoded header, route, title, atoms and properties, or None without an entry.
    """
    lines = block.splitlines()
    start = next((index for index, line in enumerate(lines) if re.match(r"^ 1([\\|])1\1", line)), None)
    if start is None:
        return None
    text = ""
    for line in lines[start:]:
        text += line.removeprefix(" ")
        separator = text[1]
        if text.rstrip().endswith(separator + "@"):
            break
    text = text.rstrip()
    separator = text[1]
    sections = text.removesuffix(separator + "@").split(separator * 2)
    header = sections[0].split(separator)
    molecule = sections[3].split(separator)
    charge, multiplicity = (int(value) for value in molecule[0].split(",")[:2])
    atoms = []
    for row in molecule[1:]:
        fields = row.split(",")
        # An optional integer freeze code may precede the coordinates.
        atoms.append([fields[0], *map(float, fields[-3:])])
    atom_count = len(atoms)
    properties, arrays = {}, {}
    for section in sections[4:]:
        if not section:
            continue
        if "=" in section.split(",")[0]:
            # A trailing separator leaves an empty field, which is not a property.
            for field in filter(None, section.split(separator)):
                key, _, value = field.partition("=")
                properties[key] = _archive_value(value)
            continue
        values = _archive_value(section)
        values = values if isinstance(values, list) else [values]
        if len(values) == 3 * atom_count * (3 * atom_count + 1) // 2:
            arrays["force_constants"] = values
        elif len(values) == 3 * atom_count:
            arrays["first_derivatives"] = values
        else:
            arrays.setdefault("unrecognized", []).append(values)
    return {
        # Host on which Gaussian ran, from the GINC field.
        "host": header[2].removeprefix("GINC-"),
        # Job type label, such as SP, FOpt, FTS, Freq or Scan.
        "job_type": header[3],
        # Method label as Gaussian files it, such as RB3LYP or RB3LYP TD-FC.
        "method": header[4],
        # Basis-set label.
        "basis": header[5],
        # Stoichiometry.
        "formula": header[6],
        # User name recorded by Gaussian.
        "user": header[7],
        # Date the job ended, as printed.
        "date": header[8],
        # Route section as archived.
        "route": sections[1],
        # Title section as archived.
        "title": sections[2],
        # Total charge.
        "charge": charge,
        # Spin multiplicity.
        "multiplicity": multiplicity,
        # Final geometry as (symbol, x, y, z) rows in angstrom, in the archived orientation.
        "atoms": atoms,
        # Archived properties, such as Version, State, HF, RMSD, RMSF, Dipole, PG and NImag, by key.
        "properties": properties,
        # Numeric sections: force_constants in hartree/bohr^2 (lower triangle), first_derivatives in
        # hartree/bohr, and any unrecognized sections in printed order.
        "arrays": arrays,
    }

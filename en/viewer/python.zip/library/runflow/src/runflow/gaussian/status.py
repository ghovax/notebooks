"""Completion, verified activity, indexed headings and category availability of a Gaussian log."""

import os
import re
import subprocess
from pathlib import Path

from ..route import keyword_options, route_keywords
from .job import catalogue


def _activity(job_id, process_id, path):
    """Verify activity explicitly rather than guessing from an unfinished log.

    Args:
        job_id: Slurm job ID to query, or None.
        process_id: Local process ID to query, or None.
        path: Log whose writing process is checked.

    Returns:
        The verified activity state and the source that verified it.

    Raises:
        ValueError: The job ID is not numeric.
    """
    if job_id is not None:
        if not re.fullmatch(r"[0-9]+(?:_[0-9]+)?", str(job_id)):
            raise ValueError("Slurm job ID must be numeric, optionally with an array index")
        try:
            result = subprocess.run(
                ["squeue", "--noheader", "--jobs", str(job_id), "--format=%T"],
                capture_output=True,
                text=True,
                timeout=10,
                check=True,
            )
            states = result.stdout.split()
            if states and all(state == "PENDING" for state in states):
                return "pending", "squeue"
            if any(state in {"RUNNING", "COMPLETING", "CONFIGURING"} for state in states):
                return "running", "squeue"
        except (OSError, subprocess.SubprocessError):
            pass  # Without Slurm or lsof here, the next sign of a running job is tried.
    if process_id is not None:
        if not isinstance(process_id, int) or process_id <= 0:
            raise ValueError("Process ID must be a positive integer")
        try:
            os.kill(process_id, 0)
            result = subprocess.run(
                [
                    "lsof",
                    "-a",
                    "-p",
                    str(process_id),
                    "-Ffa",
                    "--",
                    str(path.resolve()),
                ],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
            if any(line in {"aw", "au"} for line in result.stdout.splitlines()):
                return "running", "open writer"
        except (OSError, subprocess.SubprocessError):
            pass  # Without Slurm or lsof here, the next sign of a running job is tried.
    return None, None


def status(path, jobs, *, job_id=None, process_id=None, expected_jobs=None):
    """Report completion/failure or externally verified activity without inventing liveness.

    Args:
        path: Gaussian log.
        jobs: Its parsed linked jobs.
        job_id: Slurm job ID to verify activity with, or None.
        process_id: Local process ID to verify activity with, or None.
        expected_jobs: Number of linked jobs the input contains, or None.

    Returns:
        The log's state with the evidence for it.

    Raises:
        ValueError: The job ID is not numeric.
    """
    path = Path(path)
    if expected_jobs is not None and (not isinstance(expected_jobs, int) or expected_jobs < 1):
        raise ValueError("Expected linked-job count must be a positive integer")
    activity, source = _activity(job_id, process_id, path)
    exists = path.is_file()
    records = []
    for index, job in enumerate(jobs, 1):
        failure = bool(job["errors"]) or any(not step["converged"] for step in job["scf_history"])
        records.append(
            {
                # One-based linked-job position in the file.
                "job": index,
                # Native failure overrides a normal-termination marker.
                "state": "failed" if failure else "complete" if job["normal_termination"] else "unfinished",
                # Exact native diagnostic messages with their job-relative line positions.
                "errors": job["errors"],
            }
        )
    complete = bool(records) and all(record["state"] == "complete" for record in records)
    if expected_jobs is not None:
        complete = complete and len(records) == expected_jobs
    state = (
        "failed"
        if any(record["state"] == "failed" for record in records)
        else activity
        if activity
        else "complete"
        if complete
        else "unfinished"
        if exists
        else "missing"
    )
    return {
        # Overall evidence-based state; unfinished does not imply running or failed.
        "state": state,
        # Verified external activity only; None means no activity was established.
        "activity": activity,
        # Verification source, not an inferred scheduler identity.
        "source": source,
        # Individually assessed linked jobs, including incomplete trailing output.
        "jobs": records,
        # Caller-supplied linked-job count; None means the intended count is unknown.
        "expected_jobs": expected_jobs,
    }


def sections(blocks):
    """Index native link boundaries and scientific headings without claiming full decoding.

    Args:
        blocks: Native text of each linked job, in order.

    Returns:
        One record per heading with its linked job and line.
    """
    pattern = re.compile("|".join(catalogue()["sections"]), re.IGNORECASE)
    records = []
    for job, block in enumerate(blocks, 1):
        for line, text in enumerate(block.splitlines(), 1):
            if pattern.search(text):
                records.append(
                    {
                        # One-based linked-job position.
                        "job": job,
                        # One-based line within that linked job.
                        "line": line,
                        # Exact printed heading; indexing is not a claim of semantic coverage.
                        "heading": text.strip(),
                    }
                )
    return records


def coverage(blocks, jobs, category):
    """Explain one category's availability without assembling unrelated measurements.

    Args:
        blocks: Native text of each linked job, in order.
        jobs: Parsed linked jobs.
        category: Result category, such as ``vibrations`` or ``stability``.

    Returns:
        One record per linked job: whether the route requested the category, whether Gaussian printed it, and
        how many values were read.

    Raises:
        ValueError: The category is unknown.
    """
    specification = catalogue()["coverage"].get(category)
    if specification is None:
        raise ValueError("Unknown result category: " + str(category))
    records = []
    for index, (block, job) in enumerate(zip(blocks, jobs, strict=True), 1):
        values = job
        for key in specification["records"]:
            values = values.get(key, [])
        count = len(values)
        requested = _requested(job, specification["requested"])
        printed = bool(re.search(specification["heading"], block, re.IGNORECASE))
        unfinished = not job["normal_termination"] or bool(job["errors"])
        state = (
            ("partial" if unfinished else "available")
            if count
            else "unparsed"
            if printed
            else "partial"
            if requested and unfinished
            else "not_printed"
            if requested
            else "not_requested"
            if job["route"]
            else "unknown"
        )
        records.append(
            {
                # One-based linked-job position.
                "job": index,
                # Requested independent diagnostic category.
                "category": category,
                # Category availability, distinct from process activity or physical validity.
                "state": state,
                # Number of primary records; interpretation depends on the chosen category.
                "count": count,
                # Whether the printed route explicitly asks for the category.
                "requested": requested,
                # Whether a recognized native data heading was found.
                "printed": printed,
            }
        )
    return records


def _requested(job, rules):
    """Whether a linked job's route requests a category, by any of its catalogue rules.

    Args:
        job: One parsed linked job.
        rules: ``job:<type>``, ``keyword:<name>``, ``option:<keyword>.<option>`` or ``excited``, each negated by a
            leading ``not ``.

    Returns:
        True when any rule holds.
    """
    keywords = {
        name.lower(): keyword_options(options)
        for name, options in route_keywords(job["route"])
        if "/" not in name or options
    }

    def holds(rule):
        """Whether one rule, without negation, holds for the job.

        Args:
            rule: The rule.

        Returns:
            True when the route asks for what the rule names.
        """
        kind, _, name = rule.partition(":")
        if kind == "job":
            return name in job["request"]["jobs"]
        if kind == "keyword":
            return name in keywords
        if kind == "option":
            keyword, _, option = name.partition(".")
            return option in keywords.get(keyword, {})
        return job["request"]["excited"] is not None

    return any(not holds(rule[4:]) if rule.startswith("not ") else holds(rule) for rule in rules)

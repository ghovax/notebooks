"""Population analyses of one linked job: charge schemes, molecular multipoles and bond-index matrices."""

import re
from bisect import bisect_left

from ..text import NUMBER, blocked_matrix, line_of, parse_float


def populations(block, evaluations, geometries):
    """Keep SCF and transition-density populations in distinct records.

    Args:
        block: Native text of one linked job.
        evaluations: The job's energy and force evaluations, each with its character ``offset`` in the block.
        geometries: The job's printed geometries, each with its character ``offset`` in the block, which tie a
            population analysis to the geometry it belongs to.

    Returns:
        One record per population analysis, with the density it describes.
    """
    populations = []
    evaluation_offsets = [entry["offset"] for entry in evaluations]
    geometry_offsets = [entry["offset"] for entry in geometries]
    population_markers = list(re.finditer(r"Population analysis using (.*?)\.\s*$", block, re.MULTILINE))
    for index, match in enumerate(population_markers):
        stop = population_markers[index + 1].start() if index + 1 < len(population_markers) else len(block)
        # Do not attach a later SCF's properties to an earlier analysis when its output is incomplete.
        next_evaluation = bisect_left(evaluation_offsets, match.end())
        if next_evaluation < len(evaluations):
            stop = min(stop, evaluation_offsets[next_evaluation])
        section = block[match.end() : stop]
        evaluation = next_evaluation - 1 if next_evaluation else None
        geometry = evaluations[evaluation]["geometry"] if evaluation is not None else None
        # A new orientation since the SCF makes the association ambiguous.
        if evaluation is not None and bisect_left(geometry_offsets, match.start()) > bisect_left(
            geometry_offsets, evaluations[evaluation]["offset"]
        ):
            geometry = None
        dipole = re.search(
            r"Dipole moment[^\n]*\n\s*X=\s*("
            + NUMBER
            + r")\s+Y=\s*("
            + NUMBER
            + r")\s+Z=\s*("
            + NUMBER
            + r")\s+Tot=\s*("
            + NUMBER
            + r")",
            section,
        )
        charge_table = re.search(
            r"^\s*Mulliken charges:\s*\n\s*1\s*\n((?:\s*\d+\s+[A-Za-z]+\s+" + NUMBER + r"\s*\n)+)",
            section,
            re.MULTILINE,
        )
        charges = (
            []
            if not charge_table
            else [
                {
                    # One-based native atom index.
                    "atom": int(a),
                    # Chemical element symbol as printed.
                    "element": element,
                    # Mulliken atomic charge in elementary-charge units.
                    "charge": parse_float(value),
                }
                for a, element, value in re.findall(r"(\d+)\s+([A-Za-z]+)\s+(" + NUMBER + r")", charge_table[1])
            ]
        )
        quadrupole = re.search(r"^\s*Quadrupole moment[^\n]*\n([^\n]+\n[^\n]+)", section, re.MULTILINE)
        moments = (
            {}
            if quadrupole is None
            else {
                key.lower(): parse_float(value)
                for key, value in re.findall(r"([XYZ]{2})=\s*(" + NUMBER + r")", quadrupole[1])
            }
        )
        populations.append(
            {
                # One-based line of the population analysis in this linked job.
                "line": line_of(block, match.start()),
                # Zero-based reference to the preceding SCF evaluation, when available.
                "evaluation": evaluation,
                # Zero-based reference to its geometry, when the association is unambiguous.
                "geometry": geometry,
                # Population context, distinguishing SCF and transition densities.
                "density": match[1],
                # Population dipole x/y/z and total in debye.
                "dipole": list(map(parse_float, dipole.groups())) if dipole else None,
                # Printed xx/yy/zz/xy/xz/yz components in debye angstrom.
                "quadrupole": moments,  # Debye angstrom.
                # Atom-indexed Mulliken charges; model-dependent populations.
                "mulliken_charges": charges,
                # Native charge schemes, retaining hydrogen-summed and full tables separately.
                "charge_analyses": _charge_analyses(section),
                # Higher molecular moments in native debye/angstrom conventions.
                "multipoles": _multipoles(section),
            }
        )
    return populations


def _atomic_rows(section):
    """Read a simple native atom/element/numeric-column population table.

    Args:
        section: Native text starting at the table.

    Returns:
        One record per atom with its element and values.
    """
    rows = []
    for line in section.splitlines():
        words = line.split()
        if (
            len(words) >= 3
            and words[0].isdigit()
            and re.fullmatch(r"[A-Z][a-z]?", words[1])
            and all(re.fullmatch(NUMBER, w) for w in words[2:])
        ):
            rows.append((int(words[0]), words[1], [parse_float(v) for v in words[2:]]))
        elif rows:
            break
    return rows


def _charge_analyses(section):
    """Keep full and hydrogen-summed atomic populations in distinct native schemes.

    Args:
        section: Native text of one population analysis.

    Returns:
        The charge analyses, keyed by scheme.
    """
    records = []
    pattern = r"^[ \t]*(Mulliken|Lowdin|Löwdin|APT|ESP)(?: atomic| Atomic)? charges([^\n]*):\s*\n"
    for match in re.finditer(pattern, section, re.MULTILINE | re.IGNORECASE):
        atoms = []
        for index, element, values in _atomic_rows(section[match.end() :]):
            atoms.append(
                {
                    # One-based native atom index.
                    "atom": index,
                    # Native element symbol.
                    "element": element,
                    # Atomic charge in elementary-charge units for the named scheme.
                    "charge": values[0],
                    # Atomic spin density in electron units, when the table includes it.
                    "spin": values[1] if "spin" in match[2].lower() and len(values) > 1 else None,
                }
            )
        records.append(
            {
                # Native population scheme label; no scheme is substituted for another.
                "scheme": match[1],
                # Whether hydrogens were condensed into their parent heavy atoms.
                "hydrogens_summed": "hydrogens summed" in match[2].lower(),
                # Native center-resolved atomic populations in table order.
                "atoms": atoms,
            }
        )
    for match in re.finditer(r"Hirshfeld charges, spin densities, dipoles, and CM5 charges[^\n]*\n", section):
        rows = _atomic_rows(section[match.end() :])
        for scheme, column in [("Hirshfeld", 0), ("CM5", 5)]:
            atoms = []
            for index, element, values in rows:
                if len(values) <= column:
                    continue
                atoms.append(
                    {
                        # One-based native atom index.
                        "atom": index,
                        # Native element symbol.
                        "element": element,
                        # Atomic charge in elementary-charge units for the stated scheme.
                        "charge": values[column],
                        # Hirshfeld spin density in electron units; not a CM5 spin model.
                        "spin": values[1] if scheme == "Hirshfeld" and len(values) > 1 else None,
                        # Native Hirshfeld atomic dipole components in atomic units, when printed.
                        "dipole": values[2:5] if scheme == "Hirshfeld" and len(values) >= 5 else None,
                    }
                )
            records.append(
                {
                    # Named Hirshfeld or CM5 charge partition.
                    "scheme": scheme,
                    # This combined native table reports individual hydrogens.
                    "hydrogens_summed": False,
                    # Atomic charges retain their original center identity.
                    "atoms": atoms,
                }
            )
    for match in re.finditer(r"Summary of Natural Population Analysis:", section):
        atoms = []
        for line in section[match.end() :].splitlines():
            words = line.split()
            if (
                len(words) == 7
                and re.fullmatch(r"[A-Z][a-z]?", words[0])
                and words[1].isdigit()
                and all(re.fullmatch(NUMBER, v) for v in words[2:])
            ):
                values = [parse_float(v) for v in words[2:]]
                atoms.append(
                    {
                        # One-based atom index in the native natural-population summary.
                        "atom": int(words[1]),
                        # Native element symbol.
                        "element": words[0],
                        # Natural atomic charge in elementary-charge units.
                        "charge": values[0],
                        # Core-electron population in electrons.
                        "core": values[1],
                        # Valence population in electrons.
                        "valence": values[2],
                        # Rydberg population in electrons.
                        "rydberg": values[3],
                        # Total natural electron population in electrons.
                        "population": values[4],
                    }
                )
            elif atoms:
                break
        records.append(
            {
                # Native natural-population analysis, distinct from Mulliken charges.
                "scheme": "Natural",
                # Natural atomic charges are center-resolved in this summary.
                "hydrogens_summed": False,
                # Printed natural charges and orbital-space populations.
                "atoms": atoms,
            }
        )
    return records


def _multipoles(section):
    """Retain all printed molecular multipoles without confusing traceless tensors.

    Args:
        section: Native text of one population analysis.

    Returns:
        The dipole and higher multipoles as printed.
    """
    result = {}
    labels = [
        ("traceless_quadrupole", r"Traceless Quadrupole", 2),
        ("octupole", r"Octapole|Octupole", 3),
        ("hexadecapole", r"Hexadecapole", 4),
    ]
    for key, label, order in labels:
        marker = re.search(r"(?:" + label + r") moment[^\n]*\n", section)
        if not marker:
            continue
        components = {}
        for line in section[marker.end() :].splitlines():
            values = re.findall(r"([XYZ]{" + str(order) + r"})=\s*(" + NUMBER + r")", line)
            if not values:
                break
            components.update((name.lower(), parse_float(value)) for name, value in values)
        # Multipole units: debye angstrom, debye angstrom**2 and debye angstrom**3.
        result[key] = components
    return result


def bonds(block):
    """Read numerical NBO bond-index matrices; never infer bonds from distances.

    Args:
        block: Native text of one linked job.

    Returns:
        The bond-index matrices of the linked job.
    """
    labels = [
        "Wiberg bond index matrix in the NAO basis",
        "Atom-atom overlap-weighted NAO bond order",
        "MO bond order",
    ]
    atoms = re.findall(r"NAtoms=\s*(\d+)", block)
    dimension = int(atoms[-1]) if atoms else None
    records = []
    for label in labels:
        for match in re.finditer(re.escape(label) + r":[^\n]*\n", block):
            lines = block[match.end() :].splitlines()
            normalized = []
            for line in lines:
                line = re.sub(r"^([ \t]*)Atom[ \t]+", r"\1", line)
                line = re.sub(r"^([ \t]*\d+)\.[ \t]+", r"\1 ", line)
                if line.strip() and set(line.strip()) == {"-"}:
                    line = ""
                normalized.append(line)
            matrix, _names, _end = blocked_matrix(normalized, 0, rows=dimension, columns=dimension)
            if not matrix:
                continue
            records.append(
                {
                    # One-based native bond-matrix header line within the linked job.
                    "line": line_of(block, match.start()),
                    # Exact named numerical bond-index definition.
                    "method": label,
                    # Dimensionless atom-by-atom bond-index matrix; missing entries stay None.
                    "matrix": matrix,
                    # Whether all expected atom-pair entries were printed and parsed.
                    "complete": all(v is not None for row in matrix for v in row),
                }
            )
    return sorted(records, key=lambda item: item["line"])

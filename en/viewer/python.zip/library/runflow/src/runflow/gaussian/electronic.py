"""SCF solutions, labelled energies, wavefunction stability, canonical orbitals and the basis of one linked job."""

import re

from ..text import NUMBER, blocked_matrix, line_of, parse_float
from .excited import is_nto


def scf_history(block):
    """Read SCF evaluations and explicit failure evidence even after normal termination.

    Args:
        block: Native text of one linked job.

    Returns:
        The SCF history and the explicit errors.
    """
    records = []
    previous = 0
    nuclear_repulsion = None
    pattern = r"SCF Done:\s+E\(([^)]+)\)\s*=\s*(" + NUMBER + r").*?after\s+(\d+) cycles"
    markers = list(re.finditer(pattern, block))
    for index, match in enumerate(markers):
        history = block[previous : match.start()]
        stop = markers[index + 1].start() if index + 1 < len(markers) else len(block)
        summary = block[match.end() : stop]
        repulsions = re.findall(r"nuclear repulsion energy\s+(" + NUMBER + r")", history)
        if repulsions:
            nuclear_repulsion = parse_float(repulsions[-1])
        components = re.search(
            r"^[ \t]*KE=\s*(" + NUMBER + r")\s+PE=\s*(" + NUMBER + r")\s+EE=\s*(" + NUMBER + r")",
            summary,
            re.MULTILINE,
        )
        virial = re.search(r"-V/T\s*=\s*(" + NUMBER + r")", summary)
        samples = []
        for density in re.finditer(r"RMSDP=\s*(" + NUMBER + r")\s+MaxDP=\s*(" + NUMBER + r")([^\n]*)", history):
            cycles = re.findall(r"Cycle\s+(\d+)\s+Pass", history[: density.start()])
            change = re.search(r"\bDE=\s*(" + NUMBER + r")", density[3])
            samples.append(
                {
                    # Native SCF cycle number when printed; otherwise None.
                    "iteration": int(cycles[-1]) if cycles else None,
                    # One-based source line within the linked Gaussian job.
                    "line": line_of(block, previous + density.start()),
                    # RMS density change; dimensionless.
                    "density_rms": parse_float(density[1]),
                    # Maximum density change; dimensionless.
                    "density_maximum": parse_float(density[2]),
                    # Printed electronic energy change in hartree, if present.
                    "energy_change": parse_float(change[1]) if change else None,
                }
            )
        rms_limit = re.findall(
            r"Requested convergence on RMS density matrix\s*=\s*(" + NUMBER + r")",
            history,
        )
        maximum_limit = re.findall(
            r"Requested convergence on MAX density matrix\s*=\s*(" + NUMBER + r")",
            history,
        )
        energy_limit = re.findall(r"Requested convergence on\s+energy\s*=\s*(" + NUMBER + r")", history)
        last = samples[-1] if samples else None
        density_passed = (
            (
                last["density_rms"] <= parse_float(rms_limit[-1])
                and last["density_maximum"] <= parse_float(maximum_limit[-1])
            )
            if last and rms_limit and maximum_limit
            else None
        )
        failures = [
            line.strip()
            for line in history.splitlines()
            if re.search(
                r"Convergence criterion not met|Convergence failure|SCF (?:has )?not converged",
                line,
                re.IGNORECASE,
            )
        ]
        records.append(
            {
                # Native SCF method label.
                "method": match[1],
                # Electronic SCF energy in hartree; may be unconverged when flagged below.
                "energy": parse_float(match[2]),
                # Printed orbital kinetic energy KE in hartree; Kohn-Sham kinetic energy for DFT.
                "kinetic_energy": parse_float(components[1]) if components else None,
                # Printed one-electron potential term PE in hartree, not total potential energy.
                "nuclear_attraction": parse_float(components[2]) if components else None,
                # Printed EE term in hartree; includes exchange and, for DFT, correlation.
                "electron_interaction": parse_float(components[3]) if components else None,
                # Nuclear repulsion in hartree from the geometry preceding this SCF, never the next one.
                "nuclear_repulsion": nuclear_repulsion,
                # Gaussian's printed dimensionless -V/T ratio for this SCF solution.
                "virial_ratio": parse_float(virial[1]) if virial else None,
                # SCF cycle count reported by Gaussian, retained without reinterpretation.
                "cycles": int(match[3]),
                # Final RMS density change, dimensionless, or None when not printed.
                "density_rms": last["density_rms"] if last else None,
                # Final maximum density change, dimensionless, or None when not printed.
                "density_maximum": last["density_maximum"] if last else None,
                # Native requested RMS density threshold, dimensionless.
                "rms_threshold": parse_float(rms_limit[-1]) if rms_limit else None,
                # Native requested maximum density threshold, dimensionless.
                "maximum_threshold": parse_float(maximum_limit[-1]) if maximum_limit else None,
                # Native requested electronic energy threshold in hartree.
                "energy_threshold": parse_float(energy_limit[-1]) if energy_limit else None,
                # Recomputed comparison against both printed density thresholds, or None.
                "density_passed": density_passed,
                # SCF Done without explicit failure and without known failed density criteria.
                "converged": not failures and density_passed is not False,
                # Explicit native messages that invalidate a printed SCF Done candidate.
                "failures": failures,
                # Per-cycle residuals and energy changes in output order.
                "cycle_history": samples,
            }
        )
        previous = match.end()
    return records


def energies(block):
    """Retain labelled energy families without mixing corrections and total energies.

    Args:
        block: Native text of one linked job.

    Returns:
        The labelled energies of the linked job.
    """
    patterns = [
        (r"SCF Done:\s+E\(([^)]+)\)\s*=\s*(" + NUMBER + r")", "total"),
        (
            r"\b(EUMP[2345]|UMP4\((?:DQ|SDQ|SDTQ)\)|MP5|CCSD\(T\))\s*=\s*(" + NUMBER + r")",
            "total",
        ),
        (
            r"Wavefunction amplitudes converged\.\s+(E\(Corr\))\s*=\s*(" + NUMBER + r")",
            "total",
        ),
        (
            r"\b(E2|E3|E4\((?:DQ|SDQ|SDTQ)\)|DEMP5|E2\(B2PLYP\))\s*=\s*(" + NUMBER + r")",
            "correction",
        ),
        (r"(Grimme-\S+)\s+Dispersion energy\s*=\s*(" + NUMBER + r")", "dispersion"),
        (r"(ONIOM):\s+extrapolated energy\s*=\s*(" + NUMBER + r")", "extrapolated"),
    ]
    records = []
    for pattern, kind in patterns:
        for match in re.finditer(pattern, block, re.IGNORECASE):
            records.append(
                {
                    # One-based source line within the linked job.
                    "line": line_of(block, match.start()),
                    # Native method or energy label, without reconstructing a functional.
                    "label": match[1],
                    # Distinguishes total energies, corrections, dispersion and extrapolation.
                    "kind": kind,
                    # Printed energy in hartree; corrections are not standalone total energies.
                    "energy": parse_float(match[2]),
                }
            )
    return sorted(records, key=lambda item: item["line"])


def stability(block):
    """Read spin contamination and explicit wavefunction-stability conclusions.

    Args:
        block: Native text of one linked job.

    Returns:
        The spin-squared values and stability conclusions of the linked job.
    """
    spins = []
    for match in re.finditer(
        r"S\*\*2 before annihilation\s+(" + NUMBER + r"),\s+after\s+(" + NUMBER + r")",
        block,
    ):
        spins.append(
            {
                # One-based source line within the linked job.
                "line": line_of(block, match.start()),
                # Native expectation of S squared before spin annihilation.
                "before": parse_float(match[1]),
                # Native expectation of S squared after spin annihilation.
                "after": parse_float(match[2]),
            }
        )
    stability = []
    for number, line in enumerate(block.splitlines(), 1):
        if re.search(
            r"wavefunction is .*stable|wavefunction has .*instabilit",
            line,
            re.IGNORECASE,
        ):
            stability.append(
                {
                    # One-based source line within the linked job.
                    "line": number,
                    # Exact native stability conclusion, including the tested scope.
                    "message": line.strip(),
                    # True for an explicit stable result, False for instability, None if ambiguous.
                    "stable": False
                    if re.search(r"not stable|unstable|instabilit", line, re.IGNORECASE)
                    else True
                    if "stable" in line.lower()
                    else None,
                }
            )
    return {
        # Native before/after-annihilation spin expectations, dimensionless.
        "spin_squared": spins,
        # Explicit electronic-stability conclusions; empty if no test was printed.
        "stability": stability,
    }


def _orbital_values(section):
    """Read canonical spin channels, retaining repeated population analyses.

    Args:
        section: Native text of one population analysis.

    Returns:
        The occupied and virtual orbital energies of each spin channel.
    """
    records = []
    channels = {}
    markers = list(
        re.finditer(
            r"^[ \t]*(Alpha|Beta)[ \t]+(occ|virt)\.[ \t]+eigenvalues --([^\n]+)",
            section,
            re.MULTILINE,
        )
    )
    for match in markers:
        # NTO eigenvalues are occupations and must never become canonical energies.
        if is_nto(section, match.start(), match.end()):
            continue
        spin = match[1].lower()
        if spin not in channels or match[2] == "occ" and channels[spin]["virtual"]:
            record = {
                # One-based source line within the linked job.
                "line": line_of(section, match.start()),
                # Native alpha or beta channel; restricted output normally prints alpha only.
                "spin": spin,
                # Canonical occupied orbital energies in hartree, in printed order.
                "occupied": [],
                # Canonical virtual orbital energies in hartree, in printed order.
                "virtual": [],
            }
            channels[spin] = record
            records.append(record)
        channels[spin]["occupied" if match[2] == "occ" else "virtual"].extend(
            parse_float(v) for v in re.findall(NUMBER, match[3])
        )
    return records


def orbital_data(block):
    """Read spin-resolved canonical energies and printed AO-by-MO coefficient tables.

    Args:
        block: Native text of one linked job.

    Returns:
        The orbital energies and coefficient tables of the linked job.
    """
    n_basis = re.findall(r"NBasis=\s*(\d+)", block)
    n_mo = re.findall(r"NBsUse=\s*(\d+)", block)
    rows = int(n_basis[-1]) if n_basis else None
    columns = int(n_mo[-1]) if n_mo else rows
    coefficients = []
    for match in re.finditer(
        r"^[ \t]*(?:(Alpha|Beta)[ \t]+)?Molecular Orbital Coefficients:[^\n]*\n",
        block,
        re.MULTILINE,
    ):
        tail = block[match.end() :].splitlines()
        matrix, labels, end = blocked_matrix(tail, 0, rows=rows, columns=columns)
        if not matrix:
            continue
        eigenvalues = [
            parse_float(v)
            for line in tail[:end]
            if "Eigenvalues --" in line
            for v in re.findall(NUMBER, line.split("--", 1)[1])
        ]
        coefficients.append(
            {
                # One-based header line within the linked job.
                "line": line_of(block, match.start()),
                # Native spin channel; a restricted table is labelled restricted.
                "spin": match[1].lower() if match[1] else "restricted",
                # AO labels in native row order; atom indices remain part of the label.
                "ao_labels": labels,
                # Printed eigenvalues in hartree for the coefficient-table columns.
                "eigenvalues": eigenvalues,
                # AO-by-MO coefficients; unprinted entries remain None rather than zero.
                "coefficients": matrix,
                # Whether every expected AO/MO entry was actually printed.
                "complete": all(value is not None for row in matrix for value in row),
            }
        )
    return {
        # Canonical occupied/virtual energies separated by native spin and population pass.
        "orbitals": _orbital_values(block),
        # Canonical molecular-orbital coefficient tables only, excluding NTO coefficients.
        "coefficients": coefficients,
    }


def basis(block):
    """Read the printed basis label and GFInput shells without inferring missing data.

    Args:
        block: Native text of one linked job.

    Returns:
        The basis label and shells of the linked job.
    """
    labels = re.findall(r"Standard basis:\s*([^\n]+)", block)
    shells = []
    for match in re.finditer(r"AO basis set in the form of general basis input[^\n]*\n", block):
        lines = block[match.end() :].splitlines()
        atom = None
        index = 0
        while index < len(lines):
            words = lines[index].split()
            if not words or words == ["****"]:
                index += 1
                continue
            if len(words) == 2 and words[0].isdigit() and words[1] == "0":
                atom = int(words[0])
                index += 1
                continue
            if (
                atom is None
                or len(words) < 3
                or words[0] not in {"S", "P", "SP", "L", "D", "F", "G", "H", "I"}
                or not words[1].isdigit()
            ):
                break
            count = int(words[1])
            primitives = []
            for line in lines[index + 1 : index + 1 + count]:
                data = line.split()
                if len(data) < 2 or not all(re.fullmatch(NUMBER, v) for v in data):
                    break
                primitives.append([parse_float(v) for v in data])
            shells.append(
                {
                    # One-based atom index in the printed GFInput basis.
                    "atom": atom,
                    # Native shell label, including combined SP shells.
                    "shell": words[0],
                    # Printed shell scale factor; not silently applied a second time.
                    "scale": parse_float(words[2]),
                    # Primitive exponents in the native atomic-unit basis convention.
                    "exponents": [row[0] for row in primitives],
                    # Contraction coefficients; SP shells retain both coefficient columns.
                    "coefficients": [row[1:] for row in primitives],
                    # Whether all declared primitive rows were available.
                    "complete": len(primitives) == count,
                }
            )
            index += count + 1
    return {
        # Printed standard-basis label including Cartesian/spherical conventions.
        "label": labels[-1].strip() if labels else None,
        # Explicit GFInput contracted shells; empty if this format was not printed.
        "shells": shells,
    }

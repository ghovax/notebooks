"""Excited states of one linked job: TD roots, transition moments, configurations and NTO weights."""

import re

from ..text import NUMBER, line_of, parse_float

# Spin multiplicity 2S+1 of Gaussian's spin names in TD state labels.
MULTIPLICITIES = {"Singlet": 1, "Doublet": 2, "Triplet": 3, "Quartet": 4, "Quintet": 5, "Sextet": 6, "Septet": 7}


def _state_label(label):
    r"""Spin multiplicity and subgroup symmetry of a TD state label.

    Restricted references print a spin name, such as Singlet-B2U; unrestricted ones print an estimate of :math:`2S+1` from
    :math:`\langle S^2\rangle`, such as 3.017-A, rounded here to the nearest integer. The symmetry is the irreducible representation in
    Gaussian's computational point group, or None when Gaussian printed ?Sym or ran without symmetry.

    Args:
        label: State label as Gaussian prints it, such as Singlet-B2U or 3.017-A.

    Returns:
        Mapping with the spin 'multiplicity' and the 'symmetry', each None when the label names none.
    """
    spin, _, symmetry = label.partition("-")
    multiplicity = MULTIPLICITIES.get(spin.capitalize())
    if multiplicity is None:
        try:
            multiplicity = round(float(spin))
        except ValueError:
            multiplicity = None
    return {
        # Spin multiplicity 2S+1 of the state; None when the label names none.
        "multiplicity": multiplicity,
        # State irrep in Gaussian's computational point group, as printed; None for ?Sym or no symmetry.
        "symmetry": None if not symmetry or "?" in symmetry else symmetry,
    }


def _moments(text, title):
    """Read the consecutive state-indexed rows of one transition-moment table.

    Args:
        text: Native text of one linked job.
        title: Heading of the table.

    Returns:
        One record per state, from the last such table: a TD optimization prints one per geometry, and the last
        belongs to the final geometry.
    """
    matches = list(re.finditer(title + r"[^\n]*\n[^\n]*\n", text, re.IGNORECASE))
    if not matches:
        return []
    match = matches[-1]
    rows = []
    for line in text[match.end() :].splitlines():
        parts = line.split()
        if not parts or not parts[0].isdigit() or len(parts) < 4:
            break
        # x/y/z are transition components, strength is their printed squared magnitude;
        # oscillator is dimensionless. Components and strength retain native atomic units.
        record = dict(
            zip(
                ("x", "y", "z", "strength", "oscillator"),
                map(parse_float, parts[1:]),
                strict=False,
            )
        )
        rows.append(
            {
                # One-based excited-state index.
                "state": int(parts[0]),
                **record,
            }
        )
    return rows


def is_nto(text, position, end):
    """Recognize NTO eigenvalues printed either before or after their table heading.

    Args:
        text: Native text holding the eigenvalue line.
        position: Start of the eigenvalue line.
        end: End of the eigenvalue line.

    Returns:
        Whether the eigenvalues belong to natural transition orbitals.
    """
    before = text[:position]
    if before.rfind("Natural Transition Orbital Coefficients:") > before.rfind("Population analysis using"):
        return True
    for line in text[end:].splitlines():
        stripped = line.strip()
        if not stripped or re.match(r"(?:Alpha|Beta)\s+(?:occ|virt)\. eigenvalues --", stripped):
            continue
        return stripped.startswith("Natural Transition Orbital Coefficients:")
    return False


def _nto_values(block, occupancy):
    """Read only explicitly contextualized NTO weights, excluding canonical energies.

    Args:
        block: Native text of one linked job.
        occupancy: ``occ`` or ``virt``, the eigenvalue lines to read.

    Returns:
        The NTO weights of that occupancy, from the last NTO analysis: a job that repeats the analysis, as at
        every geometry of a TD optimization, prints one set each, and the last belongs to the final geometry.
    """
    values, end = [], None
    for match in re.finditer(
        r"^[ \t]*Alpha[ \t]+" + occupancy + r"\. eigenvalues --([^\n]+)",
        block,
        re.MULTILINE,
    ):
        if is_nto(block, match.start(), match.end()):
            # Lines of one analysis follow each other directly; anything between them starts a new analysis.
            if end is None or block[end : match.start()].strip():
                values = []
            values.extend(parse_float(value) for value in re.findall(NUMBER, match[1]))
            end = match.end()
    return values


def excited_states(block):
    """Read TD roots, transition moments, configurations and NTO weights.

    Args:
        block: Native text of one linked job.

    Returns:
        The excited-state records of the job.
    """
    roots = {}
    for match in re.finditer(r"Root\s+(\d+) (has converged|not converged)", block):
        roots[int(match[1])] = match[2] == "has converged"
    excitations = []
    markers = list(
        re.finditer(
            r"Excited State\s+(\d+):\s+(\S+)\s+("
            + NUMBER
            + r") eV\s+("
            + NUMBER
            + r") nm\s+f=("
            + NUMBER
            + r")\s+<S\*\*2>=("
            + NUMBER
            + r")",
            block,
        )
    )
    for index, match in enumerate(markers):
        stop = markers[index + 1].start() if index + 1 < len(markers) else block.find("SavETr:", match.end())
        section = block[match.end() : stop if stop >= 0 else len(block)]
        configs = [
            {
                # One-based occupied MO index in a TD contribution.
                "occupied": int(a),
                # One-based virtual MO index in a TD contribution.
                "virtual": int(b),
                # Printed TD excitation/de-excitation arrow; not a reaction-path direction.
                "direction": arrow,
                # Printed TD excitation/de-excitation coefficient; dimensionless, not an NTO weight.
                "amplitude": parse_float(value),
                # Spin channel of an unrestricted contribution, printed as an A or B suffix on its orbitals: alpha or
                # beta; None for a restricted one.
                "spin": {"A": "alpha", "B": "beta"}.get(spin),
            }
            for a, spin, arrow, b, _, value in re.findall(
                r"^\s*(\d+)([AB]?)\s*(->|<-)\s*(\d+)([AB]?)\s+(" + NUMBER + r")\s*$",
                section,
                re.MULTILINE,
            )
        ]
        excitations.append(
            {
                # One-based excited-state index.
                "state": int(match[1]),
                # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                "line": line_of(block, match.start()),
                # Printed state label, such as Singlet-B2U, Triplet-A', Singlet-?Sym or 3.017-A.
                "label": match[2],
                **_state_label(match[2]),
                # Excitation energy in electronvolt.
                "energy": parse_float(match[3]),
                # TD transition wavelength in nanometres.
                "wavelength": parse_float(match[4]),
                # Dimensionless TD oscillator strength.
                "oscillator": parse_float(match[5]),
                # Printed excited-state expectation of S**2; dimensionless.
                "spin_squared": parse_float(match[6]),
                # Printed occupied-to-virtual TD contributions; not a complete wavefunction.
                "configurations": configs,
            }
        )
    return {
        # Last explicit convergence flag for each one-based TD root.
        "root_convergence": roots,
        # Whether expansion-vector convergence was explicitly printed.
        "td_converged": "Convergence achieved on expansion vectors." in block,
        # TD states in printed order, retaining repeated states during optimization.
        "excitations": excitations,
        # State-specific TD total energies, distinct from ground-state SCF energies.
        "excited_energies": [
            {
                # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                "line": line_of(block, match.start()),
                # Electronic energy in hartree.
                "energy": parse_float(match[1]),
            }
            for match in re.finditer(r"Total Energy, E\(TD-HF/TD-DFT\)\s*=\s*(" + NUMBER + r")", block)
        ],
        # Length-gauge transition electric dipole components and strengths in atomic units.
        "length_moments": _moments(block, "Ground to excited state transition electric dipole moments"),
        # Velocity-gauge transition components and strengths in atomic units.
        "velocity_moments": _moments(block, "Ground to excited state transition velocity dipole moments"),
        # Printed transition magnetic dipole components in atomic units.
        "magnetic_moments": _moments(block, "Ground to excited state transition magnetic dipole moments"),
        # One-based states whose NTOs were explicitly saved.
        "nto_states": [int(n) for n in re.findall(r"Saving Alpha spin NTOs for state\s+(\d+)", block)],
        # Printed occupied NTO weights, without truncation or renormalization.
        "nto_holes": _nto_values(block, "occ"),
        # Printed virtual NTO weights, without truncation or renormalization.
        "nto_particles": _nto_values(block, "virt"),
    }

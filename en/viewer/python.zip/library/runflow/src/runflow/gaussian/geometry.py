"""Geometries, forces, energy evaluations, optimization steps, scans and reaction paths of one linked job."""

import re
from bisect import bisect_left

from ..text import NUMBER, identifier, line_of, parse_float


def _preceding(records, offset):
    """The last record before an offset in the linked job.

    Args:
        records: Records with a character ``offset``, in output order.
        offset: Character offset in the linked job.

    Returns:
        The zero-based index of the last record that starts before the offset, or None when none does.
    """
    index = bisect_left([record["offset"] for record in records], offset)
    return index - 1 if index else None


def _tables(text, title):
    """Read printed Cartesian tables, retaining their frame and source position.

    Args:
        text: Native text of one linked job.
        title: Heading of the tables, such as an orientation.

    Returns:
        One record per table, with its frame, atoms and vectors.
    """
    records = []
    pattern = title + r"[^\n]*\n\s*-+\n.*?\n.*?\n\s*-+\n(.*?)\n\s*-+"
    for match in re.finditer(pattern, text, re.DOTALL):
        rows = [line.split() for line in match[match.lastindex].splitlines()]
        if not rows or any(len(row) < 5 for row in rows):
            continue
        records.append(
            {
                # Zero-based character position within the linked Gaussian job.
                "offset": match.start(),
                # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                "line": line_of(text, match.start()),
                # Native coordinate frame; Cartesian forces use input orientation.
                "frame": match[1].lower(),
                # One-based center indices in native table order.
                "centers": [int(row[0]) for row in rows],
                # Atomic numbers in the printed center order.
                "atomic_numbers": [int(row[1]) for row in rows],
                # Cartesian x/y/z rows: angstrom for geometries, hartree/bohr for forces.
                "vectors": [list(map(parse_float, row[-3:])) for row in rows],
            }
        )
    return records


def cartesian(text):
    """Read geometries and Cartesian force tables with their native frames.

    Args:
        text: Native text of one linked job.

    Returns:
        The geometry tables and the force tables.
    """
    geometries = _tables(text, r"(Input|Standard|Z-Matrix) orientation:")
    forces = []
    # Force tables have one header rule rather than the orientation table's two.
    for match in re.finditer(
        r"Center\s+Atomic\s+Forces \(Hartrees/Bohr\)[^\n]*\n[^\n]*\n\s*-+\n(.*?)\n\s*-+",
        text,
        re.DOTALL,
    ):
        rows = [line.split() for line in match[1].splitlines()]
        forces.append(
            {
                # Zero-based character position within the linked Gaussian job.
                "offset": match.start(),
                # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                "line": line_of(text, match.start()),
                # Native coordinate frame; Cartesian forces use input orientation.
                "frame": "input",
                # One-based center indices in native table order.
                "centers": [int(row[0]) for row in rows],
                # Atomic numbers in the printed center order.
                "atomic_numbers": [int(row[1]) for row in rows],
                # Cartesian x/y/z rows: angstrom for geometries, hartree/bohr for forces.
                "vectors": [list(map(parse_float, row[-3:])) for row in rows],
            }
        )
    return (geometries, forces)


def evaluations(text, geometries, forces):
    """Read native evaluation records without assuming convergence.

    Args:
        text: Native text of one linked job.
        geometries: Its Cartesian geometry tables.
        forces: Its Cartesian force tables.

    Returns:
        One record per energy evaluation, linked to its geometry and forces.
    """
    evaluations = []
    markers = list(re.finditer(r"SCF Done:\s+E\(([^)]+)\)\s*=\s*(" + NUMBER + r")", text))
    for index, marker in enumerate(markers):
        stop = markers[index + 1].start() if index + 1 < len(markers) else len(text)
        geometry = _preceding(geometries, marker.start())
        force = next(
            (i for i, row in enumerate(forces) if marker.end() < row["offset"] < stop),
            None,
        )
        summary = re.search(
            r"Cartesian Forces:\s+Max\s+(" + NUMBER + r")\s+RMS\s+(" + NUMBER + r")",
            text[marker.end() : stop],
        )
        evaluations.append(
            {
                # Zero-based character position within the linked Gaussian job.
                "offset": marker.start(),
                # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                "line": line_of(text, marker.start()),
                # Electronic energy in hartree.
                "energy": parse_float(marker[2]),
                # Zero-based geometry-record reference; None when no prior orientation exists.
                "geometry": geometry,
                # Zero-based reference into the force records, or None if no force table follows.
                "forces": force,
                # Maximum Cartesian force magnitude in hartree/bohr.
                "force_maximum": parse_float(summary[1]) if summary else None,
                # RMS Cartesian force in hartree/bohr.
                "force_rms": parse_float(summary[2]) if summary else None,
            }
        )
    return evaluations


def optimization(text, evaluations):
    """Read native optimization records without assuming convergence.

    Args:
        text: Native text of one linked job.
        evaluations: Its energy evaluations.

    Returns:
        One record per optimization step, with its convergence checks.
    """
    optimization = []
    markers = list(
        re.finditer(
            r"^\s*Step number\s+(\d+) out of a maximum of\s+(\d+)(?: on scan point\s+(\d+) out of\s+(\d+))?",
            text,
            re.MULTILINE,
        )
    )
    for index, marker in enumerate(markers):
        stop = markers[index + 1].start() if index + 1 < len(markers) else len(text)
        section = text[marker.end() : stop]
        checks = convergence_checks(section)
        evaluation = _preceding(evaluations, marker.start())
        optimization.append(
            {
                # Native iteration number; Gaussian starts at one, Lotus at zero.
                "iteration": int(marker[1]),
                # Printed maximum optimization iterations for this segment.
                "limit": int(marker[2]),
                # Printed scan-target index, or None outside a relaxed scan.
                "scan_point": int(marker[3]) if marker[3] else None,
                # Printed total scan targets, or None outside a relaxed scan.
                "scan_count": int(marker[4]) if marker[4] else None,
                # Zero-based reference into evaluations; None when no prior SCF evaluation exists.
                "evaluation": evaluation,
                # Native force and displacement convergence tests for this iteration.
                "checks": checks,
                # Hessian eigenvalues Berny printed for this step in redundant internal coordinates, in native order.
                "eigenvalues": [
                    parse_float(value)
                    for line in re.findall(r"^\s*Eigenvalues ---(.*)$", section, re.MULTILINE)
                    for value in re.findall(NUMBER, line)
                ],
                # Whether Gaussian printed optimization completion for this iteration.
                "completed": "Optimization completed" in section,
                # Whether Gaussian printed Optimization stopped for this iteration.
                "stopped": "Optimization stopped" in section,
            }
        )
    return optimization


def convergence_checks(text):
    """Read native convergence values and their printed pass flags.

    Args:
        text: Native text of one linked job or optimization step.

    Returns:
        One record per printed criterion with its value, threshold and flag.
    """
    convergence = [
        {
            # Native convergence criterion as its identifier, such as maximum-force.
            "criterion": identifier(name),
            # Printed convergence or internal-coordinate value, in its native units.
            "value": parse_float(value),
            # Native convergence limit; force uses hartree/bohr, displacement bohr or radians.
            "threshold": parse_float(threshold),
            # Native YES/NO convergence result, not a recomputed tolerance.
            "passed": passed == "YES",
        }
        for name, value, threshold, passed in re.findall(
            r"^\s*(Maximum Force|RMS\s+Force|Maximum Displacement|RMS\s+Displacement)"
            r"\s+(" + NUMBER + r")\s+(" + NUMBER + r")\s+(YES|NO)",
            text,
            re.MULTILINE,
        )
    ]
    return convergence


def scan_points(text, optimization, evaluations):
    """Read native scan records without assuming convergence.

    Args:
        text: Native text of one linked job.
        optimization: Its optimization steps.
        evaluations: Its energy evaluations.

    Returns:
        One record per scan point.
    """
    scan = []
    for match in re.finditer(r"Optimization (completed|stopped)", text):
        prior = next(
            (
                row
                for row in reversed(optimization)
                if row["evaluation"] is not None and evaluations[row["evaluation"]]["offset"] < match.start()
            ),
            None,
        )
        if prior is None or prior["scan_point"] is None:
            continue
        following = text[match.end() :]
        end = re.search(r"(?:Leave Link|GradGradGrad|SCF Done:)", following)
        parameters = [
            {
                # Native internal-coordinate or GIC label.
                "name": name,
                # Printed internal-coordinate or GIC definition; units follow that definition.
                "definition": definition.strip(),
                # Printed convergence or internal-coordinate value, in its native units.
                "value": parse_float(value),
            }
            for name, definition, value in re.findall(
                r"^[ \t]*![ \t]+([A-Za-z][\w-]*)[ \t]+(.+?)[ \t]+(" + NUMBER + r")[ \t]+(?:-DE/DX|Frozen|Scan)",
                following[: end.start()] if end else following,
                re.MULTILINE,
            )
        ]
        scan.append(
            {
                # Native IRC or relaxed-scan point index, not a zero-based reference.
                "point": prior["scan_point"],
                # Zero-based reference into evaluations; None when no prior SCF evaluation exists.
                "evaluation": prior["evaluation"],
                # Whether this scan target printed Optimization completed rather than stopped.
                "converged": match[1] == "completed",
                # Printed optimized internal-coordinate/GIC values at this scan target.
                "parameters": parameters,
            }
        )
    return scan


def internal_coordinates(text):
    """Read the internal coordinates of Gaussian's first parameter table, which lists them as the job starts.

    Args:
        text: Native text of one linked job.

    Returns:
        One record per printed coordinate; empty when the job prints no parameter table.
    """
    table = re.search(
        r"Initial Parameters\s*!?\s*\n.*?!\s*Name\s+Definition\s+Value\s+Derivative Info\.\s*!\s*\n\s*-+\s*\n(.*?)\n\s*-{20,}",
        text,
        re.DOTALL,
    )
    if not table:
        return []
    rows = []
    for line in table[1].splitlines():
        match = re.match(r"^\s*!\s+(\S+)\s+(.+?)\s+(" + NUMBER + r")\s+(.*?)\s*!?\s*$", line)
        if match:
            rows.append(
                {
                    # Native coordinate label: the user's label for a GIC line, else Gaussian's, such as R1 or A3.
                    "name": match[1],
                    # Printed definition, such as R(1,2), or GIC-n for a formula whose definition is not printed.
                    "definition": match[2].strip(),
                    # Value at the start in the table's units, angstrom and degree for plain coordinates; a formula's
                    # GIC-n value is in arbitrary units.
                    "value": parse_float(match[3]),
                    # Whether the derivative column says the coordinate is frozen.
                    "frozen": "frozen" in match[4].lower(),
                    # Whether the derivative column marks the coordinate as the scanned one.
                    "scan": match[4].strip().lower().startswith("scan"),
                    # Derivative column as printed, possibly cut at the table's edge.
                    "derivative": match[4].strip(),
                }
            )
    return rows


def gic_counts(text):
    """Read the counts Gaussian prints when it initializes the GIC definitions.

    Args:
        text: Native text of one linked job.

    Returns:
        The counts of initial, input, added, removed, frozen and final coordinates, and whether the job says
        its GIC-type coordinates are in arbitrary units; None when the job prints no such block.
    """
    block = re.search(r"Initializing the GIC definitions file\.(.*?)ITRead=", text, re.DOTALL)
    if not block:
        return None
    count = lambda label: next(iter(int(value) for value in re.findall(label + r"\s*=\s*(\d+)", block[1])), None)
    return {
        # Coordinates read from the checkpoint file before the input's changes.
        "initial": count("Number of initial coordinates"),
        # Lines of the GIC input section.
        "entries": count(r"Number of input entries/lines"),
        # Coordinates the input added.
        "added": count("Number of additional coordinates"),
        # Coordinates the input removed.
        "removed": count("Number of removed coordinates"),
        # Coordinates held frozen.
        "frozen": count("Number of frozen coordinates"),
        # Active and frozen coordinates after the changes.
        "final": count("Number of final active and frozen coordinates"),
        # Whether Gaussian notes that GIC-type coordinates are in arbitrary units.
        "arbitrary_units": "GIC-type coordinates are in arbitrary units" in text,
    }


def irc(text, evaluations):
    """Read native IRC records without assuming convergence.

    Args:
        text: Native text of one linked job.
        evaluations: Its energy evaluations.

    Returns:
        The IRC points, summary, reference and direction completion.
    """
    irc = []
    points = list(re.finditer(r"Point Number:\s*(\d+)\s+Path Number:\s*(\d+)", text))
    for index, marker in enumerate(points):
        stop = points[index + 1].start() if index + 1 < len(points) else len(text)
        section = text[marker.end() : stop]
        current = re.search(
            r"CURRENT STRUCTURE\s+Cartesian Coordinates \(Ang\):.*?\n\s*-+\n.*?\n.*?\n\s*-+\n(.*?)\n\s*-+",
            section,
            re.DOTALL,
        )
        if current is None:
            continue
        rows = [line.split() for line in current[1].splitlines()]
        coordinate = re.search(r"NET REACTION COORDINATE UP TO THIS POINT\s*=\s*(" + NUMBER + r")", section)
        directions = re.findall(
            r"Point Number\s+\d+ in (FORWARD|REVERSE) path direction",
            text[: marker.start()],
        )
        evaluation = _preceding(evaluations, marker.start())
        irc.append(
            {
                # Native IRC or relaxed-scan point index, not a zero-based reference.
                "point": int(marker[1]),
                # Native IRC path number; direction is retained separately.
                "path": int(marker[2]),
                # Explicit native forward/reverse IRC direction, or None when unavailable.
                "direction": directions[-1].lower() if directions else None,
                # Native IRC coordinate; retain the printed sign and mass-weighting convention.
                "coordinate": parse_float(coordinate[1]) if coordinate else None,
                # Zero-based reference into evaluations; None when no prior SCF evaluation exists.
                "evaluation": evaluation,
                # One-based center indices in native table order.
                "centers": [int(row[0]) for row in rows],
                # Atomic numbers in the printed center order.
                "atomic_numbers": [int(row[1]) for row in rows],
                # Accepted IRC Cartesian coordinates in angstrom, center order, x/y/z.
                "coordinates": [list(map(parse_float, row[-3:])) for row in rows],
            }
        )
    summary = []
    start = text.rfind("Summary of reaction path following")
    if start >= 0:
        table = re.search(
            r"Energy\s+Rx\s*Coord[^\n]*\n((?:[ \t]*\d+[ \t]+" + NUMBER + r"[ \t]+" + NUMBER + r"[^\n]*\n)+)",
            text[start:],
        )
        if table:
            summary = [
                {
                    # Native IRC or relaxed-scan point index, not a zero-based reference.
                    "point": int(i),
                    # Printed IRC energy relative to the TS in hartree.
                    "relative_energy": parse_float(energy),
                    # Native IRC coordinate; retain the printed sign and mass-weighting convention.
                    "coordinate": parse_float(coordinate),
                }
                for i, energy, coordinate in re.findall(r"(\d+)\s+(" + NUMBER + r")\s+(" + NUMBER + r")", table[1])
            ]
    reference = re.findall(r"Energies reported relative to the TS energy of\s+(" + NUMBER + r")", text)
    return {
        # Accepted IRC structures with path identity and SCF-evaluation references.
        "irc_points": irc,
        # Native summary rows containing TS-relative energy and signed coordinate.
        "irc_summary": summary,
        # Printed TS reference energy in hartree for the IRC summary.
        "irc_reference": parse_float(reference[-1]) if reference else None,
        # Explicit reaction-path completion; does not verify endpoint minima.
        "irc_complete": "Reaction path calculation complete." in text,
        # Explicit completion markers for each IRC direction.
        "irc_directions": {
            # Whether Gaussian explicitly printed forward-path completion.
            "forward": "Calculation of FORWARD path complete." in text,
            # Whether Gaussian explicitly printed reverse-path completion.
            "reverse": "Calculation of REVERSE path complete." in text,
        },
    }

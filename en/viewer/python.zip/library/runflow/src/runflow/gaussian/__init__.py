"""Gaussian logs: every supported measurement of every linked job, read once."""

import hashlib
import os
import pickle
import re
from functools import lru_cache
from itertools import pairwise
from pathlib import Path

import numpy as np

from ..cache import cache_folder
from ..inputs.sections import modredundant_echo
from ..units import ureg
from . import electronic, excited, geometry, population, properties, vibrations
from .job import archive, catalogue, route_text, settings
from .status import coverage, sections
from .status import status as file_status


@lru_cache(maxsize=1)
def _parser_digest():
    """Digest of the source that turns a log into records.

    A parser change invalidates every cached log, and an edit elsewhere in runflow, such as its orbitals or execution,
    does not.

    Returns:
        The hexadecimal SHA-256 of the log parser's modules, its catalogue and the input readers it uses.
    """
    digest = hashlib.sha256()
    here = Path(__file__).resolve().parent
    package = here.parent
    sources = [
        *here.glob("*.py"),
        here / "catalogue.toml",
        *(package / "inputs").glob("*.py"),
        *(package / name for name in ("geometry.py", "route.py", "text.py", "units.py")),
    ]
    for path in sorted(sources):
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _parsed_key(text, expected_jobs):
    """Cache name of one parsed log, by its exact text, linked-job expectation and the parser.

    Args:
        text: Full text of the log.
        expected_jobs: Intended linked-job count the log is read with, or None.

    Returns:
        The hexadecimal SHA-256 that names the cache entry.
    """
    digest = hashlib.sha256(text.encode())
    digest.update(f"-{expected_jobs}-{_parser_digest()}".encode())
    return digest.hexdigest()


def read_gaussian(path, *, job_id=None, process_id=None, expected_jobs=None):
    """Read the file once and return all supported data, status and coverage per linked job.

    Missing measurements remain None or empty collections. Native output is unchanged. The parse of a log whose
    activity is not being verified is reused from a cache keyed by its exact content and runflow's parser source.

    Args:
        path: Gaussian log.
        job_id: Slurm job ID to verify activity with, or None.
        process_id: Local process ID to verify activity with, or None.
        expected_jobs: Number of linked jobs the input contains, or None.

    Returns:
        ``status``, ``scan`` and ``jobs``; a missing file gives an empty jobs list and a missing or verified
        scheduler status.
    """
    path = Path(path)
    text = path.read_text() if path.is_file() else ""
    if (
        text
        and not text.endswith(("\n", "\r"))
        and not re.search(r"(?:Normal|Error) termination", text.splitlines()[-1])
    ):
        text = text.rpartition("\n")[0]
    # A live job is verified against its scheduler or writing process, which a cached parse would freeze; only a
    # parse made without such verification is cached.
    cached = None
    if text and job_id is None and process_id is None:
        cached = cache_folder("parsed") / f"{_parsed_key(text, expected_jobs)}.pickle"
        try:
            return pickle.loads(cached.read_bytes())
        except (OSError, EOFError, pickle.UnpicklingError):
            pass  # A missing or unreadable cache entry is parsed again.
    blocks = list(split_jobs(text)) if text else []
    jobs = [parse_job(block) for block in blocks]
    for job in jobs:
        job["scan"] = _scan_records(job)
    for category in catalogue()["coverage"]:
        for job, record in zip(jobs, coverage(blocks, jobs, category), strict=True):
            job["coverage"][category] = record
    for section in sections(blocks):
        jobs[section["job"] - 1]["sections"].append(section)
    state = file_status(path, jobs, job_id=job_id, process_id=process_id, expected_jobs=expected_jobs)
    for job, record in zip(jobs, state["jobs"], strict=True):
        # Native completion state, distinct from live activity.
        job["state"] = record["state"]
    result = {
        # File-level completion and externally verified activity.
        "status": state,
        # Distinct relaxed-scan targets across all linked jobs, in native order.
        "scan": _distinct_scan_records(jobs),
        # Full supported measurements grouped by native linked job, in output order.
        "jobs": jobs,
    }
    if cached is not None:
        try:
            cached.parent.mkdir(parents=True, exist_ok=True)
            # Written beside its final name and moved, so a parallel reader never sees half a file.
            partial = cached.with_suffix(f".{os.getpid()}.part")
            partial.write_bytes(pickle.dumps(result))
            partial.replace(cached)
        except OSError:
            pass  # A read-only cache, as in the browser's memory file system, leaves the parse uncached.
    return result


def parse_job(block):
    """Every supported measurement of one linked job, from one shared history of geometries and evaluations.

    Args:
        block: Native text of one linked job.

    Returns:
        The parsed linked job; ``read_gaussian`` fills its ``coverage`` and ``sections`` from the whole log.
    """
    geometries, forces = geometry.cartesian(block)
    evaluations = geometry.evaluations(block, geometries, forces)
    optimization = geometry.optimization(block, evaluations)
    analyses = vibrations.frequency_sets(block)
    modes = [mode for analysis in analyses for mode in analysis]
    thermochemistry, components = vibrations.thermochemistry(block)
    return {
        **settings(block, route_text(block)),
        **excited.excited_states(block),
        **geometry.irc(block, evaluations),
        # Archive entry printed at normal termination, decoded; None when absent.
        "archive": archive(block),
        # Native SCF candidates, density residuals and convergence evidence.
        "scf_history": electronic.scf_history(block),
        # Native geometry records in angstrom, retaining their printed frames.
        "geometries": geometries,
        # Native Cartesian force records in hartree/bohr, input orientation.
        "forces": forces,
        # Shared SCF energy and geometry/force references for this job.
        "evaluations": evaluations,
        # Native Berny steps, excluding IRC corrector steps.
        "optimization_history": optimization,
        # Native force/displacement convergence values, thresholds and pass flags.
        "optimization_checks": geometry.convergence_checks(block),
        # Completed or stopped scan targets, with native coordinate values.
        "scan_points": geometry.scan_points(block, optimization, evaluations),
        # Internal coordinates of the first parameter table, with their start values and frozen or scanned flags.
        "internal_coordinates": geometry.internal_coordinates(block),
        # Counts of the GIC definitions Gaussian initialized, or None when the job builds none.
        "gic_counts": geometry.gic_counts(block),
        # ModRedundant lines Gaussian echoes as it reads the input, as parse_modredundant_section reads them.
        "modredundant_input": modredundant_echo(block),
        # Projected frequencies in inverse centimetres; negative denotes imaginary.
        "frequencies": [mode["frequency"] for mode in modes],
        # Mode reduced masses in atomic mass units.
        "reduced_masses": [mode["reduced_mass"] for mode in modes],
        # Mode force constants in millidyne/angstrom.
        "force_constants": [mode["force_constant"] for mode in modes],
        # Harmonic infrared intensities in kilometre/mole.
        "ir_intensities": [mode["ir_intensity"] for mode in modes],
        # Distinct harmonic analyses with matching high/standard listings merged.
        "frequency_sets": analyses,
        # Density-labelled atomic populations and molecular multipoles.
        "populations": population.populations(block, evaluations, geometries),
        # Thermal energies in hartree, with native temperature and pressure.
        "thermochemistry": thermochemistry,
        # Component energy in kcal/mol; heat capacity and entropy in cal/(mol K).
        "thermal_components": components,
        **electronic.stability(block),
        **properties.response(block),
        # Labelled total energies and contributions in hartree.
        "energies": electronic.energies(block),
        # Explicit basis label and GFInput primitive/contraction records.
        "basis": electronic.basis(block),
        # Canonical orbital energies in hartree and printed coefficients.
        "orbital_data": electronic.orbital_data(block),
        # PCM parameters and native solvation contributions.
        "solvent": properties.solvent(block),
        # Native numerical bond indices, never inferred from geometry.
        "bonds": population.bonds(block),
        # Printed Cartesian force constants in hartree/bohr squared.
        "hessians": properties.hessians(block),
        # Atomic NMR shielding tensors in ppm.
        "nmr": properties.nmr(block),
        # Availability of supported categories for this linked job.
        "coverage": {},
        # Native section headings with job-relative source line positions.
        "sections": [],
    }


def split_jobs(text):
    """Yield native linked-job text without interpreting unrelated sections.

    Args:
        text: Complete native Gaussian log.

    Yields:
        The text of each linked job, in order.
    """
    starts = [match.start() for match in re.finditer(r"^\s*Initial command:", text, re.MULTILINE)]
    boundaries = [0, *starts[1:], len(text)]
    for begin, end in pairwise(boundaries):
        yield text[begin:end]


def _scan_records(job):
    """Normalize distinct relaxed-scan targets from parsed linked jobs.

    Args:
        job: One parsed linked job.

    Returns:
        One record per scan target.
    """
    records = []
    for point in job["scan_points"]:
        if point["evaluation"] is None:
            continue
        evaluation = job["evaluations"][point["evaluation"]]
        if evaluation["geometry"] is None:
            continue
        geometry = job["geometries"][evaluation["geometry"]]
        coordinates = np.asarray(geometry["vectors"])
        duplicate = any(
            np.allclose(record["coordinates"].magnitude, coordinates, atol=1e-8, rtol=0)
            and abs(record["energy"].magnitude - evaluation["energy"]) < 1e-9
            for record in records
        )
        if duplicate:
            continue
        records.append(
            {
                # Native one-based relaxed-scan target number.
                "point": point["point"],
                # Whether Gaussian completed optimization at this target.
                "converged": point["converged"],
                # Native SCF energy in hartree, the ground state's in a TD scan.
                "energy": evaluation["energy"] * ureg.hartree,
                # Total energy in hartree of the excited state a TD scan follows, on which it relaxes; None without TD.
                "excited_energy": None
                if evaluation.get("excited_energy") is None
                else evaluation["excited_energy"] * ureg.hartree,
                # Full Cartesian gradient norm; None when no force table follows the evaluation.
                "force_rms": None
                if evaluation["force_rms"] is None
                else evaluation["force_rms"] * ureg.hartree / ureg.bohr,
                # Atomic numbers in native center order.
                "atomic_numbers": geometry["atomic_numbers"],
                # Accepted geometry in native center order.
                "coordinates": coordinates * ureg.angstrom,
                # Printed constrained-coordinate definitions and values.
                "parameters": point["parameters"],
            }
        )
    return records


def _distinct_scan_records(jobs):
    """Merge linked scan sections without repeating their shared boundary target.

    Args:
        jobs: Parsed linked jobs.

    Returns:
        The scan records in order.
    """
    records = []
    for job in jobs:
        for record in job["scan"]:
            coordinates = record["coordinates"].to("angstrom").magnitude
            duplicate = any(
                np.allclose(
                    existing["coordinates"].to("angstrom").magnitude,
                    coordinates,
                    atol=1e-8,
                    rtol=0,
                )
                and abs(existing["energy"].to("hartree").magnitude - record["energy"].to("hartree").magnitude) < 1e-9
                for existing in records
            )
            if not duplicate:
                normalized = dict(record)
                # File-level targets are numbered continuously after linked-job merges.
                normalized["point"] = len(records) + 1
                records.append(normalized)
    return records

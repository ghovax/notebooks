"""Response tensors, shieldings, Cartesian Hessians and continuum solvation of one linked job."""

import re

from ..text import NUMBER, blocked_matrix, line_of, parse_float


def hessians(block):
    """Read printed Cartesian force-constant matrices without certifying exact curvature.

    Args:
        block: Native text of one linked job.

    Returns:
        The force-constant matrices of the linked job.
    """
    atoms = re.findall(r"NAtoms=\s*(\d+)", block)
    dimension = 3 * int(atoms[-1]) if atoms else None
    records = []
    for match in re.finditer(r"Force constants in Cartesian coordinates:[^\n]*\n", block):
        matrix, _labels, _end = blocked_matrix(
            block[match.end() :].splitlines(),
            0,
            rows=dimension,
            columns=dimension,
            symmetric=True,
        )
        if matrix:
            records.append(
                {
                    # One-based native header line within the linked job.
                    "line": line_of(block, match.start()),
                    # Native Cartesian force constants use input orientation.
                    "frame": "input",
                    # Printed second-derivative matrix in hartree/bohr**2; missing entries stay None.
                    "matrix": matrix,
                    # Whether every element of the printed triangular matrix was recovered.
                    "complete": all(value is not None for row in matrix for value in row),
                }
            )
    return records


def _tensor_components(section, count):
    """Read a wrapped packed tensor, including adjacent signed Fortran numbers.

    Args:
        section: Native text starting at the tensor.
        count: Number of components to read.

    Returns:
        The components, empty when fewer are printed.
    """
    values = []
    for line in section.splitlines():
        matches = re.findall(NUMBER, line)
        if not matches:
            break
        values.extend(parse_float(v) for v in matches)
        if len(values) >= count:
            return values[:count]
    return []


def response(block):
    """Read polarizability/hyperpolarizability without mixing orientation conventions.

    Args:
        block: Native text of one linked job.

    Returns:
        The polarizability and hyperpolarizability records of the linked job.
    """
    polar = []
    hyper = []
    for match in re.finditer(r"SCF Polarizability for W=\s*(" + NUMBER + r"):[^\n]*\n", block):
        matrix, _labels, _end = blocked_matrix(block[match.end() :].splitlines(), 0, rows=3, columns=3, symmetric=True)
        if matrix:
            polar.append(
                {
                    # One-based source line within the linked job.
                    "line": line_of(block, match.start()),
                    # Native applied angular frequency in atomic units; zero is static.
                    "frequency": parse_float(match[1]),
                    # This analytic SCF tensor follows the native standard orientation.
                    "frame": "standard",
                    # Cartesian polarizability tensor in atomic units (bohr**3).
                    "tensor": matrix,
                    # Whether every tensor component was printed and parsed.
                    "complete": all(v is not None for row in matrix for v in row),
                }
            )
    for match in re.finditer(r"^[ \t]*Polarizability=([^\n]*)", block, re.MULTILINE):
        packed = _tensor_components(match[1] + block[match.end() :], 6)
        if len(packed) == 6:
            xx, xy, yy, xz, yz, zz = packed
            polar.append(
                {
                    # One-based source line within the linked job.
                    "line": line_of(block, match.start()),
                    # Compact harmonic-response tensor is static.
                    "frequency": 0.0,
                    # Native standard coordinate frame, without rotating to the input geometry.
                    "frame": "standard",
                    # Native lower-triangle order expanded into a symmetric tensor, atomic units.
                    "tensor": [[xx, xy, xz], [xy, yy, yz], [xz, yz, zz]],
                    # All six independent printed components were recovered.
                    "complete": True,
                }
            )
    if not polar:
        for match in re.finditer(r"Exact polarizability:([^\n]+)", block):
            values = [parse_float(v) for v in re.findall(NUMBER, match[1])]
            if len(values) == 6:
                xx, xy, yy, xz, yz, zz = values
                polar.append(
                    {
                        # One-based source line within the linked job.
                        "line": line_of(block, match.start()),
                        # Native exact static polarizability summary.
                        "frequency": 0.0,
                        # Population properties are printed in standard orientation.
                        "frame": "standard",
                        # Polarizability in atomic units, at the lower summary precision.
                        "tensor": [[xx, xy, xz], [xy, yy, yz], [xz, yz, zz]],
                        # All six independent summary components were recovered.
                        "complete": True,
                    }
                )
    for match in re.finditer(r"^[ \t]*HyperPolar[ \t]*=([^\n]*)", block, re.MULTILINE):
        values = _tensor_components(match[1] + block[match.end() :], 10)
        if len(values) == 10:
            hyper.append(
                {
                    # One-based source line within the linked job.
                    "line": line_of(block, match.start()),
                    # Harmonic static-response frame as printed by Gaussian.
                    "frame": "standard",
                    # Packed beta in native atomic units, without an extra factorial factor.
                    "components": dict(
                        zip(
                            (
                                "xxx",
                                "xxy",
                                "xyy",
                                "yyy",
                                "xxz",
                                "xyz",
                                "yyz",
                                "xzz",
                                "yzz",
                                "zzz",
                            ),
                            values,
                            strict=True,
                        )
                    ),
                }
            )
    # Final property summaries explicitly name input or dipole orientation.
    for match in re.finditer(
        r"(Dipole polarizability, Alpha|First dipole hyperpolarizability, Beta) \(([^)]+)\)\.[^\n]*\n",
        block,
    ):
        section = block[match.end() :]
        start = re.search(r"(?:Alpha|Beta)\([^\n]+\):\s*\n[^\n]*\n", section)
        if not start:
            continue
        components = {}
        for line in section[start.end() :].splitlines():
            words = line.split()
            if len(words) != 4 or not re.fullmatch(r"[xyz]{2,3}|iso|aniso", words[0]):
                if components:
                    break
                continue
            components[words[0]] = parse_float(words[1])
        if not components:
            continue
        record = {
            # One-based explicitly oriented property-summary header line.
            "line": line_of(block, match.start()),
            # Exact native orientation label; never silently combined across frames.
            "frame": match[2],
            # Native Cartesian component labels and values in atomic units.
            "components": components,
        }
        if match[1].startswith("Dipole"):
            polar.append(record)
        else:
            hyper.append(record)
    return {
        # Static/frequency-labelled polarizability records, retaining their printed frames.
        "polarizability": sorted(polar, key=lambda r: r["line"]),
        # First hyperpolarizability records in native atomic units and conventions.
        "hyperpolarizability": sorted(hyper, key=lambda r: r["line"]),
    }


def nmr(block):
    """Read shielding tensors as printed, without symmetrizing or inventing chemical shifts.

    Args:
        block: Native text of one linked job.

    Returns:
        The shielding records of the linked job.
    """
    records = []
    for match in re.finditer(
        r"^[ \t]*(\d+)[ \t]+([A-Z][a-z]?)[ \t]+Isotropic\s*=\s*(" + NUMBER + r")\s+Anisotropy\s*=\s*(" + NUMBER + r")",
        block,
        re.MULTILINE,
    ):
        section = block[match.end() :].splitlines()
        values = {
            key.lower(): parse_float(value)
            for line in section[:4]
            for key, value in re.findall(r"([XYZ]{2})=\s*(" + NUMBER + r")", line)
        }
        # Off-diagonal shielding components need not be symmetric.
        tensor = [[values.get(a + b) for b in "xyz"] for a in "xyz"]
        records.append(
            {
                # One-based native source line within the linked job.
                "line": line_of(block, match.start()),
                # One-based atom index in the native shielding table.
                "atom": int(match[1]),
                # Printed chemical element symbol.
                "element": match[2],
                # Isotropic magnetic shielding in ppm, not a referenced chemical shift.
                "isotropic": parse_float(match[3]),
                # Native shielding anisotropy in ppm.
                "anisotropy": parse_float(match[4]),
                # Cartesian shielding tensor in ppm, in the native component order.
                "tensor": tensor,
                # Whether all nine tensor components were printed and recovered.
                "complete": all(v is not None for row in tensor for v in row),
            }
        )
    return records


def solvent(block):
    """Read explicit PCM configuration and printed solvation contributions.

    Args:
        block: Native text of one linked job.

    Returns:
        The solvent model, its parameters and contributions for each linked job.
    """
    records = []
    for match in re.finditer(
        r"Solvent\s*:\s*([^,\n]+),\s*Eps=\s*(" + NUMBER + r")\s+Eps\(inf\)=\s*(" + NUMBER + r")",
        block,
    ):
        records.append(
            {
                # One-based source line within the linked job.
                "line": line_of(block, match.start()),
                # Native solvent name rather than a molecular-screening parameter.
                "solvent": match[1].strip(),
                # Static continuum-solvent dielectric constant; dimensionless.
                "epsilon": parse_float(match[2]),
                # Optical/high-frequency continuum dielectric constant; dimensionless.
                "epsilon_infinity": parse_float(match[3]),
            }
        )
    contributions = []
    for match in re.finditer(
        r"(Dispersion|Cavitation|Repulsion) energy\s+([^=\n]+)=\s*(" + NUMBER + r")",
        block,
        re.IGNORECASE,
    ):
        contributions.append(
            {
                # Native non-electrostatic contribution name.
                "label": match[1].lower(),
                # Unit label as explicitly printed; no implicit kcal/mol conversion.
                "units": match[2].strip(),
                # Native numerical contribution in the explicitly stated units.
                "value": parse_float(match[3]),
            }
        )
    return {
        # Whether a native PCM configuration banner was printed.
        "pcm": "Polarizable Continuum Model" in block,
        # Explicit continuum solvent parameters, distinct from molecular screening.
        "parameters": records,
        # Printed non-electrostatic contributions, without inventing absent terms.
        "contributions": contributions,
    }

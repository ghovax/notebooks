"""Basis functions of formatted checkpoints: their shells, overlap, orbital composition and values on grids.

PySCF evaluates the integrals and functions on the checkpoint's own shells; every function is normalized on its own,
as Gaussian writes them.
"""

import numpy as np

from .checkpoints import spin_record

# Cartesian powers of each function of a Cartesian shell, in formatted-checkpoint order.
CARTESIAN = {
    0: [(0, 0, 0)],
    1: [(1, 0, 0), (0, 1, 0), (0, 0, 1)],
    2: [(2, 0, 0), (0, 2, 0), (0, 0, 2), (1, 1, 0), (1, 0, 1), (0, 1, 1)],
    3: [(3, 0, 0), (0, 3, 0), (0, 0, 3), (1, 2, 0), (2, 1, 0), (2, 0, 1), (1, 0, 2), (0, 1, 2), (0, 2, 1), (1, 1, 1)],
}


_S3, _S15, _A, _B = np.sqrt(3), np.sqrt(15), np.sqrt(3 / 8), np.sqrt(5 / 8)


# Real solid harmonics of pure shells as Cartesian polynomials, in formatted-checkpoint order (m = 0, +1, -1, +2,
# -2, ...), scaled to equal norms.
PURE = {
    2: [
        {(0, 0, 2): 1, (2, 0, 0): -0.5, (0, 2, 0): -0.5},
        {(1, 0, 1): _S3},
        {(0, 1, 1): _S3},
        {(2, 0, 0): _S3 / 2, (0, 2, 0): -_S3 / 2},
        {(1, 1, 0): _S3},
    ],
    3: [
        {(0, 0, 3): 1, (2, 0, 1): -1.5, (0, 2, 1): -1.5},
        {(1, 0, 2): 4 * _A, (3, 0, 0): -_A, (1, 2, 0): -_A},
        {(0, 1, 2): 4 * _A, (2, 1, 0): -_A, (0, 3, 0): -_A},
        {(2, 0, 1): _S15 / 2, (0, 2, 1): -_S15 / 2},
        {(1, 1, 1): _S15},
        {(3, 0, 0): _B, (1, 2, 0): -3 * _B},
        {(2, 1, 0): 3 * _B, (0, 3, 0): -_B},
    ],
}


# Letters of the angular momenta l = 0, 1, 2, ...: s, p, d, f, then the alphabet from g without j and the letters
# already used.
ANGULAR_LETTERS = "spdfghiklmnoqrtuvwxyz"


def momentum_letter(momentum):
    """The spectroscopic letter of an angular momentum.

    Args:
        momentum: The angular momentum l, from zero.

    Returns:
        Its letter: s, p, d, f, g, h, i, k and on.
    """
    return ANGULAR_LETTERS[momentum]


def _pyscf_powers(momentum):
    """Exponents of PySCF's Cartesian functions of one angular momentum, in its order.

    Args:
        momentum: The angular momentum.

    Returns:
        The (x, y, z) exponents of each function, the power of x falling first, then of y.
    """
    return [(x, y, momentum - x - y) for x in range(momentum, -1, -1) for y in range(momentum - x, -1, -1)]


def _pure_functions(momentum):
    """The real solid harmonics of a pure shell as Cartesian polynomials, in the formatted checkpoint's order m = 0, +1,
    -1, +2, -2, ...: ``PURE`` where it writes them out, otherwise PySCF's, whose d and f harmonics are
    those of ``PURE`` in the same order and signs.

    Args:
        momentum: The angular momentum, two or more.

    Returns:
        One mapping of Cartesian exponents to coefficients per function.
    """
    return PURE[momentum] if momentum in PURE else _pyscf_pure(momentum)


def _pyscf_pure(momentum):
    """PySCF's real solid harmonics of one angular momentum as Cartesian polynomials, reordered to the formatted
    checkpoint's m = 0, +1, -1, +2, -2, ...

    Args:
        momentum: The angular momentum, two or more.

    Returns:
        One mapping of Cartesian exponents to coefficients per function.
    """
    from pyscf.gto.mole import cart2sph

    matrix, powers = cart2sph(momentum), _pyscf_powers(momentum)
    order = [0] + [m for k in range(1, momentum + 1) for m in (k, -k)]
    return [
        {
            powers[row]: float(matrix[row, momentum + m])
            for row in np.flatnonzero(np.abs(matrix[:, momentum + m]) > 1e-12)
        }
        for m in order
    ]


def basis_supported(records):
    """Whether the basis of a formatted checkpoint can be evaluated: s, sp and p shells, Cartesian d and f shells, and
    pure shells of any angular momentum. Cartesian shells above f are not, since their order in the checkpoint is not
    the one written out here.

    Args:
        records: Records from ``read_fchk_records``.

    Returns:
        True when every shell type is supported.
    """
    return all(kind == -1 or kind < -1 or kind in CARTESIAN for kind in np.asarray(records["Shell types"], dtype=int))


def _basis(records):
    """PySCF's Cartesian basis on a formatted checkpoint's own shells, and the checkpoint's functions in it.

    Every function of the checkpoint is a combination of PySCF's Cartesian functions of its shell: the Cartesian
    monomials of ``CARTESIAN`` or the solid harmonics of ``_pure_functions``, each normalized on its
    own as Gaussian writes them.

    Args:
        records: Records from ``read_fchk_records``.

    Returns:
        The PySCF molecule, with Cartesian functions, its overlap matrix, and the transform whose column i gives the
        checkpoint's function i in PySCF's functions.

    Raises:
        ValueError: The checkpoint holds a shell type that ``basis_supported`` rejects, or its shells do not give its
            number of functions.
    """
    from pyscf import gto
    from pyscf.data.elements import ELEMENTS as SYMBOLS

    if not basis_supported(records):
        raise ValueError("Cartesian shells above f are not supported; pure shells of any angular momentum are.")
    types = np.asarray(records["Shell types"], dtype=int)
    counts = np.asarray(records["Number of primitives per shell"], dtype=int)
    exponents = np.asarray(records["Primitive exponents"], dtype=float)
    contraction = np.asarray(records["Contraction coefficients"], dtype=float)
    p_contraction = np.asarray(records.get("P(S=P) Contraction coefficients", np.zeros_like(contraction)), dtype=float)
    owners = np.asarray(records["Shell to atom map"], dtype=int) - 1
    numbers = np.asarray(records["Atomic numbers"], dtype=int)
    nuclei = np.asarray(records["Current cartesian coordinates"], dtype=float).reshape(-1, 3)
    starts = np.concatenate([[0], np.cumsum(counts)])
    # One PySCF shell per angular momentum, an sp shell as an s and a p shell; each atom keeps its own label and basis.
    shells, order = {atom: [] for atom in range(len(numbers))}, []
    for shell, kind in enumerate(types):
        primitives = slice(starts[shell], starts[shell + 1])
        parts = [(0, contraction), (1, p_contraction)] if kind == -1 else [(abs(kind), contraction)]
        for momentum, weights in parts:
            atom = owners[shell]
            # The checkpoint's shell as its atom, angular momentum and occurrence among that atom's shells of it.
            order.append((atom, momentum, sum(entry[0] == momentum for entry in shells[atom])))
            shells[atom].append([momentum, *zip(exponents[primitives], weights[primitives])])
    labels = [f"{SYMBOLS[number]}{atom + 1}" for atom, number in enumerate(numbers)]
    molecule = gto.M(
        atom=[[label, tuple(position)] for label, position in zip(labels, nuclei)],
        unit="Bohr",
        basis={label: shells[atom] for atom, label in enumerate(labels)},
        cart=True,
        spin=int(numbers.sum()) % 2,
        verbose=0,
    )
    overlap = molecule.intor_symmetric("int1e_ovlp_cart")
    # PySCF orders an atom's shells by angular momentum, so each of its shells is found by atom, angular momentum and
    # occurrence; its Cartesian functions fall in the power of x, then of y, where the checkpoint has its own order.
    offsets, seen, position = {}, {}, 0
    for shell in range(molecule.nbas):
        atom, momentum = molecule.bas_atom(shell), molecule.bas_angular(shell)
        for _ in range(molecule.bas_nctr(shell)):
            occurrence = seen.get((atom, momentum), 0)
            seen[(atom, momentum)] = occurrence + 1
            offsets[(atom, momentum, occurrence)] = position
            position += (momentum + 1) * (momentum + 2) // 2
    kinds = [kind for kind in types for _ in ([0, 1] if kind == -1 else [kind])]
    columns = []
    for key, kind in zip(order, kinds):
        start, momentum = offsets[key], key[1]
        powers = _pyscf_powers(momentum)
        functions = [{p: 1.0} for p in CARTESIAN[momentum]] if kind >= -1 else _pure_functions(momentum)
        for function in functions:
            column = np.zeros(len(overlap))
            for power, weight in function.items():
                column[start + powers.index(power)] = weight
            columns.append(column)
    transform = np.array(columns).T
    if transform.shape[1] != int(records["Number of basis functions"]):
        raise ValueError(
            f"Shells give {transform.shape[1]} functions, but the checkpoint has "
            f"{int(records['Number of basis functions'])}."
        )
    transform /= np.sqrt(np.einsum("ki,kl,li->i", transform, overlap, transform))
    return molecule, overlap, transform


def _grid(records, margin, bounds, spacing):
    """The corners and shape of a Cartesian grid around a checkpoint's nuclei, or within given bounds, in bohr.

    Args:
        records: Records from ``read_fchk_records``.
        margin: Padding around the outermost nuclei.
        bounds: Lower and upper corners, replacing the nuclei and margin, or None.
        spacing: Grid step.

    Returns:
        The lower corner, the number of points along each axis, the atomic numbers and the nuclei.
    """
    numbers = np.asarray(records["Atomic numbers"], dtype=int)
    nuclei = np.asarray(records["Current cartesian coordinates"], dtype=float).reshape(-1, 3)
    lower, upper = (
        (nuclei.min(axis=0) - margin, nuclei.max(axis=0) + margin)
        if bounds is None
        else (np.asarray(bounds[0], dtype=float), np.asarray(bounds[1], dtype=float))
    )
    return lower, np.ceil((upper - lower) / spacing).astype(int) + 1, numbers, nuclei


def _on_grid(molecule, lower, shape, spacing, combine, chunk):
    """Values built from PySCF's Cartesian functions at every point of a grid, a chunk of points at a time.

    Args:
        molecule: The PySCF molecule of ``_basis``.
        lower: The grid's lower corner in bohr.
        shape: The number of points along each axis.
        spacing: Grid step in bohr.
        combine: Maps the functions' values at the points, one row per point, to one row of results per point.
        chunk: Points evaluated together.

    Returns:
        The results with shape ``(*shape, results)``.
    """
    axes = [lower[k] + spacing * np.arange(shape[k]) for k in range(3)]
    points = np.stack(np.meshgrid(*axes, indexing="ij"), axis=-1).reshape(-1, 3)
    parts = [
        combine(molecule.eval_gto("GTOval_cart", points[start : start + chunk]))
        for start in range(0, len(points), chunk)
    ]
    return np.concatenate(parts).reshape(*shape, -1)


def orbital_grid(records, orbital, *, spin="alpha", spacing=0.3, margin=5.0, bounds=None, chunk=20000):
    """One orbital of a formatted checkpoint sampled on a Cartesian grid around the molecule, in bohr.

    The basis functions are PySCF's on the checkpoint's own shells, as ``_basis`` makes them: s, sp and p shells,
    Cartesian d and f shells and pure shells of any angular momentum, each function normalized on its own as in
    Gaussian's formatted checkpoints. PySCF skips shells negligible at a point.

    Args:
        records: Records from ``read_fchk_records``.
        orbital: Zero-based orbital index.
        spin: The spin channel, ``"alpha"`` or ``"beta"``; a restricted checkpoint's beta orbitals are its alpha ones.
        spacing: Grid step in bohr.
        margin: Padding around the outermost nuclei in bohr.
        bounds: Lower and upper grid corners in bohr, replacing the nuclei and margin.
        chunk: Grid points evaluated together.

    Returns:
        Grid origin, step vectors (rows) and atom rows ``[Z, Z, x, y, z]``, all in bohr, and the orbital values
        in ``a_0^{-3/2}`` with shape ``(nx, ny, nz)``.

    Raises:
        ValueError: The checkpoint holds a shell type ``basis_supported`` rejects.
    """
    molecule, _, transform = _basis(records)
    basis = int(records["Number of basis functions"])
    vector = (
        transform
        @ np.asarray(spin_record(records, spin, "{Spin} MO coefficients"), dtype=float).reshape(-1, basis)[orbital]
    )
    lower, shape, numbers, nuclei = _grid(records, margin, bounds, spacing)
    values = _on_grid(molecule, lower, shape, spacing, lambda functions: (functions @ vector)[:, None], chunk)[..., 0]
    atoms = np.column_stack([numbers, numbers, nuclei]).astype(float)
    return lower, np.eye(3) * spacing, atoms, values


def _shell_functions(kind):
    """Angular momentum of each function of a formatted-checkpoint shell, in its order.

    Args:
        kind: Gaussian's shell type: 0, 1 and 2 or 3 for Cartesian s, p, d and f, -1 for sp, -2 and -3 for pure d and f.

    Returns:
        One angular momentum per function.
    """
    if kind == -1:
        return [0, 1, 1, 1]
    momentum = abs(kind)
    return [momentum] * ((momentum + 1) * (momentum + 2) // 2 if kind >= 0 else 2 * momentum + 1)


def overlap_matrix(records):
    """Overlap matrix of a formatted checkpoint's basis functions, each normalized on its own as Gaussian writes them.

    The integrals come from PySCF on the checkpoint's own shells, all taken as Cartesian, combined into the checkpoint's
    functions as ``_basis`` makes them: s, sp and p shells, Cartesian d and f shells and pure shells of any angular
    momentum.

    Args:
        records: Records from ``read_fchk_records``.

    Returns:
        The symmetric overlap matrix, dimensionless, in the checkpoint's order of basis functions.

    Raises:
        ValueError: The checkpoint holds a shell type that ``basis_supported`` rejects.
    """
    _, overlap, transform = _basis(records)
    return transform.T @ overlap @ transform


def basis_function_owners(records):
    """The atom and angular momentum of every basis function of a formatted checkpoint, in the order of its
    coefficients.

    Args:
        records: Records from ``read_fchk_records``.

    Returns:
        Two integer arrays: the zero-based atom and the angular momentum of each basis function.
    """
    types = np.asarray(records["Shell types"], dtype=int)
    owners = np.asarray(records["Shell to atom map"], dtype=int) - 1
    atoms, momenta = [], []
    for shell, kind in enumerate(types):
        for momentum in _shell_functions(kind):
            atoms.append(owners[shell])
            momenta.append(momentum)
    return np.asarray(atoms, dtype=int), np.asarray(momenta, dtype=int)


def orbital_composition(records, orbitals, overlap=None, spin="alpha"):
    r"""Mulliken composition of the orbitals of one spin channel of a formatted checkpoint by atom and angular momentum.

    The share of the functions of atom :math:`A` with angular momentum :math:`l` in an orbital with coefficients
    :math:`\mathbf{c}` is :math:`w_{A,l}=\sum_{\mu\in A,\ l_\mu=l}c_\mu(\mathbf{S}\mathbf{c})_\mu`; the shares of one
    orbital add up to one.

    Args:
        records: Records from ``read_fchk_records``.
        orbitals: Zero-based alpha orbital indices.
        overlap: The checkpoint's overlap matrix, when already calculated by ``overlap_matrix``.
        spin: The spin channel, ``"alpha"`` or ``"beta"``.

    Returns:
        Array of shape (orbitals, atoms, momenta), the shares of the s, p, d and f functions on each atom, up to the
        highest angular momentum of the basis.

    Raises:
        ValueError: The checkpoint holds an unsupported shell type, or its orbitals are not orthonormal in the
            calculated overlap, which would make the shares meaningless.
    """
    matrix = overlap_matrix(records) if overlap is None else overlap
    basis = int(records["Number of basis functions"])
    coefficients = (
        np.asarray(spin_record(records, spin, "{Spin} MO coefficients"), dtype=float)
        .reshape(-1, basis)[list(orbitals)]
        .T
    )
    gram = coefficients.T @ matrix @ coefficients
    if not np.allclose(gram, np.eye(len(gram)), atol=1e-5):
        raise ValueError("The checkpoint's orbitals are not orthonormal in the calculated overlap.")
    atoms, momenta = basis_function_owners(records)
    shares = coefficients * (matrix @ coefficients)
    table = np.zeros((len(orbitals), int(records["Number of atoms"]), momenta.max() + 1))
    for column in range(len(orbitals)):
        np.add.at(table[column], (atoms, momenta), shares[:, column])
    return table


def density_grid(records, orbitals, weights, *, spin="alpha", spacing=0.3, margin=5.0, bounds=None, chunk=20000):
    r"""Weighted sums of squared orbitals of one spin channel of a formatted checkpoint on a Cartesian grid, in bohr.

    Each density :math:`\sum_m w_m\psi_m(\mathbf{r})^2` is built from many orbitals at once: the basis functions are evaluated once at
    every point, as in ``orbital_grid``, and every orbital follows from one matrix product.

    Args:
        records: Records from ``read_fchk_records``.
        orbitals: Zero-based orbital indices.
        weights: Weight of each orbital's squared amplitude, or one row of weights per density.
        spin: The spin channel, ``"alpha"`` or ``"beta"``.
        spacing: Grid step in bohr.
        margin: Padding around the outermost nuclei in bohr.
        bounds: Lower and upper grid corners in bohr, replacing the nuclei and margin.
        chunk: Grid points evaluated together.

    Returns:
        Grid origin, step vectors (rows) and atom rows ``[Z, Z, x, y, z]``, all in bohr, and the density in
        ``a_0^{-3}`` with shape ``(nx, ny, nz)``, or one such density per row of ``weights``.

    Raises:
        ValueError: The checkpoint holds a shell type ``basis_supported`` rejects.
    """
    molecule, _, transform = _basis(records)
    basis = int(records["Number of basis functions"])
    coefficients = (
        transform
        @ np.asarray(spin_record(records, spin, "{Spin} MO coefficients"), dtype=float)
        .reshape(-1, basis)[list(orbitals)]
        .T
    )
    weights = np.asarray(weights, dtype=float)
    single = weights.ndim == 1
    weights = np.atleast_2d(weights)
    lower, shape, numbers, nuclei = _grid(records, margin, bounds, spacing)
    values = np.moveaxis(
        _on_grid(
            molecule, lower, shape, spacing, lambda functions: ((functions @ coefficients) ** 2) @ weights.T, chunk
        ),
        -1,
        0,
    )
    atoms = np.column_stack([numbers, numbers, nuclei]).astype(float)
    return lower, np.eye(3) * spacing, atoms, values[0] if single else values

"""Fixed-geometry single points with registered density and electrostatic-potential grids."""

import hashlib
import logging
import os
import subprocess
from pathlib import Path

import numpy as np

from .execution import execute_gaussian, formchk, gaussian_environment
from .units import ureg

LOGGER = logging.getLogger(__name__)


def export_fields(root, name, *, coordinates, metadata, utility_log, boundary=0.002, cpus="8", memory="8GB"):
    """Run one single point and export its SCF density and ESP on one registered grid.

    The density grid follows ``inputs/grid.txt`` and the ESP is evaluated on the same points.

    Args:
        root: Run folder.
        name: Input name, without extension.
        coordinates: Input positions in angstrom, used to check the cube frames.
        metadata: Description of the state for the log.
        utility_log: Open text stream for the utilities' output.
        boundary: Largest density allowed on the grid faces, so the plotted isosurface stays inside the box;
            None skips that check.
        cpus: Processors for cubegen.
        memory: Gaussian's default memory for the utilities.

    Returns:
        The logged record, holding the state, SCF energy, explicit electrons and the validated fields.

    Raises:
        ValueError: A cube has the wrong atoms or frame, is incomplete or not finite, the density reaches the
            grid boundary, or the two fields are on different grids.
    """
    environment = gaussian_environment(memory=memory)
    root = Path(root)
    checkpoints = root / "checkpoints"
    scratch = root / "scratch" / name
    scratch.mkdir(parents=True, exist_ok=True)
    atom_count = len(coordinates)
    LOGGER.info(
        "Computing single point",
        extra={
            # The calculated state, its geometry source and model, as given by the run.
            "metadata": metadata
        },
    )
    # Gaussian runs inside checkpoints/, where the input's relative %Chk resolves.
    text, jobs = execute_gaussian(root, name, scratch=scratch, cwd=checkpoints, memory=memory)
    energy = jobs[-1]["scf_history"][-1]["energy"]
    # Alpha and beta electron counts from the native output.
    electrons = sum(jobs[-1]["electron_counts"])
    formatted = formchk(checkpoints / f"{name}.chk", utility_log)
    density = root / "fields" / f"{name}-density.cube"
    potential = root / "fields" / f"{name}-potential.cube"
    subprocess.run(
        ["/opt/g16/cubegen", "1", "FDensity=SCF", str(formatted), str(density), "-1", "h"],
        input=(root / "inputs" / "grid.txt").read_bytes(),
        cwd=root,
        env=environment,
        stdout=utility_log,
        stderr=subprocess.STDOUT,
        check=True,
    )
    # Reuse the density grid so the ESP has identical coordinates and spacing.
    subprocess.run(
        [
            "/opt/g16/cubegen",
            os.environ.get("SLURM_CPUS_PER_TASK", cpus),
            "Potential=SCF",
            str(formatted),
            str(potential),
            "-1",
            "h",
            str(density),
        ],
        cwd=root,
        env=environment,
        stdout=utility_log,
        stderr=subprocess.STDOUT,
        check=True,
    )
    headers, fields = [], []
    # Check finite values, atom positions and grid registration before reporting the fields.
    for kind, path in [("density", density), ("potential", potential)]:
        with path.open() as stream:
            header = [stream.readline() for _ in range(atom_count + 6)]
            if int(header[2].split()[0]) != atom_count:
                raise ValueError(f"Unexpected atom count in {path}")
            dimensions = [int(line.split()[0]) for line in header[3:6]]
            scalars = np.asarray(stream.read().replace("D", "E").split(), dtype=np.float64)
        if scalars.size != np.prod(dimensions):
            raise ValueError(f"Incomplete cube {path}")
        if not np.isfinite(scalars).all():
            raise ValueError(f"Nonfinite scalar in {path}")
        axes = np.asarray([line.split()[1:4] for line in header[3:6]], dtype=np.float64)
        volume_element = float(np.abs(np.linalg.det(axes)))
        # Cube headers give atom positions in bohr.
        positions = (
            ureg.Quantity(np.asarray([line.split()[2:5] for line in header[6:]], dtype=np.float64), "bohr")
            .to("angstrom")
            .magnitude
        )
        error = float(np.max(np.abs(positions - np.asarray(coordinates))))
        if error > 3e-6:
            raise ValueError(f"Molecular frame differs from input in {path}")
        headers.append(header[2:])
        validation = {
            # Grid points along the three cube axes.
            "dimensions": dimensions,
            # Smallest field value on the grid, in atomic units.
            "minimum": float(scalars.min()),
            # Largest field value on the grid, in atomic units.
            "maximum": float(scalars.max()),
            # Largest cube-header atom displacement from the input geometry, in angstrom.
            "registration_error": error,
        }
        if kind == "density":
            if boundary is not None:
                grid = scalars.reshape(dimensions)
                faces = (grid[0], grid[-1], grid[:, 0], grid[:, -1], grid[:, :, 0], grid[:, :, -1])
                boundary_max = max(float(face.max()) for face in faces)
                if boundary_max >= boundary:
                    raise ValueError("Density isosurface intersects the grid boundary")
                validation["boundary_density_maximum"] = boundary_max
            validation["integrated_electrons"] = float(scalars.sum() * volume_element)
        LOGGER.info(
            "Validated volumetric field",
            extra={
                # Scientific or execution fields appended to the log message.
                "metadata": {
                    # Calculated state named by the run.
                    "state": name,
                    # Density or electrostatic potential.
                    "field": kind,
                    # Number of grid values read.
                    "samples": int(scalars.size),
                    **validation,
                }
            },
        )
        fields.append(
            {
                # Range, registration and electron checks of this field.
                "validation": validation,
                # Density or electrostatic potential.
                "kind": kind,
                # Cube path relative to the run folder.
                "path": str(path.relative_to(root)),
                # SHA-256 of the cube file.
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
        )
    if headers[0] != headers[1]:
        raise ValueError("Density and electrostatic potential are on different grids")
    record = {
        # Calculated state named by the run.
        "state": name,
        # Final SCF energy in hartree.
        "scf_energy": energy,
        # Total explicit electrons from Gaussian's alpha and beta counts.
        "explicit_electrons": electrons,
        # Exported and validated fields.
        "fields": fields,
    }
    LOGGER.info(
        "Completed single point and field exports",
        extra={
            # Energy, electron count and validated fields of the state.
            "metadata": record
        },
    )
    return record

"""Lotus logs: SCF, orbital and screening histories, and the consistency of retained response arrays."""

import ast
import re
from pathlib import Path

import numpy as np

from .text import NUMBER, parse_float


def read_lotus(path, *, response=None):
    """Read native SCF, orbital and applied-screening histories without conflating them.

    Args:
        path: Native Lotus log.
        response: Saved response arrays, as a mapping or an ``.npz`` path, whose consistency is measured; or None.

    Returns:
        The histories, weights, density change and warnings, with ``response`` and ``checks`` when arrays are given.
    """
    text = Path(path).read_text()
    result = {
        # Native SCF method label, not a reconstructed functional definition.
        "method": None,
        # Native electronic SCF convergence records in output order.
        "scf_history": [],
        # Native Lotus HOMO, LUMO and gap records with source positions.
        "orbital_history": [],
        # Applied-screening records; not assumed synchronous with SCF headers.
        "screening_history": [],
        # Native Lotus energy-component dictionaries in output order.
        "energy_parts": [],
        # Applied native exchange/correlation coefficients; dimensionless.
        "weights": {},
        # Maximum density change; None until a convergence marker is printed.
        "density_change": None,
        # Native scientific warnings retained without dismissing them.
        "warnings": [],
    }
    iteration = None
    fields = {
        # Native Lotus identifier mapped to the HF exchange fraction.
        "hybrid_hf_x": "exact_exchange",
        # Native Lotus identifier mapped to the Slater exchange weight.
        "hybrid_slater": "slater_exchange",
        # Native Lotus identifier mapped to the B88 exchange weight.
        "hybird_b88": "b88_exchange",
        # Native Lotus identifier mapped to the VWN correlation weight.
        "para_vwn": "vwn_correlation",
        # Native Lotus identifier mapped to the LYP correlation weight.
        "para_lyp": "lyp_correlation",
    }
    for line_number, line in enumerate(text.splitlines(), 1):
        method = re.search(r"\bmethod\s+(\w+)", line)
        if method:
            result["method"] = method[1]
        header = re.search(
            r"n_scf\s*=\s*(\d+)\s+max_d\s+(None|"
            + NUMBER
            + r")\s+mix_D\s+("
            + NUMBER
            + r")\s+total_ene\s+("
            + NUMBER
            + r")\s+volume\s+("
            + NUMBER
            + r")",
            line,
        )
        if header:
            iteration = int(header[1])
            result["scf_history"].append(
                {
                    # Native iteration number; Gaussian starts at one, Lotus at zero.
                    "iteration": iteration,
                    # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                    "line": line_number,
                    # Maximum density change; None until a convergence marker is printed.
                    "density_change": None if header[2] == "None" else parse_float(header[2]),
                    # Native Lotus density-mixing coefficient; dimensionless.
                    "mixing": parse_float(header[3]),
                    # Electronic energy in hartree.
                    "energy": parse_float(header[4]),
                    # Native density-contour volume in cubic bohr.
                    "volume": parse_float(header[5]),
                }
            )
        orbital = re.search(
            r"homo\s+(" + NUMBER + r")\s+lumo\s+(" + NUMBER + r")\s+gap\s+(" + NUMBER + r")",
            line,
        )
        # homo/lumo/gap are orbital energies in hartree; they are not optical excitations.
        if orbital:
            result["orbital_history"].append(
                {
                    # Native iteration number; Gaussian starts at one, Lotus at zero.
                    "iteration": iteration,
                    # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                    "line": line_number,
                    **dict(
                        zip(
                            ("homo", "lumo", "gap"),
                            map(parse_float, orbital.groups()),
                            strict=True,
                        )
                    ),
                }
            )
        screening = re.search(r"epsilon\s+(" + NUMBER + r")\s+volume\s+(" + NUMBER + r")", line)
        if screening:
            result["screening_history"].append(
                {
                    # Native iteration number; Gaussian starts at one, Lotus at zero.
                    "iteration": iteration,
                    # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                    "line": line_number,
                    # Applied molecular screening parameter; dimensionless.
                    "epsilon": parse_float(screening[1]),
                    # Native density-contour volume in cubic bohr.
                    "volume": parse_float(screening[2]),
                }
            )
        energy = re.search(r"ene_info\s+(\{.*\})", line)
        if energy:
            parts = ast.literal_eval(energy[1])
            result["energy_parts"].append(
                {
                    # Native iteration number; Gaussian starts at one, Lotus at zero.
                    "iteration": iteration,
                    # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                    "line": line_number,
                    # Native Lotus values: energies in hartree, except volume in cubic bohr.
                    "values": {key: float(value) for key, value in parts.items()},
                }
            )
        for native, name in fields.items():
            weight = re.search(r"\b" + native + r"\s+(" + NUMBER + r")", line)
            if weight:
                result["weights"][name] = parse_float(weight[1])
        converged = re.search(r"break max_d\s+(" + NUMBER + r")", line)
        if converged:
            result["density_change"] = parse_float(converged[1])
        if re.search(r"warning|traceback|error", line, re.IGNORECASE):
            result["warnings"].append(
                {
                    # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                    "line": line_number,
                    # Native warning or error text.
                    "message": line.strip(),
                }
            )
    # Number of printed SCF headers, including the initial iteration zero.
    result["scf_iterations"] = len(result["scf_history"])
    # Response arrays are optional because the native text log does not contain them.
    result["response"] = None
    # Derived matrix consistency diagnostics; absent without response arrays.
    result["checks"] = {}
    if response is not None:
        if isinstance(response, (str, Path)):
            with np.load(response, allow_pickle=False) as archive:
                arrays = {name: archive[name] for name in archive.files}
        else:
            arrays = dict(response)
        result["checks"] = _check_response(arrays)
        result["response"] = arrays
    return result


def _check_response(data):
    """Measure consistency of retained closed-shell response matrices, not a new SCF solution.

    Args:
        data: Response arrays: orbital energies, coefficients, density and overlap matrices, atomic response
            and molecular screening.

    Returns:
        The consistency metrics, such as electron count, idempotency and response errors.

    Raises:
        ValueError: Dimensions mismatch, values are not finite, orbitals are unordered or partitions are missing.
    """
    required = {
        "coefficients",
        "density_matrix",
        "overlap_matrix",
        "orbital_energies",
        "atom_response",
        "dielectric",
    }
    if not required.issubset(data):
        return {}
    coefficients = np.asarray(data["coefficients"])
    density = np.asarray(data["density_matrix"])
    overlap = np.asarray(data["overlap_matrix"])
    energies = np.asarray(data["orbital_energies"])
    if overlap.ndim != 2 or overlap.shape[0] != overlap.shape[1]:
        raise ValueError("The AO overlap matrix must be square")
    count = len(overlap)
    if coefficients.shape != (count, count) or density.shape != overlap.shape or energies.shape != (count,):
        raise ValueError("The response orbital and matrix dimensions do not match")
    if not all(
        np.isfinite(v).all()
        for v in (
            coefficients,
            density,
            overlap,
            energies,
            data["atom_response"],
            data["dielectric"],
        )
    ):
        raise ValueError("The response contains non-finite matrix or orbital values")
    if np.any(np.diff(energies) < -1e-10):
        raise ValueError("The response orbital energies must be ordered")
    if np.asarray(data["atom_response"]).ndim != 1 or not len(data["atom_response"]):
        raise ValueError("A response partition for each atom is required")
    eigenvalues = np.linalg.eigvalsh(overlap)
    if eigenvalues[0] <= 0:
        raise ValueError("The overlap matrix is not positive definite")
    electrons = float(np.trace(density @ overlap))
    occupied = round(electrons / 2)
    if abs(electrons - 2 * occupied) > 1e-7 or not 0 < occupied < count:
        raise ValueError("The spin-summed response density has an invalid electron count")
    return {
        # Spin-summed electron count trace(D @ S); dimensionless.
        "electron_count": electrons,
        # Number of AO basis functions in this record.
        "basis_count": count,
        # Maximum absolute deviation of C.T @ S @ C from identity; dimensionless.
        "coefficient_error": float(np.max(np.abs(coefficients.T @ overlap @ coefficients - np.eye(count)))),
        # Maximum absolute deviation of D @ S @ D from 2D for spin-summed density.
        "idempotency_error": float(np.max(np.abs(density @ overlap @ density - 2 * density))),
        # Maximum absolute antisymmetric part of the AO density matrix.
        "density_error": float(np.max(np.abs(density - density.T))),
        # Maximum absolute antisymmetric part of the AO overlap matrix.
        "overlap_error": float(np.max(np.abs(overlap - overlap.T))),
        # Smallest retained AO-overlap eigenvalue; dimensionless.
        "overlap_minimum": float(eigenvalues[0]),
        # Largest divided by smallest AO-overlap eigenvalue; dimensionless.
        "overlap_condition": float(eigenvalues[-1] / eigenvalues[0]),
        # Highest occupied closed-shell orbital energy in hartree.
        "homo": float(energies[occupied - 1]),  # Hartree.
        # Lowest unoccupied closed-shell orbital energy in hartree.
        "lumo": float(energies[occupied]),  # Hartree.
        # Closed-shell LUMO minus HOMO energy in hartree; not an optical excitation.
        "orbital_gap": float(energies[occupied] - energies[occupied - 1]),  # Hartree.
        # Absolute difference between mean atomic response and molecular screening.
        "response_error": float(abs(np.mean(data["atom_response"]) - data["dielectric"])),
    }

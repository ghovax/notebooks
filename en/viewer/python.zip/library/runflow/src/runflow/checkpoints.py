"""Gaussian formatted checkpoints: every native record, and the geometry, harmonic modes and reaction path they hold."""

import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .molecules import xyz_frames

# ELEMENTS is part of this module's interface: retained run scripts import it from here.
from .units import ELEMENTS, ureg  # noqa: F401


def read_fchk_records(path):
    """Every scalar and array record of a formatted checkpoint, by its native name, without changing the file.

    Args:
        path: Formatted checkpoint (``.fchk``) to read.

    Returns:
        Mapping of each native record name to its scalar or NumPy array value.

    Raises:
        ValueError: A record cannot be read.
    """
    lines = Path(path).read_text().splitlines()
    records, index = {}, 2
    while index < len(lines):
        line = lines[index]
        index += 1
        match = re.match(r"^(.{40})\s+([IRC])\s+(.*)$", line)
        if not match:
            continue
        name, kind, value = match.groups()
        name = name.strip()
        if kind == "C":
            if value.strip().startswith("N="):
                index += (int(value.split("=")[1]) + 4) // 5
            continue
        convert = int if kind == "I" else float
        if value.strip().startswith("N="):
            count = int(value.split("=")[1])
            # Gaussian writes six integers or five reals a line; the block is converted by NumPy in one call.
            rows = -(-count // (6 if kind == "I" else 5))
            text = " ".join(lines[index : index + rows])
            index += rows
            tokens = (text.replace("D", "E") if kind == "R" else text).split()
            if len(tokens) != count:
                raise ValueError(f"Invalid checkpoint record {name}.")
            records[name] = np.array(tokens, dtype=np.int64 if kind == "I" else float)
        else:
            records[name] = convert(value.replace("D", "E"))
    return records


@dataclass(frozen=True)
class Vibrations:
    """Cartesian mode directions and harmonic properties in Gaussian's native units.

    Attributes:
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of equilibrium Cartesian coordinates.
        frequencies: Pint array of harmonic frequencies; negative values are imaginary modes.
        masses: Pint array of reduced masses, one per mode.
        constants: Pint array of force constants, one per mode.
        intensities: Pint array of IR intensities, one per mode.
        modes: Array of modes by atoms by three Cartesian displacement components.
    """

    numbers: np.ndarray
    coordinates: object
    frequencies: object
    masses: object
    constants: object
    intensities: object
    modes: np.ndarray

    def trajectory(self, mode, *, amplitude, steps=41):
        """Scale a one-based mode to a requested maximum atomic excursion.

        Args:
            mode: One-based index of the normal mode.
            amplitude: Pint length of the largest atomic displacement.
            steps: Number of frames over one period, at least five.

        Returns:
            XYZ text of the frames, sampling phase rather than physical time.

        Raises:
            ValueError: The mode does not exist, the amplitude is negative or not finite, there are fewer than five
                steps, or the mode has no displacement.
        """
        amplitude = amplitude.to("angstrom")
        if not 1 <= mode <= len(self.frequencies) or not np.isfinite(amplitude.magnitude) or amplitude.magnitude < 0:
            raise ValueError("Specify an available mode and a nonnegative finite amplitude.")
        if steps < 5:
            raise ValueError("A mode trajectory requires at least five frames.")
        direction = self.modes[mode - 1]
        scale = np.linalg.norm(direction, axis=1).max()
        if scale <= 0:
            raise ValueError("The selected normal mode has no displacement.")
        phase = np.linspace(0, 2 * np.pi, steps, endpoint=False)
        geometries = (
            self.coordinates.to("angstrom").magnitude
            + amplitude.magnitude * np.sin(phase)[:, None, None] * direction / scale
        ) * ureg.angstrom
        return xyz_frames(self.numbers, geometries)


@dataclass(frozen=True)
class ReactionPath:
    """Matched geometries, energies and Cartesian gradients ordered along an IRC.

    Attributes:
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of points by atoms by three Cartesian components.
        coordinate: Pint array of the reaction coordinate at each point.
        energies: Pint array of total energies at each point.
        gradients: Pint array of Cartesian gradients at each point.
    """

    numbers: np.ndarray
    coordinates: object
    coordinate: object
    energies: object
    gradients: object

    @property
    def rms(self):
        """Return RMS Cartesian gradients in hartree per bohr.

        Returns:
            Pint array with one RMS gradient per path point.
        """
        return (
            np.sqrt(np.mean(self.gradients.to("hartree/bohr").magnitude ** 2, axis=(1, 2))) * ureg.hartree / ureg.bohr
        )

    @property
    def frames(self):
        """Return the reaction path as an XYZ trajectory in angstrom.

        Returns:
            XYZ text with one frame per path point.
        """
        return xyz_frames(self.numbers, self.coordinates)


@dataclass(frozen=True)
class GaussianCheckpoint:
    """Native geometry with optional harmonic modes and IRC path data.

    Attributes:
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of the current Cartesian coordinates.
        vibrations: Harmonic modes, or None without a frequency result.
        irc: Reaction path, or None without IRC records.
    """

    numbers: np.ndarray
    coordinates: object
    vibrations: Vibrations | None
    irc: ReactionPath | None


def _vibrations(records, numbers, coordinates):
    """Extract harmonic modes when the checkpoint contains a frequency result.

    Args:
        records: Native records from :func:`read_fchk_records`.
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of Cartesian coordinates.

    Returns:
        The :class:`Vibrations`, or None without mode records.

    Raises:
        ValueError: The mode records do not match each other or the atom count.
    """
    if "Vib-Modes" not in records or "Vib-E2" not in records:
        return None
    count = len(numbers)
    modes = records["Vib-Modes"].reshape(-1, count, 3)
    properties = records["Vib-E2"].reshape(-1, len(modes))
    if len(modes) != 3 * count - 6 or not np.isfinite(properties).all():
        raise ValueError("Expected a complete nonlinear-molecule frequency analysis.")
    return Vibrations(
        numbers,
        coordinates,
        properties[0] / ureg.centimeter,
        properties[1] * ureg.amu,
        properties[2] * ureg.millidyne / ureg.angstrom,
        properties[3] * ureg.kilometer / ureg.mole,
        modes,
    )


def _irc(records, numbers):
    """Extract an IRC path when the checkpoint contains matched path records.

    Args:
        records: Native records from :func:`read_fchk_records`.
        numbers: Atomic numbers, one per atom.

    Returns:
        The :class:`ReactionPath`, or None without IRC records.

    Raises:
        ValueError: The path records do not match each other or the atom count.
    """
    prefix = "IRC point       1 "
    required = (
        prefix + "Results for each geome",
        prefix + "Geometries",
        prefix + "Gradient at each geome",
    )
    if not all(name in records for name in required):
        return None
    results = records[required[0]].reshape(-1, 2)
    count = len(numbers)
    coordinates = records[required[1]].reshape(-1, count, 3) * ureg.bohr
    gradients = records[required[2]].reshape(-1, count, 3) * ureg.hartree / ureg.bohr
    if len(coordinates) != len(results) or len(gradients) != len(results):
        raise ValueError("The IRC checkpoint has unmatched result records.")
    order = np.argsort(results[:, 1])
    if not np.isfinite(results).all() or not np.all(np.diff(results[order, 1]) > 0):
        raise ValueError("The IRC coordinate must contain unique finite points.")
    return ReactionPath(
        numbers,
        coordinates[order],
        results[order, 1] * ureg.bohr * ureg.amu**0.5,
        results[order, 0] * ureg.hartree,
        gradients[order],
    )


def read_gaussian_checkpoint(path):
    """Return native coordinates, modes and IRC records from one formatted checkpoint.

    Args:
        path: Formatted checkpoint (``.fchk``) to read.

    Returns:
        The :class:`GaussianCheckpoint`.

    Raises:
        FileNotFoundError: The checkpoint does not exist.
        ValueError: Its records are incomplete or inconsistent.
    """
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Gaussian checkpoint is missing: {path}")
    records = read_fchk_records(path)
    try:
        numbers = np.asarray(records["Atomic numbers"], dtype=int)
        count = int(records["Number of atoms"])
        coordinates = np.asarray(records["Current cartesian coordinates"], dtype=float).reshape(count, 3) * ureg.bohr
    except KeyError as error:
        raise ValueError(f"Required checkpoint geometry field is missing: {error.args[0]}") from error
    if len(numbers) != count or not np.isfinite(coordinates).all():
        raise ValueError("Checkpoint atom numbers and Cartesian coordinates do not match.")
    return GaussianCheckpoint(
        numbers=numbers,
        coordinates=coordinates,
        vibrations=_vibrations(records, numbers, coordinates),
        irc=_irc(records, numbers),
    )


def spins(records):
    """The spin channels of a formatted checkpoint's orbitals.

    Args:
        records: Records from ``read_fchk_records``.

    Returns:
        ``["alpha"]`` for a restricted wavefunction, ``["alpha", "beta"]`` for an unrestricted one.
    """
    return ["alpha", "beta"] if "Beta MO coefficients" in records else ["alpha"]


def spin_record(records, spin, name):
    """One spin channel's record of a formatted checkpoint, such as its MO coefficients or orbital energies.

    Args:
        records: Records from ``read_fchk_records``.
        spin: ``"alpha"`` or ``"beta"``.
        name: The record's name with ``{Spin}`` or ``{spin}`` for the channel, such as ``"{Spin} MO coefficients"``.

    Returns:
        The record; a restricted checkpoint's beta channel is its alpha one.

    Raises:
        ValueError: If the spin is neither alpha nor beta.
        KeyError: If the checkpoint has no such record.
    """
    if spin not in ("alpha", "beta"):
        raise ValueError(f"The spin is alpha or beta, not {spin!r}.")
    key = name.format(Spin=spin.capitalize(), spin=spin)
    if key not in records and spin == "beta" and "Beta MO coefficients" not in records:
        key = name.format(Spin="Alpha", spin="alpha")
    return records[key]

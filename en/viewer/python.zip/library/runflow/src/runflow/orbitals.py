"""Molecular orbitals of any geometry, from PySCF, for orbitals that no calculation of a run saved.

A run's own orbitals come from its formatted checkpoint (``runflow.checkpoints.orbital_grid``). These are for a geometry
that was never calculated here, such as a fragment of a starting structure or a point of a reaction path: closed-shell
Hartree-Fock or Kohn-Sham in any basis and functional PySCF knows. Gaussian's B3LYP, with the VWN3 local correlation, is
PySCF's ``B3LYPG``; PySCF's ``B3LYP`` uses VWN5 and differs by millihartrees. Gaussian's 6-31G(d,p) is ``6-31g**`` with
Cartesian d functions, which every calculation here uses. PySCF is an optional dependency, installed with
``pip install 'runflow[orbitals]'``.

Besides the orbitals and their overlap, the module splits an overlap into atom pairs, an orbital into atoms and angular
momenta, and the orbitals of a complex into those of its fragments.
"""

import hashlib
import json
import multiprocessing
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from functools import cached_property

import numpy as np

from .cache import cache_folder
from .units import ureg

# Converged orbitals by what defines them, so a geometry is calculated once.


@dataclass(frozen=True)
class Orbitals:
    """Canonical orbitals of one closed-shell geometry."""

    # The PySCF molecule, with its atoms in the order given.
    molecule: object
    # Orbital energies in hartree.
    energies: np.ndarray
    # Orbital coefficients on the atomic orbitals, one orbital per column.
    coefficients: np.ndarray
    # Electrons in each orbital, 2 or 0.
    occupations: np.ndarray
    # Electronic-structure method: HF, or the PySCF name of a functional.
    method: str = "HF"
    # Key of the calculation, the digest of what defines it, which names fields drawn from these orbitals.
    key: str = ""

    @property
    def homo(self):
        """Zero-based index of the highest occupied orbital.

        Returns:
            The index of the last orbital with a positive occupation.
        """
        return int(np.flatnonzero(self.occupations > 0)[-1])

    @property
    def lumo(self):
        """Zero-based index of the lowest unoccupied orbital.

        Returns:
            The index after the highest occupied orbital.
        """
        return self.homo + 1

    def values(self, index, points, atoms=None):
        r"""Amplitude of an orbital at points, or of its part on some atoms, :math:`\sum_{\mu\in A}c_\mu\phi_\mu`.

        Args:
            index: Zero-based orbital index.
            points: Positions in bohr, of shape (N, 3).
            atoms: Zero-based atoms whose basis functions are kept; None keeps every one.

        Returns:
            The amplitude at each point, of shape (N,), in :math:`a_0^{-3/2}`.
        """
        from pyscf.dft import numint

        coefficients = self.coefficients[:, index]
        if atoms is not None:
            coefficients = np.where(np.isin(_function_atoms(self.molecule), atoms), coefficients, 0.0)
        return numint.eval_ao(self.molecule, np.asarray(points, dtype=float)) @ coefficients

    def parts(self, index, points):
        r"""The parts of an orbital on each atom, :math:`\psi^{(A)}=\sum_{\mu\in A}c_\mu\phi_\mu`, from one evaluation
        of the basis functions; the parts add up to the orbital.

        Args:
            index: Zero-based orbital index.
            points: Positions in bohr, of shape (N, 3).

        Returns:
            Array of shape (atoms, N), in :math:`a_0^{-3/2}`.
        """
        from pyscf.dft import numint

        terms = numint.eval_ao(self.molecule, np.asarray(points, dtype=float)) * self.coefficients[:, index]
        result = np.zeros((self.molecule.natm, len(terms)))
        np.add.at(result, _function_atoms(self.molecule), terms.T)
        return result

    def energy(self, index):
        """Energy of one orbital.

        Args:
            index: Zero-based orbital index.

        Returns:
            The orbital energy as a Pint quantity in hartree.
        """
        return float(self.energies[index]) * ureg.hartree


def digest(metadata):
    """Key of a record: the SHA-256 of its metadata written as canonical JSON, keys sorted and without spaces, so
    equal metadata always give the same key.

    Args:
        metadata: JSON-serializable mapping of what defines the record.

    Returns:
        The hexadecimal digest.
    """
    return hashlib.sha256(json.dumps(metadata, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def calculation_metadata(numbers, positions, basis, method, charge):
    """What defines one calculation of ``scf``: atoms, positions in angstrom, basis, method and charge.

    Args:
        numbers: Atomic numbers.
        positions: Cartesian coordinates in angstrom.
        basis: Basis set name.
        method: ``HF`` or a functional, compared without case.
        charge: Total charge.

    Returns:
        The metadata, whose ``digest`` names the kept orbitals.
    """
    return {
        # Atomic numbers, in the given order.
        "numbers": [int(number) for number in numbers],
        # Cartesian coordinates in angstrom, one row per atom.
        "positions": np.asarray(positions, dtype=float).tolist(),
        # Basis set name, in lower case.
        "basis": basis.lower(),
        # HF, or the functional, in upper case.
        "method": method.upper(),
        # Total charge of the molecule.
        "charge": int(charge),
    }


def _kept(numbers, positions, basis, method, charge):
    """Where ``scf`` keeps the orbitals of one calculation.

    Args:
        numbers: Atomic numbers.
        positions: Cartesian coordinates in angstrom.
        basis: Basis set name.
        method: ``HF`` or a functional.
        charge: Total charge.

    Returns:
        The path below the ``orbitals`` cache folder, named by the digest of the calculation's metadata.
    """
    return cache_folder("orbitals") / f"{digest(calculation_metadata(numbers, positions, basis, method, charge))}.npz"


def scf(numbers, positions, *, basis="6-31g", method="HF", charge=0, cache=True):
    """Closed-shell Hartree-Fock or Kohn-Sham orbitals of atoms at ``positions`` in angstrom.

    Args:
        numbers: Atomic numbers.
        positions: Cartesian coordinates in angstrom, one row per atom.
        basis: Basis set name known to PySCF, with Cartesian d and f functions.
        method: ``HF``, or a functional PySCF knows, such as ``B3LYPG`` for Gaussian's B3LYP.
        charge: Total charge; the molecule must be a closed-shell singlet.
        cache: Keep the converged orbitals in the ``orbitals`` cache folder, named by the ``digest`` of ``calculation_metadata``, with
            that metadata and the PySCF version stored in the file; the version is not part of the key, so a newer
            PySCF reuses them.

    Returns:
        The orbitals, with their atoms in the given order.

    Raises:
        RuntimeError: If the self-consistent field does not converge.
    """
    import pyscf
    from pyscf import dft, gto
    from pyscf import scf as hartree_fock

    molecule = gto.M(
        atom=[[int(number), tuple(map(float, position))] for number, position in zip(numbers, positions)],
        unit="Angstrom",
        basis=basis,
        charge=charge,
        cart=True,
        verbose=0,
    )
    hartree = method.upper() == "HF"
    metadata = calculation_metadata(numbers, positions, basis, method, charge)
    key = digest(metadata)
    path = cache_folder("orbitals") / f"{key}.npz"
    if cache and path.exists():
        with np.load(path) as kept:
            return Orbitals(molecule, kept["energies"], kept["coefficients"], kept["occupations"], method, key)
    if hartree:
        calculation = hartree_fock.RHF(molecule)
    else:
        calculation = dft.RKS(molecule)
        calculation.xc = method
    calculation.conv_tol = 1e-10
    calculation.run()
    if not calculation.converged:
        raise RuntimeError(f"The {method} calculation did not converge.")
    if cache:
        path.parent.mkdir(parents=True, exist_ok=True)
        # What defines the calculation, which its key is the digest of, and the program that ran it, which is not part
        # of the key, so that a newer PySCF reuses the orbitals.
        kept = {
            **metadata,
            # Program that calculated the orbitals.
            "program": "pyscf",
            # Version of the program.
            "version": pyscf.__version__,
            # Self-consistent-field procedure of the program.
            "procedure": "RHF" if hartree else f"RKS {method}",
        }
        np.savez(
            path,
            energies=calculation.mo_energy,
            coefficients=calculation.mo_coeff,
            occupations=calculation.mo_occ,
            metadata=json.dumps(kept),
        )
    return Orbitals(molecule, calculation.mo_energy, calculation.mo_coeff, calculation.mo_occ, method, key)


def overlap(first, index, second, other):
    """Overlap integral of orbital ``index`` of ``first`` with orbital ``other`` of ``second``.

    The two sets of orbitals may belong to different molecules or basis sets, if their atoms share one frame of
    coordinates, as the fragments of one structure do. The sign follows the sign of each orbital, which is arbitrary.

    Args:
        first: Orbitals of the first molecule or fragment.
        index: Zero-based orbital index in ``first``.
        second: Orbitals of the second molecule or fragment.
        other: Zero-based orbital index in ``second``.

    Returns:
        The overlap integral, dimensionless, between -1 and 1 for normalized orbitals.
    """
    from pyscf import gto

    matrix = gto.intor_cross("int1e_ovlp", first.molecule, second.molecule)
    return float(first.coefficients[:, index] @ matrix @ second.coefficients[:, other])


def _function_atoms(molecule):
    """Zero-based atom of each basis function of a PySCF molecule.

    Args:
        molecule: The PySCF molecule.

    Returns:
        Integer array with one atom index per basis function.
    """
    return np.array([label[0] for label in molecule.ao_labels(fmt=False)], dtype=int)


def pair_overlaps(first, index, second, other):
    r"""The overlap of ``overlap`` split into atom pairs,
    :math:`S_{A,B}=\sum_{\mu\in A}\sum_{\nu\in B}c_\mu d_\nu\langle\phi_\mu|\phi_\nu\rangle`.

    Args:
        first: Orbitals of the first molecule or fragment.
        index: Zero-based orbital index in ``first``.
        second: Orbitals of the second molecule or fragment, in the same frame of coordinates.
        other: Zero-based orbital index in ``second``.

    Returns:
        Array of shape (atoms of ``first``, atoms of ``second``), dimensionless, whose sum is the overlap.
    """
    from pyscf import gto

    matrix = gto.intor_cross("int1e_ovlp", first.molecule, second.molecule)
    terms = first.coefficients[:, index][:, None] * matrix * second.coefficients[:, other][None, :]
    pairs = np.zeros((first.molecule.natm, second.molecule.natm))
    rows, columns = _function_atoms(first.molecule), _function_atoms(second.molecule)
    np.add.at(pairs, (rows[:, None], columns[None, :]), terms)
    return pairs


def composition(orbitals, index):
    r"""Mulliken composition of one orbital by atom and angular momentum,
    :math:`w_{A,l}=\sum_{\mu\in A,\ l_\mu=l}c_\mu(\mathbf{S}\mathbf{c})_\mu` over the functions of each atom and shell type.

    Args:
        orbitals: The orbitals.
        index: Zero-based orbital index.

    Returns:
        Array of shape (atoms, momenta), the shares of the s, p, d, ... functions on each atom up to the highest angular
        momentum of the basis; the shares add up to one.
    """
    molecule = orbitals.molecule
    vector = orbitals.coefficients[:, index]
    shares = vector * (molecule.intor_symmetric("int1e_ovlp") @ vector)
    # Each function's angular momentum, from its shell.
    momenta = np.repeat([molecule.bas_angular(shell) for shell in range(molecule.nbas)], np.diff(molecule.ao_loc_nr()))
    table = np.zeros((molecule.natm, momenta.max() + 1))
    np.add.at(table, (_function_atoms(molecule), momenta), shares)
    return table


@dataclass(frozen=True)
class FragmentAnalysis:
    r"""Orbitals of a complex as mixtures of the orbitals of its fragments.

    Each complex orbital is :math:`\psi_i=\sum_k x_{ik}\chi_k` over the orbitals :math:`\chi_k` of every fragment, and
    its weight on :math:`\chi_k` is the Mulliken share :math:`w_{ik}=x_{ik}\sum_l x_{il}\langle\chi_k|\chi_l\rangle`;
    the weights of one complex orbital add up to one.
    """

    # Weights of shape (complex orbitals, fragment orbitals).
    weights: np.ndarray
    # Zero-based fragment of each fragment orbital, in the order of the columns.
    fragment: np.ndarray
    # Zero-based orbital index within its fragment, in the order of the columns.
    orbital: np.ndarray

    def weight(self, index, fragment, orbital):
        """Weight of one fragment orbital in one complex orbital.

        Args:
            index: Zero-based orbital index of the complex.
            fragment: Zero-based fragment, in the order given to ``fragment_analysis``.
            orbital: Zero-based orbital index within that fragment.

        Returns:
            The Mulliken weight, a fraction of one.
        """
        column = np.flatnonzero((self.fragment == fragment) & (self.orbital == orbital))[0]
        return float(self.weights[index, column])


def fragment_analysis(whole, fragments):
    """The orbitals of a complex expressed in the orbitals of its fragments, calculated at the same geometry.

    The fragments' basis functions must together be the complex's: each atom of the complex in exactly one fragment,
    with the same basis. The fragment orbitals then span the complex's basis, and every complex orbital has one exact
    expansion in them.

    Args:
        whole: Orbitals of the complex.
        fragments: Pairs of a fragment's orbitals and the zero-based atoms of the complex it holds, in its own order.

    Returns:
        The :class:`FragmentAnalysis`.

    Raises:
        ValueError: If the fragments do not hold each atom of the complex once, an atom's basis differs from the
            complex's, or a fragment has fewer orbitals than basis functions.
    """
    from scipy.linalg import block_diag

    slices = whole.molecule.aoslice_by_atom()
    held = sorted(atom for _, atoms in fragments for atom in atoms)
    if held != list(range(whole.molecule.natm)):
        raise ValueError("Every atom of the complex must belong to exactly one fragment.")
    order, blocks, fragment, orbital = [], [], [], []
    for number, (orbitals, atoms) in enumerate(fragments):
        own = orbitals.molecule.aoslice_by_atom()
        coefficients = orbitals.coefficients
        if coefficients.shape[0] != coefficients.shape[1]:
            raise ValueError("Each fragment needs as many orbitals as basis functions.")
        for position, atom in enumerate(atoms):
            if own[position, 3] - own[position, 2] != slices[atom, 3] - slices[atom, 2]:
                raise ValueError(f"Atom {atom} has a different basis in its fragment.")
            order.extend(range(slices[atom, 2], slices[atom, 3]))
        blocks.append(coefficients)
        fragment += [number] * coefficients.shape[1]
        orbital += list(range(coefficients.shape[1]))
    expansion = block_diag(*blocks)
    overlap_matrix = whole.molecule.intor_symmetric("int1e_ovlp")[np.ix_(order, order)]
    mixtures = np.linalg.solve(expansion, whole.coefficients[order])
    fragment_overlap = expansion.T @ overlap_matrix @ expansion
    weights = (mixtures * (fragment_overlap @ mixtures)).T
    return FragmentAnalysis(weights, np.array(fragment), np.array(orbital))


def symmetry_labels(orbitals, indices, *, group=None, samples=4000, seed=0, tolerance=0.1):
    r"""Irreducible representation of each orbital in a point group, from how the orbital transforms.

    The character of an operation :math:`g` is :math:`\langle\psi|\hat g\psi\rangle/\langle\psi|\psi\rangle`, estimated
    from points drawn around the atoms and their images; the characters then pick the representation through
    ``PointGroup.assign``. A fragment's orbitals take the group of the complex it belongs to, passed as ``group``.

    Args:
        orbitals: The orbitals.
        indices: Zero-based orbital indices.
        group: The point group and the centre its operations act about, as returned by ``point_group_of``; by default
            that of the orbitals' own geometry.
        samples: Number of points drawn.
        seed: Seed of the random points.
        tolerance: Geometric tolerance in bohr when the group is found here.

    Returns:
        One ``Irrep`` per index, or None where the characters fit no one-dimensional representation.
    """
    from pyscf.dft import numint

    group, centre = group if group is not None else point_group_of(orbitals, tolerance)
    nuclei = orbitals.molecule.atom_coords()
    generator = np.random.default_rng(seed)
    points = nuclei[generator.integers(len(nuclei), size=samples)] + generator.normal(scale=1.5, size=(samples, 3))
    columns = orbitals.coefficients[:, list(indices)]
    values = numint.eval_ao(orbitals.molecule, points) @ columns
    characters = []
    for matrix in group.operations:
        images = numint.eval_ao(orbitals.molecule, centre + (points - centre) @ np.asarray(matrix).T) @ columns
        characters.append((values * images).sum(axis=0) / np.sqrt((values**2).sum(axis=0) * (images**2).sum(axis=0)))
    characters = np.array(characters)
    return [group.assign(characters[:, k], 1) for k in range(len(indices))]


def point_group_of(orbitals, tolerance=0.1):
    """Point group of the orbitals' geometry and the centre its operations act about.

    A loose tolerance can admit near-operations that do not close into a group; the tolerance is then halved until they
    do, down to the default of ``point_group``.

    Args:
        orbitals: The orbitals, whose molecule gives the atoms.
        tolerance: Largest distance in bohr by which an operation may miss an equivalent atom, at first.

    Returns:
        The ``PointGroup`` and its centre in bohr, the nuclear-charge-weighted mean position.

    Raises:
        ValueError: If no tolerance down to 0.02 bohr gives a group.
    """
    from .symmetry import point_group

    charges = orbitals.molecule.atom_charges().astype(float)
    nuclei = orbitals.molecule.atom_coords()
    while True:
        try:
            return point_group(charges.astype(int), nuclei, tolerance), charges @ nuclei / charges.sum()
        except ValueError:
            if tolerance <= 0.02:
                raise
            tolerance = max(tolerance / 2, 0.02)


@dataclass(frozen=True)
class Interaction:
    """Two fragments of one geometry, each calculated alone, and the complex they form, with the frontier quantities
    of the pair: overlaps, gaps, the Klopman-Salem term, atom-pair overlaps and the electrons each fragment's LUMO
    receives in the complex.

    Fragment 0 donates from its HOMO into the LUMO of fragment 1 in normal electron demand, and fragment 1 into
    fragment 0 in inverse demand.
    """

    # Orbitals of the complex.
    whole: Orbitals
    # Orbitals of each fragment calculated alone at the same geometry.
    fragments: tuple
    # Zero-based atoms of the complex each fragment holds, in the fragment's order.
    atoms: tuple
    # Largest distance in bohr by which a symmetry operation may miss an atom, loose enough for points of a path.
    tolerance: float = 0.2

    def overlap(self, donor):
        """Signed overlap of the donor fragment's HOMO with the other fragment's LUMO, whose sign is arbitrary.

        Args:
            donor: The donating fragment, 0 or 1.

        Returns:
            The overlap, dimensionless.
        """
        first, second = self.fragments[donor], self.fragments[1 - donor]
        return overlap(first, first.homo, second, second.lumo)

    def gap(self, donor):
        r"""Frontier gap of a pair, :math:`\epsilon_\mathrm{LUMO}` of the acceptor less :math:`\epsilon_\mathrm{HOMO}` of
        the donor.

        Args:
            donor: The donating fragment, 0 or 1.

        Returns:
            The gap as a Pint quantity in electronvolts.
        """
        first, second = self.fragments[donor], self.fragments[1 - donor]
        return (second.energy(second.lumo) - first.energy(first.homo)).to("electron_volt")

    @property
    def stabilization(self):
        r"""Frontier term of the Klopman-Salem equation, :math:`F=S^2/\Delta\epsilon+S'^2/\Delta\epsilon'`; the frontier
        stabilization is :math:`\Delta E\approx-2k^2F` with an unknown constant :math:`k`.

        Returns:
            The term as a Pint quantity in reciprocal electronvolts.
        """
        return sum(self.overlap(donor) ** 2 / self.gap(donor) for donor in (0, 1))

    def pairs(self, donor):
        """Atom pairs of a frontier overlap, signed so that the whole overlap is positive.

        Args:
            donor: The donating fragment, 0 or 1.

        Returns:
            Array of shape (atoms of fragment 0, atoms of fragment 1) whose sum is the absolute overlap.
        """
        first, second = self.fragments[donor], self.fragments[1 - donor]
        split = pair_overlaps(first, first.homo, second, second.lumo)
        split = split if donor == 0 else split.T
        return split * np.sign(split.sum())

    @cached_property
    def analysis(self):
        """The complex's orbitals as mixtures of the fragments' orbitals.

        Returns:
            The :class:`FragmentAnalysis`, fragments numbered as in ``fragments``.
        """
        return fragment_analysis(self.whole, list(zip(self.fragments, self.atoms)))

    def lumo_population(self, acceptor):
        r"""Electrons the occupied orbitals of the complex place in a fragment's LUMO,
        :math:`n=2\sum_{i\in\mathcal{O}}w_{i,\mathrm{LUMO}}` over the set :math:`\mathcal{O}` of occupied orbitals.

        Args:
            acceptor: The accepting fragment, 0 or 1.

        Returns:
            The number of electrons.
        """
        lumo = self.fragments[acceptor].lumo
        return 2 * sum(self.analysis.weight(i, acceptor, lumo) for i in range(self.whole.homo + 1))

    @cached_property
    def group(self):
        """Point group of the complex and the centre of its operations, which also label the fragments' orbitals.

        Returns:
            The ``PointGroup`` and its centre in bohr.
        """
        return point_group_of(self.whole, self.tolerance)

    def labels(self, indices, fragment=None):
        """Lower-case Mulliken labels of orbitals in the complex's point group, such as a'.

        Args:
            indices: Zero-based orbital indices.
            fragment: The fragment, 0 or 1, whose orbitals are labelled; None for the complex.

        Returns:
            One label per index, empty where no representation fits.
        """
        orbitals = self.whole if fragment is None else self.fragments[fragment]
        return [
            irrep.orbital() if irrep is not None else ""
            for irrep in symmetry_labels(orbitals, indices, group=self.group)
        ]


def interactions(numbers, geometries, atoms, *, basis="6-31g", method="HF", workers=None):
    """The :class:`Interaction` of two fragments at each geometry, every calculation run once in parallel and kept.

    Args:
        numbers: Atomic numbers of the complex.
        geometries: Positions of the complex in angstrom, one array of shape (atoms, 3) per geometry.
        atoms: The two lists of zero-based atoms of the complex the fragments hold.
        basis: Basis set name, as ``scf`` takes it.
        method: ``HF`` or a functional, as ``scf`` takes it.
        workers: Worker processes, as ``scf_many`` takes them.

    Returns:
        One interaction per geometry, in order.
    """
    numbers = np.asarray(numbers)
    jobs = [
        (numbers[list(part)], np.asarray(positions)[list(part)])
        for positions in geometries
        for part in (range(len(numbers)), *atoms)
    ]
    found = scf_many(jobs, basis=basis, method=method, workers=workers)
    return [
        Interaction(found[3 * k], (found[3 * k + 1], found[3 * k + 2]), tuple(map(list, atoms)))
        for k in range(len(geometries))
    ]


def _scf_one(job):
    """One ``scf`` call from a tuple, for a worker process.

    Args:
        job: A (numbers, positions, basis, method, charge) tuple, the arguments of ``scf``.

    Returns:
        The orbitals ``scf`` returns, which it keeps in its cache.
    """
    numbers, positions, basis, method, charge = job
    return scf(numbers, positions, basis=basis, method=method, charge=charge)


def scf_many(geometries, *, basis="6-31g", method="HF", charge=0, workers=None):
    """``scf`` of many ``(numbers, positions)`` geometries, in order, the uncached ones calculated in parallel.

    Each calculation runs on one core, so the geometries spread over ``workers`` processes, by default one per core;
    every result is kept as ``scf`` keeps it, so a later call only reads them.

    Args:
        geometries: Pairs of atomic numbers and positions, as ``scf`` takes them.
        basis: Basis set name.
        method: ``HF`` or a functional, as ``scf`` takes it.
        charge: Total charge of every geometry.
        workers: Number of worker processes; None for one per core, and 1 to calculate in this process.

    Returns:
        The orbitals of every geometry, in the order given.
    """
    jobs = [(numbers, positions, basis, method, charge) for numbers, positions in geometries]
    # Only calculations not yet kept go to the workers.
    missing = list({_kept(*job).name: job for job in jobs if not _kept(*job).exists()}.values())
    if len(missing) < 2 or workers == 1:
        return [_scf_one(job) for job in jobs]
    with ProcessPoolExecutor(workers, mp_context=multiprocessing.get_context("spawn")) as pool:
        list(pool.map(_scf_one, missing, chunksize=1))
    # The workers have kept every result; reading them back costs only the molecule setup.
    return [_scf_one(job) for job in jobs]

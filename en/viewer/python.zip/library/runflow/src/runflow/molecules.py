"""Molecules in files that are not program output: XYZ frames, and MDL SDF and Molfile records."""

from datetime import datetime
from pathlib import Path
from textwrap import dedent

import numpy as np

from .units import ATOMIC_NUMBERS, ELEMENTS, ureg


def xyz_frames(numbers, geometries, *, charge=None, multiplicity=None):
    """Serialize matching Cartesian geometries in angstrom as native XYZ frames.

    Args:
        numbers: Atomic numbers, one per atom.
        geometries: Pint array of frames by atoms by three Cartesian components, convertible to angstrom.
        charge: Total charge, written as ``charge=`` in each frame's comment line when given, so a reader such as
            the viewer's structure drawing knows it.
        multiplicity: Spin multiplicity, written as ``multiplicity=`` the same way when given.

    Returns:
        XYZ text with one frame per geometry.

    Raises:
        ValueError: An atomic number is invalid, or the geometries are not finite tables matching the atoms.
    """
    if any(int(number) != number or not 1 <= number <= len(ELEMENTS) for number in numbers):
        raise ValueError("XYZ atoms require valid integer atomic numbers.")
    symbols = [ELEMENTS[int(number) - 1] for number in numbers]
    geometries = np.asarray(geometries.to("angstrom").magnitude)
    if geometries.ndim != 3 or geometries.shape[1:] != (len(numbers), 3) or not np.isfinite(geometries).all():
        raise ValueError("Geometries must contain matching finite Cartesian atom tables.")
    # Extended-XYZ key=value pairs after the title; without them the comment line is the title alone.
    pairs = "".join(
        f" {key}={int(value)}"
        for key, value in (("charge", charge), ("multiplicity", multiplicity))
        if value is not None
    )
    template = dedent("""
        {count}
        Molecular geometry{pairs}
        {atoms}
        """).lstrip()
    frames = []
    for geometry in geometries:
        atoms = "\n".join(
            f"{symbol} {x:.9f} {y:.9f} {z:.9f}" for symbol, (x, y, z) in zip(symbols, geometry, strict=True)
        )
        frames.append(template.format(count=len(numbers), pairs=pairs, atoms=atoms))
    return frames


def _atoms_v2000(lines, counts):
    """Element symbols and coordinates of a V2000 atom block, from its counts line.

    Args:
        lines: Lines of the molfile after the counts line, the atom block first.
        counts: The counts line, whose first two fields are the atom and bond counts.

    Returns:
        The element symbols, the coordinates in angstrom as rows of x, y, z, and the bond count.
    """
    atoms = int(counts[0:3])
    rows = lines[:atoms]
    symbols = [row[31:34].strip() for row in rows]
    coordinates = [[float(row[0:10]), float(row[10:20]), float(row[20:30])] for row in rows]
    return symbols, coordinates, int(counts[3:6])


def _atoms_v3000(lines):
    """Element symbols and coordinates of a V3000 atom block, and its bond count.

    Args:
        lines: Lines of the molfile, of which those that start with M  V30 are read.

    Returns:
        The element symbols, the coordinates in angstrom as rows of x, y, z, and the bond count.
    """
    symbols, coordinates, bonds, block = [], [], 0, None
    for line in lines:
        if not line.startswith("M  V30 "):
            continue
        fields = line[7:].split()
        if fields[:2] == ["BEGIN", "ATOM"] or fields[:2] == ["BEGIN", "BOND"]:
            block = fields[1]
        elif fields[:1] == ["END"]:
            block = None
        elif fields[:1] == ["COUNTS"]:
            bonds = int(fields[2])
        elif block == "ATOM":
            symbols.append(fields[1])
            coordinates.append([float(value) for value in fields[2:5]])
    return symbols, coordinates, bonds


def read_sdf(path):
    """Every record of an SDF or Molfile: its title, atomic numbers, coordinates and SD data fields.

    Args:
        path: SDF file, records separated by ``$$$$``, or a single Molfile.

    Returns:
        One mapping per record with ``title``, ``program`` (the program that wrote it, from the header), ``written``
        (the date and time the header states, without a time zone, or None), ``dimensions``
        (``2D`` or ``3D`` when the header states them, else empty), ``comment``, ``numbers`` (atomic numbers),
        ``coordinates`` (Pint array of atoms by three Cartesian components in angstrom), ``bonds`` (count from the
        connection table) and ``properties`` (SD data fields by name, as text, lines kept).

    Raises:
        ValueError: A record has no counts line, or an element symbol is unknown.
    """
    text = Path(path).read_text(errors="replace").replace("\r\n", "\n")
    records = []
    for block in text.split("$$$$"):
        lines = block.strip("\n").split("\n")
        if len(lines) < 4 or not block.strip():
            continue
        counts = lines[3]
        if "V3000" in counts:
            symbols, coordinates, bonds = _atoms_v3000(lines[4:])
        elif "V2000" in counts or counts[:6].strip():
            symbols, coordinates, bonds = _atoms_v2000(lines[4:], counts)
        else:
            raise ValueError(f"{path}: a record has no counts line")
        try:
            numbers = [ATOMIC_NUMBERS[symbol.casefold()] for symbol in symbols]
        except KeyError as error:
            raise ValueError(f"{path}: unknown element {error.args[0]}") from None
        # SD data fields follow the connection table: a "> <name>" line, then values up to a blank line.
        properties, name = {}, None
        end = next((index for index, line in enumerate(lines) if line.startswith("M  END")), len(lines))
        for line in lines[end + 1 :]:
            if line.startswith(">"):
                start = line.find("<")
                name = line[start + 1 : line.find(">", start)] if start >= 0 else line[1:].strip()
                properties[name] = ""
            elif name is not None and line.strip():
                properties[name] = (properties[name] + "\n" + line).strip()
            elif not line.strip():
                name = None
        # The header's second line: user initials, the program name in columns 3 to 10 (OEChem pads it with
        # dashes), the date and time as MMDDYYHHmm in columns 11 to 20 and the dimensional code in columns 21 and 22.
        header = lines[1]
        try:
            written = datetime.strptime(header[10:20], "%m%d%y%H%M")
        except ValueError:
            written = None
        records.append(
            dict(
                title=lines[0].strip(),
                program=header[2:10].strip(" -"),
                written=written,
                dimensions=header[20:22] if header[20:22] in ("2D", "3D") else "",
                comment=lines[2].strip(),
                numbers=np.array(numbers),
                coordinates=ureg.Quantity(np.array(coordinates, dtype=float).reshape(-1, 3), "angstrom"),
                bonds=bonds,
                properties=properties,
            )
        )
    return records


def atom_values(text, atoms):
    """One value per atom from an SD data field written as a count line, then one ``atom value`` line per listed
    atom, as PubChem writes partial charges; atoms not listed get zero.

    Args:
        text: The field's text.
        atoms: Number of atoms in the record.

    Returns:
        Array of the values by atom, or None when the field is not written that way.
    """
    lines = [line.split() for line in text.strip().splitlines()]
    if len(lines) < 2 or len(lines[0]) != 1 or not lines[0][0].isdigit() or int(lines[0][0]) != len(lines) - 1:
        return None
    values = np.zeros(atoms)
    try:
        for atom, value in lines[1:]:
            values[int(atom) - 1] = float(value)
    except (ValueError, IndexError):
        return None
    return values

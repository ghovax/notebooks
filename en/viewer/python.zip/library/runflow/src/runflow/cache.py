"""Where runflow keeps results it can always recompute: parsed logs and calculated orbitals."""

import os
from pathlib import Path


def cache_folder(name):
    """Folder of one kind of cached result, below ``$RUNFLOW_CACHE`` or else ``~/.cache/runflow``.

    Deleting a cache folder is always safe; it only costs the time to recompute what it held.

    Args:
        name: Kind of result, such as ``parsed`` or ``orbitals``.

    Returns:
        The folder's path, which may not exist yet.
    """
    return Path(os.environ.get("RUNFLOW_CACHE") or Path.home() / ".cache/runflow") / name

"""Native number notation, line positions and item lists, as every reader of program text needs them."""

import re
import unicodedata
from bisect import bisect_left
from functools import lru_cache

NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[DEde][-+]?\d+)?"


def parse_float(value):
    """Read either native Fortran or decimal scientific notation.

    Args:
        value: Number text, such as ``0.11D+02`` or ``1.1e1``.

    Returns:
        The value as a float.
    """
    return float(value.replace("D", "E").replace("d", "e"))


@lru_cache(maxsize=8)
def _newlines(text):
    """Offsets of every newline in a text, found once per text.

    Args:
        text: Text to scan.

    Returns:
        The offsets of its newline characters, in order.
    """
    return [match.start() for match in re.finditer("\n", text)]


def line_of(text, offset):
    """One-based line number of an offset in a text.

    Counting newlines from the start for every match made parsing quadratic in the log's length, so the offsets of the
    newlines are found once and searched by bisection.

    Args:
        text: Text the offset belongs to.
        offset: Character offset in the text.

    Returns:
        The one-based line number.
    """
    return bisect_left(_newlines(text), offset) + 1


def split_items(text, separators=" \t,"):
    """Items of a list, separated outside parentheses by any of ``separators``, or by whitespace when None.

    Args:
        text: Route, option or input text.
        separators: Characters that separate items, or None for any whitespace.

    Returns:
        The items, without empty ones.
    """
    items, depth, current = [], 0, ""
    for character in text:
        depth += (character == "(") - (character == ")")
        separating = character.isspace() if separators is None else character in separators
        if separating and depth == 0:
            items.append(current)
            current = ""
        else:
            current += character
    return [item for item in items + [current] if item]


def unwrap(value):
    """A value without one pair of enclosing parentheses.

    Args:
        value: Option text.

    Returns:
        The text inside the parentheses, or the value unchanged.
    """
    return value[1:-1] if value.startswith("(") and value.endswith(")") else value


def balanced(text, start):
    """Index just past the parenthesis that closes the one at ``start``.

    Args:
        text: Text holding the parentheses.
        start: Index of an opening parenthesis.

    Returns:
        The index after its partner, or -1 when it never closes.
    """
    depth = 0
    for index in range(start, len(text)):
        depth += (text[index] == "(") - (text[index] == ")")
        if depth == 0:
            return index + 1
    return -1


def blocked_matrix(lines, start, rows=None, columns=None, symmetric=False):
    """Read native indexed matrix blocks without filling missing entries with zeros.

    Args:
        lines: Lines of the native text.
        start: Index of the first line of the blocks.
        rows: Expected number of rows, or None.
        columns: Expected number of columns, or None.
        symmetric: Whether only one triangle is printed.

    Returns:
        The matrix as nested lists with None for unprinted entries, the row labels and the index of the next line.
    """
    entries = {}
    labels = {}
    active = []
    index = start
    observed = False
    waiting = 4
    decimal = r"[-+]?(?:\d+\.\d*|\.\d+)(?:[DEde][-+]?\d+)?"
    while index < len(lines):
        line = lines[index]
        words = line.split()
        if words and all(word.isdigit() for word in words):
            active = [int(word) for word in words]
            waiting = 0
            index += 1
            continue
        row = re.match(r"^\s*(\d+)\s+", line)
        values = list(re.finditer(decimal, line[row.end() :])) if row else []
        if row and active and values:
            number = int(row[1])
            if len(values) > len(active):
                break
            for column, value in zip(active, values, strict=False):
                entries[number, column] = parse_float(value[0])
                if symmetric:
                    entries[column, number] = parse_float(value[0])
            labels[number] = line[row.end() : row.end() + values[0].start()].strip()
            observed = True
            waiting = 4
            index += 1
            continue
        if active and waiting < 3 and not row:
            waiting += 1
            index += 1
            continue
        if observed:
            break
        if not words or "Eigenvalues" in line or re.fullmatch(r"[\s()A-Za-z0-9+*.,=\-]+", line):
            index += 1
            if index - start > 6 and not observed:
                break
            continue
        break
    if not entries:
        return [], [], index
    row_count = rows or max(row for row, column in entries)
    column_count = columns or max(column for row, column in entries)
    matrix = [[entries.get((i + 1, j + 1)) for j in range(column_count)] for i in range(row_count)]
    return matrix, [labels.get(i + 1) for i in range(row_count)], index


# Symbols of names that tell them apart, spelled as words in their identifiers: 6-31+G and 6-31G, 6-31G* and 6-31G.
SYMBOL_WORDS = {"+": "plus", "*": "star"}


# Words that join or relate other words. Keys, codes and ids name things by their content words only, so a key never
# holds them: `ongoing`, not `in-progress`, and a README section id drops them from its heading.
FILLER_WORDS = frozenset(
    "a an and as at by for from in into of on or over per than the to via with within without".split()
)


def identifier(name):
    """The identifier of a name or code, shared by runflow, its readers and their data files: lower case ASCII words
    joined by hyphens, as every key of their YAML files is.

    Words are runs of letters and digits; a plus sign or star becomes a word of its own, a letter outside ASCII its
    Unicode name, such as omega, and anything else separates words. A Link 0 command's leading percent sign is dropped.
    Gaussian reads its names whatever their case, so names that differ only in case share one identifier.

    Args:
        name: A name as a program writes it, such as ``6-31+G(d,p)``, ``%Chk``, ``1/5``, ``ds_ex_vwn`` or ``Not run``.

    Returns:
        The identifier, such as ``6-31-plus-g-d-p``, ``chk``, ``1-5``, ``ds-ex-vwn`` or ``not-run``.
    """
    words = []
    for character in str(name).lstrip("%"):
        if character in SYMBOL_WORDS:
            words += ["-", SYMBOL_WORDS[character], "-"]
        elif character.isascii() and character.isalnum():
            words.append(character.lower())
        elif not character.isascii() and unicodedata.category(character).startswith("L"):
            words += ["-", unicodedata.name(character).split()[-1].lower(), "-"]
        else:
            words.append("-")
    return re.sub(r"-+", "-", "".join(words)).strip("-")

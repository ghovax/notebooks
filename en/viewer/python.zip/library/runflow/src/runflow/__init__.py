"""Read, run and check Gaussian and Lotus calculations."""

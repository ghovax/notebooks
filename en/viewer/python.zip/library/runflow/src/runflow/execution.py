"""Gaussian batch execution and selection of usable relaxed-scan samples."""

import logging
import math
import os
import re
import subprocess
from pathlib import Path

from .gaussian import read_gaussian
from .route import input_routes

LOGGER = logging.getLogger(__name__)


def select_sample(source, target):
    """Use the highest-energy intact sample, including approximate scan targets.

    The target input keeps its route, charge and connectivity; only its coordinates are replaced.

    Args:
        source: Relaxed-scan log to sample.
        target: Transition-state input whose coordinates are replaced.

    Raises:
        RuntimeError: Called outside a Slurm allocation.
        ValueError: Fewer than two intact samples, or no energy rise along the scan.
    """
    if not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("Select scan samples inside the TS Slurm allocation")
    text = source.read_text()
    template = target.read_text()
    atom_text, connectivity = template.split("0 1\n", 1)[1].split("\n\n", 1)
    bonds = []
    for line in connectivity.strip().splitlines():
        words = line.split()
        bonds.extend((int(words[0]) - 1, int(words[i]) - 1) for i in range(1, len(words), 2))
    symbols = [line.split()[0] for line in atom_text.splitlines()]
    candidates = []
    previous = 0
    for marker in re.finditer(r"Optimization (?:completed|stopped)", text):
        block = text[previous : marker.start()]
        previous = marker.end()
        tables = list(
            re.finditer(
                r"(?:Input|Standard) orientation:\s*\n\s*-+\n.*?\n.*?\n\s*-+\n(.*?)\n\s*-+",
                block,
                re.DOTALL,
            )
        )
        energies = re.findall(r"SCF Done:.*?=\s*([-+0-9.EeDd]+)", block)
        if not tables or not energies:
            continue
        xyz = [[float(v) for v in row.split()[-3:]] for row in tables[-1][1].splitlines()]
        energy = float(energies[-1].replace("D", "E"))
        if len(xyz) != len(symbols) or not math.isfinite(energy):
            continue
        # Reject fragmented geometries before choosing the sampled maximum.
        if any(not 0.5 < math.dist(xyz[a], xyz[b]) < 2.5 for a, b in bonds):
            continue
        candidates.append((energy, xyz, marker[0] == "Optimization completed"))
    if len(candidates) < 2:
        raise ValueError("The scan has fewer than two intact samples; assess before TS refinement")
    energy, xyz, converged = max(candidates, key=lambda sample: sample[0])
    if energy <= candidates[0][0] + 1e-6:
        raise ValueError("No sampled energy rise was obtained; assess the scan before TS refinement")
    coordinates = "\n".join(f"{symbol} " + " ".join(f"{v:.10f}" for v in row) for symbol, row in zip(symbols, xyz))
    # Replace coordinates while retaining the route, charge and explicit connectivity.
    target.write_text(template.split("0 1\n", 1)[0] + "0 1\n" + coordinates + "\n\n" + connectivity)
    LOGGER.info(
        "Selected TS starting geometry",
        extra={
            # Scientific or execution fields appended to the log message.
            "metadata": {
                # Selected scan-sample electronic energy in hartree.
                "sample_energy": energy,  # Hartree.
                # Whether the selected scan target printed optimization completion.
                "sample_converged": converged,
                # Number of intact candidate scan samples passing geometry screening.
                "usable_samples": len(candidates),
            }
        },
    )


def gaussian_environment(*, memory=None):
    """Process environment with the vendor Gaussian profile applied.

    Args:
        memory: Gaussian's default memory (GAUSS_MEMDEF), for utilities such as cubegen, or None.

    Returns:
        Environment mapping for subprocesses.
    """
    environment = os.environ.copy()
    environment["g16root"] = "/opt"
    # Read the vendor profile as NUL-separated variables to preserve shell values.
    profile = subprocess.run(
        ["bash", "-c", "source /opt/g16/bsd/g16.profile >/dev/null; env -0"],
        env=environment,
        capture_output=True,
        check=True,
    )
    for item in profile.stdout.split(b"\0"):
        if b"=" in item:
            key, value = item.split(b"=", 1)
            environment[os.fsdecode(key)] = os.fsdecode(value)
    if memory:
        environment["GAUSS_MEMDEF"] = memory
    return environment


def execute_gaussian(run, name, *, scratch, expected_jobs=None, cwd=None, memory=None):
    """Run ``inputs/<name>.gjf`` into ``logs/<name>.log`` and check SCF convergence and normal termination.

    Args:
        run: Run folder.
        name: Input name, without extension.
        scratch: Folder for Gaussian's scratch files.
        expected_jobs: Required number of normal terminations, one per linked job; None requires at least one.
        cwd: Folder Gaussian runs in, where relative checkpoint paths resolve; the run folder by default.
        memory: Gaussian's default memory, or None.

    Returns:
        The native log text and the parsed linked jobs.

    Raises:
        FileExistsError: The log already exists.
        ValueError: An SCF did not converge.
        RuntimeError: A linked job did not terminate normally.
    """
    run = Path(run)
    source = run / "inputs" / f"{name}.gjf"
    output = run / "logs" / f"{name}.log"
    if output.exists():
        raise FileExistsError(f"Output already exists: {output}")
    environment = gaussian_environment(memory=memory)
    environment["GAUSS_SCRDIR"] = str(scratch)
    LOGGER.info(
        "Calculation started",
        extra={
            # Scientific or execution fields appended to the log message.
            "metadata": {
                # Native route of each linked job in the input.
                "routes": input_routes(source.read_text()),
                # Calculation input path.
                "input": str(source),
            }
        },
    )
    with source.open("rb") as stream, output.open("xb") as destination:
        subprocess.run(
            ["/opt/g16/g16"],
            cwd=cwd or run,
            env=environment,
            stdin=stream,
            stdout=destination,
            stderr=subprocess.STDOUT,
            check=True,
        )
    text = output.read_text()
    result = read_gaussian(output, expected_jobs=expected_jobs)
    jobs = result["jobs"]
    if any(not entry["converged"] for job in jobs for entry in job["scf_history"]):
        raise ValueError("Gaussian reported an unconverged SCF solution; inspect the native convergence messages")
    # Completion is judged per linked job; Opt combined with Freq prints two terminations for one job.
    if "Error termination" in text or result["status"]["state"] != "complete":
        raise RuntimeError("Gaussian did not terminate normally in every linked job; inspect its native output")
    return text, jobs


def formchk(checkpoint, log):
    """Convert a binary checkpoint into the formatted ``.fchk`` beside it.

    Args:
        checkpoint: Binary checkpoint (``.chk``).
        log: Open text stream for the utility's output.

    Returns:
        Path of the formatted checkpoint.
    """
    checkpoint = Path(checkpoint)
    formatted = checkpoint.with_suffix(".fchk")
    subprocess.run(
        ["/opt/g16/formchk", "-3", str(checkpoint), str(formatted)],
        env=gaussian_environment(),
        stdout=log,
        stderr=subprocess.STDOUT,
        check=True,
    )
    return formatted

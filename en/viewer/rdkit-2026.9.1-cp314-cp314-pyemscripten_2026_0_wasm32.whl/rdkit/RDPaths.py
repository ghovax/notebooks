import os
# unset so to trigger exceptions and track use: RDBaseDir=os.environ['RDBASE']
RDCodeDir=os.path.join(r'/Users/giovannigravili/.cache/researchsite/pyodide-wheels/work/rdkit/rdkit-install/lib/python3.14/site-packages','rdkit')
# not really hard-coded alternative RDCodeDir=os.path.dirname(__file__)
_share = os.path.join(r'/Users/giovannigravili/.cache/researchsite/pyodide-wheels/work/rdkit/rdkit-install', r'share/RDKit')
RDDataDir=os.path.join(_share,'Data')
RDDocsDir=os.path.join(_share,'Docs')
RDProjDir=os.path.join(_share,'Projects')
RDContribDir=os.path.join(_share,'Contrib')

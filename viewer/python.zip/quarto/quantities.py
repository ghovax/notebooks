"""Quantities shown in table headers and plot axes, by identifier, from quarto/quantities.yaml.

``quantity(identifier)`` gives the quantity's label, a string that carries its explanation, so tables and plots that
show the label can offer the explanation in a hover popover without looking it up by its text.
"""
from fractions import Fraction
from functools import lru_cache
from pathlib import Path
import re

import yaml
from runflow.checkpoints import ureg


class Quantity(str):
    """A rendered label, Markdown with $...$ LaTeX, with the explanation of the quantity it names."""

    def __new__(cls, label, description):
        value = super().__new__(cls, label)
        value.description = description
        return value

    def __reduce__(self):
        return Quantity, (str(self), self.description)


@lru_cache(maxsize=None)
def unit_latex(unit):
    """Format Pint units in their specified order with negative powers and thin spaces."""
    components = list(ureg.Unit(unit)._units.items())
    components.sort(key=lambda pair: pair[1] < 0)
    parts = []
    for name, exponent in components:
        symbol = format(ureg.Unit(name), "~L")
        symbol = (symbol.replace(r"\mathrm{a\_0}", "a_0").replace(r"\mathrm{E\_h}", "E_h")
                  .replace(r"\mathrm{Å}", r"\mathrm{\AA}").replace(r"\mathrm{l}", r"\mathrm{L}")
                  .replace(r"\mathrm{deg}", r"{}^\circ"))
        power = Fraction(exponent).limit_denominator(1000)
        if power != 1:
            exponent_text = str(power.numerator) if power.denominator == 1 else rf"\frac{{{power.numerator}}}{{{power.denominator}}}"
            symbol += rf"^{{{exponent_text}}}"
        parts.append(symbol)
    return r"\,".join(parts) or "1"


def resolve_units(text):
    """Replace unit tokens in generated prose with Pint-formatted LaTeX."""
    return re.sub(r"@unit\(([^()]*)\)@", lambda match: unit_latex(match[1]), text)


def unit_label(label, unit):
    """Append a Pint-formatted unit to a mathematical or plain-text label."""
    formatted = unit_latex(unit)
    return (label[:-1] + rf"\;[{formatted}]$" if label.endswith("$")
            else label + rf" $[{formatted}]$")


def scientific_latex(mantissa, exponent):
    """One ordinary math atom containing the complete scientific number."""
    return rf"$\mathord{{{mantissa}\times 10^{{{int(exponent)}}}}}$"


@lru_cache(maxsize=1)
def _quantities():
    """The quantities file beside this module, by identifier."""
    entries = yaml.safe_load(Path(__file__).with_name("quantities.yaml").read_text())
    for entry in entries.values():
        if unit := entry.get("unit"):
            entry["label"] = unit_label(entry["label"], unit)
        entry["description"] = resolve_units(entry["description"])
    return entries


def quantity(identifier):
    """The label of a quantity, carrying its explanation.

    Raises:
        KeyError: quarto/quantities.yaml has no quantity of this identifier.
    """
    entry = _quantities()[identifier]
    return Quantity(entry["label"], entry["description"])

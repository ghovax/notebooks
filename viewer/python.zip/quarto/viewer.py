"""Render dropped calculation files as calculation-page sections, for the viewer page in the browser.

The viewer page (quarto/viewer/index.qmd) runs this module in Pyodide, a Python running in the visitor's browser, on
the files they drop; nothing leaves the browser. Each Gaussian or Lotus log, with the inputs and formatted checkpoints that
belong to it, becomes a run folder in Pyodide's in-memory file system, is read with
quarto/calculations.py and is shown through the same sections as the calculation pages, from quarto/sections.py.

Quarto cannot run in a browser, so this module plays its part for those sections: it executes their Python cells and
converts their Markdown into the HTML Quarto writes for the calculation pages, with Pandoc's section identifiers,
Bootstrap tables, KaTeX math spans, fold sections and Jupyter widget views with their embedded state. The same code runs
under CPython, which is how it is tested against the rendered pages.
"""
import base64
import hashlib
import html
import json
import lzma
import re
import shutil
import sys
import traceback
from pathlib import Path

import sourcetypes

QUARTO = Path(__file__).resolve().parent
sys.path.insert(0, str(QUARTO))

import ipywidgets  # noqa: E402
import IPython.core.display_functions  # noqa: E402
import IPython.display  # noqa: E402
from ipywidgets.embed import embed_data  # noqa: E402
from markdown_it import MarkdownIt  # noqa: E402
from mdit_py_plugins.attrs import attrs_plugin  # noqa: E402
from mdit_py_plugins.dollarmath import dollarmath_plugin  # noqa: E402

from calculations import Calculation, StructureFile, _parsed  # noqa: E402
import altair  # noqa: E402

# Charts are written to the page without validating their specification against Vega-Lite's schema, which takes
# about as long as building them; they come from the same code as the calculation pages, where it is validated.
_to_dict = altair.TopLevelMixin.to_dict
altair.TopLevelMixin.to_dict = lambda self, validate=False, **options: _to_dict(self, validate, **options)
from runflow.structures import read_gaussian_input  # noqa: E402
from sections import calculation_body, checkpoint_section, input_body, input_output_tabs, prelude, structures_section  # noqa: E402
from status_cards import findings_table, status_callout  # noqa: E402

# Status icons of the tables, beside the quarto folder as projects/icons is beside it in the research checkout;
# inlined as data URIs, as quarto/render.py inlines them in the calculation pages.
ICONS = QUARTO.parent / "projects/icons"
# Shared Python helpers of every page: scientific_table, register_plot_labels and display_chart.
FORMATTING = re.search(r"```\{python\}\n(.*?)```", (QUARTO / "formatting.qmd").read_text(), re.S)[1]

# Raw HTML blocks of the Markdown, as the subtables of scientific_table write them.
RAW = re.compile(r"^```\{=html\}\n(.*?)\n```$", re.S | re.M)
# Python cells of the sections, as sections.cell writes them.
CELL = re.compile(r"^```\{python\}\n(.*?)\n```$", re.S | re.M)
HEADING = re.compile(r"^(#{1,6}) (.+?)\s*$")
DIV_OPEN = re.compile(r"^:{3,}\s*\{(.*)\}\s*$")
DIV_CLOSE = re.compile(r"^:{3,}\s*$")


def _markdown():
    """Pandoc-like Markdown: pipe tables, raw HTML, $...$ math as KaTeX spans and {.class} attributes."""
    # Pandoc's smart extension curls quotes; markdown-it's other typographic replacements stay off.
    parser = MarkdownIt("commonmark", {"html": True, "typographer": True}).enable(["table", "smartquotes"])
    parser.use(dollarmath_plugin, double_inline=True)
    parser.use(attrs_plugin, spans=True)

    def math(display):
        """Quarto's math span, which the page's KaTeX typesets."""
        kind = "display" if display else "inline"
        return lambda self, tokens, index, options, env: (
            f'<span class="math {kind}">{html.escape(tokens[index].content, quote=False)}</span>')

    parser.add_render_rule("math_inline", math(False))
    parser.add_render_rule("math_inline_double", math(True))
    def math_block(self, tokens, index, options, env):
        """A display formula in its own paragraph."""
        markup: sourcetypes.html = f"""<p>{math(True)(self, tokens, index, options, env)}</p>
"""
        return markup

    parser.add_render_rule("math_block", math_block)

    # Tables as Pandoc and Quarto write them: Bootstrap's table class, a header row class and striped body rows;
    # Quarto makes the tables of cell outputs small and striped.
    def table_open(self, tokens, index, options, env):
        env["row"] = 0
        markup: sourcetypes.html = f"""<table class="caption-top table{" table-sm table-striped small" if env.get("cell") else ""}">
"""
        return markup

    def row_open(self, tokens, index, options, env):
        if any(token.type == "thead_open" for token in tokens[max(0, index - 1):index]):
            return '<tr class="header">\n'
        env["row"] = env.get("row", 0) + 1
        return f'<tr class="{"odd" if env["row"] % 2 else "even"}">\n'

    def cell_open(self, tokens, index, options, env):
        token = tokens[index]
        style = token.attrGet("style") or ""
        alignment = style.removeprefix("text-align:")
        attributes = f' style="text-align: {alignment};"' if alignment else ""
        return f"<{token.tag}{attributes}>"

    parser.add_render_rule("table_open", table_open)
    parser.add_render_rule("tr_open", row_open)
    parser.add_render_rule("th_open", cell_open)
    parser.add_render_rule("td_open", cell_open)
    return parser


MARKDOWN = _markdown()


def _icon_uri(match):
    """A status icon's path as a data URI."""
    data = base64.b64encode((ICONS / match[2]).read_bytes()).decode()
    return f'{match[1]}"data:image/svg+xml;base64,{data}"'


def _attributes(text):
    """HTML attributes of a Pandoc attribute block such as ``.fold #id key="value"``."""
    classes, parts = [], []
    for item in re.findall(r'[.#]?[\w-]+(?:="[^"]*")?', text):
        if item.startswith("."):
            classes.append(item[1:])
        elif item.startswith("#"):
            parts.append(f'id="{item[1:]}"')
        else:
            parts.append(item)
    return " ".join(([f'class="{" ".join(classes)}"'] if classes else []) + parts)


def markdown_html(text, cell=False):
    """HTML of Markdown without headings, as Pandoc writes it: fenced divs, raw HTML blocks and the Markdown that
    scientific_table leaves in the data-qmd-base64 attributes of subtable cells; ``cell`` marks a cell's output."""
    raws = []

    def keep(match):
        raws.append(match[1])
        markup: sourcetypes.html = f"""
<!--raw-{len(raws) - 1}-->
"""
        return markup

    text = RAW.sub(keep, text)
    lines, divs = [], []
    for line in text.splitlines():
        if opening := DIV_OPEN.match(line):
            kind = re.search(r"\.callout-(\w+)", opening[1])
            if kind:
                # A callout div as Quarto writes it, its title in the header.
                title = re.search(r'title="([^"]*)"', opening[1])
                classes = " ".join(item[1:] for item in opening[1].split() if item.startswith(".status-"))
                header: sourcetypes.html = f"""<div class="callout callout-style-default callout-{kind[1]} callout-titled {classes}">
<div class="callout-header d-flex align-content-center">
<div class="callout-icon-container">
<i class="callout-icon"></i>
</div>
<div class="callout-title-container flex-fill">
{html.escape(title[1]) if title else kind[1].capitalize()}
</div>
</div>
<div class="callout-body-container callout-body">"""
                lines += ["", header, ""]
                divs.append("</div>\n</div>")
            else:
                lines += ["", f"<div {_attributes(opening[1])}>", ""]
                divs.append("</div>")
        elif DIV_CLOSE.match(line):
            lines += ["", divs.pop() if divs else "</div>", ""]
        else:
            lines.append(line)
    result = MARKDOWN.render("\n".join(lines), {"cell": cell})
    result = re.sub(r"<!--raw-(\d+)-->", lambda match: raws[int(match[1])], result)
    # Quarto turns raw HTML tables into its own tables, with the classes of the tables around them.
    table: sourcetypes.html = f"""<table class="subtables caption-top table{" table-sm table-striped small" if cell else ""}">"""
    result = result.replace('<table class="subtables">', table)
    # Quarto parses Markdown from a qmd attribute and puts the result in its place.
    result = re.sub(r'<div data-qmd-base64="([^"]*)"></div>',
                    lambda match: MARKDOWN.renderInline(base64.b64decode(match[1]).decode()), result)
    return re.sub(r'(src=)"icons/([\w-]+\.svg)"', _icon_uri, result)


def pandoc_identifier(text):
    """Pandoc's automatic identifier of a heading's text."""
    # Formatting marks go, link and math text stays; underscores stay, as Pandoc keeps them.
    plain = re.sub(r"[`*]|\[([^\]]*)\]\([^)]*\)|\$([^$]*)\$", lambda match: match[1] or match[2] or "", text)
    plain = re.sub(r"\{[^}]*\}$", "", plain).lower()
    plain = re.sub(r"[^\w\s.-]", "", plain)
    plain = re.sub(r"\s+", "-", plain.strip())
    plain = re.sub(r"^[^a-z]+", "", plain)
    return plain or "section"


def title_identifier(text):
    """A heading's identifier as Wikipedia makes it: its plain text as written, spaces as underscores, such as
    ``Lotus_input``; formatting marks go, link and math text stays."""
    plain = re.sub(r"[`*]|\[([^\]]*)\]\([^)]*\)|\$([^$]*)\$", lambda match: match[1] or match[2] or "", text)
    plain = re.sub(r"\{[^}]*\}$", "", plain)
    plain = re.sub(r"[^\w\s.()-]", "", plain)
    return re.sub(r"\s+", "_", plain.strip()) or "Section"


def document_html(text, prefix, shift=0):
    """HTML of a Markdown document as Quarto writes it, every heading opening a section with Pandoc's identifier.

    Identifiers and the links to them gain ``prefix``, so several calculations share one page, and headings move
    ``shift`` levels down. A fold div that opens with a heading becomes that heading's section, as Pandoc makes it.
    Returns the HTML and the table of contents as (level, identifier, heading HTML).
    """
    raws = []

    def keep(match):
        raws.append(match[0])
        return f"<!--block-{len(raws) - 1}-->"

    # Raw blocks may hold lines that look like headings or fences.
    text = RAW.sub(keep, text)
    blocks, buffer, divs, pending_fold = [], [], [], False
    for line in text.splitlines():
        heading = HEADING.match(line)
        opening = DIV_OPEN.match(line)
        if opening and ".fold" in opening[1].split():
            pending_fold = True
            divs.append("section")
            continue
        if opening:
            divs.append("div")
        elif DIV_CLOSE.match(line) and divs:
            if divs.pop() == "section":
                continue
        if heading:
            blocks.append(("text", "\n".join(buffer)))
            buffer = []
            blocks.append(("heading", len(heading[1]) + shift, heading[2], pending_fold))
            pending_fold = False
            continue
        buffer.append(line)
    blocks.append(("text", "\n".join(buffer)))

    seen, toc, parts, open_levels = {}, [], [], []
    restore = lambda value: re.sub(r"<!--block-(\d+)-->", lambda match: raws[int(match[1])], value)
    for block in blocks:
        if block[0] == "text":
            if block[1].strip():
                parts.append(markdown_html(restore(block[1])))
            continue
        _, level, title, fold = block
        attributes = re.search(r"\{([^}]*)\}$", title)
        explicit = re.search(r"#([\w-]+)", attributes[1]) if attributes else None
        # Classes of the heading's attributes go on its section, as Pandoc puts them.
        classes = "".join(f" {item[1:]}" for item in attributes[1].split() if item.startswith(".")) if attributes else ""
        title = re.sub(r"\s*\{[^}]*\}$", "", title)
        identifier = explicit[1] if explicit else title_identifier(title)
        # A repeated title, as each step's sections, is numbered from its second occurrence: Link_0_commands_2.
        seen[identifier] = seen.get(identifier, 0) + 1
        if seen[identifier] > 1:
            identifier += f"_{seen[identifier]}"
        identifier = prefix + identifier
        while open_levels and open_levels[-1] >= level:
            parts.append("</section>\n")
            open_levels.pop()
        heading_html = MARKDOWN.renderInline(title)
        markup: sourcetypes.html = f"""<section id="{identifier}" class="level{level}{" fold" if fold else ""}{classes}">
<h{level} class="anchored" data-anchor-id="{identifier}">{heading_html}</h{level}>
"""
        parts.append(markup)
        open_levels.append(level)
        toc.append((level, identifier, heading_html))
    parts += ["</section>\n"] * len(open_levels)
    page = "".join(parts)
    # Links within the calculation reach its own prefixed sections.
    page = re.sub(r'href="#([^"]+)"', lambda match: f'href="#{prefix}{match[1]}"', page)
    return page, toc


def callout(kind, title, text):
    """A Quarto callout of ``kind`` (note, warning, important) with a title and Markdown text."""
    markup: sourcetypes.html = f"""<div class="callout callout-style-default callout-{kind} callout-titled">
<div class="callout-header d-flex align-content-center">
<div class="callout-icon-container">
<i class="callout-icon"></i>
</div>
<div class="callout-title-container flex-fill">
{html.escape(title)}
</div>
</div>
<div class="callout-body-container callout-body">
{markdown_html(text)}</div>
</div>
"""
    return markup


class Notebook:
    """Executes the Python cells of a page's Markdown and puts their outputs in its place, as Quarto does."""

    def __init__(self):
        self.namespace = {"__name__": "__viewer__"}
        self.outputs = []
        self.widgets = []
        self.capture = self.outputs.append
        for module in (IPython.display, IPython.core.display_functions):
            module.display = self.display
        exec(FORMATTING, self.namespace)

    def display(self, *objects, **_):
        """IPython's display, collecting each object for the running cell."""
        self.outputs.extend(objects)

    def output(self, item):
        """One displayed object as Quarto's cell output HTML."""
        if isinstance(item, ipywidgets.Widget):
            self.widgets.append(item)
            markup: sourcetypes.html = f"""<div class="cell-output cell-output-display">
<!--widget-{len(self.widgets) - 1}-->
</div>
"""
            return markup
        if isinstance(item, IPython.display.Markdown):
            markup: sourcetypes.html = f"""<div class="cell-output cell-output-display cell-output-markdown">
{markdown_html(item.data, cell=True)}</div>
"""
            return markup
        if isinstance(item, IPython.display.HTML) or hasattr(item, "_repr_html_"):
            content = item.data if isinstance(item, IPython.display.HTML) else item._repr_html_()
            markup: sourcetypes.html = f"""<div class="cell-output cell-output-display">
{content}
</div>
"""
            return markup
        markup: sourcetypes.html = f"""<div class="cell-output cell-output-stdout">
<pre><code>{html.escape(str(item))}</code></pre>
</div>
"""
        return markup

    def run(self, text):
        """The Markdown with every Python cell replaced by its outputs, as raw HTML blocks; a failing cell shows a
        warning callout instead."""
        def execute(match):
            self.outputs.clear()
            try:
                exec(match[1], self.namespace)
                content = "".join(self.output(item) for item in list(self.outputs))
            except Exception as error:
                content = callout("warning", "This part could not be shown",
                                  f"Reading it raised `{type(error).__name__}: {error}`.")
                traceback.print_exc()
            text: sourcetypes.markdown = f"""```{{=html}}
<div class="cell">
{content}</div>
```"""
            return text

        return CELL.sub(execute, text)

    def widget_html(self, page):
        """The page with each widget's view and, once, the state of every widget it uses, as the Jupyter widget
        embedder reads them."""
        if not self.widgets:
            return page
        # The full state, as Jupyter stores it in a notebook: the embedder needs every view name and module, and
        # anywidget its code, all of which equal their defaults.
        data = embed_data(views=self.widgets, drop_defaults=False)
        views = [json.dumps(view).replace("</", "<\\/") for view in data["view_specs"]]
        def view(match):
            """The view of one widget, where the cell displayed it."""
            markup: sourcetypes.html = f"""<script type="application/vnd.jupyter.widget-view+json">
{views[int(match[1])]}
</script>"""
            return markup

        page = re.sub(r"<!--widget-(\d+)-->", view, page)
        state = json.dumps(data["manager_state"]).replace("</", "<\\/")
        ipywidgets.Widget.close_all()
        markup: sourcetypes.html = f"""<script type="application/vnd.jupyter.widget-state+json">
{state}
</script>
"""
        return page + markup


def kind(path):
    """What a dropped file is: gaussian, lotus, input, xyz, fchk, chk, sdf or None."""
    suffix = path.suffix.lower()
    if suffix in (".log", ".out"):
        with open(path, "rb") as stream:
            head = stream.read(65536).decode(errors="replace")
        if "Entering Gaussian System" in head or "Gaussian, Inc." in head:
            return "gaussian"
        if "DFT.pyx" in head or "scf_r, n_scf" in head:
            return "lotus"
        return None
    return {".gjf": "input", ".com": "input", ".xyz": "xyz", ".fchk": "fchk", ".fch": "fchk", ".chk": "chk",
            ".sdf": "sdf", ".mol": "sdf"}.get(suffix)


# What each kind of file is read as, and why an unread one is not.
ROLES = {"gaussian": "Gaussian log", "lotus": "Lotus log", "input": "Gaussian input", "xyz": "Lotus input",
         "fchk": "Formatted checkpoint", "sdf": "Structure file"}
UNREAD = {"chk": "A binary checkpoint is read only through `formchk`; drop its formatted checkpoint (`.fchk`) instead.",
          None: "Not a Gaussian, Lotus or structure file the viewer reads."}
# Brief descriptions of files not read, for the files table; the reasons above go in the page's warning.
UNREAD_KINDS = {"chk": "Binary checkpoint", None: "Unrecognised file"}


def _checkpoint_names(log):
    """Stems of the checkpoints a Gaussian log's jobs name in %chk and %oldchk."""
    names = set()
    for job in _parsed("gaussian", log)["jobs"]:
        for key, value in job["links"][0]["commands"].items():
            if key.lower() in ("%chk", "%oldchk"):
                names.add(Path(value).stem)
    return names


def group(drop, paths):
    """Group logs, inputs and checkpoints within their calculation folder without ambiguous associations."""
    def scope(relative):
        """Folder containing a run, whether files are loose or in its role-specific subfolders."""
        parent = Path(relative).parent
        return parent.parent if parent.name.lower() in ("logs", "inputs", "checkpoints") else parent

    kinds = {relative: kind(drop / relative) for relative in paths}
    logs = [relative for relative, value in kinds.items() if value in ("gaussian", "lotus")]
    calculations, roles, named, unread = {}, {}, {}, {}

    def name_checkpoints(owner, names):
        """Record the checkpoint names referenced by a calculation in its own folder."""
        for name in names:
            named.setdefault((scope(owner), name), set()).add(owner)

    for relative in logs:
        calculations[relative] = {"log": drop / relative, "kind": kinds[relative], "inputs": [], "checkpoints": []}
        roles[relative] = ROLES[kinds[relative]]
        if kinds[relative] == "gaussian":
            try:
                name_checkpoints(relative, _checkpoint_names(drop / relative))
            except Exception:
                pass
    inputs = [relative for relative, value in kinds.items() if value in ("input", "xyz")]
    for relative in inputs:
        value, path = kinds[relative], Path(relative)
        candidates = [log for log in logs if scope(log) == scope(relative)
                      and kinds[log] == ("gaussian" if value == "input" else "lotus")]
        same_name = [log for log in candidates if Path(log).stem == path.stem]
        owner = same_name[0] if len(same_name) == 1 else None
        if not same_name and value == "xyz" and len(candidates) == 1:
            nearby = [item for item in inputs if kinds[item] == "xyz" and scope(item) == scope(relative)]
            if len(nearby) == 1:
                owner = candidates[0]
        if owner:
            calculations[owner]["inputs"].append(drop / relative)
            roles[relative] = f"{ROLES[value]} of `{owner}`"
            continue
        calculations[relative] = {"inputs": [drop / relative], "checkpoints": []}
        roles[relative] = ROLES[value]
        if value == "input":
            try:
                names = [Path(name).stem for job in read_gaussian_input(drop / relative)
                         for key, name in job["links"][0]["commands"].items() if key.lower() in ("%chk", "%oldchk")]
                name_checkpoints(relative, names)
            except Exception:
                pass
    for relative, value in kinds.items():
        if relative in roles:
            continue
        path = Path(relative)
        owners = named.get((scope(relative), path.stem), set()) if value == "fchk" else set()
        if len(owners) == 1:
            owner = next(iter(owners))
            calculations[owner]["checkpoints"].append(drop / relative)
            roles[relative] = f"{ROLES[value]} of `{owner}`"
        elif value in ("fchk", "sdf"):
            calculations[relative] = {"checkpoints" if value == "fchk" else "structures": [drop / relative]}
            roles[relative] = ROLES[value]
        else:
            roles[relative] = UNREAD_KINDS[value]
            unread[relative] = UNREAD[value]
    return dict(sorted(calculations.items())), roles, unread


def _folder(runs, key, files):
    """The run folder of one calculation in ``runs``, made from its dropped files; returns it with its log, or
    None."""
    folder = runs / hashlib.sha256(key.encode()).hexdigest()[:16]
    shutil.rmtree(folder, ignore_errors=True)
    for name in ("inputs", "logs", "checkpoints"):
        (folder / name).mkdir(parents=True)
    # Calculation's title: the file's name.
    title: sourcetypes.markdown = f"""# `{Path(key).name}`
"""
    (folder / "README.md").write_text(title)
    for path in files.get("inputs", []):
        suffix = ".gjf" if path.suffix.lower() in (".gjf", ".com") else path.suffix
        shutil.copy(path, folder / "inputs" / (path.stem + suffix))
    for path in files.get("checkpoints", []):
        shutil.copy(path, folder / "checkpoints" / (path.stem + ".fchk"))
    for path in files.get("structures", []):
        shutil.copy(path, folder / "inputs" / path.name)
    log = None
    if "log" in files:
        # Lotus logs are recognised by their name.
        log = folder / "logs" / ("lotus.log" if files["kind"] == "lotus" else files["log"].name)
        shutil.copy(files["log"], log)
    return folder, log


def _signature(files):
    """Digest of a calculation's files, so an unchanged calculation keeps its rendered section."""
    digest = hashlib.sha256()
    for path in sorted([files.get("log"), *files.get("inputs", []), *files.get("checkpoints", []),
                        *files.get("structures", [])], key=str):
        if path and path.is_file():
            digest.update(str(path).encode() + path.read_bytes())
    return digest.hexdigest()


RENDERED = {}


# A part of a notebook left out for a missing file, as sections.missing_checkpoint writes it.
MISSING = re.compile(r"The (.+?) (?:are drawn from|require) (.+?), which is not available\.")


def render(runs, key, files, prefix):
    """One calculation's section: its title heading, status and the calculation page's sections, its table of
    contents, and what it could not show: each part left out for a missing file, or why it could not be read."""
    folder, log = _folder(runs, key, files)
    notebook = Notebook()
    try:
        calculation = Calculation(folder, log)
    except Exception as error:
        traceback.print_exc()
        message = callout("warning", "This file could not be read", f"Reading it raised `{type(error).__name__}: {error}`.")
        text: sourcetypes.markdown = f"""# `{Path(key).name}`

```{{=html}}
{message}```
"""
        return (*document_html(text, prefix, shift=1), {"error": f"It could not be read: {type(error).__name__}: {error}."})
    arguments = f"{str(folder)!r}" + (f", {str(log)!r}" if log else "")
    locate = lambda path: f"Path({str(path)!r})"
    # The title heads the calculation's section, one level above the calculation page's own sections.
    head: sourcetypes.markdown = f"""# {calculation.title}

"""
    if "structures" in files:
        # A structure file on its own.
        structure = folder / "inputs" / files["structures"][0].name
        body = prelude(str(QUARTO), arguments, "icons/") + structures_section(StructureFile(structure), locate)
    elif calculation.result is None and files.get("inputs"):
        # An input on its own, with the formatted checkpoints its jobs name.
        outputs = checkpoint_section(calculation.checkpoint_files(), locate, level="###")
        body = prelude(str(QUARTO), arguments, "icons/") + input_body(calculation, outputs)
    elif calculation.result is None:
        # A formatted checkpoint on its own.
        outputs = checkpoint_section(calculation.checkpoint_files(), locate, level="###")
        body = prelude(str(QUARTO), arguments, "icons/") + input_output_tabs("", outputs)
    else:
        head += status_callout(calculation.status(), findings_table(calculation.findings(), "icons/")) + "\n"
        body = prelude(str(QUARTO), arguments, "icons/") + calculation_body(calculation, locate, "icons/")
    page, toc = document_html(notebook.run(head + body), prefix, shift=1)
    # Each part left out, and the file it needs, in the notebook's own words.
    missing = [{"part": part[0].upper() + part[1:], "needs": needs[0].upper() + needs[1:]} for part, needs in MISSING.findall(body)]
    return notebook.widget_html(page), toc, {"missing": missing}


# A shared state's format: a four-byte header length and the header, plain JSON listing each file's
# path, time added in milliseconds and size, so the page can list the files before Python starts; then LZMA2 of the
# files' contents one after another.
SHARE_FILTERS = [{"id": lzma.FILTER_LZMA2, "preset": 9 | lzma.PRESET_EXTREME}]
# The most a share's files may add up to, so a small crafted share cannot expand to fill the browser's memory.
SHARE_UNPACKED = 256 * 1024 * 1024


def pack(drop, entries):
    """The dropped files at their ``[path, time added]`` entries, relative to the ``drop`` folder, as one compressed
    share."""
    contents = [(Path(drop) / path).read_bytes() for path, _ in entries]
    header = json.dumps([[path, time, len(content)] for (path, time), content in zip(entries, contents)],
                        separators=(",", ":")).encode()
    return (len(header).to_bytes(4, "big") + header
            + lzma.compress(b"".join(contents), format=lzma.FORMAT_RAW, filters=SHARE_FILTERS))


def unpack(data):
    """The files of a share made by ``pack``, as ``[path, time added, content]``.

    A share comes from whoever made the link, so it is checked before anything is written: its files add up to at
    most ``SHARE_UNPACKED`` bytes, its contents unpack to exactly the sizes its header lists, and every path is a
    plain relative one, so no file can land outside the drop folder, over the viewer's own sources.

    Raises:
        ValueError: The share is too large or malformed.
    """
    data = bytes(data)
    length = int.from_bytes(data[:4], "big")
    try:
        entries = [(str(path), int(time), int(size)) for path, time, size in json.loads(data[4:4 + length])]
    except (ValueError, TypeError):
        raise ValueError("This link's files are malformed.") from None
    total = sum(size for _, _, size in entries)
    if total > SHARE_UNPACKED or any(size < 0 for _, _, size in entries):
        raise ValueError("This link's files are too large to open.")
    for path, _, _ in entries:
        if not path or path.startswith("/") or "\\" in path or any(part in ("", ".", "..") for part in path.split("/")):
            raise ValueError(f"This link names a file outside its folder: {path}")
    decompressor = lzma.LZMADecompressor(format=lzma.FORMAT_RAW, filters=SHARE_FILTERS)
    blob = decompressor.decompress(data[4 + length:], max_length=total + 1)
    if len(blob) != total or not decompressor.eof:
        raise ValueError("This link's files are malformed.")
    files, offset = [], 0
    for path, time, size in entries:
        files.append([path, time, blob[offset:offset + size]])
        offset += size
    return files


def set_zone(name):
    """Show times in the time zone of the given IANA name, the visitor's; the calculation pages keep their own."""
    from zoneinfo import ZoneInfo
    import calculations
    try:
        calculations.ZONE = ZoneInfo(name)
    except Exception:
        pass  # A zone the browser names but the time-zone database lacks keeps the default.


def update(drop, paths, progress=None):
    """Every calculation of the files dropped into the ``drop`` folder, at their relative ``paths``, rendered or
    reused: the files' roles, the reasons files were not read, and per calculation its key, signature, section HTML, table of contents and what it could not show,
    in page order. Run folders are made beside the drop folder. ``progress`` is called with each calculation to render and
    its state: pending for all of them first, then running and done for each in turn."""
    drop = Path(drop)
    runs = drop.with_name(drop.name + "-runs")
    calculations, roles, unread = group(drop, paths)
    signatures = {key: _signature(files) for key, files in calculations.items()}
    todo = [key for key in calculations if RENDERED.get(key, (None,))[0] != signatures[key]]
    for key in todo:
        if progress:
            progress(key, "pending")
    for key in todo:
        if progress:
            progress(key, "running")
        # Distinct calculations can have the same section and tab names on one page.
        prefix = "calculation-" + hashlib.sha256(key.encode()).hexdigest()[:16] + "-"
        RENDERED[key] = (signatures[key], *render(runs, key, calculations[key], prefix))
        if progress:
            progress(key, "done")
    for key in set(RENDERED) - set(calculations):
        del RENDERED[key]
    shown = [dict(key=key, signature=RENDERED[key][0], html=RENDERED[key][1], toc=RENDERED[key][2],
                  issues=RENDERED[key][3]) for key in calculations]
    return dict(roles=roles, unread=unread, calculations=shown)

"""Status callouts and findings shared by calculation pages and the viewer."""
import sourcetypes

CALLOUTS = {"Accepted": ("tip", "accepted"), "Completed": ("tip", "accepted"), "Caveats": ("warning", "caveats"),
            "Problems": ("warning", "caveats"), "In progress": ("note", "in-progress"),
            "Rejected": ("important", "rejected"), "Failed": ("important", "rejected"),
            "Prepared": ("note", None), "Job summary": ("note", None),
            "Succeeded": ("tip", "accepted"), "Submitted": ("note", "in-progress"), "Not run": ("note", None),
            "Not submitted": ("note", None)}


def status_callout(word, reason):
    """A Quarto status callout with its findings or other supporting detail; a calculation that has not been run
    shows no status at all."""
    if word == "Not run":
        return ""
    kind, name = CALLOUTS[word]
    text: sourcetypes.markdown = f"""::: {{.callout-{kind}{f" .status-{name}" if name else ""} title="{word}"}}
{reason}
:::
"""
    return text


def findings_table(findings, icons, show_source=True):
    """Warnings and errors in a single table; the source column is omitted where the callout names it."""
    kinds = {"Info": "hourglass", "Warning": "warning", "Error": "cross"}
    grouped = {}
    for finding in findings:
        # A prepared calculation has no log to report on, so its status alone describes it.
        if finding.kind not in kinds or finding.status == "Not run":
            continue
        source = (finding.source or "Calculation").replace("|", r"\|") if show_source else ""
        message = finding.markdown().replace("|", r"\|")
        key = (finding.kind, source, message)
        grouped[key] = grouped.get(key, 0) + finding.count
    rows = []
    for (kind, source, message), count in grouped.items():
        icon = f"![{kind}]({icons}{kinds[kind]}.svg){{.workflow-status}}"
        rows.append((icon, source, message) if show_source else (icon, message))
    if not rows:
        return ""
    line = lambda cells: "| " + " | ".join(cells) + " |"
    header = ("Kind", "Calculation", "Message") if show_source else ("Kind", "Message")
    return "\n".join([line(header), line(("---",) * len(header)), *(line(row) for row in rows)]) + "\n"

"""Parsed views of one calculation folder for the generated Calculations pages.

A calculation folder holds inputs/, logs/ and scripts/. Its Gaussian or Lotus log and its runflow
scheduler log are read with runflow, and every table or chart here is built from those records.
Table columns use the codenames of ``LABELS``, which the pages render through ``scientific_table``
and register as plot labels; in tables of mixed quantities each value carries its own unit. Booleans
are drawn as status icons by the page. The page builder, quarto/build_calculations.py, uses the same
class to decide which sections a page has.
"""
import hashlib
import json
import os
import pickle
import shutil
import subprocess
from functools import lru_cache
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path

import altair as alt
import networkx as nx
import numpy as np
import pandas as pd
import yaml
from babel.dates import format_datetime
from molstarview import MolstarViewer
from molstarview.volume import CubeGrid, VolumeSurface, VolumeViewer, color_field_view
from runflow.checkpoints import (ELEMENTS, Vibrations, xyz_frames, read_fchk_records, read_gaussian_checkpoint, orbital_grid,
                                 density_grid, orbital_composition, overlap_matrix, basis_function_owners,
                                 basis_supported, momentum_letter, ANGULAR_LETTERS, spin_record)
from runflow.parsers import _warning_code
from runflow.parsers.gic import evaluate, latex, merge_definitions
from runflow.parsers.input_sections import PRINTED, evaluate_modredundant, merge_modredundant
from runflow.parsers.route import route_keywords, split_items, unwrap
from runflow.results import read_gaussian, read_lotus, ureg
from runflow.structures import atom_values, read_gaussian_input, read_sdf
from runflow.symmetry import OrbitalSet, orbital_symmetry, point_group, state_symmetry
from quantities import Quantity, quantity, resolve_units, scientific_latex, unit_latex
from routes import readme_metadata
import runflow
from runflow.runtime import read_log

# Meanings and manual pages of Gaussian route keywords, options and Link 0 commands.
GAUSSIAN = yaml.safe_load(Path(__file__).with_name("gaussian-keywords.yaml").read_text())
# Every IOp's description and documented values, from the IOps Reference.
IOPS = yaml.safe_load(Path(__file__).with_name("gaussian-iops.yaml").read_text())

# The manual's route options, Link 0 commands and basis sets, merged in: the manual's spelling is shown, and the
# hand-written meanings above are kept where both explain a name.
MANUAL = yaml.safe_load(Path(__file__).with_name("gaussian-manual.yaml").read_text())
for _keyword, _options in MANUAL["options"].items():
    _meanings = GAUSSIAN["keywords"].setdefault(_keyword, {"page": _keyword, "meaning": ""}).setdefault("options", {})
    for _name, _meaning in _options.items():
        _meanings.setdefault(_name.lower(), _meaning)
        GAUSSIAN["display_names"]["options"][_name.lower()] = _name
for _command, _meaning in MANUAL["link0"].items():
    GAUSSIAN["links"][0]["commands"].setdefault(_command.lower(), {"name": _command, "meaning": _meaning})
for _name, _meaning in MANUAL["basis_sets"].items():
    GAUSSIAN["basis_sets"].setdefault(_name.lower(), _meaning)
    GAUSSIAN["display_names"]["basis"][_name.lower()] = _name

# Rendered names of table columns and plot fields, by codename.
LABELS = {
    "frontier_level": quantity("frontier_level"),
    "orbital_composition": quantity("orbital_composition"),
    "composition_atom": quantity("composition_atom"),
    "molecular_fragment": quantity("molecular_fragment"),
    **{f"share_{letter}": quantity(f"share_{letter}") for letter in ANGULAR_LETTERS[:8]},
    "share_total": quantity("share_total"),
    "spectral_region": quantity("spectral_region"),
    "quantity": "Quantity",
    "value": "Value",
    "description": "Description",
    "command": "Command",
    "keyword": "Keyword",
    "option": "Option",
    "meaning": "Meaning",
    "options": "Options",
    "iop": "IOp",
    "weights": "Weights",
    "dft_weight": "Weight",
    "atom": "Atom",
    "element": "Element",
    "x": quantity("coordinate_x"),
    "y": quantity("coordinate_y"),
    "z": quantity("coordinate_z"),
    "method": "Method",
    "scf": quantity("scf_solution"),
    "energy": quantity("total_energy"),
    "cycles": quantity("scf_cycles"),
    "cycle": quantity("iteration"),
    "density_rms": quantity("density_change_rms"),
    "converged": quantity("converged"),
    "convergence": quantity("convergence"),
    "evaluation_force": quantity("evaluation_force"),
    "force_statistic": quantity("force_statistic"),
    "optimization_force": quantity("optimization_force"),
    "optimization_force_threshold": quantity("optimization_force_threshold"),
    "optimization_displacement": quantity("optimization_displacement"),
    "optimization_displacement_threshold": quantity("optimization_displacement_threshold"),
    "absolute_energy": quantity("thermochemistry_absolute_energy"),
    "linked_step": "Step",
    "section": "Section",
    "step": quantity("optimization_step"),
    "check_index": quantity("convergence_check_index"),
    "point_index": quantity("point_index"),
    "branch": quantity("branch"),
    "force_max": quantity("force_max"),
    "force_rms": quantity("force_rms"),
    "displacement_max": quantity("displacement_max"),
    "displacement_rms": quantity("displacement_rms"),
    "relative": quantity("energy_above_final"),
    "threshold": "Threshold",
    "criterion": quantity("optimization_criterion"),
    "mode": "Mode",
    "mode_character": quantity("mode_character"),
    "symmetry": quantity("symmetry"),
    "frequency": quantity("wavenumber"),
    "reduced_mass": quantity("reduced_mass"),
    "force_constant": quantity("force_constant"),
    "intensity": quantity("infrared_intensity"),
    "contribution": "Contribution",
    "thermal_total": "Total",
    "thermal_electronic": "Electronic",
    "thermal_translational": "Translational",
    "thermal_rotational": "Rotational",
    "thermal_vibrational": "Vibrational",
    "thermo_level": quantity("thermochemistry_level"),
    "thermo_relative_energy": quantity("thermochemistry_relative_energy"),
    "thermal_energy": quantity("thermal_energy"),
    "heat_capacity": quantity("heat_capacity"),
    "entropy": quantity("entropy"),
    "state": quantity("excited_state"),
    "term": quantity("symmetry"),
    "character": quantity("transition_character"),
    "selection": quantity("dipole_selection"),
    "excitation": quantity("excitation_energy"),
    "wavelength": quantity("wavelength"),
    "oscillator": quantity("oscillator_strength"),
    "velocity": quantity("oscillator_strength_velocity"),
    "spin_squared": quantity("spin_squared"),
    "transition": quantity("orbital_transition"),
    "configurations": quantity("configurations"),
    "weight_percent": quantity("transition_weight"),
    "orbital": quantity("orbital"),
    "orbital_energy": quantity("orbital_energy"),
    "hartree": quantity("energy"),
    "electronvolt": quantity("energy"),
    "occupation": quantity("occupation"),
    "degeneracy": quantity("degeneracy"),
    "transferred": quantity("transferred_charge"),
    "transfer_distance": quantity("transfer_distance"),
    "overlap": quantity("hole_particle_overlap"),
    "charge": quantity("partial_charge"),
    "component": "Component",
    "dipole": quantity("dipole_moment"),
    "axis": "Axis",
    "polar_x": quantity("polarizability_x"),
    "polar_y": quantity("polarizability_y"),
    "polar_z": quantity("polarizability_z"),
    "pair": quantity("nto_pair"),
    "weight": quantity("nto_weight"),
    "stable": quantity("stable"),
    "message": "Message",
    "requested": "Requested",
    "decoded": "Decoded",
    "records": "Records",
    "iteration": quantity("iteration"),
    "density_change": quantity("density_change"),
    "epsilon": quantity("screening"),
    "gap": quantity("orbital_gap"),
    "checkpoint": "Checkpoint",
    "atoms": quantity("atom_count"),
    "reaction_coordinate": quantity("reaction_coordinate"),
    "path_energy": quantity("energy_from_transition_state"),
    "reverse_relative_energy": quantity("energy_from_reverse_endpoint"),
    "check": "Check",
    "time": "Time",
    "level": "Level",
    "field": "Field",
    "kind": "Kind",
    "source": "Source",
    "series": "Quantity",
    "sign": "Sign",
    "label": quantity("coordinate_label"),
    "definition": quantity("coordinate_definition"),
    "coordinate": quantity("coordinate_kind"),
    "action": quantity("coordinate_action"),
    "setting": quantity("coordinate_setting"),
    "start": quantity("coordinate_start"),
    "bonds": quantity("bonded_atoms"),
    "rule": quantity("optimize_rule"),
}

# Plot fields carry this prefix, so their registered labels cannot clash with those of the notebook
# the calculations are appended to.
PLOT = "calculation_"
# Approximate conventional mid-IR regions, in cm-1; they guide interpretation, not mode assignments.
# OpenStax Organic Chemistry, section 12.7: https://openstax.org/books/organic-chemistry/pages/12-7-interpreting-infrared-spectra
IR_REGIONS = [("Fingerprint", 400, 1500), ("Double bonds", 1500, 2000),
              ("Triple bonds", 2000, 2500), ("X–H stretches", 2500, 4000)]
# Approximate wavelength bands, in nm. The visible boundary is conventional and varies between observers.
# WHO UV bands: https://www.who.int/news-room/questions-and-answers/item/radiation-ultraviolet-(uv)
UV_REGIONS = [("UV-C", 100, 280), ("UV-B", 280, 315), ("UV-A", 315, 400), ("Visible", 400, 700),
              ("Near IR", 700, 2500)]
PLOT_LABELS = {PLOT + key: label for key, label in LABELS.items()}

# Display names of the programs, by the lower-case code used throughout.
PROGRAMS = {"gaussian": "Gaussian", "lotus": "Lotus"}

# Status words of a calculation, from best to worst, with their icons in projects/icons.
STATUSES = {"Succeeded": "check", "Problems": "warning", "Failed": "cross", "Submitted": "hourglass", "Not run": None,
            "Accepted": "check", "Caveats": "warning", "Rejected": "cross", "Not submitted": None}

# Status each finding implies and its message template, by finding code; {detail} is the finding's detail.
FINDINGS = {
    # No program log is retained in logs/.
    "missing_log": ("Not run", "No calculation log is retained."),
    # No program log is retained yet, and the README records the Slurm job of the queued or running run.
    "submitted": ("Submitted", "Submitted as Slurm job {detail}; no calculation log is retained yet."),
    # runflow's completion state is not complete: unfinished, failed or missing linked jobs.
    "incomplete": ("Failed", "Gaussian did not complete normally."),
    "unfinished": ("Problems", "Gaussian output is unfinished; activity is not established."),
    "running": ("Submitted", "Gaussian activity is {detail}."),
    # Gaussian printed an error termination or a native error message.
    "error": ("Failed", "{detail}."),
    # An SCF stopped without meeting its convergence criteria.
    "scf_unconverged": ("Failed", "An SCF did not converge."),
    # Lotus stopped before its final convergence marker.
    "lotus_unconverged": ("Failed", "The final convergence marker was not reached."),
    # The runflow script logged an error.
    "script_error": ("Failed", "{detail}."),
    # A native program warning; it is a caveat, so the status states it rather than reading as clean.
    "warning": ("Problems", "{detail}."),
    "checkpoint_basis": ("Succeeded", "{detail}."),
    "error_context": ("Succeeded", "{detail}."),
    # An optimization ended without meeting its geometry criteria.
    "optimization_unconverged": ("Problems", "The optimization did not converge."),
    # Not every requested TD root converged.
    "td_unconverged": ("Problems", "Not every TD root converged."),
    # The count of imaginary modes contradicts the job type: one for a TS, none otherwise.
    "imaginary_modes": ("Problems", "{detail}."),
    # A stability analysis found the wavefunction unstable.
    "unstable": ("Problems", "The wavefunction is unstable: {detail}."),
    # A Lotus response or consistency check failed.
    "check_failed": ("Problems", "The {detail} check failed."),
    # The runflow script logged a warning.
    "script_warning": ("Problems", "{detail}."),
}

# Component order of the symmetric tensors Gaussian archives, by archive key.
ARCHIVE_TENSORS = {"Quadrupole": ("xx", "yy", "zz", "xy", "xz", "yz"), "Polar": ("xx", "xy", "yy", "xz", "yz", "zz")}


LOTUS_METHODS = {
    "hf": "HF", "slater": "Slater exchange", "b88": "B88 exchange", "svwn": "SVWN", "blyp": "BLYP", "b3lyp": "B3LYP",
    "dd_svwn": "DD-SVWN", "ds_svwn": "DS-SVWN", "dd_blyp": "DD-BLYP", "ds_ex_vwn": "DS-erfc-VWN",
    "ds_ex_lyp": "DS-erfc-LYP",
}

LOTUS_DESCRIPTIONS = {
    "hf": "Hartree–Fock exchange without density-functional correlation.",
    "slater": "Local Slater exchange.", "b88": "Becke 1988 gradient-corrected exchange.",
    "svwn": "Slater exchange with VWN local correlation.",
    "blyp": "Becke 1988 exchange with Lee–Yang–Parr correlation.",
    "b3lyp": "Three-parameter hybrid exchange with Lee–Yang–Parr correlation.",
    "dd_svwn": "Dielectric-dependent hybrid of exact and Slater exchange with VWN correlation.",
    "ds_svwn": "Density-screened hybrid of exact and Slater exchange with VWN-RPA correlation.",
    "dd_blyp": "Dielectric-dependent hybrid using B88 exchange and LYP correlation.",
    "ds_ex_vwn": "Density-screened complementary-error-function exchange with VWN correlation.",
    "ds_ex_lyp": "Density-screened complementary-error-function exchange with LYP correlation.",
}

# Names and symbols of the Lotus functional weights, by Lotus's weight name: the dielectric-dependent forms use
# alpha = 1/epsilon of Hartree–Fock exchange, 1 - alpha of local exchange and c = sqrt(1 - alpha) of correlation.
LOTUS_WEIGHTS = {
    "exact_exchange": r"Hartree–Fock exchange weight $\alpha$",
    "b88_exchange": r"B88 exchange weight $1-\alpha$",
    "slater_exchange": r"Slater exchange weight $1-\alpha$",
    "lyp_correlation": r"LYP correlation weight $c=\sqrt{1-\alpha}$",
    "vwn_correlation": r"VWN correlation weight $c=\sqrt{1-\alpha}$",
}

# Readable names of the Lotus settings in the XYZ comment line.
LOTUS_SETTINGS = {
    "method": quantity("method"), "basis": quantity("basis_set"), "spin": quantity("spin_multiplicity"),
    "charge": quantity("molecular_charge"), "epsilon": quantity("initial_screening"),
    "sc_scrEx": quantity("screening_self_consistency"), "max_scf": quantity("maximum_scf_iterations"),
    "threshold_scf": quantity("scf_threshold"),
}

# Optimization criteria as Gaussian names them: table codename and plot legend label.
CRITERIA = {
    "maximum force": ("force_max", "Maximum force"), "rms force": ("force_rms", "RMS force"),
    "maximum displacement": ("displacement_max", "Maximum displacement"),
    "rms displacement": ("displacement_rms", "RMS displacement"),
}

# Acronyms kept in capitals when a warning Gaussian prints in capitals is written as a sentence.
ACRONYMS = {"TS", "SCF", "IRC", "TD", "TDA", "DFT", "HF", "MO", "NTO", "RMS", "CPHF", "PCM", "SCRF", "ECP", "QST", "GDIIS"}


# A short explanation is attached only when the parser's diagnostic code identifies the failure; {link} names the
# Gaussian link a bare error termination stopped in.
ERROR_EXPLANATIONS = {
    "gaussian.error.route_syntax": "Gaussian could not parse the input route",
    "gaussian.error.expected_numeric_input": "Gaussian expected a numeric input value",
    "gaussian.error.unexpected_input_value": "Gaussian found an unexpected value where the input format requires another",
    "gaussian.error.electron_multiplicity": "The charge, electron count or multiplicity is inconsistent",
    "gaussian.error.charge_multiplicity_input": "The charge, electron count or multiplicity is inconsistent",
    "gaussian.error.unsupported_basis_atom": "The specified basis does not cover an atom",
    "gaussian.error.unknown_atom": "Gaussian could not interpret the molecular specification",
    "gaussian.error.input_molecular_specification": "Gaussian rejected the molecular specification",
    "gaussian.error.input_parser_type": "Gaussian could not interpret the molecular specification",
    "gaussian.error.input_eof": "Gaussian reached the end of the input while reading an atomic symbol",
    "gaussian.error.basis_eof": "Gaussian reached the end of the input while reading the basis set",
    "gaussian.error.input_zmatrix_symbol": "Gaussian could not resolve an atom in the Z-matrix",
    "gaussian.error.input_optimization_variables": "Gaussian found no optimization variables",
    "gaussian.error.missing_file": "Gaussian could not access a required file",
    "gaussian.error.file_write": "Gaussian reported a file-writing failure",
    "gaussian.error.file_open": "Gaussian could not create or open a file it requires",
    "gaussian.error.temp_input_file": "Gaussian could not create or open a file it requires",
    "gaussian.error.deleted_input_file": "Gaussian lost its internal input file",
    "gaussian.error.file_g_write": "Gaussian could not write to a file",
    "gaussian.error.file_range": "Gaussian attempted an operation outside a file's range",
    "gaussian.error.scratch_open": "Gaussian could not open a scratch file",
    "gaussian.error.constraints": "Gaussian could not impose the requested geometry constraints",
    "gaussian.error.internal_coordinate_formbx": "Gaussian encountered a problem with its internal coordinates",
    "gaussian.error.internal_coordinate_system": "Gaussian encountered a problem with its internal coordinates",
    "gaussian.error.linear_angle": "Gaussian encountered a problem with its internal coordinates",
    "gaussian.error.internal_variable_count": "Gaussian found inconsistent numbers of internal-coordinate variables",
    "gaussian.error.curvilinear_step": "Gaussian could not converge the constrained geometry step",
    "gaussian.error.internal_variables_initialization": "Gaussian could not initialise its internal-coordinate variables",
    "gaussian.error.distance_matrix": "Gaussian reported an invalid molecular geometry",
    "gaussian.error.atoms_too_close": "Gaussian reported an invalid molecular geometry",
    "gaussian.error.insufficient_memory": "Gaussian could not allocate the required memory",
    "gaussian.error.memory_allocation": "Gaussian required more memory than was available",
    "gaussian.error.convergence_criterion": "Gaussian reported a convergence failure",
    "gaussian.error.convergence_failure": "Gaussian reported a convergence failure",
    "gaussian.error.scf_not_converged": "Gaussian reported an SCF that did not converge",
    "gaussian.error.optimization_stopped": "Gaussian stopped the geometry optimization",
    "gaussian.error.optimization_steps_exceeded": "Gaussian stopped the geometry optimization",
    "gaussian.error.diagonalization": "Gaussian reported a matrix diagonalization failure",
    "gaussian.error.pcm_matrix_inverse": "Gaussian reported a failure in the solvent-model matrix calculation",
    "gaussian.error.solvent_epsilon_infinity": "The solvent model lacks a dielectric constant for this solvent",
    "gaussian.error.solvent_cavity_atoms": "The solvent model found no atoms for its cavity",
    "gaussian.error.solvent_vdw_radius": "The solvent model lacks a van der Waals radius for an atom",
    "gaussian.error.irc_corrector_steps": "Gaussian could not complete the reaction-path correction",
    "gaussian.error.irc_optimization": "Gaussian could not complete the reaction-path correction",
    "gaussian.error.irc_error_termination": "Gaussian could not complete the reaction-path correction",
    "gaussian.error.dispersion_parameters": "The dispersion correction lacks parameters for an atom",
    "gaussian.error.unavailable_third_derivatives": "The method does not provide the third derivatives the calculation requires",
    "gaussian.error.quadrature": "Gaussian reported inaccurate quadrature in the density-functional integration",
    "gaussian.error.orbital_localisation": "Gaussian reported a problem in the orbital localisation",
    "gaussian.error.orbital_gap": "Gaussian reported a vanishing orbital gap",
    "gaussian.error.hessian_storage": "Gaussian reported an inconsistency in its Hessian storage",
    "gaussian.error.correlation_cycles": "Gaussian stopped the correlation iterations at the maximum number of cycles",
    "gaussian.error.occupied_orbital_projection": "Gaussian could not project the read-in occupied orbitals",
    "gaussian.error.blas_lapack_arguments": "Gaussian passed invalid arguments to a numerical library routine",
    "gaussian.error.internal_consistency_getijb": "Gaussian reported an internal consistency failure",
    "gaussian.error.biorthogonal_vectors": "Gaussian could not match its left and right vectors",
    "gaussian.error.nuclear_coordinate_error": "Gaussian could not process the nuclear coordinates",
    "gaussian.error.segmentation_fault": "Gaussian crashed with a segmentation fault",
    "gaussian.error.illegal_instruction": "Gaussian crashed on an illegal instruction",
    "gaussian.error.windows_severe_error": "Gaussian reported a severe Windows error",
    "gaussian.error.mmcore_bounds": "Gaussian reported an array-bound failure in MMCore",
    "gaussian.error.transition_orthogonality": "Gaussian reported a transition vector not orthogonal to T",
    "gaussian.error.wrong_negative_eigenvalues": "The Hessian has the wrong number of negative eigenvalues for the requested stationary point",
    "gaussian.error.no_atoms": "The input structure contains no atoms",
    "gaussian.error.bad_file": "Gaussian read an inconsistent scratch file",
    "gaussian.error.garbage_pointers": "Gaussian read inconsistent checkpoint pointers",
    "gaussian.error.termination": "Gaussian stopped with an error termination in link {link}",
}


# Titles of the two views of an electrostatic potential, which a viewer's toolbar button switches between.
POTENTIAL_ON_SURFACE = "Potential on Surface"


def potential_in_space(surfaces, isovalue=0.5):
    """The in-space view of the electrostatic potential colouring ``surfaces`` (density surfaces with the potential in
    volts as their colour field, one or a mapping of snapshot titles to them): red surfaces at -``isovalue`` volts,
    where a positive charge is attracted, and blue ones at +``isovalue``, for ``VolumeViewer``'s ``alternates``."""
    return color_field_view(surfaces, isovalue=isovalue, title="Potential in Space",
                            color_label=quantity("electrostatic_potential"), field_name="Electrostatic potential",
                            field_symbol="V", field_unit=unit_latex("volt"))


@dataclass(frozen=True)
class Finding:
    """One parsed reason behind a calculation's status: a FINDINGS code, where it comes from and its detail."""

    code: str
    # Where the finding comes from: Gaussian or a named linked step, or Lotus; empty for the runflow script.
    source: str = ""
    detail: str = ""
    count: int = 1
    diagnostic_code: str = ""
    original_message: str = ""

    @property
    def status(self):
        """Status word this finding implies; a warning repeated within a job stays a problem."""
        return FINDINGS[self.code][0]

    @property
    def kind(self):
        """Classify a finding as an error, warning or activity information."""
        return "Error" if self.status == "Failed" else "Warning" if self.code == "warning" or self.status == "Problems" else "Info"

    def message(self):
        """Readable message: Gaussian's Fortran numbers such as 0.11361587D+02 written as numbers, a warning Gaussian
        prints in capitals with exclamation marks written as a sentence, first letter capital."""
        detail = re.sub(r"[-+]?\d*\.\d+[DdEe][-+]?\d+",
                        lambda match: _number(float(re.sub("[Dd]", "e", match[0]))), re.sub(r"^(?:[\w.]+(?:Error|Exception)):\s*", "", self.detail).rstrip(". !"))
        if self.code == "warning" and detail == detail.upper() and re.search("[A-Z]{4}", detail):
            detail = re.sub(r"[A-Z]+", lambda match: match[0] if match[0] in ACRONYMS else match[0].lower(), detail)
        message = FINDINGS[self.code][1].format(detail=detail)
        if self.code == "error":
            explanation = ERROR_EXPLANATIONS.get(self.diagnostic_code)
            if explanation and self.diagnostic_code == "gaussian.error.optimization_steps_exceeded":
                steps = re.search(r"NStep=\s*(\d+)", detail)
                message = f"{explanation} after {steps[1]} steps." if steps else f"{explanation}."
            elif explanation and "{link}" in explanation:
                link = re.search(r"Lnk(?:1e|le) in \S*?l(\d+)\.exe", detail, re.I)
                message = (f"Gaussian stopped with an error termination in link {link[1]}." if link
                           else "Gaussian stopped with an error termination.")
            elif explanation:
                message = f"{explanation}."
        elif self.code == "script_warning":
            explanations = {
                "runflow.warning.constrained_saddle_only": "The saddle was identified under constraints; this alone does not establish a first-order saddle in the full coordinate space",
                "runflow.warning.screening_weights_changed": "Relaxing the geometry changed the rounded screening-dependent functional weights; examine the screening residual before further calculations",
                "runflow.warning.screening_first_cycle_geometry_and_weights": "This calculation used the first-cycle geometry and screening-dependent weights; the recorded screening residual remains relevant",
                "runflow.warning.screening_first_cycle_weights": "This calculation used the first-cycle screening-dependent weights; the recorded screening residual remains relevant",
            }
            if explanation := explanations.get(self.diagnostic_code):
                message = f"{explanation}."
        return message[:1].upper() + message[1:]

    def markdown(self):
        """Typeset scientific symbols without changing existing math or quoted text."""
        message = self.message()
        kept = []

        def keep(match):
            """Keep existing math and quoted text unchanged."""
            kept.append(match[0])
            return f"\x00K{len(kept) - 1}K\x00"

        message = re.sub(r"\$[^$]+\$|`[^`]*`|" + chr(39) + r"[^" + chr(39) + r"]*" + chr(39) + r"|\S*/\S*", keep, message)
        message = re.sub(r"\b(alpha|beta)\b", lambda match: rf"$\{match[1].lower()}$", message, flags=re.IGNORECASE)
        message = re.sub(r"\bdelta epsilon\b", r"$\\Delta\\epsilon$", message, flags=re.IGNORECASE)
        return re.sub(r"\x00K(\d+)K\x00", lambda match: kept[int(match[1])], message)


    def text(self):
        """One line with source, message and repeat count, for hover titles."""
        count = f" ({self.count} times)" if self.count > 1 else ""
        return (f"{self.source}: " if self.source else "") + self.message().removesuffix(".") + count + "."


def _mantissa(value, digits):
    """Mantissa and exponent of a very small or large number, or None for an ordinary one."""
    if value == 0 or 1e-3 <= abs(value) < 1e5:
        return None
    mantissa, exponent = f"{value:.{digits - 1}e}".split("e")
    return mantissa.rstrip("0").rstrip("."), int(exponent)


def _number(value, digits=6):
    """A number as text at the given significant digits; a very small or large one as a mantissa followed by
    a power of ten in LaTeX, as scientific_table writes them."""
    if isinstance(value, bool) or not isinstance(value, (int, float, np.integer, np.floating)):
        return str(value)
    if (parts := _mantissa(value, digits)) is None:
        return f"{value:.{digits}g}"
    return scientific_latex(*parts)


def _value(value, unit=None, digits=6):
    """A value with its unit; a list becomes a parenthesized vector; text stays text. Only what needs math is LaTeX."""
    if isinstance(value, str):
        return value
    if unit == "hartree":
        value, unit = _to_ev(np.asarray(value) if isinstance(value, (list, tuple)) else value), "eV"
    if unit == "hartree/bohr":
        value, unit = (value * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude, "eV/angstrom"
    text = ("$(" + ", ".join(_number(item, digits).replace("$", "") for item in value) + ")$" if isinstance(value, (list, tuple, np.ndarray))
            else _number(value, digits))
    return "$" + text.replace("$", "") + r"\," + unit_latex(unit) + "$" if unit else text


def _tensor(values, order, unit, digits=6):
    """A symmetric 3 x 3 tensor as a LaTeX matrix with its unit, from components in the given order.

    ``order`` names each value's component, such as "xy"; the matrix fills both triangles.
    """
    def latex(value):
        parts = _mantissa(value, digits)
        return f"{value:.{digits}g}" if parts is None else scientific_latex(*parts).strip("$")

    components = {}
    for name, value in zip(order, values):
        components[name] = components[name[::-1]] = value
    rows = [" & ".join(latex(components[a + b]) for b in "xyz") for a in "xyz"]
    return rf"$\begin{{pmatrix}}{r' \\ '.join(rows)}\end{{pmatrix}}\,{unit_latex(unit)}$"


def _formula(text):
    """A stoichiometry such as C16H14B2F2O5 or N1 as upright LaTeX, without counts of one, its elements in the Hill
    system through molmass; any suffix Gaussian adds, such as a charge in parentheses, is kept as written."""
    from molmass import Formula

    core, suffix = re.fullmatch(r"((?:[A-Z][a-z]?\d*)+)(.*)", text).groups() if re.match(r"[A-Z]", text) else ("", text)
    if core:
        core = Formula(core).formula
    return r"$\mathrm{" + re.sub(r"([A-Z][a-z]?)(\d+)", lambda m: m[1] + (f"_{{{m[2]}}}" if m[2] != "1" else ""), core) + suffix + "}$"


def _point_group(code):
    """A Gaussian point-group label such as C1, C02V, D03H, CS or D*H in Schoenflies notation, as LaTeX."""
    special = {"CS": "C_s", "CI": "C_i", "T": "T", "TD": "T_d", "TH": "T_h", "O": "O", "OH": "O_h", "I": "I", "IH": "I_h"}
    if code.upper() in special:
        return f"${special[code.upper()]}$"
    match = re.fullmatch(r"([CDS])(\*|\d+)([A-Z]*)", code.upper())
    if not match:
        return code
    order = r"{\infty}" if match[2] == "*" else str(int(match[2]))
    return f"${match[1]}_{{{order}{match[3].lower()}}}$"


def _symmetry_element(code):
    """Where a framework-group atom set sits: X general positions, O the centre, Cn axes and SG mirror planes,
    with a leading count of equivalent elements."""
    count, element = re.fullmatch(r"(\d*)(.+)", code).groups()
    many = count not in ("", "1")
    planes = {"SG": r"$\sigma$", "SGH": r"$\sigma_h$", "SGV": r"$\sigma_v$", "SGD": r"$\sigma_d$"}
    if element == "X":
        return "in general positions"
    if element == "O":
        return "at the centre"
    if element in planes:
        return f"in {count} equivalent {planes[element]} planes" if many else f"in the {planes[element]} plane"
    if axis := re.fullmatch(r"C(\d+|\*)", element):
        order = r"\infty" if axis[1] == "*" else axis[1]
        return f"on {count} equivalent $C_{{{order}}}$ axes" if many else f"on the $C_{{{order}}}$ axis"
    return f"on `{element}`"


def _framework(text):
    """Gaussian's framework group, such as [O(N1),3C2(H1)]: each atom set and the symmetry element it sits on."""
    parts = [f"{_formula(atoms)} {_symmetry_element(element)}"
             for element, atoms in re.findall(r"([0-9A-Z*]+)\(([A-Za-z0-9]+)\)", text)]
    return "; ".join(parts) if parts else text


# Gaussian writes its times without a zone, in the calculation server's local time, Japan Standard Time.
JST = ZoneInfo("Asia/Tokyo")
# The zone times are shown in: the computer's own, Japan Standard Time where these pages are rendered; the viewer
# sets it to the zone of the visitor's browser.
ZONE = JST


def _moment(time):
    """Display a recorded instant in the shown zone, retaining seconds.

    Args:
        time: Recorded datetime, including its source timezone.
    Returns:
        Abbreviated local date and clock time labelled with the zone's abbreviation, such as JST.
    """
    return f"{format_datetime(time, 'd MMM y, HH:mm:ss', tzinfo=ZONE, locale='en_GB')} {time.astimezone(ZONE).tzname()}"


def _period(start, end):
    """Display the span between two recorded instants in the shown zone, retaining seconds.

    Args:
        start: Recorded datetime the span begins at, including its source timezone.
        end: Recorded datetime the span ends at, including its source timezone; the render time while it continues.
    Returns:
        The start and the end clock time, its date repeated only when it differs.
    """
    same_day = start.astimezone(ZONE).date() == end.astimezone(ZONE).date()
    finish = format_datetime(end, "HH:mm:ss" if same_day else "d MMM y, HH:mm:ss", tzinfo=ZONE, locale="en_GB")
    return (f"{format_datetime(start, 'd MMM y, HH:mm:ss', tzinfo=ZONE, locale='en_GB')} – {finish} "
            f"{end.astimezone(ZONE).tzname()}")


def _duration(seconds):
    """Format elapsed time with the standard library's compact duration notation.

    Args:
        seconds: Nonnegative elapsed time in seconds.
    Returns:
        Hours, minutes and seconds, prefixed by days when needed.
    """
    if seconds < 0:
        raise ValueError("Elapsed time must be nonnegative.")
    return str(timedelta(seconds=round(seconds)))


def _changes(values):
    """Values kept only where they differ from the previous one, so a column shows changes rather than repeats."""
    return [value if index == 0 or value != values[index - 1] else None for index, value in enumerate(values)]


def _warning_findings(warnings, source, program="gaussian"):
    """One warning finding per kind of native warning, grouping repeats that differ only in their numbers.

    The detail keeps the first occurrence, without Gaussian's own "Warning" prefix and asterisks.
    """
    groups = {}
    for original in warnings:
        text = re.sub(r"^[*\s]*warning\W*", "", " ".join(original.split()), flags=re.IGNORECASE)
        groups.setdefault(re.sub(r"[-+]?\d[\d.]*(?:[DEde][-+]?\d+)?", "#", text), []).append((text, original))
    return [Finding("checkpoint_basis" if texts[0][0].casefold().rstrip(" .") == "basis set taken from checkpoint file"
                    else "warning", source, texts[0][0], len(texts), _warning_code(texts[0][0], program), texts[0][1])
            for texts in groups.values()]


# Display names of Gaussian job types in job descriptions.
JOB_NAMES = {"sp": "SP", "irc": "IRC", "ircmax": "IRCMax", "admp": "ADMP", "bomd": "BOMD"}


def job_word(job, name):
    """Name of one job keyword with the option that says what kind of job it is.

    An optimization is named for what it looks for: a relaxed scan when it logged scan points, a TS or QST2/QST3
    search when its route asks for one, otherwise a minimum search; an IRC names its direction when it follows only
    one.

    Args:
        job: Linked job from a log or an input, with its ``request`` and, for a log, its ``scan_points``.
        name: Job keyword, lower case, such as ``opt`` or ``irc``.

    Returns:
        The display name, such as ``TS Opt``, ``Scan``, ``IRC forward`` or ``Freq``.
    """
    options = job["request"]["options"].get(name, {})
    if name == "opt":
        if job.get("scan_points"):
            return "Scan"
        for search in ("ts", "qst2", "qst3"):
            if search in options:
                return f"{search.upper() if search != 'ts' else 'TS'} Opt"
    if name == "irc":
        for direction in ("forward", "reverse"):
            if direction in options:
                return f"IRC {direction}"
    return JOB_NAMES.get(name, name.capitalize())


def _method_name(name):
    """Use conventional functional casing without losing a spin restriction prefix.

    Args:
        name: Gaussian method as reported by the input or output parser.
    Returns:
        Canonical method name, retaining R, U or RO when explicitly present.
    """
    names = GAUSSIAN["display_names"]["methods"]
    key = name.lower()
    if key in names:
        return names[key]
    for prefix in ("ro", "r", "u"):
        if key.startswith(prefix) and key[len(prefix):] in names:
            return prefix.upper() + names[key[len(prefix):]]
    return name


def _basis_name(name):
    """Normalize supported basis names and equivalent polarization aliases.

    Args:
        name: Parsed basis name.
    Returns:
        Conventional Gaussian basis notation.
    """
    name = GAUSSIAN["display_names"]["basis"].get(name.lower(), name)
    return _basis_math(name)


def _basis_math(name):
    """A Pople or minimal basis-set name in LaTeX, as written in the READMEs: the split-valence digits and hyphen
    upright, diffuse plus signs and polarization stars as symbols, and the polarization functions in parentheses, such
    as 6-31G(d,p) as $6\\text{-}31\\mathrm{G}(d,p)$; other names are left as written."""
    match = re.fullmatch(r"(\d+)-(\d+)(\+{0,2})G(\*{0,2})(\([^)]*\))?", name)
    if match:
        plus = "{+}" * len(match[3])
        stars = f"^{{{'*' * len(match[4])}}}" if match[4] else ""
        return f"${match[1]}\\text{{-}}{match[2]}{plus}\\mathrm{{G}}{stars}{match[5] or ''}$"
    if match := re.fullmatch(r"STO-(\d+)G", name):
        return f"$\\mathrm{{STO}}\\text{{-}}{match[1]}\\mathrm{{G}}$"
    return name


def _keyword_name(name):
    """Normalize a route keyword or method for display.

    Args:
        name: Parsed route keyword or method.
    Returns:
        Canonical display name, preserving unsupported names verbatim.
    """
    # The form written, short or long, in the manual's spelling.
    return GAUSSIAN["display_names"]["keywords"].get(name.lower(), _method_name(name))


def _manual(name):
    """Manual page and meaning of a route keyword, either possibly None."""
    key = GAUSSIAN["aliases"].get(name.lower(), name.lower())
    entry = GAUSSIAN["keywords"].get(key) or GAUSSIAN["methods"].get(key) or {}
    page = entry.get("page") or (key if key in GAUSSIAN["pages"] else None)
    return page, entry.get("meaning")


def _link(text, page):
    """Literal keyword text linked to its Gaussian manual page when it has one."""
    shown = f"`{text}`"
    return f"[{shown}](https://gaussian.com/{page}/)" if page else shown


# The functional the DFT weight IOps parameterize, from Gaussian's DFT page.
FUNCTIONAL = (r"$E_{\mathrm{xc}}=P_2E_x^{\mathrm{HF}}+P_1(P_4E_x^{\mathrm{Slater}}+P_3\Delta E_x^{\mathrm{nonlocal}})"
              r"+P_6E_c^{\mathrm{local}}+P_5\Delta E_c^{\mathrm{nonlocal}}$")
# Per DFT weight IOp, what it sets, then the weight its first five digits MMMMM set and the weight its last five
# NNNNN set, with their meanings as Gaussian's overlay 3 and DFT pages document them.
WEIGHT_OPTIONS = {"3/76": "Exchange weights $P_1$ and $P_2$.", "3/77": "Density-functional exchange weights $P_3$ and $P_4$.",
                  "3/78": "Correlation weights $P_5$ and $P_6$."}
WEIGHTS = {
    "3/76": (("P_1", "Density-functional exchange weight. It multiplies the local and nonlocal exchange weights "
                     "$P_4$ and $P_3$, whether the functional implies them or `IOp(3/77)` sets them."),
             ("P_2", "Hartree–Fock exchange weight.")),
    "3/77": (("P_3", "Nonlocal (gradient-correction) exchange weight, within the density-functional exchange."),
             ("P_4", "Local (Slater) exchange weight, within the density-functional exchange.")),
    "3/78": (("P_5", "Nonlocal (gradient-correction) correlation weight."),
             ("P_6", "Local correlation weight.")),
}


def _iop_rows(name, value):
    """Rows of one IOp setting: its name, value as written, meaning and, for a DFT weight IOp, a subtable of the
    weights its MMMMMNNNNN digits set, each with its value and meaning."""
    if name in WEIGHTS and re.fullmatch(r"-?\d+", value) and int(value) > 0 or (
            name in ("3/77", "3/78") and re.fullmatch(r"-\d+", value) and int(value) < -1):
        # Gaussian reads the value as an integer: MMMMM is its quotient by 100000 and NNNNN the remainder, so
        # leading zeros may be omitted. For 3/77 and 3/78 a negative sign applies to the local term only.
        code = abs(int(value))
        weights = (code // 100000 / 10000, (-1 if int(value) < 0 else 1) * (code % 100000) / 10000)
        table = pd.DataFrame([(f"${symbol}$", weight, meaning) for (symbol, meaning), weight in zip(WEIGHTS[name], weights)],
                             columns=["dft_weight", "value", "meaning"])
        meaning = WEIGHT_OPTIONS[name] + (f" The weights enter {FUNCTIONAL}." if name == "3/76" else "")
        return [(_iop_name(name), f"`{value}`", meaning, table)]
    template = GAUSSIAN["keywords"]["iop"]["options"].get(name)
    meaning = resolve_units(template.format(value=value)) if template else _iop_meaning(name, value)
    return [(_iop_name(name), f"`{value}`" if value else None, meaning, None)]


def _iop_name(name):
    """An IOp's overlay/option, linked to its entry in the IOps Reference when it has one."""
    entry = IOPS.get(name)
    return f"[`{name}`](https://gaussian.com/{entry['anchor']})" if entry else f"`{name}`"


def _iop_meaning(name, value):
    """An IOp's description from the IOps Reference, followed by the meaning of its value when the reference
    lists that value, in the reference's own words."""
    entry = IOPS.get(name)
    if not entry:
        return ""
    # Markdown's special characters taken literally, and every IOp the text mentions written as code.
    literal = lambda text: re.sub(r"IOp\(([^()]*)\)", r"`IOp(\1)`", re.sub(r"([*_`$\\\[\]])", r"\\\1", text))
    meaning = literal(entry["meaning"])
    number = lambda text: int(text) if re.fullmatch(r"[-+]?\d+", text) else None
    match = next((text for setting, text in entry.get("values", [])
                  if setting == value or number(setting) is not None and number(setting) == number(value)), None)
    return meaning + (f" Value `{value}`: {literal(match)}" if match else "")


def _setting(value):
    """A setting's value as read: an integer or decimal number as a number, other text as written, and a
    parenthesized list as its items separated by commas."""
    if re.fullmatch(r"[-+]?\d+", value):
        return int(value)
    if re.fullmatch(r"[-+]?(\d+\.\d*|\.\d+)([eEdD][-+]?\d+)?", value):
        return float(re.sub("[dD]", "e", value))
    return ", ".join(split_items(unwrap(value))) if value.startswith("(") else value


# Solvents by lower-case name: the manual's spelling and Gaussian's static dielectric constant, as written.
SOLVENTS = {name.lower(): (name, epsilon) for name, epsilon in GAUSSIAN["solvents"].items()}


def _option_name(name):
    """A route option as the manual spells it, whatever its case in the input; unknown options as written."""
    return GAUSSIAN["display_names"]["options"].get(name.lower(), name)


def _option_rows(keyword, options):
    """Rows of a keyword's options: the option's name, its value when it takes one, and its meaning; nested
    options are explained in place."""
    key = GAUSSIAN["aliases"].get(keyword.lower(), keyword.lower())
    meanings = GAUSSIAN["keywords"].get(key, {}).get("options", {})
    rows, items = [], []
    for item in split_items(unwrap(options)):
        # A solvent whose name has commas, such as n,n-DiMethylFormamide, is split at them like separate options.
        if items and items[-1].lower().startswith("solvent=") and "=" not in item and any(
                name.startswith((items[-1].partition("=")[2] + "," + item).lower()) for name in SOLVENTS):
            items[-1] += "," + item
        else:
            items.append(item)
    for option in items:
        name, _, value = option.partition("=")
        template = meanings.get(name.lower(), "")
        nested = [meanings.get(inner.partition("=")[0].lower(), "").format(value=inner.partition("=")[2])
                  for inner in split_items(unwrap(value))] if value.startswith("(") and "=" in value else []
        if nested:
            # Nested options spelled as the manual spells them, with their values as written.
            value = "(" + ",".join(_option_name(inner.partition("=")[0]) + inner[len(inner.partition("=")[0]):]
                                   for inner in split_items(unwrap(value))) + ")"
        elif name.lower() == "solvent" and value.lower() in SOLVENTS:
            value, epsilon = SOLVENTS[value.lower()]
            template = meanings.get("solvent_tabulated", template).replace("{epsilon}", epsilon)
        # A solvent's name is one value, commas and all; a list's items are separated as words are.
        meaning = template.format(value=value if name.lower() == "solvent" else ", ".join(split_items(unwrap(value))))
        meaning = resolve_units(" ".join(part for part in [meaning, *nested] if part))
        rows.append((f"`{_option_name(name)}`", _setting(value) if value else None, meaning))
    return rows


def _options_table(keyword, options):
    """A keyword's options as a subtable, with the Value column only when some option takes a value."""
    table = pd.DataFrame(_option_rows(keyword, options), columns=["option", "value", "meaning"])
    return table if table.value.notna().any() else table.drop(columns="value")


def _link0_value(key, value):
    """A Link 0 command's value in words: a memory size as a number and its unit, such as 8 GB, a count as a
    number and a processor list with ranges written as en dashes."""
    if not value:
        return ""
    if key == "%mem":
        match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*([KMGT]?)(B|W)?", value.strip(), re.I)
        if match:
            # Gaussian counts memory in 8-byte words when no unit is given.
            unit = (match[2].upper() + ("B" if (match[3] or "W").upper() == "B" else "W")) if match[2] or match[3] else "words"
            return f"{match[1]} {unit}"
    if re.fullmatch(r"\d+", value.strip()):
        return int(value)
    if key in ("%cpu", "%gpucpu"):
        return value.replace("-", "–").replace(",", ", ")
    return value


def _requested_resource(key, value):
    """A Slurm request as the overview shows it: memory as a number and its binary unit, such as 12 GB, and a
    partition list as its names, such as r01, r02, r03."""
    if key == "mem" and (match := re.fullmatch(r"(\d+(?:\.\d+)?)\s*([KMGT])i?B?", value.strip(), re.I)):
        return f"{match[1]} {match[2].upper()}B"
    if key == "partition":
        return ", ".join(name for name in re.split(r"[\s,]+", value.strip()) if name)
    return value


def _energy_sets(occupied, virtual, degeneracy=1e-4):
    """Orbital sets from energies in hartree alone, without symmetry: degenerate orbitals together."""
    sets = []
    for index, energy in enumerate(list(occupied) + list(virtual)):
        is_occupied = index < len(occupied)
        last = sets[-1] if sets else None
        if last and last.occupied == is_occupied and abs(energy - last.energy) < degeneracy:
            last.indices.append(index)
        else:
            sets.append(OrbitalSet([index], float(energy), is_occupied))
    return sets


def _frontier(sets, count, occupied):
    """The occupied sets from the highest down, or the unoccupied ones from the lowest up, until they hold at least
    ``count`` orbitals."""
    chosen, held = [], 0
    for orbital_set in (reversed(sets) if occupied else sets):
        if orbital_set.occupied != occupied or held >= count:
            continue
        chosen.append(orbital_set)
        held += len(orbital_set.indices)
    return chosen[::-1] if occupied else chosen


def level_diagram(levels, columns, *, color, scale=alt.Undefined, links=None, domain=None, tooltip=(), close=None):
    """Energy levels as a diagram: a bar per level in its column, named on hover rather than written beside it, so the
    diagram stays legible however many levels it holds. Levels of one column closer than ``close`` share their row side
    by side and a degenerate set splits its bar into components, so no two bars overlap; dashed links join levels of
    different columns, darker for larger weights. Clicking a level keeps its whole chain in full colour, every level its
    links reach directly or through others and those links, and fades every other level and link by the same amount;
    clicking empty space restores them.

    Args:
        levels: Table of levels: ``column`` (position in ``columns``), ``orbital_energy`` in eV, ``components`` (bars
            side by side, one by default) and the fields named by ``color`` and ``tooltip``.
        columns: Column titles under the axis, LaTeX inside ``$...$``.
        color: Field that colours the bars.
        scale: Colour scale of that field.
        links: Table of links: ``source`` and ``target``, positions of two levels of different columns in ``levels``,
            and ``weight`` from zero to one; None for none.
        domain: Energies framed at first, in eV; by default every level with half an electronvolt to spare.
        tooltip: Fields of the levels listed when hovering a bar, before the energy.
        close: Energy difference in eV below which levels of a column share a row; by default 3% of the framed span.

    Returns:
        The layered Altair chart.
    """
    levels = levels.reset_index(drop=True).copy()
    if domain is None:
        domain = (levels.orbital_energy.min() - 0.5, levels.orbital_energy.max() + 0.5)
    close = 0.03 * (domain[1] - domain[0]) if close is None else close
    # Half the width of a column's bars, and the space between bars sharing a row.
    half, space = 0.36, 0.04
    for column, group in levels.groupby("column"):
        rows = []
        for index in group.sort_values("orbital_energy").index:
            if rows and levels.orbital_energy[index] - levels.orbital_energy[rows[-1][0]] < close:
                rows[-1].append(index)
            else:
                rows.append([index])
        for row in rows:
            width = (2 * half - space * (len(row) - 1)) / len(row)
            for k, index in enumerate(row):
                levels.loc[index, "left"] = column - half + k * (width + space)
                levels.loc[index, "right"] = column - half + k * (width + space) + width
    # Each level is known by its position and lists every level its links reach, directly or through others, both ways,
    # as |i|j|...|: its connected component of the links. A click on one keeps that whole chain in colour.
    levels["level"] = levels.index
    graph = nx.Graph()
    graph.add_nodes_from(levels.index)
    graph.add_edges_from((link["source"], link["target"]) for link in (links.to_dict("records") if links is not None else []))
    chain = {index: "|" + "|".join(str(member) for member in sorted(component)) + "|"
             for component in nx.connected_components(graph) for index in component}
    levels["linked"] = [chain[index] for index in levels.index]
    bars = []
    for record in levels.to_dict("records"):
        count = int(record.get("components") or 1)
        width = (record["right"] - record["left"] - space * (count - 1)) / count
        bars += [dict(record, start=record["left"] + k * (width + space), end=record["left"] + k * (width + space) + width)
                 for k in range(count)]
    # Every layer names the same y title, which Vega would otherwise merge from the layers' fields.
    title = PLOT + "orbital_energy"
    heights = alt.Scale(domain=list(domain), nice=False, zero=False)
    across = alt.Scale(domain=[-0.5, len(columns) - 0.5], nice=False, zero=False)
    # The columns are numbered; the axis, styled as every other, writes each number as its title.
    axis = alt.Axis(values=list(range(len(columns))), labelExpr=f"{json.dumps(list(columns))}[datum.value]", grid=False,
                    labelOverlap=False, labelLimit=0, title=None)
    x = lambda field: alt.X(f"{PLOT}{field}:Q", scale=across, axis=axis)
    y = alt.Y(f"{PLOT}orbital_energy:Q", scale=heights, title=title)
    # The clicked level: Vega-Lite holds a point selection's value as {field: [value]}, empty when nothing is chosen.
    pick = alt.selection_point(name="level_pick", fields=[f"{PLOT}level"], on="click")
    chosen = (f"!isValid(level_pick.{PLOT}level) || "
              f"indexof(datum.{PLOT}linked, '|' + level_pick.{PLOT}level[0] + '|') >= 0")
    layers = []
    if links is not None and len(links):
        joined = []
        for link in links.to_dict("records"):
            first, second = sorted((levels.loc[link["source"]], levels.loc[link["target"]]), key=lambda row: row.column)
            # A link belongs to the chain of the levels it joins.
            joined.append(dict(start=first.right, end=second.left, orbital_energy=first.orbital_energy,
                               target=second.orbital_energy, weight=link["weight"], linked=chain[link["source"]]))
        layers.append(_chart(pd.DataFrame(joined)).mark_rule(**_REFERENCE).encode(
            x=x("start"), x2=f"{PLOT}end", y=y, y2=alt.Y2(f"{PLOT}target", title=title),
            opacity=alt.condition(f"!({chosen})", alt.value(_FADED),
                                  alt.Opacity(f"{PLOT}weight:Q", scale=alt.Scale(domain=[0, 1], range=[0.25, 1]),
                                              legend=None))))
    fade = alt.condition(chosen, alt.value(1), alt.value(_FADED))
    layers.append(_chart(pd.DataFrame(bars)).mark_rule(strokeWidth=3, clip=True).encode(
        x=x("start"), x2=f"{PLOT}end", y=y, color=alt.Color(f"{PLOT}{color}:N", scale=scale), opacity=fade,
        tooltip=[PLOT + field for field in tooltip] + [alt.Tooltip(f"{PLOT}orbital_energy:Q", format=".4f")]))
    # A thin bar is hard to reach, so a wider transparent one takes the pointer and the click; its own opacity overrides
    # the highlight.
    layers.append(layers[-1].mark_rule(strokeWidth=12, clip=True).encode(opacity=alt.value(0)).add_params(pick))
    # One layer of every part: each + would copy the whole chart built so far. The links' opacity shows their weight, so
    # it keeps its own scale.
    return alt.layer(*layers).resolve_scale(opacity="independent")


# Colours of an atom's share of an orbital, from none to the largest, in the composition chart and the viewer.
COMPOSITION_COLORS = ("#efedf5", "#9e9ac8", "#3f007d")


def _bonded_groups(numbers, coordinates, tolerance=0.4):
    """The molecule's bonded fragments, each as its Hill formula and its atom groups in the order of its bonds.

    Bonds are those of ``runflow.reaction.bond_graph``: within ``tolerance`` angstrom of the sum of the covalent radii,
    so bonds still forming at a saddle are not. A group is a heavy atom with the hydrogens bonded to it, each hydrogen with its nearest heavy
    atom, or a hydrogen bonded to none; it is named by the list of its atoms, such as C1, H7, H8. Within a fragment the groups follow a depth-first walk along the bonds, from the end atom of lowest number
    and through the neighbours in input order, so bonded groups are mostly adjacent; the fragments come in the order of
    their first atom.

    Args:
        numbers: Atomic numbers.
        coordinates: Positions in angstrom, one row per atom.
        tolerance: Margin in angstrom beyond the sum of covalent radii within which two atoms are bonded.

    Returns:
        A list of pairs of a fragment's Hill formula, written for mhchem, and its groups, each a pair of a LaTeX label and the
        zero-based atoms it holds.
    """
    from runflow.reaction import bond_graph, fragments, hill_formula

    graph = bond_graph(numbers, coordinates, tolerance)
    distances = np.linalg.norm(coordinates[:, None] - coordinates[None], axis=2)
    # Each hydrogen bonded to a heavy atom joins its nearest one.
    owner = {atom: min(partners, key=lambda other: distances[atom, other]) for atom in graph if numbers[atom] == 1
             and (partners := [other for other in graph[atom] if numbers[other] != 1])}
    skeleton = graph.subgraph(atom for atom in graph if atom not in owner)
    result = []
    for members in fragments(graph):
        order = []
        # A walk along the bonds of each connected part of the fragment's skeleton, from its end atom of lowest number.
        for part in sorted((sorted(c) for c in nx.connected_components(skeleton.subgraph(members))), key=lambda c: c[0]):
            start = min(part, key=lambda atom: (skeleton.degree(atom) > 1, atom))
            order += list(nx.dfs_preorder_nodes(skeleton.subgraph(part), source=start))
        formula = hill_formula(numbers, members)
        groups = []
        for atom in order:
            hydrogens = sorted(other for other, centre in owner.items() if centre == atom)
            # The group as the list of its atoms, such as C1, H7, H8, the heavy atom first.
            names = [rf"\ce{{{ELEMENTS[numbers[member] - 1]}{member + 1}}}" for member in (atom, *hydrogens)]
            groups.append((f"${', '.join(names)}$", [atom, *hydrogens]))
        result.append((formula, groups))
    return result


def reaction_quantity(key, reaction):
    """A quantity of a frontier pair of two fragments, written for a ``runflow.reaction.Reaction``: its X, the donor of
    normal demand, becomes the first fragment's formula and its Y, the acceptor, the second's, such as C4H6 and C2H4,
    in the label and in the explanation alike."""
    original = quantity(key)
    names = {"X": rf"\ce{{{reaction.formula(0)}}}", "Y": rf"\ce{{{reaction.formula(1)}}}"}
    fill = lambda text: re.sub(r"\((X|Y)\)|\$(X|Y)\$",
                               lambda match: f"({names[match[1]]})" if match[1] else f"${names[match[2]]}$", text)
    return Quantity(fill(str(original)), fill(original.description))


# Quantities written for a reaction's fragments by ``reaction_quantity``.
REACTION_QUANTITIES = ("frontier_overlap", "frontier_pair", "frontier_stabilization", "lumo_population", "orbital_sum",
                       "orbital_overlap_density", "orbital_overlap", "reverse_overlap_density")


def bond_tex(reaction, pair):
    r"""A bond of a ``runflow.reaction.Reaction`` in mhchem's notation, such as $\ce{C1-C6}$."""
    return rf"$\ce{{{reaction.bond_name(pair)}}}$"


def pair_group_markdown(reaction, first, second):
    """Markdown bullets that define the groups of atom pairs of two fragments of a ``runflow.reaction.Reaction``, one per
    role that has pairs, each one short sentence that opens with the group's name in bold, as the plots name it."""
    groups = reaction.pair_groups(first, second)
    atoms = lambda pairs: [(reaction.fragments[first][a], reaction.fragments[second][b]) for a, b in pairs]
    name = lambda role: reaction.role_name(role, str(quantity(f"pairs_{role}")))
    either = lambda names: ", ".join(names[:-1]) + " or " + names[-1] if len(names) > 1 else names[0]
    lines = []
    if groups["forming"]:
        bonds = " and ".join(bond_tex(reaction, pair) for pair in atoms(groups["forming"]))
        lines.append(f"- **{name('forming')}** form the bonds {bonds}.")
    if groups["reacting"]:
        lines.append(f"- **{name('reacting')}** pair reacting atoms that do not bond.")
    if groups["spectator"]:
        heavy = sorted({atom for pair in atoms(groups["spectator"]) for atom in pair if atom not in reaction.reacting})
        listed = either([rf"$\ce{{{reaction.names[atom]}}}$" for atom in heavy])
        lines.append(f"- **{name('spectator')}** involve {listed}, which do not react.")
    if groups["hydrogen"]:
        lines.append(f"- **{name('hydrogen')}** involve a hydrogen that does not react.")
    return "\n".join(lines) + "\n"


def _atom_tex(numbers, atom):
    """A zero-based atom as its element symbol with its one-based number as a subscript, as the viewers name it."""
    return rf"$\mathrm{{{ELEMENTS[numbers[atom] - 1]}}}_{{{atom + 1}}}$"


def _part_tex(numbers, part):
    """The LaTeX name of a part of an orbital: an atom as the viewers name it, or the letter of an angular momentum."""
    return _atom_tex(numbers, part[1])[1:-1] if part[0] == "atom" else momentum_letter(part[1])


def _part_shares(matrix, part, momenta):
    """An orbital's shares on the atoms for one part of it, as ``VolumeViewer`` colours them: the values, every atom's
    hover text and the part's colour scale. The whole orbital and one atom take $w_A$, one atom's alone; the functions of
    one angular momentum take $w_{A,l}$."""
    texts = [_share_text(row, momenta) for row in matrix]
    if part is None:
        return matrix.sum(axis=1), texts, "whole"
    if part[0] == "momentum":
        return matrix[:, part[1]], texts, f"l{part[1]}"
    values = np.zeros(len(matrix))
    values[part[1]] = matrix[part[1]].sum()
    return values, texts, "whole"


def _share_text(part, momenta):
    """An atom's share of an orbital in percent as one equation for hover text: $w_A$ as the sum of its parts $w_{A,l}$
    of at least 0.05%, each with its value in parentheses, then the total."""
    percent = unit_latex("percent")
    value = lambda number: f"{number:.1f}".replace("-0.0", "0.0") + rf"\,{percent}"
    parts = [(letter, number) for letter, number in zip(momenta, part) if abs(number) >= 0.05]
    if len(parts) > 1:
        terms = "+".join(rf"w_{{A,{letter}}}\,({value(number)})" for letter, number in parts)
        return rf"$w_A={terms}={value(part.sum())}$"
    if parts:
        return rf"$w_A=w_{{A,{parts[0][0]}}}={value(part.sum())}$"
    return rf"$w_A={value(part.sum())}$"


# Opacity of the levels and links a click on another level leaves out.
_FADED = 0.2


# Mulliken's letters of representations by dimension (t also written f), then the Greek names of linear molecules by
# angular momentum about the axis.
_IRREP_ORDER = ["a", "b", "e", "t", "f", "g", "h", "sigma", "pi", "delta", "phi", "gamma"]


def _irrep_order(label):
    """Sort key of a representation's label in LaTeX: Mulliken's order of letters, A, B, E, T, G, H, then the linear
    molecules' Sigma, Pi, Delta, ... in either case, then the label, so a' precedes a'' and a_{1} precedes b_{1};
    unknown or empty labels come last."""
    name = re.match(r"\\?([A-Za-z]+)", label or "")
    word = name[1].lower() if name else ""
    greek = word if label.startswith("\\") else word[:1]
    return (_IRREP_ORDER.index(greek) if greek in _IRREP_ORDER else len(_IRREP_ORDER), label)


def _frontier_names(shown, spin=None):
    """HOMO, HOMO_1, HOMO_2, ... for the occupied sets shown and LUMO, LUMO_1, ... for the unoccupied ones, the
    subscript counting sets from the frontier, in LaTeX, by set; ``spin``, alpha or beta for an unrestricted
    wavefunction, adds the channel as a superscript, such as HOMO^beta."""
    occupied = [s for s in shown if s.occupied][::-1]
    virtual = [s for s in shown if not s.occupied]
    channel = rf"^{{\{spin}}}" if spin else ""
    names = {id(s): r"$\mathrm{HOMO}" + channel + (f"_{{{k}}}" if k else "") + "$" for k, s in enumerate(occupied)}
    names.update({id(s): r"$\mathrm{LUMO}" + channel + (f"_{{{k}}}" if k else "") + "$" for k, s in enumerate(virtual)})
    return names


def _levels_chart(channels, window=4):
    """Orbital energies around the gap, in eV, as a ``level_diagram``: one column per symmetry of each spin channel,
    coloured by occupation, each set named by its position from the frontier on hover. ``channels`` are pairs of a
    spin, alpha or beta for an unrestricted wavefunction or None for a restricted one, and its orbital sets."""
    species = lambda s: s.irrep.orbital() if s.irrep is not None else ""
    columns, rows = [], []
    for spin, sets in channels:
        shown = _frontier(sets, window, True) + _frontier(sets, window, False)
        names = _frontier_names(shown, spin)
        kinds = sorted(dict.fromkeys(species(s) for s in shown), key=_irrep_order)
        offset = len(columns)
        columns += [", ".join(part for part in (rf"$\{spin}$" if spin else "", f"${kind}$" if kind else "") if part)
                    for kind in kinds]
        rows += [dict(column=offset + kinds.index(species(s)), orbital_energy=_to_ev(s.energy), components=len(s.indices),
                      orbital=f"${s.label()}$", frontier_level=names[id(s)], degeneracy=len(s.indices),
                      occupation="Occupied" if s.occupied else "Unoccupied",
                      character=f"${s.character_label()}$" if s.character_label() else "") for s in shown]
    levels = pd.DataFrame(rows)
    tooltip = ["frontier_level", "orbital", *(["character"] if levels.character.astype(bool).any() else []), "occupation",
               "degeneracy"]
    return level_diagram(levels, columns, color="occupation",
                         scale=alt.Scale(domain=["Occupied", "Unoccupied"]), tooltip=tooltip)


# Tableau's 20 categorical colours, in its own order of pairs.
TABLEAU20 = ["#4e79a7", "#a0cbe8", "#f28e2b", "#ffbe7d", "#59a14f", "#8cd17d", "#b6992d", "#f1ce63", "#499894",
             "#86bcb6", "#e15759", "#ff9d9a", "#79706e", "#bab0ac", "#d37295", "#fabfd2", "#b07aa1", "#d4a6c8",
             "#9d7660", "#d7b5a6"]


def _distinct_colors(count):
    """``count`` colours, no two alike: Tableau's ten main colours for up to ten, its twenty for up to twenty, and
    beyond that hues spread by the golden angle at alternating lightness."""
    if count <= 10:
        return TABLEAU20[::2][:count]
    if count <= 20:
        return TABLEAU20[:count]
    import colorsys
    return ["#" + "".join(f"{round(255 * c):02x}" for c in colorsys.hls_to_rgb((k * 0.381966) % 1, 0.45 + 0.15 * (k % 2), 0.6))
            for k in range(count)]


def _title_math(title):
    """A Gaussian job title with its singlet and triplet states typeset: S0 becomes $S_{0}$ and "S0 to Sn" an arrow
    between states. Titles stay plain text in the input, where a backslash would break Gaussian's archive entry."""
    state = r"\b([ST])(\d+|n)\b"
    title = re.sub(state + r"\s+to\s+" + state, lambda m: f"${m[1]}_{{{m[2]}}}\\rightarrow {m[3]}_{{{m[4]}}}$", title)
    # States outside the math already written.
    parts = re.split(r"(\$[^$]*\$)", title)
    return "".join(part if part.startswith("$") else re.sub(state, lambda m: f"${m[1]}_{{{m[2]}}}$", part)
                   for part in parts)


def _quantities(rows):
    """Table of quantity, value and description rows; the Description column only when some row has one."""
    table = pd.DataFrame([row if len(row) == 3 else (*row, "") for row in rows], columns=["quantity", "value", "description"])
    return table if table.description.astype(bool).any() else table.drop(columns="description")


def _irrep(label):
    """A Gaussian irreducible-representation label, such as A, B1U, A' or SGG, in Mulliken notation as LaTeX."""
    match = re.fullmatch(r"(SG|PI|DLT|PHI|[ABET])(\d*)([GU]?)('*|\"?)", label.strip().upper().replace("?", ""))
    if not match:
        return label
    letter = {"SG": r"\Sigma", "PI": r"\Pi", "DLT": r"\Delta", "PHI": r"\Phi"}.get(match[1], match[1])
    subscript = match[2] + match[3].lower()
    primes = "''" if match[4] == '"' else match[4]
    return f"${letter}" + (f"_{{{subscript}}}" if subscript else "") + primes + "$"


def _lower_label(label):
    """Lower-case Mulliken label of a one-particle function, such as e_{1u} for E_{1u}."""
    for upper, lower in ((r"\Sigma", r"\sigma"), (r"\Pi", r"\pi"), (r"\Delta", r"\delta")):
        if label.startswith(upper):
            return lower + label[len(upper):]
    return label[0].lower() + label[1:]


class _LabelledFrames(list):
    """XYZ frames with optional one-based landmarks for the molecular viewer."""

    def __init__(self, frames, frame_labels):
        super().__init__(frames)
        self.frame_labels = frame_labels


def _frames(numbers, geometries):
    """XYZ frames of matching geometries in angstrom."""
    return xyz_frames(numbers, np.asarray(geometries, dtype=float) * ureg.angstrom)


def _to_ev(value):
    """Energy in hartree converted to eV."""
    return (value * ureg.hartree).to("eV").magnitude


# One hartree per particle in kilojoules per mole, as Gaussian's conversion reference gives it.
HARTREE_KJ = (1 * ureg.hartree * ureg.avogadro_constant).to("kilojoule/mole").magnitude


def _to_kj(value):
    """A thermal contribution printed in kilocalories per mole, converted to kilojoules per mole."""
    return (value * ureg.kilocalorie / ureg.mole).to("kilojoule/mole").magnitude


# A scale leaving room at its ends: a zoomable chart clips its marks to the plot, which would cut markers on the edges.
_MARGIN = alt.Scale(zero=False, padding=10)
# Every dashed reference line: a limit, a saddle, a region's border. A line given only its y or x spans the whole plot.
_REFERENCE = dict(strokeWidth=1.5, strokeDash=[5, 4], color="#595959", clip=True)
# The limit of an RMS criterion, dotted as its data line is, beside the limit of a maximum on one plot.
_RMS_REFERENCE = {**_REFERENCE, "strokeDash": [2, 2]}


def _chart(data):
    """Altair chart of a table whose columns are renamed to their plot fields."""
    return alt.Chart(data.rename(columns=lambda name: PLOT + name))


def _hover(chart):
    """The chart with a hover box listing its encoded x, y and colour fields, unless it declares its own. Every
    drawn line or point layer of a layered chart gets one; reference rules stay silent, since their second endpoints
    are not data fields."""
    if isinstance(chart, alt.LayerChart):
        chart.layer = [layer if isinstance(layer, alt.Chart) and getattr(layer.mark, "type", None) == "rule"
                       else _hover(layer) for layer in chart.layer]
        return chart
    if chart.encoding.tooltip is not alt.Undefined:
        return chart
    fields = [channel.shorthand for channel in (chart.encoding.x, chart.encoding.y, chart.encoding.color)
              if channel is not alt.Undefined and isinstance(getattr(channel, "shorthand", None), str)]
    return chart.encode(tooltip=[alt.Tooltip(field, format=".6~g") if field.endswith(":Q") else alt.Tooltip(field)
                                 for field in fields])


def _hovered(method):
    """Decorate a chart method so that every chart it returns, alone or in a tuple, has a hover box."""
    def wrapper(*args, **kwargs):
        result = method(*args, **kwargs)
        return tuple(map(_hover, result)) if isinstance(result, tuple) else _hover(result)
    wrapper.__doc__, wrapper.__name__ = method.__doc__, method.__name__
    return wrapper


def _annotation(chart, **style):
    """Text marks written in a plot: dark text over a white halo of the same text, so that the marks they cross
    stay behind it, instead of running through it; clipped to the plot when it is zoomed. The chart carries the
    text and its position; the result is the halo and the text, two charts to layer with the plot's others."""
    style = dict(fontSize=13, clip=True) | style
    return [chart.mark_text(color="white", stroke="white", strokeWidth=4, strokeJoin="round", **style),
            chart.mark_text(color="#333333", **style)]


def _regions(field, low, high, regions):
    """Layers dividing a spectrum's x axis between ``low`` and ``high`` into regions: a dashed line at each border
    inside that range. The regions are named on hover of each band, by ``_region``, not written in the plot."""
    shown = [(name, max(lower, low), min(upper, high)) for name, lower, upper in regions if lower < high and upper > low]
    borders = sorted({edge for _, lower, upper in shown for edge in (lower, upper)} - {low, high})
    return [alt.Chart(pd.DataFrame({PLOT + field: borders})).mark_rule(
        **{**_REFERENCE, "color": "#adb5bd"}).encode(x=f"{PLOT}{field}:Q")]


def _region(value, regions):
    """Name of the region a value falls in, or an empty name outside them all."""
    return next((name for name, lower, upper in regions if lower <= value < upper), "")


def _series(label):
    """Colour encoding of a single plotted quantity, so its chart carries a legend naming it."""
    return alt.Color(f"{PLOT}series:N", scale=alt.Scale(domain=[label]))


def _mode_tooltip(table):
    """Hover box of a normal mode: all the columns of its table that the job printed, in physical order."""
    fields = (("mode", "N", None), ("mode_character", "N", None), ("symmetry", "N", None), ("frequency", "Q", ".2f"),
              ("reduced_mass", "Q", ".4f"), ("force_constant", "Q", ".4f"), ("intensity", "Q", ".3f"))
    return [alt.Tooltip(f"{PLOT}{name}:{kind}", **({"format": style} if style else {}))
            for name, kind, style in fields if name in table]


def _step_path(data, x, y):
    """A step-after path, one line per run of points of one status, each coloured by that status; the piece into a change
    of status takes the colour of the point it arrives at. A line per pair would draw a node per pair."""
    rows, segment = [], -1
    for index in range(len(data) - 1):
        first, second = data.iloc[index], data.iloc[index + 1]
        status = second["convergence"]
        if not rows or rows[-1]["convergence"] != status:
            segment += 1
            rows.append({x: first[x], y: first[y], "convergence": status, "segment": segment})
        rows.append({x: second[x], y: first[y], "convergence": status, "segment": segment})
        rows.append({x: second[x], y: second[y], "convergence": status, "segment": segment})
    return pd.DataFrame(rows)


def _marker_rows(frame, field, group=None, maximum=40):
    """Rows a line shows markers for, as thin_line_markers samples a point overlay: at most ``maximum`` rows of each
    series, evenly spaced in order with both endpoints kept."""
    columns = [field] + ([group] if group else [])
    data = frame.sort_values(columns)
    parts = []
    for _, series in (data.groupby(group, sort=False) if group else [(None, data)]):
        count = len(series)
        parts.append(series if count <= maximum
                     else series.iloc[np.rint(np.linspace(0, count - 1, maximum)).astype(int)])
    return pd.concat(parts).sort_values(columns)


def _fchk_digest(path):
    """First sixteen hex digits of a formatted checkpoint's digest, read once per checkpoint and stat."""
    info = Path(path).stat()
    return _checkpoint_digest(str(Path(path).resolve()), info.st_mtime_ns, info.st_size)


@lru_cache(maxsize=4)
def _fchk_parsed(path, digest):
    return read_fchk_records(path)


def _records(path):
    """The records of a formatted checkpoint, parsed once per page; a copy, so callers may add their own keys."""
    return dict(_fchk_parsed(str(Path(path).resolve()), _fchk_digest(path)))


def _fchk_pickled(path, kind, compute):
    """``compute()`` for a formatted checkpoint, cached on disk by the checkpoint's content and runflow's source."""
    cache = CACHE_FCHK / f"{Path(path).stem}-{_fchk_digest(path)}-{kind}-{_parser_version()[:12]}.pickle"
    try:
        return pickle.loads(cache.read_bytes())
    except (OSError, EOFError, pickle.UnpicklingError):
        pass
    result = compute()
    CACHE_FCHK.mkdir(parents=True, exist_ok=True)
    # Written beside its final name and moved, so a parallel reader never sees half a file.
    partial = cache.with_suffix(f".{os.getpid()}.part")
    partial.write_bytes(pickle.dumps(result))
    partial.replace(cache)
    return result


@lru_cache(maxsize=16)
def _overlap_cached(path):
    """Overlap matrix of a formatted checkpoint's basis, or None when its shells are not supported."""
    def compute():
        try:
            return overlap_matrix(_records(path))
        except (KeyError, ValueError, ImportError):
            return None
    return _fchk_pickled(path, "overlap", compute)


@lru_cache(maxsize=16)
def _symmetry_cached(path, spin="alpha"):
    """Symmetry of the canonical orbitals of one spin channel of a formatted checkpoint, or None when they cannot be
    classified."""
    def compute():
        try:
            return orbital_symmetry(_records(path), spin=spin)
        except (KeyError, ValueError, np.linalg.LinAlgError):
            return None
    return _fchk_pickled(path, f"symmetry-{spin}", compute)


# Spin letters of excited states by multiplicity 2S+1.
SPIN_LETTERS = {1: "S", 2: "D", 3: "T", 4: "Q"}


def _same_name(latex, code):
    """Whether a LaTeX Schoenflies name and Gaussian's point-group code name the same group."""
    plain = lambda text: re.sub(r"[${}_\\]", "", text).lower().replace("infty", "*")
    return plain(latex) == plain(_point_group(code))


def _transfer(origin, axes, hole, particle):
    """Charge-transfer descriptors of hole and particle densities on a grid: the transferred charge q_CT, the
    distance d_CT between the centroids of the density gained and lost (Le Bahers, Adamo and Ciofini, J. Chem. Theory
    Comput. 7, 2498 (2011)), both in e and angstrom, the hole-particle centroid distance D in angstrom and their
    overlap, the integral of sqrt(rho_h rho_p)."""
    hole, particle = hole.astype(float), particle.astype(float)
    step = np.diag(axes)
    coordinates = [origin[k] + step[k] * np.arange(hole.shape[k]) for k in range(3)]
    volume = np.prod(step)

    def centroid(density):
        """Centroid of a non-negative density on the grid, in bohr."""
        return np.array([coordinates[k] @ density.sum(axis=tuple(j for j in range(3) if j != k))
                         for k in range(3)]) / density.sum()

    difference = particle - hole
    gain, loss = np.clip(difference, 0, None), np.clip(-difference, 0, None)
    bohr = (1 * ureg.bohr).to("angstrom").magnitude
    return dict(transferred=gain.sum() * volume, transfer_distance=np.linalg.norm(centroid(gain) - centroid(loss)) * bohr,
                separation=np.linalg.norm(centroid(particle) - centroid(hole)) * bohr,
                overlap=np.sqrt(hole * particle).sum() * volume)


def _state_densities(path, groups, spacing, bounds=None):
    """Hole and particle densities of groups of degenerate excited states from their printed amplitudes, on one
    grid, cached on disk by the checkpoint's content, the amplitudes and the grid.

    ``groups`` holds, per group, each state's (occupied, virtual, amplitude) excitations with one-based orbital
    indices. A group's hole matrix is the mean over its states of X X^T and its particle matrix that of X^T X, each
    scaled to unit trace, so each density holds one electron; their eigenvectors combine the canonical orbitals into
    natural transition orbitals, so the densities keep every cross term. Degenerate states are averaged, as their
    level is. Gaussian prints only amplitudes above 0.1, so the densities are those of the printed part."""
    key = hashlib.sha256(Path(path).read_bytes() + repr((groups, spacing, None if bounds is None else
                                                          np.round(np.asarray(bounds), 6).tolist())).encode()).hexdigest()[:16]
    cache = CACHE_FCHK / f"{Path(path).stem}-states-{key}.npz"
    if cache.exists():
        with np.load(cache) as stored:
            return stored["origin"], stored["axes"], stored["atoms"], stored["holes"], stored["particles"]
    records = _records(path)
    basis = int(records["Number of basis functions"])
    coefficients = np.asarray(records["Alpha MO coefficients"], dtype=float).reshape(-1, basis)
    rows, weights = [], []
    for group in groups:
        occupied = sorted({i - 1 for state in group for i, _, _ in state})
        virtual = sorted({a - 1 for state in group for _, a, _ in state})
        hole, particle = np.zeros((len(occupied),) * 2), np.zeros((len(virtual),) * 2)
        for state in group:
            x = np.zeros((len(occupied), len(virtual)))
            for i, a, amplitude in state:
                x[occupied.index(i - 1), virtual.index(a - 1)] += amplitude
            hole += x @ x.T
            particle += x.T @ x
        for matrix, indices in ((hole, occupied), (particle, virtual)):
            values, vectors = np.linalg.eigh(matrix / np.trace(matrix))
            start = len(rows)
            rows += list(vectors.T @ coefficients[indices])
            weights.append((start, np.clip(values, 0, None)))
    combined = dict(records)
    combined["Alpha MO coefficients"] = np.concatenate(rows)
    table = np.zeros((len(weights), len(rows)))
    for row, (start, values) in enumerate(weights):
        table[row, start:start + len(values)] = values
    origin, axes, atoms, densities = density_grid(combined, list(range(len(rows))), table, spacing=spacing, bounds=bounds)
    densities = np.asarray(densities, dtype=np.float32)
    holes, particles = densities[0::2], densities[1::2]
    CACHE_FCHK.mkdir(parents=True, exist_ok=True)
    # Uncompressed: smooth single-precision fields hardly compress, and reading them back stays a copy.
    np.savez(cache, origin=origin, axes=axes, atoms=atoms, holes=holes, particles=particles)
    return origin, axes, atoms, holes, particles


def _orbital_entries(sets, names=None):
    """Snapshot titles and orbitals of the sets: each title has the set's name from ``names`` when given, such as
    HOMO or LUMO_1, the label, the Cartesian function a degenerate component transforms like, as in 1e_{1g}(xz), the
    character and the energy; each orbital is a zero-based index, or for symmetry-adapted components the canonical
    indices and the weights that combine them."""
    entries = []
    for orbital_set in sets:
        count = len(orbital_set.indices)
        name = [names[id(orbital_set)]] if names else []
        for k, index in enumerate(orbital_set.indices):
            if orbital_set.components:
                parts = name + [f"${orbital_set.label()}({orbital_set.components[k]})$"]
                index = (tuple(orbital_set.indices), tuple(round(float(w), 12) for w in orbital_set.rotation[:, k]))
            else:
                parts = name + [f"${orbital_set.label()}$"] + ([f"orbital {orbital_set.indices[k] + 1}"] if count > 1 else [])
            if orbital_set.character_label():
                parts.append(f"${orbital_set.character_label()}$")
            parts.append(rf"$\epsilon={{{_to_ev(orbital_set.energy):.3f}}}\,{unit_latex('eV')}$")
            entries.append((", ".join(parts), index))
    return entries


def _orbital_cached(path, index, spacing, isovalue, part=None, spin="alpha"):
    """An orbital of a formatted checkpoint on a fine grid over the box where its amplitude reaches an eighth of the
    isovalue, cached on disk by the checkpoint's content and the grid settings. ``index`` is a zero-based orbital,
    or canonical indices and weights whose combination is the orbital, as for symmetry-adapted components.

    ``part``, ``("atom", A)`` or ``("momentum", l)``, keeps only the terms of the orbital's own expansion on the
    functions of atom A, psi^(A) = sum over mu in A of c_mu phi_mu, or of angular momentum l, on its own box, or on
    the whole orbital's box when it never reaches an eighth of the isovalue; the parts of each kind add up to the
    orbital. ``spin`` chooses the alpha or beta orbitals of an unrestricted
    wavefunction."""
    digest = _fchk_digest(path)
    name = index if isinstance(index, (int, np.integer)) else "mix" + hashlib.sha256(repr(index).encode()).hexdigest()[:12]
    piece = ("" if part is None else f"-{part[0]}{part[1]}-own") + ("" if spin == "alpha" else f"-{spin}")
    cache = CACHE_FCHK / f"{Path(path).stem}-{digest}-orbital{name}{piece}-{spacing}-{isovalue}-eighth.npz"
    if cache.exists():
        stored = np.load(cache)
        return stored["origin"], stored["axes"], stored["atoms"], stored["values"]
    records = _records(path)
    basis = int(records["Number of basis functions"])
    coefficients = np.asarray(spin_record(records, spin, "{Spin} MO coefficients"), dtype=float).reshape(-1, basis)
    vector = (coefficients[index] if isinstance(index, (int, np.integer))
              else np.asarray(index[1]) @ coefficients[list(index[0])])
    if part is not None:
        atoms, momenta = basis_function_owners(records)
        vector = np.where((atoms if part[0] == "atom" else momenta) == part[1], vector, 0.0)
    target = dict(records, **{"Alpha MO coefficients": vector[None, :]})
    # The box where this field reaches an eighth of the isovalue, found on a coarse grid with a margin. A part can
    # reach beyond the whole orbital's box, so it takes its own.
    coarse = 0.4
    origin, _, _, values = orbital_grid(target, 0, spacing=coarse)
    inside = np.argwhere(np.abs(values) >= isovalue / 8)
    if len(inside):
        lower, upper = origin + (inside.min(axis=0) - 3) * coarse, origin + (inside.max(axis=0) + 3) * coarse
    else:
        origin, axes, _, values = _orbital_cached(path, index, spacing, isovalue, spin=spin)
        lower, upper = origin, origin + (np.asarray(values.shape) - 1) * np.diag(axes)
    # The coarse grid can miss a thin lobe, so the fine box grows past every face the field still reaches.
    while True:
        origin, axes, atoms, values = orbital_grid(target, 0, spacing=spacing, bounds=(lower, upper))
        reached = np.abs(values) >= isovalue / 8
        low = [reached.take(0, axis=k).any() for k in range(3)]
        high = [reached.take(-1, axis=k).any() for k in range(3)]
        if not any(low) and not any(high):
            break
        lower = lower - 3 * coarse * np.asarray(low)
        upper = upper + 3 * coarse * np.asarray(high)
    CACHE_FCHK.mkdir(parents=True, exist_ok=True)
    # Half precision, about 0.05 % of a value, is finer than the 0.1 % the page writes the field in, and halves the
    # cache; uncompressed, as such a field hardly compresses, so reading it back is a copy. The orbital is returned as
    # stored, in single precision for the arithmetic, so a fresh and a cached render encode the same field.
    values = values.astype(np.float16)
    np.savez(cache, origin=origin, axes=axes, atoms=atoms, values=values)
    return origin, axes, atoms, values.astype(np.float32)


def _transition_cached(path, spacing, bounds=None):
    """Hole and particle densities of the natural transition orbitals of a formatted checkpoint, on one grid around
    the molecule, cached on disk by the checkpoint's content and the grid spacing.

    Gaussian stores hole k as the k-th occupied orbital below the last and particle k as the k-th unoccupied one, each with the pair's
    weight lambda_k as its orbital energy. Every pair adds lambda_k / sum(lambda) times its squared hole and particle
    to the two densities, so each holds one electron and the decomposition is complete. ``bounds``, the lower and upper
    corners in bohr, replaces the default box around the molecule. Returns the grid origin, step vectors and atom rows
    in bohr, the two densities in a_0^-3, the number of pairs and the sum of their weights."""
    digest = _fchk_digest(path)
    box = "" if bounds is None else "-" + hashlib.sha256(np.round(np.asarray(bounds), 6).tobytes()).hexdigest()[:8]
    cache = CACHE_FCHK / f"{Path(path).stem}-{digest}-transition-{spacing}{box}.npz"
    if cache.exists():
        with np.load(cache) as stored:
            return (stored["origin"], stored["axes"], stored["atoms"], stored["hole"], stored["particle"],
                    int(stored["pairs"]), float(stored["total"]))
    records = _records(path)
    occupied = int(records["Number of alpha electrons"])
    weights = np.asarray(records["Alpha Orbital Energies"], dtype=float)[:occupied][::-1]
    shares = weights / weights.sum()
    # One pass over the grid for both densities: holes first, then particles, each density weighting its own half.
    orbitals = [occupied - 1 - k for k in range(occupied)] + [occupied + k for k in range(occupied)]
    zeros = np.zeros(occupied)
    origin, axes, atoms, (hole, particle) = density_grid(records, orbitals, [np.concatenate([shares, zeros]),
                                                                              np.concatenate([zeros, shares])],
                                                         spacing=spacing, bounds=bounds)
    CACHE_FCHK.mkdir(parents=True, exist_ok=True)
    hole, particle = hole.astype(np.float32), particle.astype(np.float32)
    # Uncompressed: smooth single-precision fields hardly compress, and reading them back stays a copy.
    np.savez(cache, origin=origin, axes=axes, atoms=atoms, hole=hole, particle=particle, pairs=occupied,
             total=weights.sum())
    return origin, axes, atoms, hole, particle, occupied, float(weights.sum())


def _nominal(field, order):
    """A categorical axis in a fixed order, kept when charts are layered, whose labels are its values, not numbers.
    Every category keeps its label: Vega would judge overlap from a label's LaTeX source, longer than its typeset
    text, and drop some."""
    return alt.X(f"{PLOT}{field}:N", sort=order, scale=alt.Scale(domain=order),
                 axis=alt.Axis(labelExpr="datum.value", labelOverlap=False, labelLimit=0))


# Formatted checkpoints converted from retained binary ones, for pages only.
CACHE_FCHK = Path.home() / ".cache/research-findings/fchk"
# Parsed program logs, reused while a log and the parser are unchanged.
PARSED = Path.home() / ".cache/research-findings/parsed"


@lru_cache(maxsize=1)
def _parser_version():
    """Digest of runflow's own source, so a parser change invalidates every parsed log."""
    digest = hashlib.sha256()
    for path in sorted(Path(runflow.__file__).parent.rglob("*.py")):
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _parsed(program, log):
    """A Gaussian or Lotus log parsed by runflow: Gaussian logs from runflow's cache, which notebook cells share,
    and Lotus logs from this one, reused while the log and the parser are unchanged."""
    # Parsing every Gaussian log took most of a page build; runflow caches that parse by the log's content.
    if program == "gaussian":
        return read_gaussian(log)
    info = log.stat()
    key = hashlib.sha256(f"{program}|{log.resolve()}|{info.st_size}|{info.st_mtime_ns}|{_parser_version()}".encode())
    cached = PARSED / f"{key.hexdigest()}.pickle"
    try:
        return pickle.loads(cached.read_bytes())
    except (OSError, EOFError, pickle.UnpicklingError):
        pass
    result = read_lotus(log)
    PARSED.mkdir(parents=True, exist_ok=True)
    # Written beside its final name and moved, so a parallel reader never sees half a file.
    partial = cached.with_suffix(f".{os.getpid()}.part")
    partial.write_bytes(pickle.dumps(result))
    partial.replace(cached)
    return result


@lru_cache(maxsize=1)
def _original_folders():
    """Map original native-output folder paths to current scientific folders.

    Args:
        None.
    Returns:
        Mapping from preserved project/workflow/run paths to current local directories.
    """
    root = Path(__file__).resolve().parents[1] / "projects"
    mapping = {}
    for readme in root.rglob("README.md"):
        if "original-folder" not in readme_metadata(readme.parent):
            continue
        folder = readme.parent
        chain = []
        for depth in range(1, len(folder.relative_to(root).parts) + 1):
            parent = root.joinpath(*folder.relative_to(root).parts[:depth])
            original = readme_metadata(parent).get("original-folder")
            if not original:
                break
            chain.append(str(original))
        else:
            mapping["/".join(chain)] = folder
    return mapping


def _checkpoint_path(folder, value):
    """Resolve a checkpoint reference without rewriting paths in retained native output.

    Args:
        folder: Current run directory.
        value: Checkpoint path recorded by Gaussian.
    Returns:
        Corresponding local formatted-checkpoint path, whether or not retained locally.
    """
    direct = (folder / value).resolve().with_suffix(".fchk")
    if direct.exists():
        return direct
    # A formatted checkpoint kept in the folder's checkpoints/ under the checkpoint's own name, whatever folder the
    # job wrote it in.
    kept = folder / "checkpoints" / Path(value).with_suffix(".fchk").name
    if kept.exists():
        return kept.resolve()
    mapping = _original_folders()
    old = next((key for key, current in mapping.items() if current == folder.resolve()), None)
    if old is None:
        return direct
    if Path(value).is_absolute():
        relative = value.split("/projects/", 1)[-1]
    else:
        relative = os.path.normpath(old + "/" + value)
    for key, current in sorted(mapping.items(), key=lambda item: -len(item[0])):
        if relative.startswith(key + "/"):
            return (current / relative[len(key) + 1:]).with_suffix(".fchk")
    return direct


@lru_cache(maxsize=None)
def _sha256_by_stat(path, modified, size):
    """SHA-256 of a file, cached by its path, modification time and size, so each version of it is read once."""
    with open(path, "rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def _file_sha256(path):
    """SHA-256 of a file, read once per version of it: workflow diagrams and scans ask for a log's digest many times."""
    info = Path(path).stat()
    return _sha256_by_stat(str(Path(path).resolve()), info.st_mtime_ns, info.st_size)


def _checkpoint_digest(path, modified, size):
    """First sixteen hex digits of a checkpoint's digest, cached by its path and stat so each checkpoint is read once."""
    return _sha256_by_stat(path, modified, size)[:16]


def _worst_status(findings):
    """Worst status implied by the findings; Succeeded when there are none."""
    order = {"Not run": 0, "Submitted": 1, "Succeeded": 2, "Problems": 3, "Failed": 4}
    return max((finding.status for finding in findings), key=order.get, default="Succeeded")


def _coalesced(findings):
    """Drop findings that restate another finding and normalise wrapper failures."""
    native = [finding for finding in findings if finding.code == "error" and finding.source != "runflow"]
    stepped = {finding.source for finding in native if finding.diagnostic_code.endswith("optimization_steps_exceeded")}
    linked = {finding.source for finding in native if finding.diagnostic_code.endswith("termination")}
    eigen = {finding.source for finding in native if finding.diagnostic_code.endswith("wrong_negative_eigenvalues")}
    atomless = {finding.source for finding in native if finding.diagnostic_code.endswith("no_atoms")}
    kept = []
    seen = set()
    for finding in findings:
        if finding.code == "incomplete" and native:
            continue
        if finding.code == "error_context" and any(other.source == finding.source for other in native):
            continue
        if finding.code == "optimization_unconverged" and finding.source in stepped:
            continue
        if finding.code == "error" and finding.source != "runflow":
            if finding.diagnostic_code.endswith("optimization_stopped") and finding.source in stepped:
                continue
            if finding.diagnostic_code.endswith("optimization_stopped") and finding.source in eigen:
                continue
            if finding.diagnostic_code.endswith("input_molecular_specification") and finding.source in atomless:
                continue
            if finding.detail.startswith("Error termination request processed by link") and finding.source in linked:
                continue
        if finding.code == "script_error":
            match = re.search(r"returned non-zero exit status (\d+)", finding.detail)
            if match:
                if native:
                    continue
                replaced = Finding(finding.code, finding.source,
                                   ("Gaussian" if "g16" in finding.detail else "The calculation script") + f" exited with status {match[1]}.",
                                   diagnostic_code=finding.diagnostic_code)
                finding = replaced
        key = (finding.code, finding.source, finding.detail)
        if key in seen:
            continue
        seen.add(key)
        kept.append(finding)
    return kept

# Names of what a GIC line measures, by runflow's measure.
GIC_MEASURES = {"bond": "Bond length", "angle": "Bond angle", "dihedral": "Dihedral angle", "linear bend": "Linear bend",
                "cartesian": "Cartesian component", "centroid": "Centroid component", "dot product": "Dot product",
                "formula": "Formula"}
# Words for the actions of a GIC line, by runflow's action.
GIC_ACTIONS = {"active": "Active", "frozen": "Frozen", "inactive": "Inactive", "kill": "Removed with its dependents",
               "printonly": "Printed only", "modify": "Modified", "diff": "Numerical second derivatives",
               "unfrozen": "Unfrozen", "xyzonly": "Cartesian coordinates only"}
# Words for the standalone GIC lines, by runflow's command.
GIC_COMMANDS = {"freezeall": "Freeze all", "unfreezeall": "Unfreeze all", "removeall": "Remove all"}
# GIC options as the manual spells them, by runflow's lower-case name.
GIC_OPTIONS = {"nsteps": "NSteps", "stepsize": "StepSize", "min": "Min", "max": "Max", "fc": "FC",
               "forceconstant": "ForceConstant", "value": "Value", "onlyif": "OnlyIf", "ifnot": "IfNot"}


# Words for the actions of a ModRedundant line, by runflow's action.
MODREDUNDANT_ACTIONS = {"add": "Added", "activate": "Active", "freeze": "Frozen", "build": "Added with related coordinates",
                        "kill": "Removed with its dependents", "remove": "Removed", "diff": "Numerical second derivatives",
                        "hessian": "Initial Hessian element", "scan": "Scanned"}
# Bond orders of a connectivity section in words.
BOND_ORDERS = {1.0: "single", 1.5: "aromatic", 2.0: "double", 3.0: "triple"}
# Font Awesome icons in projects/icons for what a coordinate measures, by runflow's measure.
COORDINATE_ICONS = {"bond": "coordinate-bond", "angle": "coordinate-angle", "dihedral": "coordinate-dihedral",
                    "linear bend": "coordinate-angle", "cartesian": "coordinate-cartesian",
                    "centroid": "coordinate-centroid", "dot product": "coordinate-dot", "formula": "coordinate-formula"}
# Icons for what a line does to its coordinate, by the action's words.
ACTION_ICONS = {"Active": "action-active", "Added": "action-active", "Unfrozen": "action-active",
                "Frozen": "action-frozen", "Freeze all": "action-frozen", "Unfreeze all": "action-active",
                "Inactive": "action-inactive", "Scanned": "scan", "Removed": "action-removed",
                "Removed with its dependents": "action-removed", "Remove all": "action-removed",
                "Printed only": "action-print", "Modified": "action-modify",
                "Numerical second derivatives": "action-hessian", "Initial Hessian element": "action-hessian",
                "Added with related coordinates": "action-build", "Cartesian coordinates only": "coordinate-cartesian"}
# Names of the settings a GIC line gives, by runflow's option name.
SETTING_NAMES = {"nsteps": "Steps", "stepsize": "Step size", "min": "Lower bound", "max": "Upper bound",
                 "fc": "Force constant", "forceconstant": "Force constant", "value": "Value", "onlyif": "Only if",
                 "ifnot": "Unless"}


def _icon(icons, name, title):
    """An icon of the folder ``icons`` with ``title`` as its hover text; the title alone without a folder or icon."""
    return f'![{title}]({icons}{name}.svg "{title}"){{.workflow-status}}' if icons and name else title


def _coordinate_kind(measure, unit, icons):
    """What a coordinate measures, as its icon, or in words without icons, followed by its unit in brackets, the unit
    of every value in the row; None for nothing."""
    name = GIC_MEASURES.get(measure)
    if not name:
        return None
    shown = _icon(icons, COORDINATE_ICONS.get(measure), name)
    return f"{shown} $[{unit_latex(unit)}]$" if unit else shown


def _action_icons(words, icons):
    """Actions as icons with their words as hover text, or the words without icons; None for none."""
    return " ".join(_icon(icons, ACTION_ICONS.get(word), word) for word in words) or None


def _coordinate_value(value, digits=6):
    """A coordinate's value in LaTeX, in the unit its row's coordinate column gives; None for no value."""
    if value is None:
        return None
    return "$" + _number(value, digits).replace("$", "") + "$"


def _settings_table(rows):
    """Settings of a line as a subtable of option and value; None without any."""
    return pd.DataFrame(rows, columns=["option", "value"]) if rows else None


def _scan_rows(steps, step, start):
    """Rows of a scan's settings: its steps, its step size and, when the start is known, its last point."""
    rows = [(quantity("scan_steps"), steps), (quantity("scan_step_size"), _coordinate_value(step, 12))]
    if start is not None:
        rows.append((quantity("scan_last_point"), _coordinate_value(start + steps * step)))
    return rows


def _modredundant_definition(entry):
    """A ModRedundant line's coordinate in LaTeX: its printed function with the atoms as a subscript, a Cartesian
    line as the atom's position; the line as written when its type is unknown."""
    if not entry["type"]:
        return f"`{entry['text']}`"
    atoms = ",".join(r"\ast" if atom == "*" else str(atom) for atom in entry["atoms"])
    symbol = r"\mathbf{r}" if entry["type"] == "X" else rf"\mathrm{{{PRINTED[entry['type']]}}}"
    return f"${symbol}_{{{atoms}}}$"


def _modredundant_settings(entry, start):
    """What a ModRedundant line sets, as a subtable: a value, a scan, a Hessian element, limits and words not
    understood; None when it sets nothing."""
    rows = []
    if entry["value"] is not None:
        rows.append(("Value", _coordinate_value(entry["value"])))
    if entry["action"] == "scan" and entry["steps"] is not None and entry["step"] is not None:
        rows += _scan_rows(entry["steps"], entry["step"], start)
    if entry["hessian"] is not None:
        rows.append(("Diagonal element", _coordinate_value(entry["hessian"])))
    if entry["minimum"] is not None:
        rows.append(("Lower bound", _coordinate_value(entry["minimum"])))
    if entry["maximum"] is not None:
        rows.append(("Upper bound", _coordinate_value(entry["maximum"])))
    rows += [("Not understood", f"`{item}`") for item in entry["unparsed"]]
    return _settings_table(rows)


def _gic_group(entry):
    """Key of the GIC lines a table shows as one row: the label without its trailing number, the formula with its atom
    and label numbers left out, the actions and the settings; a standalone line is a row of its own."""
    if entry["kind"] != "coordinate":
        return ("line", entry["line"])
    shape = re.sub(r"(?<=[A-Za-z(,])\d+", "#", entry["expression"] or "")
    return (re.sub(r"\d+$", "", entry["label"] or ""), shape, tuple(entry["actions"]),
            tuple(sorted(entry["options"].items())), tuple(entry["unparsed"]))


def _gic_definition(entry):
    """A GIC line's formula in LaTeX, a sum of three or more consecutively numbered labels as a sum over n; the formula
    as written when it cannot be read; None for options on an existing label."""
    expression = entry["expression"]
    if not expression:
        return None
    terms = [re.fullmatch(r"([A-Za-z_]+)(\d+)", term.strip()) for term in expression.split("+")]
    if len(terms) >= 3 and all(terms) and len({term[1] for term in terms}) == 1:
        numbers = [int(term[2]) for term in terms]
        if numbers == list(range(numbers[0], numbers[0] + len(numbers))):
            name = terms[0][1].replace("_", r"\_")
            return f"$\\sum_{{n={numbers[0]}}}^{{{numbers[-1]}}}\\mathrm{{{name}}}_{{n}}$"
    try:
        return f"${latex(expression)}$"
    except ValueError:
        return f"`{expression}`"


# Atom and label numbers of a GIC formula: digits right after a letter, an opening parenthesis or a comma.
FORMULA_NUMBERS = re.compile(r"(?<=[A-Za-z(,])\d+")


def _group_formula(entries):
    """The formula of lines of one form written once for their n-th line, n being the number that ends each label,
    with every atom or label number that steps with n written as a multiple of n plus a constant; None when the
    labels carry no numbers or a number does not follow n.

    Returns:
        The formula and, in parentheses, the range of n in LaTeX, such as the formula of X(n) for n from 1 to 30, or None.
    """
    labels = [re.fullmatch(r"(.*?)(\d+)", entry["label"] or "") for entry in entries]
    if not all(labels) or any(not entry["expression"] for entry in entries):
        return None
    ns = [int(label[2]) for label in labels]
    if ns != list(range(ns[0], ns[0] + len(ns))):
        return None
    columns = [[int(value) for value in FORMULA_NUMBERS.findall(entry["expression"])] for entry in entries]
    if len({len(column) for column in columns}) != 1:
        return None
    written = []
    for values in zip(*columns):
        slope = values[1] - values[0]
        offset = values[0] - slope * ns[0]
        if any(value != slope * n + offset for value, n in zip(values, ns)):
            return None
        written.append(str(values[0]) if slope == 0 else
                       ("" if slope == 1 else str(slope)) + "n" + (f"+{offset}" if offset > 0 else f"{offset}" if offset else ""))
    template = FORMULA_NUMBERS.sub(lambda match, parts=iter(written): next(parts), entries[0]["expression"])
    try:
        formula = latex(template)
    except ValueError:
        return None
    return f"${formula}$ ($n={ns[0]},\\dots,{ns[-1]}$)"


def _gic_start(entry, printed, computed):
    """Start value of one labeled GIC line with its unit: Gaussian's printed value, else the value at the input
    geometry; bonds and Cartesian components in angstrom, angles in degrees, a formula in its own units."""
    label = (entry["label"] or "").lower()
    value = printed.get(label)
    unit = {"angstrom": "angstrom", "degree": "degree"}.get(entry["unit"])
    if value is None and label in computed:
        value = computed[label]
        # Gaussian's internal bohr and radians, converted for a coordinate printed in angstrom or degrees.
        if unit == "angstrom":
            value = (value * ureg.bohr).to("angstrom").magnitude
        elif unit == "degree":
            value = float(np.degrees(value))
    return value, unit


def _gic_row(entries, printed, computed, icons):
    """One row of the GIC table for lines of one form: the first and last labels and equations, what the coordinate
    measures, what the lines do, a subtable of their settings, and the start value when all the lines share it."""
    first, last = entries[0], entries[-1]
    if first["kind"] != "coordinate":
        word = GIC_COMMANDS.get(first.get("command")) or ", ".join(GIC_ACTIONS.get(a, a) for a in first["actions"]) or None
        return (f"`{first['text']}`", None, None, _action_icons([word] if word else [], icons), None, None)
    label = lambda entry: f"`{entry['label']}`" if entry["label"] else None
    labels = label(first) if len(entries) == 1 else (
        f"{label(first)}–{label(last)}" if first["label"] and last["label"] else None)
    definitions = [_gic_definition(entry) for entry in ((first,) if len(entries) == 1 else (first, last))]
    definition = (_group_formula(entries) if len(entries) > 1 else None) or ", …, ".join(text for text in definitions if text) or None
    words = [GIC_ACTIONS.get(action, action) for action in first["actions"]]
    options = first["options"]
    if "nsteps" in options:
        words = [word for word in words if word != "Active"] + ["Scanned"]
    if not words and first["expression"]:
        words = ["Active"]
    starts = [_gic_start(entry, printed, computed) for entry in entries]
    unit = starts[0][1]
    values = [value for value, _ in starts if value is not None]
    start = values[0] if len(values) == len(entries) and len(set(np.round(values, 6))) == 1 else None
    rows = []
    if "nsteps" in options and "stepsize" in options:
        rows += _scan_rows(options["nsteps"], options["stepsize"], start)
    for name, value in options.items():
        if name not in ("nsteps", "stepsize"):
            rows.append((SETTING_NAMES.get(name, name),
                         _coordinate_value(value, 12) if isinstance(value, float) else f"`{value}`"))
    rows += [("Not understood", f"`{item}`") for item in first["unparsed"]]
    return (labels, definition, _coordinate_kind(first.get("measure"), unit, icons), _action_icons(words, icons),
            _settings_table(rows), _coordinate_value(start))


class Calculation:
    """One calculation folder with its parsed Gaussian or Lotus results and runflow records."""

    def __init__(self, folder, log=None):
        """``log`` names the program log when it is not found by the run-folder convention, as for the viewer's
        dropped files."""
        self.folder = Path(folder)
        # Mode symmetry per linked job, found once.
        self._mode_symmetry = {}
        heading = next(line for line in (self.folder / "README.md").read_text().splitlines() if line.startswith("# "))
        # Calculation title: the README heading, with its inline math.
        self.title = heading.removeprefix("# ").strip()
        self.inputs = sorted(path for path in (self.folder / "inputs").glob("*") if path.is_file())
        logs = self.folder / "logs"
        # Program log: Gaussian's is named after the input file, Lotus writes lotus.log.
        candidates = [logs / f"{path.stem}.log" for path in self.inputs if path.suffix == ".gjf"] + [logs / "lotus.log"]
        self.log = Path(log) if log else next((path for path in candidates if path.exists()), None)
        # Program code: gaussian or lotus, None without a log.
        self.program = None if self.log is None else ("lotus" if self.log.name == "lotus.log" else "gaussian")
        self.result = _parsed(self.program, self.log) if self.log else None
        # The jobs a Gaussian input defines, read whether or not the calculation has output, since only the input holds
        # its GIC section; with output, an input runflow cannot read leaves none rather than breaking the page.
        inputs = [path for path in self.inputs if path.suffix == ".gjf"]
        try:
            self.gaussian_input = read_gaussian_input(inputs[0]) if inputs else []
        except (ValueError, IndexError, OSError):
            if self.result is None:
                raise
            self.gaussian_input = []
        # The input's jobs stand for the jobs while the calculation has no output.
        self.input_jobs = self.gaussian_input if self.result is None else []
        scheduler = logs / "scheduler.log"
        self.records = read_log(scheduler) if scheduler.exists() else []

    @property
    def jobs(self):
        """Linked Gaussian jobs as the output records them, or as the input defines them without output; empty for
        Lotus."""
        return self.result["jobs"] if self.program == "gaussian" else self.input_jobs

    def findings(self):
        """Parsed reasons behind the status, from the program output and the runflow records only."""
        if self.result is None:
            job = re.search(r"^- Slurm job `(\d+)`\.$", (self.folder / "README.md").read_text(), re.M)
            return [Finding("submitted", "", job[1]) if job else Finding("missing_log")]
        findings = []
        if self.program == "gaussian":
            state = self.result["status"]["state"]
            if state == "failed":
                findings.append(Finding("incomplete", "Gaussian", state))
            elif state in ("running", "pending"):
                findings.append(Finding("running", "Gaussian", state))
            elif state != "complete":
                findings.append(Finding("unfinished", "Gaussian"))
            for number, job in enumerate(self.jobs, 1):
                # A linked step is identified by what it does; the page already names the program.
                source = "Gaussian" if len(self.jobs) == 1 else self.step_name(number)
                findings += [Finding("error", source, error["message"], diagnostic_code=error.get("code", "gaussian.error.other"), original_message=error["message"]) for error in job["errors"]]
                if job["error_termination"]:
                    known = {error["message"] for error in job["errors"]}
                    context = [entry["message"] for entry in job.get("error_context", []) if entry["message"] not in known]
                    if context:
                        findings.append(Finding("error_context", source, "Termination context: " + " | ".join(context), diagnostic_code="gaussian.error.termination_context"))
                if job["error_termination"] and not job["errors"]:
                    findings.append(Finding("error", source, "error termination"))
                if any(not scf["converged"] for scf in job["scf_history"]):
                    findings.append(Finding("scf_unconverged", source))
                findings += _warning_findings(job["warnings"], source)
                if job["optimization_history"] and not job["optimization_complete"] and job.get("state") != "unfinished":
                    findings.append(Finding("optimization_unconverged", source))
                if job["request"]["excited"] and not job["td_converged"] and job.get("state") != "unfinished":
                    findings.append(Finding("td_unconverged", source))
                if job["frequencies"] and job.get("state") != "unfinished" and "opt" in job["request"]["jobs"]:
                    imaginary = sum(mode["frequency"] < 0 for mode in job["frequency_sets"][-1])
                    expected = int(any(option in job["request"]["options"].get("opt", {}) for option in ("ts", "qst2", "qst3")))
                    if imaginary != expected:
                        findings.append(Finding("imaginary_modes", source,
                                                f"Gaussian found {imaginary} imaginary {'mode' if imaginary == 1 else 'modes'}; {expected} {'was' if expected == 1 else 'were'} expected"))
                findings += [Finding("unstable", source, entry["message"]) for entry in job["stability"]
                             if not entry["stable"]]
        else:
            if not self.result["scf_history"] or self.result["density_change"] is None:
                findings.append(Finding("lotus_unconverged", "Lotus"))
            findings += _warning_findings(self.result["warnings"], "Lotus", "lotus")
            findings += [Finding("check_failed", "Lotus", name.replace("_", " "))
                         for name, check in (self.result["checks"] or {}).items()
                         if isinstance(check, dict) and check.get("passed") is False]
        for record in self.records:
            if record["level"] in ("ERROR", "CRITICAL"):
                # The traceback's last line names the exception and its message.
                lines = [line.strip() for line in record["detail"] if line.strip()]
                findings.append(Finding("script_error", "runflow", lines[-1] if lines else record["message"]))
            elif record["level"] == "WARNING":
                findings.append(Finding("script_warning", "runflow", record["message"], diagnostic_code=_warning_code(record["message"], "runflow")))
        return _coalesced(findings)

    def findings_table(self, icons):
        """Every warning and error, with its kind as an icon from ``icons`` (by Warning or Error), its source,
        message."""
        return pd.DataFrame([dict(kind=icons[finding.kind], source=finding.source, message=finding.markdown()) for finding in self.findings()])

    def recorded_assessment(self):
        """Status word and text a workflow README's Status heading records for this calculation, or (None, "")."""
        readme = self.folder.parent / "README.md"
        if not readme.exists():
            return None, ""
        section = re.search(r"(?ms)^## Status\n+(.*?)(?=^#{1,2} |^```|\Z)", readme.read_text())
        if not section:
            return None, ""
        word = None
        for line in section[1].splitlines():
            heading = re.match(r"^#{3,6}\s+(Succeeded|Problems|Failed|Submitted|Not run)\s*$", line.strip(), re.I)
            if heading:
                word = heading[1].capitalize()
                continue
            if word and re.match(r"^- .+$", line) and f"({self.folder.name}/README.md" in line:
                return word, line[2:].strip()
        return None, ""

    def status(self):
        """Automatic status implied by the calculation's own output and run records."""
        return _worst_status(self.findings())

    def scientific_assessment(self):
        """Read a human assessment and its explanation from this calculation's README.

        The log digest keeps a judgment of an earlier run from applying to a later run.
        """
        path = self.folder / "README.md"
        if not path.exists():
            return None
        text = path.read_text()
        metadata = readme_metadata(self.folder)
        record = metadata.get("assessment")
        if record is None:
            return None
        codes = ("accepted", "caveats", "rejected", "not-submitted")
        if not isinstance(record, dict) or record.get("status") not in codes:
            raise ValueError(f"{path}: assessment.status must be one of {', '.join(codes)}")
        if record["status"] != "not-submitted" and not re.fullmatch(r"[0-9a-f]{64}", str(record.get("log-sha256", ""))):
            raise ValueError(f"{path}: a completed or reviewed run requires a lowercase SHA-256 log digest")
        if record["status"] == "not-submitted" and "log-sha256" in record:
            raise ValueError(f"{path}: a not-submitted assessment cannot carry a log digest")
        section = re.search(r"(?ms)^#{2,3} Scientific assessment\s*\n(.*?)(?=^#{1,3} |\Z)", text)
        reason = section[1].strip() if section else ""
        if not reason:
            raise ValueError(f"{path}: assessment requires a Scientific assessment section explaining the judgment")
        current = _file_sha256(self.log) if self.log and self.log.is_file() else None
        valid = (self.log is None and not self.records and self.status() == "Not run"
                 if record["status"] == "not-submitted" else current == record["log-sha256"])
        return {**record, "reason": reason, "current": valid}

    def diagram_status(self):
        """Use an explicit current scientific assessment, otherwise retain the automatic run status."""
        assessment = self.scientific_assessment()
        return assessment["status"].replace("-", " ").capitalize() if assessment and assessment["current"] else self.status()

    def wall_time(self):
        """Wall time in seconds: Gaussian's own timing, else the span of the runflow records; None without either."""
        seconds = sum((job["timing"] or {}).get("wall_time") or 0 for job in self.jobs)
        if not seconds and len(self.records) > 1:
            seconds = (self.records[-1]["time"] - self.records[0]["time"]).total_seconds()
        return seconds or None

    def wall_time_text(self):
        """Wall time written out, or empty."""
        seconds = self.wall_time()
        return _duration(seconds) if seconds else ""

    def job_type(self):
        """Short job description: the job keywords of every linked job, or the Lotus method."""
        if self.program == "lotus":
            settings = self._lotus_settings()
            return "Self-consistent screening" if settings.get("sc_scrEx") else "Screening"
        kinds = []
        for job in self.jobs:
            request = job["request"]
            words = ([request["excited"]["method"].upper()] if request["excited"] else []) + [
                job_word(job, name) for name in request["jobs"] if not (request["excited"] and name == "sp")]
            kinds.append(" ".join(words))
        return ", ".join(kinds)

    def step_name(self, number):
        """What a linked Gaussian step does, from its route keywords, such as Excited states or Natural transition
        orbitals."""
        request = self.jobs[number - 1]["request"]
        keywords = {name.lower(): options.lower() for name, options in route_keywords(self.jobs[number - 1]["route"])}
        excited = request["excited"] is not None
        if "only" in keywords.get("guess", "") and "nto" in keywords.get("pop", keywords.get("population", "")):
            return "Natural transition orbitals"
        if "irc" in request["jobs"]:
            return "Reaction path"
        if "modredundant" in request["options"].get("opt", {}):
            return "Relaxed scan"
        if "opt" in request["jobs"]:
            return "Excited-state geometry optimization" if excited else "Geometry optimization"
        if "freq" in request["jobs"]:
            return "Excited-state frequencies" if excited else "Vibrational frequencies"
        if excited:
            return "Excited states"
        return "Single point"

    def step_anchor(self, number):
        """The identifier of a linked step's section, its name as written with underscores for spaces, as Wikipedia
        writes anchors, such as Excited_states; a name repeated by a later step is numbered from its second, as in
        Excited_states_2."""
        anchor = lambda index: re.sub(r"\s+", "_", re.sub(r"[^\w\s.()-]", "", self.step_name(index)).strip())
        repeats = sum(anchor(index) == anchor(number) for index in range(1, number + 1))
        return anchor(number) + (f"_{repeats}" if repeats > 1 else "")

    def step_findings(self, number):
        """Findings that name a linked job; repeated step names share theirs."""
        source = "Gaussian" if len(self.jobs) == 1 else self.step_name(number)
        return [finding for finding in self.findings() if finding.source == source]

    def step_status(self, number):
        """Automatic status of a linked step, independent of any scientific assessment."""
        return _worst_status(self.step_findings(number))

    def screening(self):
        """Screening evaluated by Lotus, as reported in the runflow records, or None."""
        values = [record["fields"]["dielectric"] for record in self.records if "dielectric" in record["fields"]]
        return values[-1] if values else None

    def overview(self, icons=None):
        """Program, resources and timing; a status word takes its icon from the page's mapping when given."""
        rows = [(quantity("program"), PROGRAMS.get(self.program, ""))]
        submission = self.folder / "scripts" / "submit.sh"
        if submission.is_file():
            directives = dict(re.findall(r"(?m)^#SBATCH\s+--([\w-]+)(?:=|\s+)([^\s#]+)", submission.read_text()))
            for key, label in (("time", quantity("requested_wall_time")), ("mem", quantity("requested_memory")),
                               ("cpus-per-task", quantity("requested_cpus")), ("nodes", quantity("requested_nodes")),
                               ("ntasks", quantity("requested_tasks")), ("partition", quantity("requested_partitions"))):
                if key in directives:
                    rows.append((label, _requested_resource(key, directives[key])))
        state = (self.result or {}).get("status")
        if isinstance(state, dict) and state.get("state"):
            word = state["state"].capitalize()
            rows.append((quantity("clean_completion"), (icons or {}).get(word, word)))
        elif self.program == "lotus" and self.result is not None:
            finished = any(record["message"] == "Calculation converged" for record in self.records)
            failed = any(record["level"] in ("ERROR", "CRITICAL") for record in self.records)
            word = "Complete" if finished else "Failed" if failed else "Unknown"
            rows.append((quantity("clean_completion"), (icons or {}).get(word, word)))
        if self.jobs:
            rows += [(quantity("gaussian_version"), self.jobs[0]["version"] or ""),
                     (quantity("linked_jobs"), _value(len(self.jobs))),
                     (quantity("processors"), _value(self.jobs[0]["processors"]) if self.jobs[0]["processors"] else "")]
        if self.records:
            fields = self.records[0]["fields"]
            if "job_id" in fields:
                rows.append((quantity("slurm_job"), str(fields["job_id"])))
            state = (self.result or {}).get("status") if self.result else None
            complete = (state["state"] == "complete" if state is not None else
                        not any(finding.code in ("unfinished", "incomplete", "lotus_unconverged")
                                for finding in self.findings()))
            end = self.records[-1]["time"] if complete else datetime.now(ZONE)
            rows.append((quantity("execution_interval"), _period(self.records[0]["time"], end)))
        if self.wall_time():
            rows.append((quantity("wall_time"), self.wall_time_text()))
        cpu = sum((job["timing"] or {}).get("cpu_time") or 0 for job in self.jobs)
        if cpu:
            rows.append((quantity("cpu_time"), _duration(cpu)))
        return pd.DataFrame([row for row in rows if row[1] != ""], columns=["quantity", "value"])

    def links_table(self, number, index=0):
        """Report the selected link from a Gaussian job's ordered link records.

        Args:
            number: One-based linked-job number.
            index: Zero-based position in its links, including repeated executions.
        Returns:
            Commands for the initial link, or timing details for an executable link.
        """
        links = self.jobs[number - 1]["links"]
        link = links[index]
        if "commands" not in link:
            rows = [("Link", _value(link["index"]))]
            rows += [(label, _duration(link[key])) for key, label in
                     (("wall_time", "Wall time"), ("cpu_time", "CPU time")) if link.get(key) is not None]
            if link.get("finished"):
                rows.append(("Link finished", _moment(datetime.strptime(link["finished"], "%a %b %d %H:%M:%S %Y").replace(tzinfo=JST))))
            return _quantities(rows)
        definitions = GAUSSIAN["links"][0]["commands"]
        rows, present = [], set()
        for name, value in link["commands"].items():
            key = "%" + name.lower().lstrip("%")
            present.add(key)
            definition = definitions.get(key, {})
            shown = bool(value) if key in ("%chk", "%oldchk") else _link0_value(key, value)
            rows.append((_link(definition.get("name", name), "link0"), shown, definition.get("meaning", "")))
        for key in ("%chk", "%oldchk"):
            if key not in present:
                definition = definitions[key]
                rows.append((_link(definition["name"], "link0"), False, definition["meaning"]))
        return pd.DataFrame(rows, columns=["command", "value", "meaning"])

    def route_table(self, number):
        """Route keywords of one linked job: each keyword with its meaning and a subtable of its options."""
        rows = []
        for name, options in route_keywords(self.jobs[number - 1]["route"]):
            if "/" in name and not options:
                method, basis = name.split("/", 1)
                basis_label = GAUSSIAN["display_names"]["basis"].get(basis.lower(), basis)
                page, meaning = _manual(method)
                rows += [(_link(_method_name(method), page), meaning or "Method.", None),
                         (_link(basis_label, "basissets"), GAUSSIAN["basis_sets"].get(basis.lower(), GAUSSIAN["basis"]), None)]
                continue
            # IOps have a table of their own (iop_table).
            if name.lower() == "iop":
                continue
            page, meaning = _manual(name)
            rows.append((_link(_keyword_name(name), page), meaning or "",
                         _options_table(name, options) if options else None))
        table = pd.DataFrame(rows, columns=["keyword", "meaning", "options"])
        # The Options column only when some keyword has options.
        return table if table.options.notna().any() else table.drop(columns="options")

    def iop_table(self, number):
        """The IOps of one linked job's route, each with its value and meaning from the IOps Reference, and for a DFT
        weight IOp a subtable of the weights it sets; None when the route sets none."""
        rows = [row for name, options in route_keywords(self.jobs[number - 1]["route"]) if name.lower() == "iop"
                for option in split_items(unwrap(options)) for row in _iop_rows(*option.partition("=")[::2])]
        if not rows:
            return None
        table = pd.DataFrame(rows, columns=["iop", "value", "meaning", "weights"])
        return table if table.weights.notna().any() else table.drop(columns="weights")

    def _input_job(self, number):
        """The input's definition of one linked job; None when the input is missing, unreadable or has fewer jobs."""
        jobs = getattr(self, "gaussian_input", None) or []
        return jobs[number - 1] if 0 < number <= len(jobs) else None

    def _result_job(self, number):
        """One linked job as the Gaussian output records it; None without output for it."""
        jobs = (self.result or {}).get("jobs", []) if self.program == "gaussian" else []
        return jobs[number - 1] if 0 < number <= len(jobs) else None

    def gic_mode(self, number):
        """How the route of one linked job builds its generalized internal coordinates: read-all, add, automatic or
        old; None without a GIC option or input."""
        job = self._input_job(number)
        return job["gic"]["mode"] if job and job.get("gic") else None

    def gic_table(self, number, icons=None):
        """The GIC section of one linked job's input, lines of one form as one row: their labels, the equations that
        define them in LaTeX, what the coordinate measures, what the lines do, their settings as a subtable and the
        start value; None without a section.

        Args:
            number: One-based linked job.
            icons: Folder of the page's icons, drawing the coordinate and action columns as icons; words without one.

        Returns:
            The table, or None.
        """
        job = self._input_job(number)
        gic = job.get("gic") if job else None
        if not gic or not gic["entries"]:
            return None
        output = self._result_job(number)
        merged = merge_definitions(gic["entries"], output.get("internal_coordinates") or []) if output else []
        printed = {row["name"].lower(): row["value"] for row in merged if row["expression"] is not None}
        geometry = job["geometries"][0]["vectors"] if job["geometries"] else None
        computed = evaluate(gic["entries"], geometry) if geometry else {}
        groups = {}
        for entry in gic["entries"]:
            groups.setdefault(_gic_group(entry), []).append(entry)
        rows = [_gic_row(entries, printed, computed, icons) for entries in groups.values()]
        table = pd.DataFrame(rows, columns=["label", "definition", "coordinate", "action", "setting", "start"])
        return table.drop(columns=[name for name in ("definition", "coordinate", "setting", "start") if table[name].isna().all()])

    def modredundant_table(self, number, icons=None):
        """The ModRedundant section of one linked job: each line's printed label, coordinate in LaTeX, what it
        measures, what it does, its settings as a subtable and its start value; None without a section.

        The lines are the input's, or those the log echoes when no input is retained. Start values are Gaussian's
        printed initial parameters when the output has them, else measured at the input geometry.

        Args:
            number: One-based linked job.
            icons: Folder of the page's icons, drawing the coordinate and action columns as icons; words without one.

        Returns:
            The table, or None.
        """
        job = self._input_job(number)
        output = self._result_job(number)
        section = job.get("modredundant") if job else None
        entries = section["entries"] if section else (output.get("modredundant_input") if output else None)
        if not entries:
            return None
        merged = merge_modredundant(entries, (output.get("internal_coordinates") or []) if output else [])
        geometry = job["geometries"][0]["vectors"] if job and job["geometries"] and section else None
        measured = evaluate_modredundant(entries, geometry) if geometry else [None] * len(entries)
        rows = []
        for entry, row, value in zip(entries, merged, measured):
            start = row["start"] if row["start"] is not None else value
            rows.append((f"`{row['name']}`" if row["name"] else None, _modredundant_definition(entry),
                         _coordinate_kind(entry["measure"], entry["unit"], icons),
                         _action_icons([MODREDUNDANT_ACTIONS[entry["action"]]], icons),
                         _modredundant_settings(entry, start), _coordinate_value(start)))
        table = pd.DataFrame(rows, columns=["label", "definition", "coordinate", "action", "setting", "start"])
        return table.drop(columns=[name for name in ("label", "setting", "start") if table[name].isna().all()])

    def read_optimize_table(self, number):
        """The ReadOptimize rules of one linked job, each with what it does, and the atoms left to optimize; None
        without a section."""
        job = self._input_job(number)
        section = job.get("read_optimize") if job else None
        if not section:
            return None
        rows = []
        for rule in section["rules"]:
            if rule["selection"] == "none":
                rows.append(("`noatoms`", "Start from no optimized atoms."))
                continue
            name = ("" if rule["include"] else "not") + rule["selection"]
            verb = "Optimize" if rule["include"] else "Hold fixed"
            rows.append((f"`{name}={','.join(rule['items'])}`", f"{verb} the {rule['selection']} {', '.join(rule['items'])}."))
        atoms = section["atoms"]
        if atoms is not None:
            rows.append(("Result", f"{len(atoms)} optimized atoms: " + (", ".join(map(str, atoms)) or "none") + "."))
        return pd.DataFrame(rows, columns=["rule", "meaning"])

    def connectivity_table(self, number):
        """The connectivity section of one linked job: each atom that lists bonds, with its element and bonded atoms
        and their orders; None without a section."""
        job = self._input_job(number)
        records = job.get("connectivity") if job else None
        if not records:
            return None
        numbers = job["geometries"][0]["atomic_numbers"] if job["geometries"] else []
        element = lambda atom: ELEMENTS[numbers[atom - 1] - 1] if 0 < atom <= len(numbers) else None
        rows = [(record["atom"], element(record["atom"]) if record["atom"] else None,
                 ", ".join(f"{bond['atom']} ({BOND_ORDERS.get(bond['order'], _number(bond['order']))})" for bond in record["bonds"])
                 + "".join(f" `{item}`" for item in record["unparsed"]))
                for record in records if record["bonds"] or record["unparsed"]]
        table = pd.DataFrame(rows, columns=["atom", "element", "bonds"])
        return table if table.element.notna().any() else table.drop(columns="element")

    def molecule_table(self, number):
        """Title, charge, multiplicity and where the job takes its geometry from."""
        job = self.jobs[number - 1]
        names = {name.lower(): options for name, options in route_keywords(job["route"])}
        geometry = names.get("geom", "").lower()
        source = ("Checkpoint file" if any(word in geometry for word in ("allcheck", "check")) else "Input file")
        rows = []
        if job["archive"] and job["archive"]["title"]:
            rows.append(("Title", _title_math(job["archive"]["title"])))
        if job["charge"] is not None:
            rows += [(quantity("molecular_charge"), _value(job["charge"])), (quantity("spin_multiplicity"), _value(job["multiplicity"]))]
        rows.append((quantity("geometry_source"), source))
        further = (self._input_job(number) or {}).get("structures") or []
        for position, structure in enumerate(further, 2):
            rows.append((f"Structure {position}", _title_math(structure["title"]) if structure["title"] else "Untitled"))
        return pd.DataFrame(rows, columns=["quantity", "value"])

    def system_table(self, number):
        """The system: formula, charge, spin, size, symmetry, electrons and solvent, each once; the method and basis are
        those of the input, shown with it."""
        job = self.jobs[number - 1]
        archive = job.get("archive") or {}
        electrons = job["electron_counts"] or []
        rows = [
            ("Formula", _formula(archive["formula"]) if archive.get("formula") else ""),
            (quantity("molecular_charge"), _value(job.get("charge")) if job.get("charge") is not None else ""),
            (quantity("spin_multiplicity"), _value(job.get("multiplicity")) if job.get("multiplicity") is not None else ""),
            ("Atoms", _value(job["atom_count"]) if job["atom_count"] else ""),
            (quantity("point_group_gaussian"), _point_group(job["point_group"]) if job["point_group"] else ""),
            (quantity("framework_group"),
             _framework(str(archive.get("properties", {}).get("PG", "")).partition(" ")[2])
             if " " in str(archive.get("properties", {}).get("PG", "")) else ""),
            (quantity("point_group_geometry"), f"${self.symmetry(number).group.name}$" if self.symmetry(number) else ""),
            (quantity("basis_functions"), _value(job["basis_count"]) if job["basis_count"] else ""),
            (quantity("independent_functions"), _value(job["independent_count"]) if job["independent_count"] else ""),
            (quantity("alpha_electrons"), _value(electrons[0]) if electrons else ""),
            (quantity("beta_electrons"), _value(electrons[1]) if len(electrons) > 1 else ""),
            (quantity("closed_shell"), job["closed_shell"] if job["closed_shell"] is not None else ""),
        ]
        solvents = dict.fromkeys((entry["solvent"], entry["epsilon"], entry["epsilon_infinity"])
                                 for entry in job["solvent"]["parameters"])
        for solvent, epsilon, infinity in solvents:
            rows += [(quantity("solvent"), solvent), (quantity("static_permittivity"), _value(epsilon)),
                     (quantity("optical_permittivity"), _value(infinity))]
        return pd.DataFrame([row for row in rows if row[1] != ""], columns=["quantity", "value"])

    def energy_table(self, number):
        """Printed energy components and virial ratio of the last SCF, without mixing geometries or linked jobs."""
        history = self.jobs[number - 1]["scf_history"]
        if not history:
            return None
        scf = history[-1]
        components = [("kinetic_energy", "kinetic_energy"), ("nuclear_attraction", "nuclear_attraction"),
                      ("electron_interaction", "electron_interaction"), ("nuclear_repulsion", "nuclear_repulsion")]
        rows = [(quantity(label), _value(scf[key], "hartree", 12))
                for key, label in components if scf[key] is not None]
        if not rows and scf["virial_ratio"] is None:
            return None
        rows.append((quantity("scf_energy"), _value(scf["energy"], "hartree", 12)))
        if scf["virial_ratio"] is not None:
            rows.append((quantity("virial_ratio"), _value(scf["virial_ratio"], digits=6)))
        return pd.DataFrame(rows, columns=["quantity", "value"])

    def initial_geometry(self, number=1):
        """Starting atoms of a linked job as element symbols and Cartesian rows in angstrom, and their source.

        For Gaussian, the first geometry it printed for the job: what it read from the input in any
        molecule-specification format, or from the checkpoint. For Lotus, the folder's XYZ input.
        None when neither exists.
        """
        if self.jobs and self.jobs[number - 1]["geometries"]:
            geometry = self.jobs[number - 1]["geometries"][0]
            return ([ELEMENTS[n - 1] for n in geometry["atomic_numbers"]], geometry["vectors"],
                    "the first geometry Gaussian printed" if self.result else "the input specifies it")
        xyz = [path for path in self.inputs if path.suffix == ".xyz"]
        if xyz:
            lines = xyz[0].read_text().splitlines()
            rows = [line.split() for line in lines[2:2 + int(lines[0])] if line.strip()]
            # A prepared input declares its atom count before runflow writes the coordinates.
            if len(rows) == int(lines[0]):
                return [row[0] for row in rows], [list(map(float, row[1:4])) for row in rows], f"`{xyz[0].name}`"
        return None

    def coordinate_overlay(self, number=1, limit=12):
        """What the starting-geometry viewer draws of the coordinates the input's GIC or ModRedundant section defines:
        bonds as distances and angles as angle measurements, each with a readout, and dihedrals as labelled groups of
        their four atoms; Cartesian and centroid terms are not drawn. Empty without such a section or input atoms.

        Args:
            number: One-based linked job.
            limit: Most bonds and angles drawn, so a long section does not cover the molecule.

        Returns:
            Keyword arguments of ``MolstarViewer``: ``distances``, ``angles``, ``readouts`` and ``groups``, each only
            when not empty.
        """
        job = self._input_job(number)
        atom_count = len(job["geometries"][0]["atomic_numbers"]) if job and job["geometries"] else 0
        if not atom_count:
            return {}
        terms = [(term["function"], term["atoms"]) for entry in ((job.get("gic") or {}).get("entries") or [])
                 if entry["kind"] == "coordinate" and not entry.get("error") for term in entry.get("terms", [])]
        terms += [(PRINTED[entry["type"]], entry["atoms"]) for entry in ((job.get("modredundant") or {}).get("entries") or [])
                  if entry["type"] in ("B", "A", "D") and entry["action"] not in ("remove", "kill")]
        distances, angles, readouts, groups, seen, grouped = [], [], [], [], set(), set()
        for function, atoms in terms:
            if not atoms or not all(isinstance(atom, int) and 1 <= atom <= atom_count for atom in atoms):
                continue
            key = (function, tuple(min(atoms, atoms[::-1])))
            if key in seen:
                continue
            seen.add(key)
            subscript = ",".join(map(str, atoms))
            if function == "R" and len(atoms) == 2 and len(readouts) < limit:
                distances.append(list(atoms))
                readouts.append(dict(kind="distance", atoms=list(atoms), label=f"r_{{{subscript}}}", unit=r"\mathrm{\AA}"))
            elif function == "A" and len(atoms) == 3 and len(readouts) < limit:
                angles.append(list(atoms))
                readouts.append(dict(kind="angle", atoms=list(atoms), label=rf"\theta_{{{subscript}}}"))
            elif function == "D" and len(atoms) == 4 and not grouped & set(atoms):
                groups.append(dict(label=rf"$\tau_{{{subscript}}}$", atoms=list(atoms)))
                grouped |= set(atoms)
        overlay = dict(distances=distances, angles=angles, readouts=readouts, groups=groups)
        return {name: value for name, value in overlay.items() if value}

    def geometry_frame(self, number=1):
        """XYZ frame of the starting geometry."""
        symbols, coordinates, _ = self.initial_geometry(number)
        return _frames([ELEMENTS.index(symbol) + 1 for symbol in symbols], [coordinates])

    def _lotus_settings(self):
        """Lotus settings from the JSON comment line of the XYZ input, empty without them."""
        xyz = [path for path in self.inputs if path.suffix == ".xyz"]
        try:
            return json.loads(xyz[0].read_text().splitlines()[1])
        except (IndexError, ValueError):
            return {}

    def lotus_settings(self):
        """Lotus settings as a table, the method under its standard name, or None without settings."""
        settings = self._lotus_settings()
        if not settings:
            return None

        def shown(key, value):
            if key == "method":
                return LOTUS_METHODS.get(value, f"`{value}`")
            if key == "basis":
                return _basis_name(value)
            if isinstance(value, bool):
                return value
            return f"`{value}`" if isinstance(value, str) else _value(value)

        return _quantities([(LOTUS_SETTINGS.get(key, f"`{key}`"), shown(key, value),
                             GAUSSIAN["basis_sets"].get(value.lower(), "") if key == "basis" else (LOTUS_DESCRIPTIONS.get(value, "") if key == "method" else ""))
                            for key, value in settings.items()])

    def scf_method(self, number):
        """The method shared by every SCF of a linked job, or None when they differ."""
        methods = {scf["method"] for scf in self.jobs[number - 1]["scf_history"]}
        return methods.pop() if len(methods) == 1 else None

    def scf_table(self, number):
        """Every SCF of a linked job: final energy, cycles and density convergence; convergence where it changes."""
        history = self.jobs[number - 1]["scf_history"]
        table = pd.DataFrame(dict(scf=range(1, len(history) + 1), method=[_method_name(scf["method"]) for scf in history],
                                  energy=[_to_ev(scf["energy"]) for scf in history], cycles=[scf["cycles"] for scf in history],
                                  density_rms=[scf["density_rms"] for scf in history],
                                  converged=_changes([scf["converged"] for scf in history])))
        return table.drop(columns="method") if self.scf_method(number) else table

    @_hovered
    def scf_chart(self, number):
        """SCF cycles or density history, with convergence shown for each reported point."""
        history = self.jobs[number - 1]["scf_history"]
        status = lambda value: "Converged" if value is True else "Not converged" if value is False else "Unknown"
        color = alt.Color(f"{PLOT}convergence:N",
                          scale=alt.Scale(domain=["Converged", "Not converged", "Unknown"],
                                          range=["#198754", "#dc3545", "#6c757d"]))
        # A rule's second endpoint would otherwise merge both field names into one axis title.
        if len(history) > 1:
            data = pd.DataFrame([dict(scf=index, cycles=row["cycles"], convergence=status(row.get("converged")))
                                 for index, row in enumerate(history, 1)])
            x = alt.X(f"{PLOT}scf:Q", axis=alt.Axis(tickMinStep=1), scale=_MARGIN, title=f"{PLOT}scf")
            y = alt.Y(f"{PLOT}cycles:Q", axis=alt.Axis(tickMinStep=1), title=f"{PLOT}cycles")
            line = _chart(_step_path(data, "scf", "cycles")).mark_line(strokeWidth=2).encode(
                x=x, y=y, color=color, detail=f"{PLOT}segment:N")
            # A dot marks where the staircase changes level and the last SCF always, so the path ends on a dot.
            changed = data[data.cycles.ne(data.cycles.shift()) | (data.index == data.index[-1])]
            points = _chart(changed).mark_point(filled=True, size=50).encode(x=x, y=y, color=color,
                tooltip=[alt.Tooltip(f"{PLOT}scf:Q"), alt.Tooltip(f"{PLOT}cycles:Q"),
                         alt.Tooltip(f"{PLOT}convergence:N")])
            return line + points
        scf = history[0]
        threshold = scf.get("rms_threshold")
        data = pd.DataFrame([dict(cycle=row["iteration"], density_rms=row["density_rms"],
                                  convergence=status(row["density_rms"] <= threshold if threshold is not None else None))
                             for row in scf["cycle_history"] if row["density_rms"] is not None and row["density_rms"] > 0])
        x = alt.X(f"{PLOT}cycle:Q", axis=alt.Axis(tickMinStep=1), scale=_MARGIN, title=f"{PLOT}cycle")
        y = alt.Y(f"{PLOT}density_rms:Q", title=f"{PLOT}density_rms", scale=alt.Scale(type="log"))
        line = _chart(_step_path(data, "cycle", "density_rms")).mark_line(strokeWidth=2).encode(
            x=x, y=y, color=color, detail=f"{PLOT}segment:N")
        points = _chart(_marker_rows(data, "cycle")).mark_point(filled=True, size=50).encode(
            x=x, y=y, color=color,
            tooltip=[alt.Tooltip(f"{PLOT}cycle:Q"), alt.Tooltip(f"{PLOT}density_rms:Q"),
                     alt.Tooltip(f"{PLOT}convergence:N")])
        if threshold is None or threshold <= 0:
            return line + points
        rule = _chart(pd.DataFrame([dict(density_rms=threshold)])).mark_rule(**_REFERENCE).encode(y=y)
        return line + points + rule

    @_hovered
    def evaluation_forces_chart(self, number):
        """Recorded Cartesian force magnitudes by SCF solution, the axis of the SCF convergence chart, including IRC corrector steps."""
        rows = []
        conversion = (1 * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude
        for index, evaluation in enumerate(self.jobs[number - 1]["evaluations"], 1):
            for key, label in (("force_maximum", r"Maximum $F_{\max}$"),
                               ("force_rms", r"RMS $F_{\mathrm{RMS}}$")):
                value = evaluation.get(key)
                if value is not None:
                    rows.append(dict(scf=index, evaluation_force=value * conversion, force_statistic=label))
        # With a marker, a job of one evaluation still shows its value.
        return _chart(pd.DataFrame(rows)).mark_line(point=True).encode(
            x=alt.X(f"{PLOT}scf:Q", axis=alt.Axis(tickMinStep=1), scale=_MARGIN, title=f"{PLOT}scf"),
            y=alt.Y(f"{PLOT}evaluation_force:Q", scale=_MARGIN),
            color=alt.Color(f"{PLOT}force_statistic:N"),
            tooltip=[alt.Tooltip(f"{PLOT}scf:Q"), alt.Tooltip(f"{PLOT}force_statistic:N"),
                     alt.Tooltip(f"{PLOT}evaluation_force:Q", format=".6~g")])

    def irc_branches(self, number):
        """Directions along the reaction path, in the order the job reached them."""
        return list(dict.fromkeys(point["direction"].capitalize() for point in self.jobs[number - 1]["irc_points"]))

    def irc_reference(self, number):
        """Printed IRC saddle energy, or the last SCF before the first recorded path point."""
        job = self.jobs[number - 1]
        if job["irc_reference"] is not None:
            return job["irc_reference"]
        indices = [point["evaluation"] for point in job["irc_points"] if point["evaluation"] is not None]
        if not indices:
            return None
        first = min(indices)
        return job["evaluations"][first - 1]["energy"] if 0 < first <= len(job["evaluations"]) else None

    def irc_table(self, number, branch=None):
        """Reaction-path points in order: branch, reaction coordinate and energy relative to the saddle."""
        job = self.jobs[number - 1]
        energies = [evaluation["energy"] for evaluation in job["evaluations"]]
        reference = self.irc_reference(number)
        rows = []
        for point in job["irc_points"]:
            if branch is not None and point["direction"].capitalize() != branch:
                continue
            index = point["evaluation"]
            energy = energies[index] if index is not None and 0 <= index < len(energies) else None
            rows.append(dict(point_index=point["point"], branch=point["direction"].capitalize(),
                             reaction_coordinate=point["coordinate"],
                             path_energy=(energy - reference) * HARTREE_KJ
                             if energy is not None and reference is not None else None))
        table = pd.DataFrame(rows)
        return table.drop(columns="branch") if branch is not None and "branch" in table else table

    @_hovered
    def irc_chart(self, number):
        """Join the reverse and forward paths at the transition state, with a dashed line at zero."""
        data = self.irc_table(number).copy()
        data["reaction_coordinate"] = np.where(data["branch"] == "Reverse",
                                               -data["reaction_coordinate"].abs(),
                                               data["reaction_coordinate"].abs())
        # Add the actual saddle only when its energy is known, once for each displayed branch.
        if self.irc_reference(number) is not None:
            saddle = pd.DataFrame([dict(branch=branch, reaction_coordinate=0.0, path_energy=0.0)
                                   for branch in data["branch"].unique()])
            data = pd.concat([data, saddle], ignore_index=True)
        reverse = data[(data["branch"] == "Reverse") & data["path_energy"].notna()]
        # A missing reverse branch cannot supply this reference. Keep the transition-state reference in that case.
        if reverse.empty:
            energy = "path_energy"
        else:
            endpoint = reverse.loc[reverse["reaction_coordinate"].idxmin(), "path_energy"]
            data["reverse_relative_energy"] = data["path_energy"] - endpoint
            energy = "reverse_relative_energy"
        data["branch"] = data["branch"] + " path"
        line = _chart(data).mark_line(point=True).encode(
            x=alt.X(f"{PLOT}reaction_coordinate:Q"), y=alt.Y(f"{PLOT}{energy}:Q"),
            color=alt.Color(f"{PLOT}branch:N"))
        transition = _chart(pd.DataFrame({"reaction_coordinate": [0.0]})).mark_rule(**_REFERENCE).encode(x=f"{PLOT}reaction_coordinate:Q")
        # Put the reference first so the zoom selection belongs to a non-faceted layer.
        return transition + line

    def optimization_table(self, number):
        """Energy and the four convergence criteria at every optimization step; convergence where it changes."""
        job = self.jobs[number - 1]
        energies = [evaluation["energy"] for evaluation in job["evaluations"]]
        rows = []
        for index, step in enumerate(job["optimization_history"], 1):
            row = dict(check_index=index)
            if step["evaluation"] is not None and step["evaluation"] < len(energies):
                row["energy"] = _to_ev(energies[step["evaluation"]])
            for check in step["checks"]:
                row[CRITERIA[check["criterion"]][0]] = ((check["value"] * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude
                    if "force" in check["criterion"] else check["value"])
            row["converged"] = all(check["passed"] for check in step["checks"])
            rows.append(row)
        table = pd.DataFrame(rows)
        table["converged"] = _changes(list(table["converged"]))
        return table

    def optimization_thresholds(self, number):
        """Distinct convergence limits, with check indices only where a limit changes."""
        limits = {}
        for index, step in enumerate(self.jobs[number - 1]["optimization_history"], 1):
            for check in step["checks"]:
                key = check["criterion"], check["threshold"]
                limits.setdefault(key, []).append(index)
        varying = any(sum(name == criterion for name, _ in limits) > 1 for criterion, _ in limits)
        rows = []
        for (criterion, threshold), indices in limits.items():
            key = CRITERIA[criterion][0]
            value = ((threshold * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude
                     if "force" in criterion else threshold)
            row = dict(criterion=LABELS[key], threshold=value)
            if varying:
                row["check_index"] = "$" + ", ".join(map(str, indices)) + "$"
            rows.append(row)
        return pd.DataFrame(rows)

    @_hovered
    def optimization_charts(self, number):
        """Optimization energy in eV, forces and native displacements, with separate maximum/RMS limits."""
        job = self.jobs[number - 1]
        indexed = []
        segment, previous = 0, None
        for index, step in enumerate(job["optimization_history"], 1):
            if previous is not None and step["iteration"] <= previous:
                segment += 1
            indexed.append((index, segment, step))
            previous = step["iteration"]
        samples = [(index, segment, job["evaluations"][step["evaluation"]]["energy"], step["checks"])
                   for index, segment, step in indexed if step["evaluation"] is not None]
        final = samples[-1][2]
        status = lambda value: "Converged" if value is True else "Not converged" if value is False else "Unknown"
        color = alt.Color(f"{PLOT}convergence:N",
                          scale=alt.Scale(domain=["Converged", "Not converged", "Unknown"],
                                          range=["#198754", "#dc3545", "#6c757d"]))
        def overall(checks):
            flags = [check.get("passed") for check in checks]
            if any(flag is False for flag in flags):
                return False
            return True if len(flags) >= 4 and all(flag is True for flag in flags) else None
        data = pd.DataFrame([dict(check_index=index, optimization_segment=segment, relative=_to_ev(value - final),
                                  convergence=status(overall(checks)))
                             for index, segment, value, checks in samples])
        # Pair consecutive checks in output order, so the line reaches the last point even where a restart begins.
        segments = data.assign(next_check=data.check_index.shift(-1), next_relative=data.relative.shift(-1),
                               convergence=data.convergence.shift(-1)).dropna(subset=["next_check"])
        check_axis = alt.X(f"{PLOT}check_index:Q", axis=alt.Axis(tickMinStep=1), scale=_MARGIN, title=f"{PLOT}check_index")
        relative_axis = alt.Y(f"{PLOT}relative:Q", title=f"{PLOT}relative", scale=_MARGIN)
        energy_line = _chart(segments).mark_rule(strokeWidth=2).encode(
            x=check_axis, x2=f"{PLOT}next_check:Q", y=relative_axis, y2=f"{PLOT}next_relative:Q", color=color)
        energy_points = _chart(_marker_rows(data, "check_index", group="optimization_segment")).mark_point(
            filled=True, size=64).encode(
            x=check_axis, y=relative_axis, color=color,
            tooltip=[alt.Tooltip(f"{PLOT}check_index:Q"), alt.Tooltip(f"{PLOT}relative:Q"),
                     alt.Tooltip(f"{PLOT}convergence:N")])
        energy = energy_line + energy_points

        def criteria(family):
            """Show one family in its own units, with shape and line style identifying maximum and RMS."""
            value_field, limit_field = f"optimization_{family}", f"optimization_{family}_threshold"
            names = ([r"Maximum $F_{\max}$", r"RMS $F_{\mathrm{RMS}}$"] if family == "force"
                     else [r"Maximum $\Delta q_{\max}$", r"RMS $\Delta q_{\mathrm{RMS}}$"])
            rows = []
            for index, segment, step in indexed:
                for check in step["checks"]:
                    if family not in check["criterion"]:
                        continue
                    value, threshold = check["value"], check["threshold"]
                    if family == "force":
                        value = (value * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude
                        threshold = (threshold * ureg.hartree / ureg.bohr).to("eV/angstrom").magnitude
                    rows.append(dict(check_index=index, optimization_segment=segment,
                                     criterion=names["rms" in check["criterion"]], **{value_field: value, limit_field: threshold},
                                     convergence=status(check.get("passed"))))
            check_axis = alt.X(f"{PLOT}check_index:Q", axis=alt.Axis(tickMinStep=1), scale=_MARGIN, title=f"{PLOT}check_index")
            value_axis = alt.Y(f"{PLOT}{value_field}:Q", title=PLOT + value_field, scale=_MARGIN)
            base = _chart(pd.DataFrame(rows)).encode(x=check_axis, y=value_axis)
            # Both legends carry a title so Vega-Lite aligns their entries beneath it in one bottom row.
            style = alt.StrokeDash(f"{PLOT}criterion:N", scale=alt.Scale(domain=names, range=[[], [2, 2]]),
                                  legend=alt.Legend(title=PLOT + "criterion"))
            shape = alt.Shape(f"{PLOT}criterion:N", scale=alt.Scale(domain=names, range=["circle", "square"]),
                              legend=alt.Legend(title=PLOT + "criterion"))
            # Pair each criterion's consecutive checks, so every line reaches its last printed point.
            frame = pd.DataFrame(rows)
            grouped = frame.groupby("criterion", sort=False)
            segments = frame.assign(next_check=grouped.check_index.shift(-1), next_value=grouped[value_field].shift(-1),
                                    convergence=grouped.convergence.shift(-1)).dropna(subset=["next_check"])
            line = _chart(segments).mark_rule(strokeWidth=2).encode(
                x=check_axis, x2=f"{PLOT}next_check:Q", y=value_axis,
                y2=f"{PLOT}next_value:Q", color=color, strokeDash=style)
            points = base.mark_point(filled=True, size=64).encode(shape=shape, color=color)
            # Each limit spans the whole plot, in its criterion's line type; a restart that changes it adds another.
            limits = [_chart(pd.DataFrame({limit_field: checks[limit_field].dropna().unique()})).mark_rule(
                **(_RMS_REFERENCE if name == names[1] else _REFERENCE)).encode(
                y=alt.Y(f"{PLOT}{limit_field}:Q", title=PLOT + value_field, scale=_MARGIN))
                      for name, checks in frame.groupby("criterion", sort=False)]
            hit = base.mark_point(opacity=0, size=576).encode(tooltip=[
                alt.Tooltip(f"{PLOT}check_index:Q"), alt.Tooltip(f"{PLOT}criterion:N"),
                alt.Tooltip(f"{PLOT}{value_field}:Q", format=".6~g"), alt.Tooltip(f"{PLOT}{limit_field}:Q", format=".6~g"),
                alt.Tooltip(f"{PLOT}convergence:N")])
            return alt.layer(line, *limits, points, hit).properties(height=200)

        return energy, criteria("force"), criteria("displacement")

    def trajectory(self, number):
        """XYZ frames of every geometry Gaussian printed in a linked job, a reaction path ordered from its reverse
        endpoint, through the starting saddle, to its forward endpoint."""
        job = self.jobs[number - 1]
        geometries = job["geometries"]
        points = job["irc_points"]
        # Only reorder when every point has a known branch and coordinate. An incomplete record with unknown
        # direction must not be silently assigned to the reverse branch; retain native geometry order instead.
        if points and all(point["direction"] in ("reverse", "forward") and point["coordinate"] is not None
                          and np.isfinite(point["coordinate"]) for point in points):
            angstrom = lambda values: (values.to("angstrom").magnitude if hasattr(values, "to")
                                       else np.asarray(values, dtype=float))
            # Gaussian outputs may carry either signed or unsigned branch coordinates.
            reverse = sorted((point for point in points if point["direction"] == "reverse"),
                             key=lambda point: -abs(point["coordinate"]))
            forward = sorted((point for point in points if point["direction"] == "forward"),
                             key=lambda point: abs(point["coordinate"]))
            between = [geometries[0]["vectors"]] if geometries else []
            frames = [angstrom(point["coordinates"]) for point in reverse] + between + [
                angstrom(point["coordinates"]) for point in forward]
            labels = {}
            if reverse:
                labels["Reverse endpoint"] = 1
            if between:
                labels["Transition state"] = len(reverse) + 1
            if forward:
                labels["Forward endpoint"] = len(frames)
            return _LabelledFrames(_frames(points[0]["atomic_numbers"], frames), labels)
        return _frames(geometries[0]["atomic_numbers"], [geometry["vectors"] for geometry in geometries])

    def mode_symmetry(self, number):
        """Point group of a frequency job's geometry and the irreducible representation of every harmonic mode in it,
        in lower case as for orbitals, degenerate modes together; None when no mode set carries one representation.

        Each operation moves every atom's displacement to the atom it moves to and rotates it; the character of a set
        of degenerate modes is the trace of that action within the set."""
        if number in self._mode_symmetry:
            return self._mode_symmetry[number]
        job = self.jobs[number - 1]
        if not job["frequency_sets"] or not job["geometries"]:
            return None
        modes, geometry = job["frequency_sets"][-1], job["geometries"][-1]
        if any(len(mode["displacements"]) != len(geometry["atomic_numbers"]) for mode in modes):
            return None
        coordinates = (np.asarray(geometry["vectors"], dtype=float) * ureg.angstrom).to("bohr").magnitude
        group = point_group(np.asarray(geometry["atomic_numbers"]), coordinates)
        displacements = np.asarray([mode["displacements"] for mode in modes], dtype=float)
        # Modes within 0.5 cm-1 of the previous one are taken as degenerate partners.
        sets = []
        for index, mode in enumerate(modes):
            if sets and abs(mode["frequency"] - modes[sets[-1][-1]]["frequency"]) < 0.5:
                sets[-1].append(index)
            else:
                sets.append([index])
        labels = [None] * len(modes)
        for indices in sets:
            vectors = displacements[indices].reshape(len(indices), -1).T
            inverse, characters = np.linalg.pinv(vectors), []
            for matrix, permutation in zip(group.operations, group.permutations):
                moved = np.zeros_like(displacements[indices])
                moved[:, permutation, :] = displacements[indices] @ matrix.T
                characters.append(np.trace(inverse @ moved.reshape(len(indices), -1).T))
            irrep = group.assign(np.array(characters), len(indices))
            if irrep is None:
                self._mode_symmetry[number] = None
                return None
            for index in indices:
                labels[index] = irrep
        self._mode_symmetry[number] = (group, labels)
        return self._mode_symmetry[number]

    def modes_table(self, number):
        """Harmonic modes of a linked job with their reduced masses, force constants and IR intensities; symmetry in
        the point group of the geometry when ``mode_symmetry`` finds it, otherwise as Gaussian printed it."""
        modes = self.jobs[number - 1]["frequency_sets"][-1]
        found = self.mode_symmetry(number)
        symmetry = ([f"${irrep.orbital()}$" for irrep in found[1]] if found
                    else [_irrep(mode["symmetry"]) for mode in modes])
        table = pd.DataFrame([dict(mode=mode["mode"], symmetry=label, frequency=mode["frequency"],
                                   reduced_mass=mode["reduced_mass"], force_constant=mode["force_constant"],
                                   intensity=mode["ir_intensity"]) for mode, label in zip(modes, symmetry)])
        # Under a single irreducible representation, as without symmetry, the column says nothing.
        return table.drop(columns="symmetry") if table.symmetry.nunique() == 1 else table

    @_hovered
    def ir_chart(self, number):
        """IR stick spectrum of the real harmonic modes, over the usual spectral regions; each stick's hover gives all
        that is known of its mode."""
        table = self.modes_table(number)
        table = table[table.frequency >= 0]
        table = table.assign(spectral_region=[_region(value, IR_REGIONS) for value in table.frequency])
        sticks = _chart(table.assign(series="Infrared intensity")).mark_rule(strokeWidth=2).encode(
            x=alt.X(f"{PLOT}frequency:Q"), y=alt.Y(f"{PLOT}intensity:Q"), y2=alt.datum(0), color=_series("Infrared intensity"),
            tooltip=_mode_tooltip(table) + [alt.Tooltip(f"{PLOT}spectral_region:N")])
        # A thin stick is hard to reach, so a wide transparent one takes the pointer.
        hover = sticks.mark_rule(strokeWidth=12, opacity=0)
        regions = _regions("frequency", 0, table.frequency.max(), IR_REGIONS) if len(table) else []
        return alt.layer(sticks, hover, *regions)

    def mode_frequencies_chart(self, number):
        """All harmonic modes in frequency order, distinguishing imaginary wavenumbers."""
        table = self.modes_table(number).sort_values(["frequency", "mode"], kind="stable").copy()
        table["mode"] = table["mode"].astype(str)
        table["mode_character"] = np.where(table.frequency < 0, "Imaginary", "Non-imaginary")
        present = [label for label in ("Non-imaginary", "Imaginary") if label in table.mode_character.values]
        base = _chart(table).encode(
            x=alt.X(f"{PLOT}mode:N", sort=table["mode"].tolist(),
                    scale=alt.Scale(domain=table["mode"].tolist()),
                    axis=alt.Axis(labelExpr="datum.value", labelOverlap="greedy", labelLimit=0)),
            y=alt.Y(f"{PLOT}frequency:Q"),
            color=alt.Color(f"{PLOT}mode_character:N",
                            scale=alt.Scale(domain=["Non-imaginary", "Imaginary"], range=["#3976b6", "#f58518"]),
                            legend=alt.Legend(values=present)),
            tooltip=_mode_tooltip(table))
        levels = base.mark_tick(thickness=3, size=12, orient="horizontal", clip=True)
        hover = base.mark_point(opacity=0, size=256)
        return alt.layer(levels, hover)

    def infrared_rule(self, number):
        """Markdown on which modes can absorb in the infrared, from the point group of the geometry; empty without it."""
        found = self.mode_symmetry(number)
        if not found or found[0].order == 1:
            return ""
        group = found[0]
        active = ", ".join(f"${_lower_label(label)}$ $({axes})$" for label, axes in group.dipole.items())
        return rf"""In ${group.name}$ only modes that change the dipole absorb in the infrared:

- Infrared-active symmetries are {active}.
- Every other mode has zero intensity.
"""

    def shown_modes(self, number):
        """Modes the viewer animates, in mode order: every imaginary mode, the six lowest real modes and the four
        most intense in the infrared."""
        modes = self.jobs[number - 1]["frequency_sets"][-1]
        real = [mode for mode in modes if mode["frequency"] >= 0]
        chosen = {mode["mode"] for mode in modes if mode["frequency"] < 0}
        chosen |= {mode["mode"] for mode in real[:6]}
        chosen |= {mode["mode"] for mode in sorted(real, key=lambda mode: -(mode["ir_intensity"] or 0))[:4]}
        return [mode for mode in modes if mode["mode"] in chosen]

    def mode_frames(self, number):
        """Animated frames of each shown mode at a 0.6 angstrom largest atomic excursion, by snapshot title."""
        job = self.jobs[number - 1]
        modes = job["frequency_sets"][-1]
        geometry = job["geometries"][-1]
        vibrations = Vibrations(
            numbers=np.asarray(geometry["atomic_numbers"]),
            coordinates=np.asarray(geometry["vectors"]) * ureg.angstrom,
            frequencies=[mode["frequency"] for mode in modes],
            masses=[mode["reduced_mass"] for mode in modes],
            constants=[mode["force_constant"] for mode in modes],
            intensities=[mode["ir_intensity"] for mode in modes],
            modes=np.asarray([mode["displacements"] for mode in modes], dtype=float))
        frames = {}
        for mode in self.shown_modes(number):
            title = rf"Mode {mode['mode']}, $\tilde{{\nu}}={mode['frequency']:.2f}\,{unit_latex('1 / centimeter')}$"
            frames[title] = vibrations.trajectory(mode["mode"], amplitude=0.6 * ureg.angstrom, steps=21)
        return frames

    def thermochemistry_table(self, number):
        """Gaussian's thermochemistry summary at its temperature and pressure."""
        thermo = self.jobs[number - 1]["thermochemistry"]
        rows = [
            (quantity("temperature"), thermo["temperature"], "K"), (quantity("pressure"), thermo["pressure"], "atm"),
            (quantity("zero_point_correction"), thermo["zero_point"], "hartree"),
            (quantity("thermal_correction_energy"), thermo["thermal_energy"], "hartree"),
            (quantity("thermal_correction_enthalpy"), thermo["thermal_enthalpy"], "hartree"),
            (quantity("thermal_correction_gibbs"), thermo["thermal_gibbs"], "hartree"),
            (quantity("energy_zero_point_total"), thermo["energy_zero_point"], "hartree"),
            (quantity("energy_thermal_total"), thermo["energy_thermal"], "hartree"),
            (quantity("enthalpy_total_symbol"), thermo["enthalpy"], "hartree"), (quantity("gibbs_total_symbol"), thermo["gibbs"], "hartree"),
            (quantity("symmetry_number"), thermo["symmetry_number"], None),
        ]
        return pd.DataFrame([(name, _value(value, unit, 10)) for name, value, unit in rows if value is not None],
                            columns=["quantity", "value"])

    def thermal_components(self, number):
        """Gaussian's thermal contributions by quantity, with the printed vibrational modes in a subtable."""
        rows = self.jobs[number - 1]["thermal_components"]
        aggregates = {row["component"].lower(): row for row in rows
                      if not re.fullmatch(r"(?:vibration\s+)?\d+", row["component"], re.I)}
        modes = [(int(match.group(1)), row) for row in rows
                 if (match := re.fullmatch(r"(?:vibration\s+)?(\d+)", row["component"], re.I))]
        table = []
        for key, field in (("thermal_energy", "energy"), ("heat_capacity", "heat_capacity"), ("entropy", "entropy")):
            values = {"quantity": quantity(key)}
            # Gaussian prints the energy contributions in kilocalories per mole; the other two stay in calories.
            shown = _to_kj if key == "thermal_energy" else (lambda value: value)
            for name in ("total", "electronic", "translational", "rotational"):
                if (row := aggregates.get(name)) is not None and row.get(field) is not None:
                    values["thermal_" + name] = shown(row[field])
            vibrational = aggregates.get("vibrational")
            if vibrational is not None and vibrational.get(field) is not None:
                # The aggregate and its printed modes share one nested group under the Vibrational heading.
                vibrational_values = {"Aggregate": shown(vibrational[field])}
                vibrational_values.update({rf"$k={mode}$": shown(row[field])
                                           for mode, row in modes if row.get(field) is not None})
                values["thermal_vibrational"] = pd.DataFrame([vibrational_values])
            table.append(values)
        return pd.DataFrame(table, columns=["quantity", "thermal_total", "thermal_electronic", "thermal_translational",
                                            "thermal_rotational", "thermal_vibrational"])

    def thermochemistry_levels(self, number):
        """Reported energies in eV relative to the inferred electronic-structure reference."""
        thermo = self.jobs[number - 1]["thermochemistry"]
        pairs = [("energy_zero_point", "zero_point"), ("energy_thermal", "thermal_energy"),
                 ("enthalpy", "thermal_enthalpy"), ("gibbs", "thermal_gibbs")]
        reference = next((thermo[total] - thermo[correction] for total, correction in pairs
                          if thermo.get(total) is not None and thermo.get(correction) is not None), None)
        if reference is None:
            return pd.DataFrame(columns=["level", "relative_energy", "absolute_energy"])
        values = [(r"$E_{\mathrm{el}}$", reference),
                  (r"$E_{\mathrm{el}}+E_{\mathrm{ZPE}}$", thermo.get("energy_zero_point")),
                  (r"$U$", thermo.get("energy_thermal")), (r"$H$", thermo.get("enthalpy")),
                  (r"$G$", thermo.get("gibbs"))]
        return pd.DataFrame([dict(level=label, relative_energy=_to_ev(value - reference), absolute_energy=_to_ev(value))
                             for label, value in values if value is not None])

    def thermochemistry_chart(self, number):
        """Thermodynamic energy levels relative to the electronic-structure energy."""
        data = self.thermochemistry_levels(number)
        if len(data) < 2:
            return None
        data = data.rename(columns={"level": "thermo_level", "relative_energy": "thermo_relative_energy"})
        return _chart(data).mark_tick(thickness=3, size=38).encode(
            x=_nominal("thermo_level", list(data.thermo_level)),
            y=alt.Y(f"{PLOT}thermo_relative_energy:Q", scale=_MARGIN),
            tooltip=[alt.Tooltip(f"{PLOT}thermo_level:N"), alt.Tooltip(f"{PLOT}thermo_relative_energy:Q", format=".6f"),
                     alt.Tooltip(f"{PLOT}absolute_energy:Q", format=".6f")])

    def _homo(self, number):
        """One-based index of the highest occupied alpha orbital."""
        return self.jobs[number - 1]["electron_counts"][0]

    def spins(self, number):
        """The spin channels of a job's SCF: alpha alone for a restricted wavefunction, alpha and beta for an
        unrestricted one, whose output prints both."""
        records = self.jobs[number - 1]["orbital_data"]["orbitals"]
        return ["alpha", "beta"] if any(record.get("spin") == "beta" for record in records) else ["alpha"]

    def _scf_orbitals(self, number, spin="alpha"):
        """The occupied and virtual orbital energies of one spin channel of a job's last SCF; a restricted job's beta
        channel is its alpha one."""
        records = self.jobs[number - 1]["orbital_data"]["orbitals"]
        return next((record for record in reversed(records) if record.get("spin", "alpha") == spin),
                    next(record for record in reversed(records) if record.get("spin", "alpha") == "alpha"))

    def symmetry(self, number, spin="alpha"):
        """Point group of the geometry and symmetry of the canonical orbitals of one spin channel of a job, from its
        saved checkpoint when that holds the job's orbitals: None without one, for NTOs or when its orbital energies
        differ from the job's last SCF."""
        job = self.jobs[number - 1]
        if job.get("nto_particles") or not job.get("orbital_data", {}).get("orbitals"):
            return None
        path = self._job_checkpoint(number)
        symmetry = _symmetry_cached(str(path), spin) if path else None
        if symmetry is None:
            return None
        orbitals = self._scf_orbitals(number, spin)
        energies = np.concatenate([orbitals["occupied"], orbitals["virtual"]])
        own = np.array([energy for s in symmetry.sets for energy in [s.energy] * len(s.indices)])
        if len(own) != len(energies) or np.abs(own - energies).max() > 1e-4:
            return None
        return symmetry

    def orbital_sets(self, number, spin="alpha"):
        """Canonical orbital sets of one spin channel of a job's last SCF, degenerate orbitals together: with their
        symmetry when ``symmetry`` finds it, otherwise by energy alone."""
        if (symmetry := self.symmetry(number, spin)) is not None:
            return symmetry.sets
        orbitals = self._scf_orbitals(number, spin)
        return _energy_sets(orbitals["occupied"], orbitals["virtual"])

    def symmetry_points(self, number):
        """What the orbital and state labels mean for a job, one sentence each."""
        symmetry = self.symmetry(number)
        if symmetry is None:
            return [r"Orbitals use indices $\psi_{i}$; symmetry labels require a matching checkpoint and successful assignment."]
        group = symmetry.group.name
        computed = self.jobs[number - 1]["point_group"]
        points = [f"Labels use ${group}$ symmetry: lowercase for orbitals, capitals for states."]
        if computed and not _same_name(group, computed):
            points.append(f"Gaussian computed in {_point_group(computed)}, so the labels it printed belong to that group.")
        return points

    def symmetry_note(self, number):
        """Sentences on what the orbital and state labels mean for a job."""
        return " ".join(self.symmetry_points(number))

    def _closed_symmetry(self, number):
        """The orbital symmetry of a closed-shell job, or None."""
        electrons = self.jobs[number - 1]["electron_counts"] or []
        closed = len(electrons) == 2 and electrons[0] == electrons[1]
        return self.symmetry(number) if closed else None

    def selection_rules(self, number):
        """Markdown on why a state is bright or dark: the oscillator strength, the dipole selection rule of the point
        group of the geometry, and the states each leading transition between orbital sets can form."""
        text = r"""Oscillator strength measures the transition dipole (atomic units):

$$
f_n=\frac{2}{3}\,\Delta E_n\left|\langle\Psi_0|\hat{\mathbf r}|\Psi_n\rangle\right|^2,\qquad
\langle\Psi_0|\hat{\mathbf r}|\Psi_n\rangle=\int\mathbf r\,\rho_{0n}(\mathbf r)\,\mathrm{d}\mathbf r
$$

"""
        symmetry = self._closed_symmetry(number)
        if symmetry is None:
            return text + """Without the symmetry of the states, only $f_n$ tells bright states from dark ones.

"""
        group = symmetry.group
        ground = next(irrep.label for irrep in group.irreps if np.allclose(irrep.characters, 1))
        components = " and ".join(f"${f'({axes})' if ',' in axes else axes}$ in ${label}$"
                                  for label, axes in group.dipole.items())
        allowed = r",\ ".join(group.dipole)
        text += rf"""In ${group.name}$, the closed-shell ground state is $^{{1}}{ground}$. Dipole components lie {components}; allowed states satisfy:

$$
\Gamma_0\otimes\Gamma_{{\hat{{\mathbf r}}}}\otimes\Gamma_n\ni {ground}\quad\Longrightarrow\quad\Gamma_n\in\lbrace {allowed}\rbrace
$$

"""
        pairs, seen = [], set()
        for state in self.final_states(number):
            weights, sets = {}, {}
            for configuration in state["configurations"]:
                if configuration["direction"] != "->":
                    continue
                source = self._set_of(number, configuration["occupied"], configuration.get("spin"))
                target = self._set_of(number, configuration["virtual"], configuration.get("spin"))
                # A restricted contribution stands for both spins, so its weight is twice its squared amplitude.
                spin = configuration.get("spin")
                key = (source.label(), target.label(), spin)
                sets[key] = (source, target)
                weights[key] = weights.get(key, 0) + (1 if spin else 2) * configuration["amplitude"] ** 2
            for key, weight in weights.items():
                source, target = sets[key]
                if weight >= 0.1 and key not in seen and source.irrep and target.irrep:
                    seen.add(key)
                    pairs.append((source, target))
        if not pairs:
            return text

        def product(first, second):
            counts = group.reduce(first.characters * second.characters)
            return r"\oplus ".join((f"{round(count)}" if round(count) > 1 else "") + irrep.label
                                   for count, irrep in zip(counts, group.irreps) if round(count) > 0)

        lines = " \\\\\n".join(rf"\Gamma({s.label()}\rightarrow{a.label()})&={s.irrep.orbital()}\otimes "
                               rf"{a.irrep.orbital()}={product(s.irrep, a.irrep)}" for s, a in pairs)
        text += rf"""Excitations transform as orbital-representation products; configuration signs determine dipole cancellation.

$$
\begin{{aligned}}
{lines}
\end{{aligned}}
$$

"""
        return text

    def inversion(self, number):
        """Whether the geometry of a job, by its orbital symmetry, has an inversion centre."""
        symmetry = self.symmetry(number)
        return symmetry is not None and any(np.allclose(matrix, -np.eye(3)) for matrix in symmetry.group.operations)

    def _set_of(self, number, index, spin=None):
        """The orbital set of a one-based orbital index, in its spin channel; None means a restricted orbital."""
        return next(s for s in self.orbital_sets(number, spin or "alpha") if index - 1 in s.indices)

    def final_states(self, number):
        """Excited states of the job's last TD solution. A TD optimization solves the states again at every geometry,
        restarting the state numbering each time; only the set at the final geometry describes the result."""
        states = self.jobs[number - 1]["excitations"]
        starts = [index for index, state in enumerate(states) if index == 0 or state["state"] <= states[index - 1]["state"]]
        return states[starts[-1]:] if starts else []

    def td_solutions(self, number):
        """Number of TD solutions in the job, one per geometry it solved the states at."""
        states = self.jobs[number - 1]["excitations"]
        return sum(1 for index, state in enumerate(states) if index == 0 or state["state"] <= states[index - 1]["state"])

    def states(self, number):
        """The final excited states, each with its name, numbered per spin multiplicity as S_n or T_n, its symmetry
        and character, its dipole selection from the ground state, and its configurations merged over degenerate
        orbitals into transitions between orbital sets with their summed weight 2c^2 in percent."""
        job = self.jobs[number - 1]
        states = self.final_states(number)
        symmetry = self.symmetry(number)
        electrons = job["electron_counts"] or []
        closed = len(electrons) == 2 and electrons[0] == electrons[1]
        counts, result = {}, []
        for state in states:
            multiplicity = state.get("multiplicity")
            counts[multiplicity] = counts.get(multiplicity, 0) + 1
            letter = SPIN_LETTERS.get(multiplicity)
            name = f"${letter}_{{{counts[multiplicity]}}}$" if letter else rf"$\Psi_{{{state['state']}}}$"
            merged = {}
            for configuration in state["configurations"]:
                source = self._set_of(number, configuration["occupied"], configuration.get("spin"))
                target = self._set_of(number, configuration["virtual"], configuration.get("spin"))
                arrow = r"\rightarrow" if configuration["direction"] == "->" else r"\leftarrow"
                # An unrestricted contribution names its spin after each orbital.
                spin = configuration.get("spin")
                channel = rf"\,(\{spin})" if spin else ""
                key = (source.label(), target.label(), arrow, spin)
                entry = merged.setdefault(key, dict(
                    transition=f"${source.label()}{channel}{arrow}{target.label()}{channel}$", sets=(spin, source, target),
                    character=(f"${source.character_label()}{arrow}{target.character_label()}$"
                               if source.character and target.character else ""),
                    weight_percent=0.0))
                entry["weight_percent"] += (100 if spin else 200) * configuration["amplitude"] ** 2
            configurations = sorted(merged.values(), key=lambda entry: -entry["weight_percent"])
            result.append(dict(state=state, name=name, multiplicity=multiplicity, configurations=configurations))
        # Degenerate states together: consecutive, of one multiplicity, equal in energy at the printed precision.
        groups = []
        for entry in result:
            last = groups[-1] if groups else None
            if (last and last[-1]["multiplicity"] == entry["multiplicity"]
                    and abs(last[-1]["state"]["energy"] - entry["state"]["energy"]) < 1e-3):
                last.append(entry)
            else:
                groups.append([entry])
        for group in groups:
            irrep = None
            if symmetry is not None and closed:
                irrep = state_symmetry(symmetry, [[(c["occupied"], c["virtual"], c["amplitude"])
                                                   for c in entry["state"]["configurations"] if c["direction"] == "->"]
                                                  for entry in group])
            for entry in group:
                multiplicity = entry["multiplicity"]
                entry["term"] = f"$^{{{multiplicity}}}{irrep.label}$" if irrep is not None and multiplicity else ""
                if not closed or multiplicity is None:
                    entry["selection"] = None
                elif multiplicity != 1:
                    entry["selection"] = (False, "spin")
                elif irrep is None:
                    entry["selection"] = None
                elif irrep.label in symmetry.group.dipole:
                    entry["selection"] = (True, f"${symmetry.group.dipole[irrep.label]}$")
                else:
                    entry["selection"] = (False, "")
                # The character of the transitions holding most of the weight.
                shares = {}
                for configuration in entry["configurations"]:
                    shares[configuration["character"]] = shares.get(configuration["character"], 0) + configuration["weight_percent"]
                total = sum(shares.values())
                leading = sorted(shares.items(), key=lambda item: -item[1])
                if not leading or "" in shares:
                    entry["character"] = ""
                elif leading[0][1] >= 0.7 * total:
                    entry["character"] = leading[0][0]
                else:
                    entry["character"] = ", ".join(name for name, share in leading if share >= 0.2 * total)
        return result

    def excitations_table(self, number, icons):
        """Excited states: each with its name, symmetry, character and dipole selection, its energy, wavelength and
        oscillator strengths, and a subtable of its transitions between orbital sets with their summed weight;
        columns that no state fills are left out. The dipole selection is a tick from ``icons`` with the dipole
        components that reach the state, or a cross, marked spin when spin forbids it."""
        job = self.jobs[number - 1]
        velocity = {row["state"]: row["oscillator"] for row in job["velocity_moments"]}
        rows = []
        for entry in self.states(number):
            state = entry["state"]
            configurations = pd.DataFrame(entry["configurations"], columns=["transition", "character", "weight_percent"])
            if not configurations.character.astype(bool).any():
                configurations = configurations.drop(columns="character")
            rows.append(dict(state=entry["name"], term=entry["term"], character=entry["character"],
                             selection=(f"{icons[entry['selection'][0]]} {entry['selection'][1]}".strip()
                                        if entry["selection"] else ""), excitation=state["energy"], wavelength=state["wavelength"],
                             oscillator=state["oscillator"], velocity=velocity.get(state["state"]),
                             spin_squared=state["spin_squared"], configurations=configurations))
        table = pd.DataFrame(rows, columns=["state", "term", "character", "selection", "excitation", "wavelength",
                                            "oscillator", "velocity", "spin_squared", "configurations"])
        empty = [column for column in ("term", "character", "selection") if not table[column].astype(bool).any()]
        return table.drop(columns=empty)

    @_hovered
    def spectrum_chart(self, number):
        """Stick spectrum of the excited states against wavelength: each state a rule from zero to its oscillator
        strength, over the ultraviolet, visible and infrared regions."""
        data = pd.DataFrame([dict(state=entry["name"], wavelength=entry["state"]["wavelength"],
                                  oscillator=entry["state"]["oscillator"], excitation=entry["state"]["energy"],
                                  spectral_region=_region(entry["state"]["wavelength"], UV_REGIONS),
                                  series="Oscillator strength")
                             for entry in self.states(number)])
        color = _series("Oscillator strength")
        sticks = _chart(data).encode(
            x=alt.X(f"{PLOT}wavelength:Q", scale=_MARGIN), y=alt.Y(f"{PLOT}oscillator:Q"), color=color,
            tooltip=[PLOT + "state", alt.Tooltip(f"{PLOT}excitation:Q", format=".4f"),
                     alt.Tooltip(f"{PLOT}wavelength:Q", format=".2f"), alt.Tooltip(f"{PLOT}oscillator:Q", format=".4f"),
                     alt.Tooltip(f"{PLOT}spectral_region:N")])
        return alt.layer(sticks.mark_rule(strokeWidth=2, clip=True).encode(y2=alt.datum(0)),
                         *_regions("wavelength", data.wavelength.min(), data.wavelength.max(), UV_REGIONS))

    @_hovered
    def configurations_chart(self, number):
        """Weights of every excited state's transitions between orbital sets, stacked per state, coloured by
        transition."""
        states = self.states(number)
        data = pd.DataFrame([dict(state=entry["name"], transition=configuration["transition"],
                                  weight_percent=configuration["weight_percent"])
                             for entry in states for configuration in entry["configurations"]])
        order = [entry["name"] for entry in states]
        # Transitions in order of first appearance, each in a colour of its own however many there are.
        transitions = list(dict.fromkeys(data.transition))
        return _chart(data).mark_bar().encode(
            x=_nominal("state", order), y=alt.Y(f"{PLOT}weight_percent:Q", stack="zero"),
            # Whole labels: Vega would otherwise truncate them; the page wraps the legend to the plot's width.
            color=alt.Color(f"{PLOT}transition:N", legend=alt.Legend(labelLimit=0),
                            scale=alt.Scale(domain=transitions, range=_distinct_colors(len(transitions)))),
            tooltip=[PLOT + "state", PLOT + "transition", alt.Tooltip(f"{PLOT}weight_percent:Q", format=".1f")])

    @_hovered
    def orbitals_chart(self, number, window=4):
        """Canonical orbital energies of a linked job's last SCF around the gap, as ``_levels_chart`` draws them, both
        spin channels of an unrestricted job side by side."""
        spins = self.spins(number)
        return _levels_chart([(spin if len(spins) > 1 else None, self.orbital_sets(number, spin)) for spin in spins],
                             window)

    def frontier_table(self, number):
        """Energies of the HOMO and LUMO sets of each spin channel, with their symmetry labels, and the HOMO–LUMO gap in
        eV: for an unrestricted job, the lowest unoccupied orbital of either channel above the highest occupied one."""
        spins = self.spins(number)
        rows, tops, bottoms = [], [], []
        for spin in spins:
            sets = self.orbital_sets(number, spin)
            top = next(s for s in reversed(sets) if s.occupied)
            bottom = next(s for s in sets if not s.occupied)
            channel = rf"^{{\{spin}}}" if len(spins) > 1 else ""
            words = f" {spin}" if len(spins) > 1 else ""
            rows += [(Quantity(rf"HOMO{words} energy $\epsilon_{{\mathrm{{HOMO}}}}{channel}$, ${top.label()}$",
                               quantity("highest_occupied_energy").description), top.energy),
                     (Quantity(rf"LUMO{words} energy $\epsilon_{{\mathrm{{LUMO}}}}{channel}$, ${bottom.label()}$",
                               quantity("lowest_unoccupied_energy").description), bottom.energy)]
            tops.append(top.energy)
            bottoms.append(bottom.energy)
        rows.append((quantity("orbital_gap_row"), min(bottoms) - max(tops)))
        return pd.DataFrame([dict(quantity=name, electronvolt=_to_ev(value)) for name, value in rows])

    def _frontier_composition(self, number, window=2):
        """The Mulliken share in percent of each atom's functions of each angular momentum in the frontier orbital sets,
        at least ``window`` sets on each side of the gap, of each spin channel in turn: ``shown`` (the sets), ``names``
        (HOMO, LUMO_1, ... by set, with the spin as a superscript for an unrestricted job), ``spins`` (each set's
        channel), ``unrestricted``,
        ``orbitals`` (per orbital index, shape orbitals x atoms x momenta), ``means`` (by set, its orbitals averaged),
        ``numbers`` (atomic numbers) and ``momenta`` (the letters of the momenta); None without a saved checkpoint of a
        supported basis, or when the checkpoint holds natural transition orbitals."""
        cache = self.__dict__.setdefault("_compositions", {})
        if (number, window) in cache:
            return cache[number, window]
        result = None
        if not self.jobs[number - 1]["nto_particles"] and (path := self._job_checkpoint(number)):
            overlap = _overlap_cached(str(path))
            if overlap is not None:
                records = _records(path)
                spins = self.spins(number)
                unrestricted = len(spins) > 1
                shown, names, blocks, means, channels = [], {}, [], {}, {}
                try:
                    for spin in spins:
                        sets = self.orbital_sets(number, spin)
                        part = _frontier(sets, window, True) + _frontier(sets, window, False)
                        shares = orbital_composition(records, [index for s in part for index in s.indices], overlap,
                                                     spin=spin) * 100
                        first = 0
                        for s in part:
                            means[id(s)] = shares[first:first + len(s.indices)].mean(axis=0)
                            channels[id(s)] = spin
                            first += len(s.indices)
                        shown += part
                        names.update(_frontier_names(part, spin if unrestricted else None))
                        blocks.append(shares)
                except ValueError:
                    blocks = []
                if blocks:
                    shares = np.concatenate(blocks)
                    result = dict(shown=shown, names=names, spins=channels, unrestricted=unrestricted, orbitals=shares,
                                  means=means, numbers=np.asarray(records["Atomic numbers"], dtype=int),
                                  momenta="".join(map(momentum_letter, range(shares.shape[2]))),
                                  coordinates=(np.asarray(records["Current cartesian coordinates"], dtype=float)
                                               .reshape(-1, 3) * ureg.bohr).to("angstrom").magnitude)
        cache[number, window] = result
        return result

    def orbital_composition_charts(self, number, window=4):
        """The share $w_A$ in percent of the atoms in the frontier orbital sets as heat maps that follow the molecule's
        bonds, one matrix per bonded fragment and, for an unrestricted job, per spin channel, titled by the fragment's
        formula and sharing one colour scale: one column per set of the level diagram, at least ``window`` orbitals each
        side of the gap, from the lowest to the highest; one row per atom group of ``_bonded_groups``, a heavy atom
        with its hydrogens, in the order of the bonds. Groups below 1% of every set are summed as the rest of their
        fragment, or as the whole fragment when none reaches it. Hovering a cell lists the set, the group, $w_A$ and its
        parts $w_{A,l}$; degenerate components are averaged. None where ``_frontier_composition`` is."""
        composition = self._frontier_composition(number, window)
        if composition is None:
            return None
        shown, names, momenta = composition["shown"], composition["names"], composition["momenta"]
        columns = [f"share_{letter}" for letter in momenta]
        means = np.stack([composition["means"][id(s)] for s in shown])
        # The matrices' rows, each fragment's groups with at least 1% of some set, and the rest of it summed.
        fragments = []
        for formula, groups in _bonded_groups(composition["numbers"], composition["coordinates"]):
            fragment = rf"$\ce{{{formula}}}$"
            kept = [(label, atoms) for label, atoms in groups if (means[:, atoms].sum(axis=(1, 2)) >= 1).any()]
            rest = [atom for label, atoms in groups if (label, atoms) not in kept for atom in atoms]
            if rest and (np.abs(means[:, rest].sum(axis=(1, 2))) >= 0.05).any():
                kept.append((rf"Rest of {fragment}" if kept else fragment, rest))
            if kept:
                fragments.append((fragment, kept))
        channels = [spin for spin in ("alpha", "beta") if any(composition["spins"][id(s)] == spin for s in shown)]
        upper = max(float(means.sum(axis=2).max()), 1.0)
        # One width of the row labels for every matrix, from the longest, so the matrices' columns line up.
        band = 24 + 9 * max(len(re.sub(r"\\ce\{|[$}]", "", label)) for _, kept in fragments for label, _ in kept)
        charts = []
        for spin in channels:
            sets = [(s, part) for s, part in zip(shown, means) if composition["spins"][id(s)] == spin]
            levels = [names[id(s)] for s, _ in sets]
            for position, (fragment, kept) in enumerate(fragments):
                rows = []
                for s, part in sets:
                    for label, atoms in kept:
                        shares = part[atoms].sum(axis=0)
                        # Rounded shares, with a rounded negative zero written as zero.
                        rows.append(dict(frontier_level=names[id(s)], orbital=f"${s.label()}$", composition_atom=label,
                                         share_total=round(float(shares.sum()), 1) + 0.0,
                                         **{column: round(float(value), 1) + 0.0 for column, value in zip(columns, shares)}))
                # Nominal axes write each LaTeX name as it is, the shared number format would turn it into NaN, and
                # labels are whole: one cut short ends in an ellipsis that leaves its math unclosed.
                # The matrices stack on one x-axis, written under the last; equal label bands keep their columns aligned.
                last = position == len(fragments) - 1
                charts.append(_chart(pd.DataFrame(rows)).mark_rect(stroke="white", strokeWidth=1).encode(
                    x=alt.X(f"{PLOT}frontier_level:N", sort=levels,
                            axis=alt.Axis(labelExpr="datum.value", labelOverlap=False) if last else None),
                    y=alt.Y(f"{PLOT}composition_atom:N", sort=[label for label, _ in kept], title=fragment,
                            axis=alt.Axis(labelExpr="datum.value", labelOverlap=False, labelLimit=0,
                                          minExtent=band, maxExtent=band)),
                    # One colour scale for every matrix, its legend under the last one of each spin channel.
                    color=alt.Color(f"{PLOT}share_total:Q", legend=alt.Undefined if last else None,
                                    scale=alt.Scale(domain=[0, upper], range=list(COMPOSITION_COLORS), clamp=True)),
                    tooltip=[f"{PLOT}frontier_level", f"{PLOT}orbital", f"{PLOT}composition_atom",
                             alt.Tooltip(f"{PLOT}share_total:Q", format=".1f"),
                             *[alt.Tooltip(f"{PLOT}{column}:Q", format=".1f") for column in columns]]
                ).properties(height=alt.Step(22)))
        return charts

    def scf_population(self, number):
        """The final SCF's population analysis when its evaluation and geometry are known, else None."""
        job = self.jobs[number - 1]
        evaluations = job["evaluations"]
        found = [entry for entry in job["populations"] if "SCF" in entry["density"]
                 and entry.get("evaluation") == len(evaluations) - 1 and entry.get("geometry") is not None]
        return found[-1] if evaluations and found else None

    def _charge_viewer(self, number, charges, label, symbol="q"):
        """Molstar view of the job's last geometry with each atom coloured by its charge, red negative and blue
        positive on a scale symmetric about zero, with its charge, written as ``symbol``, in its hover label."""
        details = [rf"${symbol}={{{charge:+.3f}}}\,{unit_latex('elementary_charge')}$" for charge in charges]
        return MolstarViewer(self.trajectory(number)[-1:], atom_values=charges, atom_details=details,
                             color_label=label, trail=False)

    def charge_values(self, number):
        """Mulliken atomic charges of the job's last SCF population analysis, by atom."""
        return pd.Series([row["charge"] for row in self.scf_population(number)["mulliken_charges"]])

    def charges_viewer(self, number):
        """Mulliken atomic charges of the job's last SCF population analysis, drawn on the molecule."""
        population = self.scf_population(number)
        charges = [row["charge"] for row in population["mulliken_charges"]]
        geometry = self.jobs[number - 1]["geometries"][population["geometry"]]
        details = [rf"$q={{{charge:+.3f}}}\,{unit_latex('elementary_charge')}$" for charge in charges]
        return MolstarViewer(_frames(geometry["atomic_numbers"], [geometry["vectors"]]), atom_values=charges,
                             atom_details=details, color_label=quantity("mulliken_charge"), trail=False)

    def formatted_checkpoint(self, value):
        """Formatted checkpoint of a checkpoint reference: the retained one, or else one converted with formchk from
        the retained binary checkpoint into the local cache, never into the run folder; None when neither exists."""
        path = _checkpoint_path(self.folder, value)
        if path.exists():
            return path
        binary = (self.folder / value).resolve()
        tool = shutil.which("formchk") or str(Path.home() / ".local/bin/formchk")
        if not binary.exists() or not Path(tool).exists():
            return None
        stat = binary.stat()
        digest = _checkpoint_digest(binary, stat.st_mtime_ns, stat.st_size)
        target = CACHE_FCHK / f"{binary.stem}-{digest}.fchk"
        if not target.exists():
            CACHE_FCHK.mkdir(parents=True, exist_ok=True)
            subprocess.run([tool, str(binary), str(target)], check=True, capture_output=True)
        return target

    def _job_checkpoint(self, number):
        """Formatted checkpoint the job saved through its %chk, or None."""
        commands = self.jobs[number - 1]["links"][0]["commands"]
        value = next((v for k, v in commands.items() if k.lower() == "%chk"), None)
        return value and self.formatted_checkpoint(value)

    @staticmethod
    def _orbital_viewer(path, orbitals, label, name, symbol, isovalue, spacing, atom_shares=None, parts=((), ()),
                        spins=None, momenta=""):
        """Molstar snapshots of alpha orbitals of a formatted checkpoint, one per (title, zero-based index), each drawn
        as its surfaces at amplitude -isovalue (red) and +isovalue (blue). ``atom_shares``, one pair of atom shares
        and hover texts per orbital, adds the viewer's composition toggles. ``parts``, the dropdowns and the parts of
        ``_orbital_parts``, add dropdowns after the orbital's that draw each orbital's part at the same isovalue.
        An orbital may name its spin channel third, as (title, index, spin); ``spins``, both channels of an
        unrestricted job, adds a Spin dropdown before the orbital's. ``atom_shares`` holds, per orbital, its shares in
        percent by atom and angular momentum, whose letters are ``momenta``; the composition toggle colours the atoms by
        the shown part's own share, on a scale per part: $w_A$ for the whole orbital, $w_{A,l}$ for the functions of
        one angular momentum, and for one atom its $w_A$ alone.

        Each orbital is evaluated from its basis functions on a ``spacing`` grid in bohr over the box where its
        amplitude reaches an eighth of the isovalue, found first on a coarse grid. The page carries that whole box in the
        compact encoding of ``CubeGrid.compact``, so the viewer's settings can move the surfaces down to an eighth of
        the isovalue or render the amplitude as a volume that fades out inside the box."""
        def surface(index, spin, part=None):
            origin, axes, atoms, values = _orbital_cached(path, index, spacing, isovalue, part, spin)
            return VolumeSurface(grid=CubeGrid(origin, axes, atoms, values), isovalue=isovalue, signed=True,
                                 floor=isovalue / 8)
        orbitals = [(item[0], item[1], item[2] if len(item) > 2 else "alpha") for item in orbitals]
        axes, pieces = parts
        choices, fields = (), None
        if len(pieces) > 1 or spins:
            several = len(pieces) > 1
            # Every snapshot as its keys, orbital, spin and part. A part that never reaches the lowest level the viewer
            # can show, an eighth of the isovalue, has nothing to draw, so that combination is not offered.
            snapshots = []
            for k, (_, index, spin) in enumerate(orbitals):
                for keys, part in (pieces if several else pieces[:1]):
                    if part is not None and np.abs(_orbital_cached(path, index, spacing, isovalue, part, spin)[3]).max() < isovalue / 8:
                        continue
                    snapshots.append(((*((spin,) if spins else ()), k, *(keys if several else ())), k, index, spin, part))
            surfaces = {key: surface(index, spin, part) for key, _, index, spin, part in snapshots}
            # Only the options some snapshot uses, in their own order.
            used = [set(key[axis] for key, *_ in snapshots) for axis in range(len(snapshots[0][0]))]
            lead = [("Spin", {spin: rf"$\{spin}$" for spin in spins})] if spins else []
            choices = [*lead, ("Orbital", {k: title for k, (title, _, _) in enumerate(orbitals)}), *(axes if several else [])]
            choices = [(choice[0], {value: text for value, text in choice[1].items() if value in used[axis]}, *choice[2:])
                       for axis, choice in enumerate(choices)]
            if several:
                # A part is named by its own symbol, psi^(A) or psi^(l), on the colour scale and in hover labels.
                numbers = next(iter(surfaces.values())).display_grids[0].atoms[:, 0].astype(int)
                fields = [(str(label).replace(symbol, each, 1), each) for each in
                          (symbol if part is None else rf"{symbol}^{{({_part_tex(numbers, part)})}}"
                           for *_, part in snapshots)]
            if atom_shares is not None:
                atom_shares = [_part_shares(atom_shares[k], part, momenta) for _, k, _, _, part in snapshots]
        else:
            surfaces = {title: surface(index, spin) for title, index, spin in orbitals}
            if atom_shares is not None:
                atom_shares = [_part_shares(matrix, None, momenta) for matrix in atom_shares]
        # The colour scale of each part's shares: w_A, or w_{A,l} for the functions of one angular momentum.
        whole = quantity("share_total")
        atom_label = {"whole": whole, **{f"l{l}": Quantity(str(whole).replace("w_A", rf"w_{{A,{letter}}}"),
                                                             quantity(f"share_{letter}").description)
                                         for l, letter in enumerate(momenta)}}
        return VolumeViewer(surfaces, color_range=(-isovalue, isovalue), colors=("#d7301f", "#2b6cb0"), opacity=0.85,
                            choices=choices,
                            color_label=label, field_name=name, field_symbol=symbol,
                            field_unit=unit_latex("bohr ** -1.5"), atom_shares=atom_shares,
                            atom_label=atom_label if atom_shares is not None else "",
                            atom_title="Toggle Orbital Composition", surface_title="Toggle Orbital Surfaces",
                            snapshot_fields=fields)

    def potential_cube(self):
        """The first electrostatic-potential cube the run saved under fields/ beside its density cube, or None."""
        return next((path for path in sorted((self.folder / "fields").glob("*-potential.cube"))
                     if path.with_name(path.name.replace("-potential.cube", "-density.cube")).exists()), None)

    def potential_viewer(self, density_level=0.002, isovalue=0.5):
        """The electrostatic potential of the saved cube in one viewer with two views, switched from its toolbar with
        the camera kept: on the electron-density surface at ``density_level`` in elementary charges per cubic bohr, in
        volts on one symmetric colour scale; and in space, at -isovalue (red, where a positive charge is attracted) and
        +isovalue (blue), in volts, whose settings move the level down to an eighth of ``isovalue`` or as far as the
        cube's box allows. Requires ``potential_cube``."""
        path = self.potential_cube()
        density = path.with_name(path.name.replace("-potential.cube", "-density.cube"))
        # The cube holds hartree per elementary charge.
        volts = (1 * ureg.hartree / ureg.e).to("volt", "energy").magnitude
        surface = VolumeSurface(grid=CubeGrid.read(density), color_grid=CubeGrid.read(path), isovalue=density_level,
                                color_factor=volts)
        scale = max(abs(limit) for limit in surface.color_limits())
        return VolumeViewer(surface, color_range=(-scale, scale), color_label=quantity("electrostatic_potential"),
                            title=POTENTIAL_ON_SURFACE, alternates=[potential_in_space(surface, isovalue)])

    def nto_viewer(self, number, isovalue=0.02, spacing=0.2):
        """The dominant hole and particle natural transition orbitals of a job that saved them, with the pair weight;
        None without their checkpoint."""
        path = self._job_checkpoint(number)
        if not path:
            return None
        records = _records(path)
        occupied = int(records["Number of alpha electrons"])
        weights = np.asarray(records["Alpha Orbital Energies"], dtype=float)
        orbitals = [(rf"{role} $\phi_{{\mathrm{{{symbol}}}}}$, weight $\lambda={weights[index]:.3f}$", index)
                    for role, symbol, index in (("Hole", "h", occupied - 1), ("Particle", "p", occupied))]
        return self._orbital_viewer(path, orbitals, quantity("nto_amplitude"), "NTO amplitude", r"\phi", isovalue, spacing)

    def transition_densities(self, number, spacing=0.2, bounds=None):
        """Hole and particle densities of a job that saved its NTOs, from ``_transition_cached``; None without their
        checkpoint."""
        if not self.jobs[number - 1]["nto_particles"]:
            return None
        path = self._job_checkpoint(number)
        return _transition_cached(path, spacing, bounds) if path else None

    def charge_transfer_table(self, number):
        """Charge-transfer descriptors of the excitation from its hole and particle densities.

        The difference density is split into its gain rho+ and loss rho-; their integral is the transferred charge
        q_CT and their centroids are d_CT apart (Le Bahers, Adamo and Ciofini, J. Chem. Theory Comput. 7, 2498
        (2011)). The hole and particle centroids give the distance D, and the integral of sqrt(rho_h rho_p) their
        overlap."""
        origin, axes, _, hole, particle, pairs, total = self.transition_densities(number)
        found = _transfer(origin, axes, hole, particle)
        charge, distance, separation, overlap = (found["transferred"], found["transfer_distance"], found["separation"],
                                                 found["overlap"])
        dipole = (charge * ureg.elementary_charge * distance * ureg.angstrom).to("debye").magnitude
        return _quantities([
            (r"Hole–particle centroid distance $D$", _value(separation, "angstrom", 4),
             "How far the excited electron's density centre moves."),
            (r"Hole–particle overlap $S_{\mathrm{hp}}=\int\sqrt{\rho_{\mathrm{h}}\rho_{\mathrm{p}}}\,\mathrm{d}\mathbf{r}$",
             _number(overlap, 4), r"$S_{\mathrm{hp}}=1$ for a hole and particle in the same place, $S_{\mathrm{hp}}=0$ for fully separated ones."),
            (r"Transferred charge $q_{\mathrm{CT}}=\int\rho_{+}\,\mathrm{d}\mathbf{r}$", _value(charge, "elementary_charge", 4),
             r"Density gained where $\Delta\rho>0$, equal to that lost where $\Delta\rho<0$."),
            (r"Charge-transfer distance $d_{\mathrm{CT}}$", _value(distance, "angstrom", 4),
             r"Between the centroids of the gain $\rho_{+}$ and the loss $\rho_{-}$."),
            (r"Charge-transfer dipole $\mu_{\mathrm{CT}}=q_{\mathrm{CT}}d_{\mathrm{CT}}$", _value(dipole, "debye", 4), ""),
            ("NTO pairs", rf"${pairs}$, with $\sum_k\lambda_k={total:.4f}$",
             r"All of them, each weighted by $\lambda_k/\sum_j\lambda_j$."),
        ])

    def transition_density_viewer(self, number, isovalue=0.001, spacing=0.2):
        """The electron density the excitation removes, adds and moves on the molecule, chosen in the snapshot
        selector: the loss -rho_h, the gain rho_p and their sum, the difference density, at +-isovalue.

        The fields come from a grid as fine as the orbital views', over the box where either density reaches an
        eighth of the isovalue on the coarser grid of the descriptors, so the viewer's settings can move the surfaces
        down to an eighth of the isovalue or render the density as a volume that fades out inside the box."""
        origin, axes, _, hole, particle, _, _ = self.transition_densities(number)
        step = np.diag(axes)
        inside = np.argwhere(np.maximum(hole, particle) >= isovalue / 8)
        bounds = (origin + (inside.min(axis=0) - 3) * step, origin + (inside.max(axis=0) + 3) * step)
        origin, axes, atoms, hole, particle, _, _ = self.transition_densities(number, spacing, bounds)
        fields = {r"Loss $-\rho_{\mathrm{h}}$": -hole.astype(float), r"Gain $\rho_{\mathrm{p}}$": particle.astype(float),
                  r"Difference $\Delta\rho=\rho_{\mathrm{p}}-\rho_{\mathrm{h}}$": particle.astype(float) - hole.astype(float)}
        surfaces = {title: VolumeSurface(grid=CubeGrid(origin, axes, atoms, values), isovalue=isovalue, signed=True,
                                         floor=isovalue / 8)
                    for title, values in fields.items()}
        # Blue where electrons leave, red where they arrive, as red marks negative charge in the charge views.
        return VolumeViewer(surfaces, color_range=(-isovalue, isovalue), colors=("#2b6cb0", "#d7301f"), opacity=0.85,
                            color_label=quantity("density_change_field"), field_name="Density change",
                            field_symbol=r"\Delta\rho", field_unit=unit_latex("bohr ** -3"))

    def transition_charges_viewer(self, number):
        """Each atom's change in charge on excitation, minus the difference density integrated over the region
        nearest its nucleus, drawn on the molecule in the charge colours."""
        origin, axes, atoms, hole, particle, _, _ = self.transition_densities(number)
        difference = particle.astype(float) - hole.astype(float)
        step = np.diag(axes)
        nuclei = atoms[:, 2:]
        from scipy.spatial import cKDTree

        # Every grid point is assigned to its nearest nucleus, found in a k-d tree of the nuclei.
        points = np.stack(np.meshgrid(*[origin[k] + step[k] * np.arange(difference.shape[k]) for k in range(3)],
                                      indexing="ij"), axis=-1).reshape(-1, 3)
        nearest = cKDTree(nuclei).query(points)[1]
        changes = np.bincount(nearest, weights=difference.ravel(), minlength=len(nuclei))
        return self._charge_viewer(number, list(-changes * np.prod(step)), quantity("charge_change"), r"\Delta q")

    def transition_sets(self, number, threshold=10):
        """Orbital sets that a transition of at least ``threshold`` percent of some excited state's weight leaves or
        enters, as pairs of their spin channel (alpha for a restricted job) and the set, in order of channel and energy."""
        used = {(spin or "alpha", id(s)) for entry in self.states(number) for configuration in entry["configurations"]
                if configuration["weight_percent"] >= threshold
                for spin, *pair in [configuration["sets"]] for s in pair}
        return [(spin, s) for spin in self.spins(number) for s in self.orbital_sets(number, spin) if (spin, id(s)) in used]

    def transition_orbitals_viewer(self, number, isovalue=0.02, spacing=0.2):
        """Every orbital of the sets the excited states' main transitions use, with its label, component, character
        and energy; None without the job's checkpoint."""
        path = self._job_checkpoint(number)
        if not path or self.jobs[number - 1]["nto_particles"]:
            return None
        chosen, spins = self.transition_sets(number), self.spins(number)
        entries = [(title, index, spin) for spin in spins
                   for title, index in _orbital_entries([s for channel, s in chosen if channel == spin])]
        return self._orbital_viewer(path, entries, quantity("orbital_amplitude"), "Orbital amplitude", r"\psi",
                                    isovalue, spacing, spins=spins if len(spins) > 1 else None)

    def _state_groups(self, number):
        """The states grouped into degenerate levels, as ``states`` returns them, with each level's name."""
        levels = []
        for entry in self.states(number):
            last = levels[-1] if levels else None
            if (last and last[-1]["multiplicity"] == entry["multiplicity"] and last[-1]["term"] == entry["term"]
                    and abs(last[-1]["state"]["energy"] - entry["state"]["energy"]) < 1e-3):
                last.append(entry)
            else:
                levels.append([entry])
        return levels

    def _level_name(self, level):
        """Name of a degenerate level, such as S_3/S_4."""
        return "$" + "/".join(entry["name"].strip("$") for entry in level) + "$"

    def state_densities(self, number, spacing=0.25, bounds=None):
        """Hole and particle densities of every degenerate level of excited states, from ``_state_densities``;
        None without the job's checkpoint."""
        path = self._job_checkpoint(number)
        if not path or self.jobs[number - 1]["nto_particles"]:
            return None
        groups = [[[(c["occupied"], c["virtual"], c["amplitude"]) for c in entry["state"]["configurations"]
                    if c["direction"] == "->"] for entry in level] for level in self._state_groups(number)]
        return _state_densities(str(path), groups, spacing, bounds)

    def state_transfer_table(self, number):
        """How far each level of excited states moves charge: the transferred charge q_CT, the distance d_CT it moves
        and the hole-particle overlap, from the densities of ``state_densities``."""
        origin, axes, _, holes, particles = self.state_densities(number)
        rows = []
        for level, hole, particle in zip(self._state_groups(number), holes, particles):
            found = _transfer(origin, axes, hole, particle)
            rows.append(dict(state=self._level_name(level), term=level[0]["term"], transferred=found["transferred"],
                             transfer_distance=found["transfer_distance"], overlap=found["overlap"]))
        table = pd.DataFrame(rows)
        return table if table.term.astype(bool).any() else table.drop(columns="term")

    def state_density_viewer(self, number, isovalue=0.001, spacing=0.2):
        """The difference density of every level of excited states, one snapshot each: blue where electrons leave,
        red where they arrive, at +-isovalue, over the box where any level's densities reach an eighth of it."""
        origin, axes, _, holes, particles = self.state_densities(number)
        step = np.diag(axes)
        inside = np.argwhere(np.maximum(holes.max(axis=0), particles.max(axis=0)) >= isovalue / 8)
        bounds = (origin + (inside.min(axis=0) - 3) * step, origin + (inside.max(axis=0) + 3) * step)
        origin, axes, atoms, holes, particles = self.state_densities(number, spacing, bounds)
        surfaces = {}
        for level, hole, particle in zip(self._state_groups(number), holes, particles):
            term = f", {level[0]['term']}" if level[0]["term"] else ""
            values = particle.astype(float) - hole.astype(float)
            surfaces[self._level_name(level) + term] = VolumeSurface(
                grid=CubeGrid(origin, axes, atoms, values), isovalue=isovalue, signed=True,
                floor=isovalue / 8)
        return VolumeViewer(surfaces, color_range=(-isovalue, isovalue), colors=("#2b6cb0", "#d7301f"), opacity=0.85,
                            color_label=quantity("density_change_field"), field_name="Density change",
                            field_symbol=r"\Delta\rho", field_unit=unit_latex("bohr ** -3"))

    def drawable(self, number):
        """Whether the job's orbitals can be drawn: its formatted checkpoint is saved and ``basis_supported`` accepts
        its basis."""
        path = self._job_checkpoint(number)
        return bool(path) and basis_supported(_records(path))

    def frontier_viewer(self, number, isovalue=0.02, spacing=0.2, window=2):
        """The highest occupied and lowest unoccupied canonical orbital sets, at least ``window`` orbitals each, with
        their labels, components and energies, from the job's saved checkpoint; None without it or when the
        checkpoint holds NTOs."""
        if self.jobs[number - 1]["nto_particles"]:
            return None
        path = self._job_checkpoint(number)
        if not path:
            return None
        spins = self.spins(number)
        unrestricted = len(spins) > 1
        shown, entries = [], []
        for spin in spins:
            sets = self.orbital_sets(number, spin)
            part = _frontier(sets, window, True) + _frontier(sets, window, False)
            shown += part
            entries += [(title, index, spin) for title, index
                        in _orbital_entries(part, _frontier_names(part, spin if unrestricted else None))]
        # Each orbital's composition on the atoms; a degenerate component, a mixture of its set, takes the set's average.
        composition, shares = self._frontier_composition(number, window), None
        if composition is not None:
            shares, first = [], 0
            for s in shown:
                for k in range(len(s.indices)):
                    part = composition["means"][id(s)] if s.components else composition["orbitals"][first + k]
                    shares.append(part)
                first += len(s.indices)
        return self._orbital_viewer(path, entries, quantity("orbital_amplitude"), "Orbital amplitude", r"\psi", isovalue,
                                    spacing, shares, self._orbital_parts(composition), spins if unrestricted else None,
                                    composition["momenta"] if composition else "")

    @staticmethod
    def _orbital_parts(composition, momentum_share=1, atom_share=1, most=16):
        """The parts of the frontier orbitals the viewer offers, chosen in three dropdowns after the orbital's: Part (the
        whole orbital, the functions of each angular momentum with at least ``momentum_share`` percent of some orbital
        shown, or one atom), then Element and Atom for an atom, among the atoms with at least ``atom_share`` percent of
        some orbital (the rows of the composition chart), at most ``most`` of the strongest; the atom's number is typed
        into a field and clamped to the nearest atom of the chosen element. Both are hidden for the other parts.

        Returns:
            The dropdowns as pairs of a label and its options, and the parts as pairs of their keys on the three dropdowns
            and a part for ``_orbital_cached`` (None for the whole orbital); no dropdowns and only the whole orbital
            without a composition.
        """
        whole = [(("whole", "all", "all"), None)]
        if composition is None:
            return (), whole
        kinds, elements, atoms = {"whole": r"Whole orbital $\psi$"}, {"all": "All elements"}, {"all": "All atoms"}
        pieces = list(whole)
        means = np.stack([composition["means"][id(s)] for s in composition["shown"]])
        for momentum, letter in enumerate(composition["momenta"]):
            if (means[:, :, momentum].sum(axis=1) >= momentum_share).any():
                kinds[f"l{momentum}"] = rf"${letter}$ functions, $\psi^{{({letter})}}$"
                pieces.append(((f"l{momentum}", "all", "all"), ("momentum", momentum)))
        strongest = means.sum(axis=2).max(axis=0)
        chosen = sorted(atom for atom in np.argsort(-strongest, kind="stable")[:most] if strongest[atom] >= atom_share)
        if chosen:
            kinds["atom"] = r"One atom, $\psi^{(A)}$"
        numbers = composition["numbers"]
        # Elements in order of atomic number, each atom under its element in input order.
        for atom in sorted(chosen, key=lambda atom: (numbers[atom], atom)):
            element = ELEMENTS[numbers[atom] - 1]
            elements.setdefault(element, rf"$\mathrm{{{element}}}$")
            atoms[int(atom)] = str(atom + 1)
            pieces.append((("atom", element, int(atom)), ("atom", int(atom))))
        return [("Part", kinds), ("Element", elements, {"collapse": True}),
                ("Atom", atoms, {"input": True, "collapse": True})], pieces

    def dipole_table(self, number):
        """Dipole moment components and magnitude in debye."""
        x, y, z, total = self.scf_population(number)["dipole"]
        return pd.DataFrame([dict(component=name, dipole=value) for name, value in
                             ((r"$\mu_x$", x), (r"$\mu_y$", y), (r"$\mu_z$", z), (r"$\lvert\mu\rvert$", total))])

    def dipole_equation(self, number):
        """The printed dipole vector and magnitude in debye and atomic units, in the printed orientation."""
        values = self.scf_population(number)["dipole"]
        debye = [_number(value, 6).strip("$") for value in values[:3]]
        atomic = [_number((value * ureg.debye).to("e*bohr").magnitude, 6).strip("$") for value in values[:3]]
        magnitude, magnitude_atomic = _number(values[3], 6).strip("$"), _number(
            (values[3] * ureg.debye).to("e*bohr").magnitude, 6).strip("$")
        vector = lambda parts: r" \\ ".join(parts)
        return (rf"$$\boldsymbol{{\mu}}=\begin{{pmatrix}}{vector(debye)}\end{{pmatrix}}\,\mathrm{{D}}"
                rf"=\begin{{pmatrix}}{vector(atomic)}\end{{pmatrix}}\,e a_0,\qquad "
                rf"|\boldsymbol{{\mu}}|={magnitude}\,\mathrm{{D}}={magnitude_atomic}\,e a_0$$")

    def static_polarizability(self, number):
        """Last complete, nonzero static tensor; zero-filled response placeholders are not a physical result."""
        entries = [entry for entry in self.jobs[number - 1]["polarizability"]
                   if entry.get("complete") and entry.get("frequency") == 0
                   and any(value != 0 for row in entry["tensor"] for value in row)]
        return entries[-1] if entries else None

    def polarizability_equation(self, number):
        """Static tensor and isotropic mean in the printed coordinate frame."""
        tensor = self.static_polarizability(number)["tensor"]
        rows = [" & ".join(_number(value, 6).strip("$") for value in row) for row in tensor]
        matrix = r" \\ ".join(rows)
        mean = _number(sum(tensor[i][i] for i in range(3)) / 3, 6).strip("$")
        return (rf"$$\boldsymbol{{\alpha}}=-\frac{{\partial^2E}}{{\partial F_i\,\partial F_j}}"
                rf"=\begin{{pmatrix}}{matrix}\end{{pmatrix}}\,a_0^3,\qquad "
                rf"\bar{{\alpha}}=\tfrac{{1}}{{3}}\operatorname{{tr}}\boldsymbol{{\alpha}}={mean}\,a_0^3$$")

    def quadrupole_equation(self, number):
        """The traceless quadrupole tensor of the archived density, in atomic units and debye angstrom."""
        properties = (self.jobs[number - 1].get("archive") or {}).get("properties", {})
        values = properties.get("Quadrupole")
        if not isinstance(values, list) or len(values) != 6:
            return None
        atomic = _tensor(values, ARCHIVE_TENSORS["Quadrupole"], "e*bohr**2").strip("$")
        debye = _tensor([(value * ureg.e * ureg.bohr**2).to("debye*angstrom").magnitude for value in values],
                        ARCHIVE_TENSORS["Quadrupole"], "debye*angstrom").strip("$")
        return rf"$$\mathbf{{Q}}={atomic}={debye}$$"

    def polarizability_table(self, number):
        """Static polarizability tensor in bohr cubed, from the last complete tensor."""
        entries = [entry for entry in self.jobs[number - 1]["polarizability"] if entry.get("complete")]
        table = pd.DataFrame(np.asarray(entries[-1]["tensor"]), columns=["polar_x", "polar_y", "polar_z"])
        table.insert(0, "axis", ["$x$", "$y$", "$z$"])
        return table

    def stability_table(self, number):
        """Wavefunction stability conclusions."""
        return pd.DataFrame([dict(stable=entry["stable"], message=entry["message"])
                             for entry in self.jobs[number - 1]["stability"]])

    @_hovered
    def lotus_scf_charts(self):
        """Energy and density change at every Lotus SCF iteration."""
        data = pd.DataFrame([dict(iteration=row["iteration"] + 1, native_iteration=row["iteration"], energy=_to_ev(row["energy"]),
                                  density_change=row["density_change"]) for row in self.result["scf_history"]])
        energy = _chart(data.assign(series="Electronic energy")).mark_line(point=True).encode(
            x=alt.X(f"{PLOT}iteration:Q", axis=alt.Axis(tickMinStep=1), scale=_MARGIN), y=alt.Y(f"{PLOT}energy:Q", scale=_MARGIN),
            color=_series("Electronic energy"))
        change = _chart(data.dropna().assign(series="Density change")).mark_line(point=True).encode(
            x=alt.X(f"{PLOT}iteration:Q", axis=alt.Axis(tickMinStep=1), scale=_MARGIN),
            y=alt.Y(f"{PLOT}density_change:Q", scale=alt.Scale(type="log")), color=_series("Density change"))
        return energy, change

    @_hovered
    def lotus_screening_chart(self):
        """Screening parameter applied at each outer iteration."""
        data = pd.DataFrame([dict(iteration=row["iteration"] + 1, native_iteration=row["iteration"], epsilon=row["epsilon"], series="Applied screening")
                             for row in self.result["screening_history"]])
        return _chart(data).mark_line(point=True).encode(
            x=alt.X(f"{PLOT}iteration:Q", axis=alt.Axis(tickMinStep=1), scale=_MARGIN), y=alt.Y(f"{PLOT}epsilon:Q", scale=_MARGIN),
            color=_series("Applied screening"))

    @_hovered
    def lotus_orbitals_chart(self):
        """Frontier orbital gap at each iteration, in eV."""
        data = pd.DataFrame([dict(iteration=row["iteration"] + 1, native_iteration=row["iteration"], gap=_to_ev(row["gap"]), series="Orbital gap")
                             for row in self.result["orbital_history"]])
        return _chart(data).mark_line(point=True).encode(
            x=alt.X(f"{PLOT}iteration:Q", axis=alt.Axis(tickMinStep=1), scale=_MARGIN), y=alt.Y(f"{PLOT}gap:Q", scale=_MARGIN),
            color=_series("Orbital gap"))

    def lotus_summary(self):
        """Final Lotus quantities: method, iterations, convergence, screening, frontier orbitals and weights."""
        result = self.result
        rows = [(quantity("method"), LOTUS_METHODS.get(result["method"], f"`{result['method']}`"), LOTUS_DESCRIPTIONS.get(result["method"], "")),
                (quantity("scf_iterations"), _value(result["scf_iterations"])),
                (quantity("final_density_change"), _value(result["density_change"]))]
        if result["screening_history"]:
            rows.append((quantity("applied_screening"), _value(result["screening_history"][-1]["epsilon"])))
        if (value := self.screening()) is not None:
            rows.append((quantity("evaluated_screening"), _value(value)))
        if result["orbital_history"]:
            last = result["orbital_history"][-1]
            rows += [(quantity("highest_occupied_energy"), _value(last["homo"], "hartree")),
                     (quantity("lowest_unoccupied_energy"), _value(last["lumo"], "hartree")),
                     (quantity("orbital_gap_lotus"), _value(last["gap"], "hartree"))]
        # A weight of zero marks a term the functional does not contain.
        rows += [(LOTUS_WEIGHTS.get(name, name.replace("_", " ").capitalize() + " weight"), _value(value))
                 for name, value in (result["weights"] or {}).items() if value]
        return _quantities(rows)

    def lotus_energy_table(self):
        """Last native Lotus interaction components, excluding its volume and without reweighting exchange."""
        records = self.result["energy_parts"]
        if not records:
            return None
        values = records[-1]["values"]
        exchange = ("nonlocal_exchange_energy" if self.result["method"] in ("ds_ex_vwn", "ds_ex_lyp")
                    else "exact_exchange_energy")
        labels = [("Hartree", "hartree_energy"), ("exact_Ex", exchange),
                  ("pure_dft", "dft_energy"), ("env", "environment_energy"), ("proj", "projection_energy")]
        rows = [(quantity(label), _value(values[key], "hartree", 12))
                for key, label in labels if key in values]
        history = self.result.get("scf_history", [])
        if history:
            rows.append((quantity("lotus_total_energy"), _value(history[-1]["energy"], "hartree", 12)))
        return pd.DataFrame(rows, columns=["quantity", "value"])

    def lotus_checks(self):
        """Response and consistency checks reported by Lotus, one row per scalar entry."""
        rows = []
        for name, check in (self.result["checks"] or {}).items():
            entries = check.items() if isinstance(check, dict) else [("value", check)]
            rows += [dict(check=name.replace("_", " ").capitalize(), quantity=key.replace("_", " ").capitalize(),
                          value=value if isinstance(value, bool) else _value(value))
                     for key, value in entries if not isinstance(value, (list, dict))]
        return pd.DataFrame(rows)


    def checkpoint_files(self):
        """Find locally retained input and final formatted checkpoints without converting binary files.

        Args:
            None.
        Returns:
            Ordered pairs of role and formatted checkpoint path, with duplicate paths removed.
        """
        found = {}
        for job in self.jobs:
            links = job["links"]
            for name, value in links[0]["commands"].items():
                role = name.lower().lstrip("%")
                if role not in ("chk", "oldchk"):
                    continue
                path = _checkpoint_path(self.folder, value)
                if path.exists():
                    found.setdefault(path, "Starting checkpoint" if role == "oldchk" else "Saved checkpoint")
        for path in sorted((self.folder / "checkpoints").glob("*.fchk")):
            found.setdefault(path.resolve(), "Saved checkpoint")
        return sorted([(role, path) for path, role in found.items()], key=lambda item: item[0] != "Starting checkpoint")

    def checkpoints_table(self, checkpoints):
        """The formatted checkpoints as (role, path) pairs, one row each: what it is, or its number in order when
        there are several, its atoms, its energy and its orbital gap in eV."""
        rows = []
        for index, (role, path) in enumerate(checkpoints, 1):
            records = _records(path)
            energies, electrons = records.get("Alpha Orbital Energies"), records.get("Number of alpha electrons")
            gap = (_to_ev(energies[electrons] - energies[electrons - 1])
                   if energies is not None and electrons and electrons < len(energies) else None)
            energy = records.get("Total Energy", records.get("SCF Energy"))
            rows.append(dict(checkpoint=index if len(checkpoints) > 1 else role, atoms=records.get("Number of atoms"),
                             energy=_number(_to_ev(energy), 10) if energy is not None else "", gap=gap))
        table = pd.DataFrame(rows)
        return table.drop(columns="gap") if table.gap.isna().all() else table

    def checkpoint_frames(self, checkpoints):
        """XYZ frames of the checkpoints' geometries in order, for one animated viewer; checkpoints of other atoms
        than the first are left out."""
        read = [read_gaussian_checkpoint(path) for _, path in checkpoints]
        kept = [checkpoint for checkpoint in read if np.array_equal(checkpoint.numbers, read[0].numbers)]
        return xyz_frames(read[0].numbers, np.stack([checkpoint.coordinates.to("angstrom").magnitude for checkpoint in kept]) * ureg.angstrom)

    def checkpoint_orbitals(self, path):
        """Orbital-level charts of a formatted checkpoint, as the output sections draw them: one for a restricted
        wavefunction, the alpha then the beta orbitals for an unrestricted one; empty without orbital energies."""
        records = _records(path)
        charts = []
        for spin in ("Alpha", "Beta"):
            energies = records.get(spin + " Orbital Energies")
            electrons = records.get(f"Number of {spin.lower()} electrons")
            if energies is not None and electrons and electrons < len(energies):
                symmetry = _symmetry_cached(str(path), spin.lower())
                sets = symmetry.sets if symmetry is not None else _energy_sets(energies[:electrons], energies[electrons:])
                charts.append(_hover(_levels_chart([(None, sets)])))
        return charts

    @_hovered
    def checkpoint_path_chart(self, path):
        """Energy along the reaction path a formatted checkpoint holds, relative to its highest point, the transition
        structure, against the reaction coordinate."""
        reaction = read_gaussian_checkpoint(path).irc
        energies = reaction.energies.to("hartree").magnitude
        data = pd.DataFrame(dict(reaction_coordinate=reaction.coordinate.magnitude,
                                 path_energy=(energies - energies.max()) * 627.509474))
        return _chart(data.sort_values("reaction_coordinate")).mark_line(point=True).encode(
            x=f"{PLOT}reaction_coordinate:Q", y=f"{PLOT}path_energy:Q")

    def checkpoint_modes_table(self, path):
        """Harmonic modes of a formatted checkpoint with their reduced masses, force constants and IR intensities, as
        the output sections list them."""
        modes = read_gaussian_checkpoint(path).vibrations
        return pd.DataFrame(dict(mode=range(1, len(modes.frequencies) + 1), frequency=modes.frequencies.to("1/cm").magnitude,
                                 reduced_mass=modes.masses.to("dalton").magnitude,
                                 force_constant=modes.constants.to("millidyne/angstrom").magnitude,
                                 intensity=modes.intensities.to("km/mol").magnitude))


class StructureFile:
    """The records of an SDF or Molfile, as runflow.structures reads them, for the viewer page's structure sections."""

    def __init__(self, path):
        self.path = Path(path)
        self.records = read_sdf(path)
        self.first = self.records[0]
        # Whether every record has the same atoms in the same order, as conformers do, so that one viewer plays them.
        self.shared = all(list(record["numbers"]) == list(self.first["numbers"]) for record in self.records)

    def viewers(self, limit=10):
        """One viewer whose frames are the records when they share their atoms, else one per record up to
        ``limit``."""
        frames = lambda record: record["coordinates"].to("angstrom").magnitude
        if self.shared:
            return [MolstarViewer(xyz_frames(self.first["numbers"], np.stack([frames(record) for record in self.records])
                                             * ureg.angstrom))]
        return [MolstarViewer(xyz_frames(record["numbers"], frames(record)[None] * ureg.angstrom))
                for record in self.records[:limit]]

    def summary_table(self):
        """The first record's title, formula, atoms and bonds, and the program and dimensions its header states."""
        from runflow.reaction import hill_formula

        # The Hill system: with carbon, carbon, hydrogen, then alphabetically; without carbon, all alphabetically.
        formula = re.sub(r"(\d+)", r"_{\1}", hill_formula(self.first["numbers"]))
        rows = [("Title", self.first["title"]), ("Formula", rf"$\mathrm{{{formula}}}$"),
                ("Atoms", _value(len(self.first["numbers"]))), ("Bonds", _value(self.first["bonds"]))]
        if len(self.records) > 1:
            rows.append(("Records", _value(len(self.records))))
        written = self.first["written"]
        rows += [("Written by", self.first["program"]),
                 ("Written", f"{written.day} {written:%b %Y, %H:%M}" if written else ""),
                 ("Coordinates", self.first["dimensions"]),
                 ("Comment", self.first["comment"])]
        return _quantities([row for row in rows if row[1]])

    def coordinates_table(self):
        """The first record's Cartesian coordinates in angstrom."""
        coordinates = self.first["coordinates"].to("angstrom").magnitude
        table = pd.DataFrame(coordinates, columns=["x", "y", "z"])
        table.insert(0, "element", [ELEMENTS[number - 1] for number in self.first["numbers"]])
        table.insert(0, "atom", range(1, len(coordinates) + 1))
        return table

    def charges(self):
        """The first record's partial charges by atom, from a data field named for them, with the field's name; None
        without one."""
        for name, text in self.first["properties"].items():
            if "CHARGE" in name.upper():
                values = atom_values(text, len(self.first["numbers"]))
                if values is not None:
                    return name, values
        return None

    def charges_viewer(self):
        """The first record with each atom coloured by its partial charge, red negative and blue positive on a scale
        symmetric about zero, with the charge in its hover label."""
        _, charges = self.charges()
        frame = xyz_frames(self.first["numbers"], self.first["coordinates"].to("angstrom").magnitude[None] * ureg.angstrom)
        details = [rf"$q={{{charge:+.3f}}}\,{unit_latex('elementary_charge')}$" for charge in charges]
        return MolstarViewer(frame, atom_values=list(charges), atom_details=details,
                             color_label=quantity("atom_partial_charge"), trail=False)

    def fields_table(self):
        """The first record's single-line data fields, by name."""
        rows = [dict(field=f"`{name}`", value=text) for name, text in self.first["properties"].items()
                if "\n" not in text]
        return pd.DataFrame(rows, columns=["field", "value"])

    def long_fields(self):
        """The first record's data fields of several lines, as (name, text)."""
        return [(name, text) for name, text in self.first["properties"].items() if "\n" in text]

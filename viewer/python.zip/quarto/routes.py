"""Timestamp-based website routes, independent of descriptive page and browser titles."""
import copy
import functools
import re
import yaml
from pathlib import Path

PROJECTS = Path(__file__).resolve().parent.parent / "projects"


def write(path, text):
    """Write a generated file only when its text changes, so an unchanged rebuild keeps its modification time and
    quarto/render.py skips the pages that read it."""
    if not path.exists() or path.read_text() != text:
        path.write_text(text)


@functools.lru_cache(maxsize=None)
def _parsed_yaml(text):
    """Parsed YAML text, which a build asks for tens of thousands of times over the same few files."""
    return yaml.safe_load(text)


def load_yaml(text):
    """YAML text as data of the caller's own, parsed once per distinct text so that an edited file is always read afresh."""
    return copy.deepcopy(_parsed_yaml(text))


def readme_metadata(folder):
    """Read YAML front matter from a README; a README without front matter has no metadata."""
    path = Path(folder) / "README.md"
    text = path.read_text()
    match = re.match(r"\A---[ \t]*\n(.*?)\n---[ \t]*(?:\n|$)", text, re.S)
    if not match:
        return {}
    data = load_yaml(match[1]) or {}
    if not isinstance(data, dict):
        raise ValueError(f"{path}: front matter must be a mapping")
    return data


def without_latex(title, source):
    """A title that has no LaTeX, as the browser-tab title of a page that gave none of its own.

    Args:
        title: Title of the page.
        source: Name of the file holding it, for the message.

    Returns:
        The title.

    Raises:
        ValueError: The title has LaTeX. A tab title is written by hand as a plain sentence, never made from a formula.
    """
    if "$" in title:
        raise ValueError(f"{source}: a title with LaTeX needs a page-title in front matter, written as a plain sentence")
    return title


def readme_title(folder):
    """Plain title of a README: its ``page-title`` front matter, else its heading when that has no LaTeX.

    Args:
        folder: Folder holding the README.

    Returns:
        The plain title.

    Raises:
        ValueError: The heading has LaTeX and the README gives no ``page-title``.
    """
    text = (folder / "README.md").read_text()
    if title := readme_metadata(folder).get("page-title"):
        return str(title).strip()
    return without_latex(next(line[2:].strip() for line in text.splitlines() if line.startswith("# ")), f"{folder.name}/README.md")


def page_title(folder):
    """Plain title of the page a project, workflow or calculation folder publishes.

    A workflow page is its notebook, titled by the notebook's ``page-title``; other pages take their README's.

    Args:
        folder: Project, workflow or calculation folder.

    Returns:
        The plain title.
    """
    notebook = folder / "notebook.qmd"
    if notebook.exists():
        header = notebook.read_text().split("---", 2)[1]
        fields = {key: front_matter_text(value) for key, value in re.findall(r"(?m)^(page-title|title):\s*(.+)$", header)}
        return fields.get("page-title") or without_latex(fields["title"], f"{folder.name}/notebook.qmd")
    return readme_title(folder)


def front_matter_text(value):
    """Text of a one-line front-matter value, unquoted as YAML writes single- and double-quoted scalars.

    Args:
        value: The value as written after its key.

    Returns:
        The text.
    """
    value = value.strip()
    if len(value) > 1 and value[0] == value[-1] == "'":
        return value[1:-1].replace("''", "'")
    if len(value) > 1 and value[0] == value[-1] == '"':
        return value[1:-1].replace('\\"', '"')
    return value


def route(folder):
    """Use the original timestamp directories as the published page route.

    Args:
        folder: Scientific project, workflow or run directory.
    Returns:
        Timestamp path relative to projects, without leading or trailing slashes.
    """
    parts = Path(folder).resolve().relative_to(PROJECTS).parts
    if not parts or not all(re.fullmatch(r"\d{4}-\d\d-\d\d_\d{6}", part) for part in parts):
        raise ValueError(f"A page route requires timestamp folders: {folder}")
    return "/".join(parts)


def check_unique():
    """Validate the timestamp route of every documented scientific directory.

    Args:
        None.
    Returns:
        None; raises when a scientific directory lacks a valid timestamp route.
    """
    for readme in PROJECTS.rglob("README.md"):
        if "created" in readme_metadata(readme.parent):
            route(readme.parent)


def created(folder):
    """Read the preserved creation date independently of the descriptive folder name.

    Args:
        folder: Project, workflow or run directory.
    Returns:
        ISO creation date from README metadata.
    """
    value = str(readme_metadata(folder).get("created", ""))
    if not re.fullmatch(r"\d{4}-\d\d-\d\d", value):
        raise ValueError(f"Creation metadata missing or invalid in {folder}")
    return value


def is_page(folder):
    """Check whether a directory is a documented scientific project, workflow or run.

    Args:
        folder: Candidate directory.
    Returns:
        Whether it has a README and retained creation metadata.
    """
    return folder.is_dir() and (folder / "README.md").is_file() and "created" in readme_metadata(folder)


def published(folder):
    """Check whether a folder publishes a notebook page.

    Args:
        folder: Candidate directory.
    Returns:
        Whether it holds a notebook, whose page build_calculations writes.
    """
    return (Path(folder) / "notebook.qmd").is_file()

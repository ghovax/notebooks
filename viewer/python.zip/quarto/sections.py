"""Sections of a calculation page, shared by quarto/build_calculations.py and the in-browser viewer.

Each function returns Quarto Markdown with Python cells; the cells call the ``_calculation`` methods of
quarto/calculations.py, so a page shows only what runflow parsed. The calculation pages render these with Quarto, and
the viewer page renders them in the browser through quarto/viewer.py.
"""
import sourcetypes
import re
from pathlib import PurePath

from runflow.checkpoints import read_fchk_records, read_gaussian_checkpoint
from quantities import unit_latex
from status_cards import findings_table, status_callout


def cell(code):
    """Python cell of a generated page."""
    text: sourcetypes.markdown = f"""```{{python}}
{code}
```

"""
    return text


def show(expression, precision=None):
    """Cell that renders a table of codename columns with their labels."""
    return cell(f"_calculation_table({expression}" + (f", precision={precision})" if precision else ")"))


def chart(expression, zoom=()):
    """Cell that displays one Altair chart, with pan and zoom along the ``zoom`` axes where they make sense."""
    return cell(f"display_chart({expression}" + (f", zoom_axes={tuple(zoom)!r})" if zoom else ")"))


def viewer(expression):
    """Cell that displays one Molstar viewer of XYZ frames."""
    return cell(f"display(MolstarViewer({expression}))")


def fold(heading, content):
    """Collapsible section: the heading stays in the table of contents."""
    text: sourcetypes.markdown = f"""::: {{.fold}}
{heading}

{content}:::

"""
    return text


def gaussian_input(calculation, number, level):
    """Input of one linked Gaussian job: Link 0 commands, route keywords and the molecule specification."""
    job = calculation.jobs[number - 1]
    parts = []
    links = job["links"]
    if links[0]["commands"]:
        text: sourcetypes.markdown = f"""{level} Link 0 commands

Link 0 sets memory, processors and files.

"""
        parts.append(text + show(f"_calculation.links_table({number}, 0)"))
    text: sourcetypes.markdown = f"""{level} Route keywords and options

The route selects the method, basis and job type.

"""
    parts.append(text + show(f"_calculation.route_table({number})"))
    if calculation.gic_table(number) is not None:
        intro = ("`ReadAllGIC` builds no coordinates of its own; the optimization uses only these "
                 "[generalized internal coordinates](https://gaussian.com/gic/)."
                 if calculation.gic_mode(number) == "read-all" else
                 "These [generalized internal coordinates](https://gaussian.com/gic/) add to or change the default ones.")
        text: sourcetypes.markdown = f"""{level} Generalized internal coordinates

- {intro}
- Lines of one form share a row, written for the $n$-th line, or as the first and last when their atoms do not follow $n$.

"""
        parts.append(text + show(f"_calculation.gic_table({number}, _calculation_icon_folder)"))
    if calculation.modredundant_table(number) is not None:
        text: sourcetypes.markdown = f"""{level} Redundant internal coordinate changes

- `ModRedundant` adds, freezes, scans or removes [redundant internal coordinates](https://gaussian.com/opt/) before the
  optimization starts.
- Gaussian may print a coordinate with its atoms reversed.

"""
        parts.append(text + show(f"_calculation.modredundant_table({number}, _calculation_icon_folder)"))
    if calculation.read_optimize_table(number) is not None:
        text: sourcetypes.markdown = f"""{level} Optimized atoms

`ReadOptimize` selects the atoms the [optimization](https://gaussian.com/opt/) moves, applying its rules in order
from every atom.

"""
        parts.append(text + show(f"_calculation.read_optimize_table({number})"))
    if calculation.connectivity_table(number) is not None:
        text: sourcetypes.markdown = """Bonds and bond orders the input gives instead of Gaussian's own,
from which it builds the redundant internal coordinates; each bond is listed once, under its first atom.

"""
        parts.append(fold(f"{level} Connectivity", text + show(f"_calculation.connectivity_table({number})")))
    if calculation.iop_table(number) is not None:
        text: sourcetypes.markdown = f"""{level} Internal options

`IOp` settings override defaults; meanings follow the [IOps Reference](https://gaussian.com/iops/).

"""
        parts.append(text + show(f"_calculation.iop_table({number})"))
    text: sourcetypes.markdown = f"""{level} Molecule specification

The job's title, charge and spin multiplicity, and where Gaussian took its geometry from.

"""
    parts.append(text + show(f"_calculation.molecule_table({number})"))
    return "".join(parts)


def _repeats(calculation, number, methods):
    """Whether every named table or chart of a linked job equals the previous job's, as when a later step reuses the
    same ground state. Charts are compared without Altair's numbered parameter and view names."""
    if number == 1:
        return False
    for name in methods:
        try:
            before, after = (getattr(calculation, name)(index) for index in (number - 1, number))
        except Exception:
            return False
        if hasattr(before, "equals"):
            if not before.equals(after):
                return False
        elif (re.sub(r"(param|view)_\d+", "", before.to_json()) != re.sub(r"(param|view)_\d+", "", after.to_json())):
            return False
    return True


def missing_checkpoint(calculation, number, orbitals):
    """Callout in place of orbitals that cannot be drawn: the formatted checkpoint of the job's %chk is not available,
    or its basis has shells the grid evaluation does not support."""
    commands = calculation.jobs[number - 1]["links"][0]["commands"]
    value = next((value for key, value in commands.items() if key.lower() == "%chk"), None)
    source = (f"the formatted checkpoint `{PurePath(value).with_suffix('.fchk').name}` this job wrote" if value
              else "a formatted checkpoint, and this job wrote none")
    reason = ("whose basis has Cartesian shells above $f$, which are not evaluated" if calculation._job_checkpoint(number)
              else "which is not available")
    text: sourcetypes.markdown = f"""::: {{.callout-important title="Orbitals not shown"}}
The {orbitals} are drawn from {source}, {reason}.
:::

"""
    return text


def symmetry_notice(calculation, number):
    """Explain why the excitation table uses orbital indices instead of symmetry labels."""
    if calculation.symmetry(number) is not None:
        return ""
    if calculation._job_checkpoint(number):
        detail = ("The available formatted checkpoint does not establish the orbital symmetry for this job. "
                  "It must contain canonical orbitals matching the final SCF; the table retains the printed orbital indices.")
    else:
        commands = calculation.jobs[number - 1]["links"][0]["commands"]
        value = next((value for key, value in commands.items() if key.lower() == "%chk"), None)
        source = (f"the matching formatted checkpoint `{PurePath(value).with_suffix('.fchk').name}`" if value
                  else "a matching formatted checkpoint")
        detail = (f"The orbital symmetry labels require {source}, which is not available. "
                  "The table retains the orbital indices and transitions from the output; a matching checkpoint is "
                  "needed to attempt the symmetry assignment.")
    text: sourcetypes.markdown = f"""::: {{.callout-important title="Orbital symmetry not determined"}}
{detail}
:::

"""
    return text


def system_section(calculation, number, level="##"):
    """The system, its level of theory and its solvent, before the parsed input and output."""
    text: sourcetypes.markdown = f"""{level} System

The system the job treated, its symmetry and its electrons; the method and basis are those of the input above.

"""
    relations: sourcetypes.markdown = r"""- $N_\alpha$ and $N_\beta$ count spin-up and spin-down electrons; together they are the nuclear charges $Z_A$ less the charge $q$.
- Their difference fixes the spin projection $M_S=(N_\alpha-N_\beta)/2$; the usual highest-weight input has $S=M_S$.
- Closed shells have doubly occupied orbitals; equal spin counts alone do not establish one.

$$
N_\alpha+N_\beta=\sum_A Z_A-q,\qquad 2S+1=N_\alpha-N_\beta+1
$$

"""
    return text + relations + show(f"_calculation.system_table({number})")


def gaussian_output(calculation, number, level):
    """Output of one linked Gaussian job, each section present only when the job printed its data: the electronic solution,
    then how the geometry moved, then the vibrations and thermochemistry at the result, then ground-state properties and
    last excited states. A section whose data repeat the previous linked job's keeps its heading with a note pointing
    back instead."""
    job = calculation.jobs[number - 1]

    def repeated(*methods):
        """Whether the section's data repeat the previous job's; such a section is left out."""
        return _repeats(calculation, number, methods)

    parts = []
    if job["scf_history"]:
        count = len(job["scf_history"])
        solutions = "solution" if count == 1 else "solutions, one per geometry or state it evaluated"
        if count > 1:
            reading = " The chart shows the number of cycles each SCF needed, against its index."
        elif sum(1 for row in job["scf_history"][0]["cycle_history"] if row["density_rms"]) > 1:
            reading = " The chart shows the RMS density change by cycle; the dashed line is the threshold."
        else:
            reading = ""
        text: sourcetypes.markdown = f"""{level} SCF convergence

The job recorded {count} self-consistent field {solutions}.{reading}

"""
        parts.append(text + (chart(f"_calculation.scf_chart({number})", "x") if reading else ""))
    if job["stability"] and not repeated("stability_table"):
        text: sourcetypes.markdown = f"""{level} Wavefunction stability

SCF stability against orbital rotations.

"""
        parts.append(text + show(f"_calculation.stability_table({number})"))
    if job["optimization_history"] and job["evaluations"]:
        steps = len(job["optimization_history"])
        text: sourcetypes.markdown = rf"""{level} Geometry optimization

Gaussian printed {steps} convergence checks, in output order, against their limits:

- Each energy $E_n$ is measured from that of the last check printed, $E_n-E_N$, which is not assumed converged.
- The forces are given by their largest value, $F_{{\max}}=\max_i\lvert F_i\rvert$, and their root mean square, $F_{{\mathrm{{RMS}}}}=\sqrt{{\tfrac{{1}}{{N}}\sum_{{i=1}}^{{N}}F_i^2}}$, over the $N$ coordinates the optimization uses.
- Displacements $\Delta q$ are in bohr for distances and radians for angles.

"""
        code: sourcetypes.python = f"""_energy, _forces, _displacements = _calculation.optimization_charts({number})
display_chart(_energy, zoom_axes=('x', 'y'))
display_chart(_forces, zoom_axes=('x', 'y'))
display_chart(_displacements, zoom_axes=('x', 'y'))"""
        parts.append(text + cell(code))
    if not job["optimization_history"] and any(
        evaluation.get("force_maximum") is not None or evaluation.get("force_rms") is not None
        for evaluation in job["evaluations"]
    ):
        text: sourcetypes.markdown = f"""{level} Forces along the calculation

Maximum and RMS Cartesian forces at each recorded SCF solution:

- The solutions include reaction-path corrector steps when present.
- They are not geometry-optimization convergence checks.

"""
        parts.append(text + chart(f"_calculation.evaluation_forces_chart({number})", ("x", "y")))
    if len(job["geometries"]) > 1:
        text: sourcetypes.markdown = f"""{level} Geometries along the job

Printed geometries in order; faded frames show the preceding structures.

"""
        parts.append(text + cell(f"display(MolstarViewer(_calculation.trajectory({number})))"))
    if job["irc_points"] and not repeated("irc_chart", "irc_table"):
        points = len(job["irc_points"])
        text: sourcetypes.markdown = f"""{level} Reaction path

The job recorded {points} reaction-path points:

- Energy is relative to the starting saddle when its energy is available.
- The dashed line marks the saddle.

"""
        parts.append(text + chart(f"_calculation.irc_chart({number})", "x"))
    if job["frequency_sets"] and not repeated("ir_chart", "modes_table"):
        imaginary = sum(mode["frequency"] < 0 for mode in job["frequency_sets"][-1])
        note: sourcetypes.markdown = f"""{level} Vibrational frequencies

The latest analysis has {len(job['frequency_sets'][-1])} modes, {imaginary} of them imaginary, shown with their IR intensities over approximate [mid-infrared regions](https://openstax.org/books/organic-chemistry/pages/12-7-interpreting-infrared-spectra), unscaled:

"""
        harmonic: sourcetypes.markdown = r"""- Each wavenumber follows from the mode's force constant and reduced mass, $\tilde{\nu}_k=\frac{1}{2\pi c}\sqrt{k_k/\mu_k}$.
- The IR intensity grows with the squared change of the dipole along the mode, $I_k\propto\lvert\partial\boldsymbol{\mu}/\partial Q_k\rvert^2$.
- A mode is imaginary when $k_k<0$, a direction of negative curvature.

"""
        rule = calculation.infrared_rule(number)
        note += harmonic + (f"""{rule}

""" if rule else "")
        text: sourcetypes.markdown = rf"""{level}# Normal-mode animations

The imaginary modes, the six lowest real modes and the four most IR-intense ones, each scaled so that its largest atomic displacement is

$$
\max_A\lVert\mathbf{{u}}_{{kA}}\rVert=0.6\,\mathrm{{\AA}},
$$

with $\mathbf{{u}}_{{kA}}$ the displacement of atom $A$ in mode $k$.

"""
        modes = job["frequency_sets"][-1]
        parts.append(note + (chart(f"_calculation.ir_chart({number})", "x")
                             if any(mode["frequency"] >= 0 for mode in modes) else ""))
        label: sourcetypes.markdown = f"""{level}# Normal-mode frequencies

Negative wavenumbers mark imaginary modes, not absorption frequencies.

"""
        parts.append(label + chart(f"_calculation.mode_frequencies_chart({number})", "y"))
        if job["geometries"] and all(len(mode["displacements"]) == len(job["geometries"][-1]["atomic_numbers"])
                                     and mode["reduced_mass"] is not None and mode["force_constant"] is not None
                                     and mode["ir_intensity"] is not None for mode in modes):
            parts.append(text + cell(f"display(MolstarViewer(_calculation.mode_frames({number})))"))
    if job["orbital_data"]["orbitals"] and not repeated("frontier_table", "orbitals_chart"):
        note: sourcetypes.markdown = rf"""{level} Frontier orbitals

The orbital gap is not an optical excitation energy:

$$
\Delta\epsilon=\epsilon_{{\mathrm{{LUMO}}}}-\epsilon_{{\mathrm{{HOMO}}}}
$$

"""
        unrestricted = len(calculation.spins(number)) > 1
        points = ["Hover a level to name it; click it to highlight it.", *calculation.symmetry_points(number)]
        detail = (f"Levels near the gap, one column per symmetry{' and spin' if unrestricted else ''}:\n\n"
                  + "".join(f"- {point}\n" for point in points) + "\n")
        composed = calculation._frontier_composition(number) is not None
        text: sourcetypes.markdown = r"""The orbitals in space, chosen in the dropdowns:

- Red surfaces enclose $\psi<-0.02\,@UNIT@$, blue ones $\psi>+0.02\,@UNIT@$.
""".replace("@UNIT@", unit_latex("bohr ** -1.5")) + (r"""- The part dropdown keeps the orbital's terms on one atom or of one angular momentum, at the same isovalue.
- The pie-chart toggle colours the atoms by that part's share, the eye toggle hides the surfaces.
""" if composed else "") + "\n"
        drawn = (text + cell(f"display(_calculation.frontier_viewer({number}))") if calculation.drawable(number)
                 else missing_checkpoint(calculation, number, "frontier orbitals"))
        parts.append(note + show(f"_calculation.frontier_table({number})")
                     + detail + chart(f"_calculation.orbitals_chart({number})", "y") + drawn)
        if calculation.orbital_composition_charts(number) is not None:
            composition: sourcetypes.markdown = level + r"""# Orbital composition

Each atom's share $w_A$ of the frontier orbitals, from the coefficients $\mathbf{c}$ and the overlap $\mathbf{S}$, $l_\mu$ being the angular momentum of $\phi_\mu$:

$$
w_{A,l}=\sum_{\mu\in A,\ l_\mu=l}c_\mu(\mathbf{S}\mathbf{c})_\mu,\qquad w_A=\sum_l w_{A,l}
$$

- One matrix per fragment, its rows atoms with their hydrogens along the bonds; groups with $w_A<1\%$ in every set are summed.
- Hover a cell for its parts $w_{A,l}$.

"""
            parts.append(composition + cell(f"""for _chart in _calculation.orbital_composition_charts({number}):
    display_chart(_chart)"""))
    if calculation.potential_cube() is not None:
        text: sourcetypes.markdown = rf"""{level} Electrostatic potential

The saved electrostatic potential $V$ of the final density, in two views, switched by the last button of the viewer's toolbar:

- On the density surface $\rho=0.002\,@DENSITY@$, red marks where a positive charge is attracted and blue where it is repelled, on one scale symmetric about zero.
- In space, red surfaces enclose $V<-0.5\,@UNIT@$ and blue ones $V>+0.5\,@UNIT@$; the settings lower the level.

""".replace("@DENSITY@", unit_latex("elementary_charge / bohr ** 3")).replace("@UNIT@", unit_latex("volt"))
        parts.append(text + cell("display(_calculation.potential_viewer())"))
    # Charges and dipole of the ground-state density; transition-density analyses, as in NTO jobs, are not charges.
    populations = calculation.scf_population(number)
    quadrupole = calculation.quadrupole_equation(number)
    shown = [name for name, present in (("charge_values", populations and populations["mulliken_charges"]),
                                        ("dipole_table", populations and populations["dipole"])) if present]
    if (shown or quadrupole) and (not shown or not repeated(*shown)):
        text: sourcetypes.markdown = f"""{level} Atomic charges and electric moments

"""
        parts.append(text)
        if populations and populations["mulliken_charges"]:
            text: sourcetypes.markdown = r"""Mulliken charges for the final evaluated geometry, when a matching SCF population analysis was printed:

- Red atoms carry $q_A<0$, blue ones $q_A>0$ and white ones $q_A\approx0$, on a scale symmetric about zero.
- Mulliken populations split shared density equally, $\mathbf P$ being the density and $\mathbf S$ the overlap matrix, so compare charges only within one method and basis.

$$
q_A=Z_A-\sum_{\mu\in A}(\mathbf{P}\mathbf{S})_{\mu\mu}
$$

"""
            parts.append(text + cell(f"display(_calculation.charges_viewer({number}))"))
        if populations and populations["dipole"]:
            text: sourcetypes.markdown = """The dipole moment of the same density, in its printed orientation:

"""
            parts.append(text + cell(f"display(Markdown(_calculation.dipole_equation({number})))"))
        if quadrupole:
            text: sourcetypes.markdown = """The traceless quadrupole moment of the same density, in atomic units and debye ångström:

"""
            parts.append(text + cell(f"display(Markdown(_calculation.quadrupole_equation({number})))"))
    complete = calculation.static_polarizability(number)
    if complete is not None and not repeated("polarizability_table"):
        text: sourcetypes.markdown = rf"""{level} Static polarizability

The last complete response gives the static polarizability tensor and its isotropic average, with the defining energy derivative:

"""
        parts.append(text + cell(f"display(Markdown(_calculation.polarizability_equation({number})))"))
    if job["excitations"] and not repeated("excitations_table"):
        solutions = calculation.td_solutions(number)
        count = len(calculation.final_states(number))
        states_text = (f"The job solved for {count} excited states." if solutions == 1 else
                       f"The job solved for {count} excited states at each of its {solutions} geometries; the table, "
                       "spectrum and weights show those at the final geometry.")
        note: sourcetypes.markdown = f"""{level} Excited states and spectrum

{states_text} The spectrum places each state at its wavelength $\\lambda_n$ with its oscillator strength $f_n$, over conventional [ultraviolet bands](https://www.who.int/news-room/questions-and-answers/item/radiation-ultraviolet-(uv)).

"""
        points = "\n".join("- " + point for point in calculation.symmetry_points(number))
        detail: sourcetypes.markdown = r"""Each excited state in a row:

- $S_{n}$ for singlets, $T_{n}$ for triplets, numbered by energy.
- Symmetry and character of the state.
- A tick marks allowed transitions; a cross marks symmetry- or spin-forbidden ones.
- Its configurations give the orbital set an electron leaves, the one it enters and their summed weight.
""" + points + """

"""
        rules = calculation.selection_rules(number)
        text: sourcetypes.markdown = """Transition weights by state.

"""
        parts.append(note + chart(f"_calculation.spectrum_chart({number})", "x")
                     + detail + symmetry_notice(calculation, number)
                     + show(f"_calculation.excitations_table({number}, _calculation_icons)") + rules
                     + text + chart(f"_calculation.configurations_chart({number})"))
        if not job["nto_particles"] and calculation.drawable(number):
            orbitals: sourcetypes.markdown = f"""{level}# Orbitals of the transitions

Orbitals contributing at least $10\\,{unit_latex('percent')}$ to a state:

- Red surfaces enclose $\\psi<-0.02\\,{unit_latex('bohr ** -1.5')}$, blue ones $\\psi>+0.02\\,{unit_latex('bohr ** -1.5')}$.

"""
            densities: sourcetypes.markdown = f"""{level}# Density change of each state

Density changes by state, with degenerate states grouped:

- Blue surfaces enclose $\\Delta\\rho<-0.001\\,{unit_latex('bohr ** -3')}$, where electrons leave, and red ones $\\Delta\\rho>+0.001\\,{unit_latex('bohr ** -3')}$, where they arrive.
- The densities come from the printed configurations, which leave out amplitudes $\\lvert c_{{ia}}\\rvert<0.1$.

"""
            transfer: sourcetypes.markdown = r"""Hole and particle densities integrate to one electron and average degenerate states.

$$
\rho_{\mathrm{h}}=\frac{\sum_{ij}(\mathbf{X}\mathbf{X}^{\mathsf{T}})_{ij}\,\phi_i\phi_j}{\operatorname{tr}\mathbf{X}\mathbf{X}^{\mathsf{T}}},\qquad
\rho_{\mathrm{p}}=\frac{\sum_{ab}(\mathbf{X}^{\mathsf{T}}\mathbf{X})_{ab}\,\phi_a\phi_b}{\operatorname{tr}\mathbf{X}^{\mathsf{T}}\mathbf{X}},\qquad
\Delta\rho=\rho_{\mathrm{p}}-\rho_{\mathrm{h}}
$$

$$
q_{\mathrm{CT}}=\int\rho_{+}\,\mathrm{d}\mathbf{r},\qquad
d_{\mathrm{CT}}=\lvert\mathbf{R}_{+}-\mathbf{R}_{-}\rvert,\qquad
S_{\mathrm{hp}}=\int\sqrt{\rho_{\mathrm{h}}\rho_{\mathrm{p}}}\,\mathrm{d}\mathbf{r}
$$

$q_{\mathrm{CT}}$, $d_{\mathrm{CT}}$ and $S_{\mathrm{hp}}$ measure transferred charge, centroid separation and overlap.
""" + (r"""Inversion symmetry makes $d_{\mathrm{CT}}$ vanish; use $q_{\mathrm{CT}}$ and $S_{\mathrm{hp}}$ instead.
""" if calculation.inversion(number) else "") + """
"""
            parts.append(orbitals + cell(f"display(_calculation.transition_orbitals_viewer({number}))")
                         + densities + cell(f"display(_calculation.state_density_viewer({number}))")
                         + transfer + show(f"_calculation.state_transfer_table({number})"))
    if job["nto_particles"]:
        text: sourcetypes.markdown = f"""{level} Natural transition orbitals

The dominant pair of natural transition orbitals, chosen in the snapshot selector:

- The hole $\\phi_{{\\mathrm{{h}}}}$ is the orbital the electron leaves, the particle $\\phi_{{\\mathrm{{p}}}}$ the one it enters.
- Their weight $\\lambda$ is the pair's share of the transition density.
- Red surfaces enclose $\\phi<-0.02\\,{unit_latex('bohr ** -1.5')}$, blue ones $\\phi>+0.02\\,{unit_latex('bohr ** -1.5')}$.

"""
        heading: sourcetypes.markdown = f"""{level} Natural transition orbitals

"""
        if not calculation.drawable(number):
            parts.append(heading + missing_checkpoint(calculation, number, "natural transition orbitals"))
        else:
            parts.append(text + cell(f"display(_calculation.nto_viewer({number}))"))
            note: sourcetypes.markdown = rf"""{level} Transition density

NTO pairs contribute according to $\lambda_k/\sum_j\lambda_j$; each density integrates to one electron:

$$
\rho_{{\mathrm{{h}}}}=\frac{{\sum_k\lambda_k\lvert\phi_{{\mathrm{{h}},k}}\rvert^2}}{{\sum_k\lambda_k}},\qquad
\rho_{{\mathrm{{p}}}}=\frac{{\sum_k\lambda_k\lvert\phi_{{\mathrm{{p}},k}}\rvert^2}}{{\sum_k\lambda_k}}.
$$

- Select loss, gain or difference density $\Delta\rho=\rho_{{\mathrm{{p}}}}-\rho_{{\mathrm{{h}}}}$.
- Blue surfaces enclose $\Delta\rho<-0.001\,{unit_latex('bohr ** -3')}$, where electrons leave, and red ones $\Delta\rho>+0.001\,{unit_latex('bohr ** -3')}$, where they arrive.
- $\Delta\rho$ is unrelaxed: exact within TDA, approximate for full TDDFT.

"""
            detail: sourcetypes.markdown = r"""Charge-transfer descriptors use the positive and negative parts of $\Delta\rho$.

"""
            text: sourcetypes.markdown = r"""Atomic charge changes from $\Delta\rho$: red gains electrons; blue loses them.

"""
            parts.append(note + cell(f"display(_calculation.transition_density_viewer({number}))")
                         + detail + show(f"_calculation.charge_transfer_table({number})")
                         + text + cell(f"display(_calculation.transition_charges_viewer({number}))"))
    return "".join(parts)
def prelude(quarto, arguments, icons):
    """First cell of a page: imports, the ``_calculation`` read from ``arguments`` (the source of Calculation's
    arguments), and table helpers drawing booleans with the status icons in ``icons``; ``quarto`` is the folder of
    quarto/calculations.py."""
    code: sourcetypes.python = f"""import sys
sys.path.insert(0, "{quarto}")
from pathlib import Path
import pandas as pd
from runflow.results import read_gaussian_checkpoint, xyz_frames
from IPython.display import Markdown, display
from molstarview import MolstarViewer
from calculations import LABELS, PLOT_LABELS, Calculation

_calculation = Calculation({arguments})
register_plot_labels(PLOT_LABELS)
_calculation_icon_folder = "{icons}"
_calculation_icons = {{True: "![Yes]({icons}check.svg){{.workflow-status}}", False: "![No]({icons}cross.svg){{.workflow-status}}", "Info": "![Info]({icons}hourglass.svg){{.workflow-status}}", "Warning": "![Warning]({icons}warning.svg){{.workflow-status}}", "Error": "![Error]({icons}cross.svg){{.workflow-status}}"}}
_calculation_states = {{"Complete": "![Complete]({icons}check.svg){{.workflow-status}}", "Failed": "![Failed]({icons}cross.svg){{.workflow-status}}", "Running": "![Running]({icons}hourglass.svg){{.workflow-status}}", "Pending": "![Pending]({icons}hourglass.svg){{.workflow-status}}", "Unfinished": "![Unfinished]({icons}hourglass.svg){{.workflow-status}}", "Missing": "![Missing]({icons}hourglass.svg){{.workflow-status}}"}}


def _calculation_labels(data):
    \"\"\"Codename columns under their labels and booleans as status icons, in subtables too.\"\"\"
    data = data.map(lambda value: _calculation_icons[value] if isinstance(value, bool)
                    else _calculation_labels(value) if isinstance(value, pd.DataFrame) else value)
    return data.rename(columns=LABELS)


def _calculation_table(data, precision=5):
    \"\"\"Render a table of codename columns under their labels, with booleans as status icons.\"\"\"
    display(Markdown(scientific_table(_calculation_labels(data), precision=precision)))"""
    return cell(code)


def checkpoint_section(checkpoints, locate, level="##", logged=False):
    """Section of formatted checkpoints, as (role, path) pairs; ``locate`` writes the Python expression of a path.

    One table lists every checkpoint and one viewer animates their geometries in order. Without a log, whose output
    sections already show them, it also draws the last checkpoint's orbital levels, its reaction path and its modes.
    """
    if not checkpoints:
        return ""
    listed = "[" + ", ".join(f"({role!r}, {locate(path)})" for role, path in checkpoints) + "]"
    several = len(checkpoints) > 1
    text: sourcetypes.markdown = f"""{level} Checkpoints

Saved checkpoint{"s" if several else ""}, with energies and frontier gaps{", in read/write order" if several else ""}.

"""
    code: sourcetypes.python = f"""_checkpoints = {listed}
_calculation_table(_calculation.checkpoints_table(_checkpoints))"""
    parts = [text + cell(code)]
    if several or not logged:
        text: sourcetypes.markdown = f"""{level}# Checkpoint geometries

{"The saved geometries, one frame per checkpoint, in order." if several else "The saved geometry."}

"""
        parts.append(text + cell("display(MolstarViewer(_calculation.checkpoint_frames(_checkpoints)))"))
    if logged:
        return "".join(parts)
    last = locate(checkpoints[-1][1])
    checkpoint = read_gaussian_checkpoint(checkpoints[-1][1])
    if _has_orbitals(checkpoints[-1][1]):
        text: sourcetypes.markdown = f"""{level}# Orbital levels

The orbital energies of the last checkpoint around its gap, the alpha then the beta orbitals when they differ.

"""
        parts.append(text + cell(f"""for _chart in _calculation.checkpoint_orbitals({last}):
    display_chart(_chart, zoom_axes=('y',))"""))
    if checkpoint.irc is not None:
        text: sourcetypes.markdown = f"""{level}# Reaction path

The {len(checkpoint.irc.coordinate)} points of the reaction path, animated along it, and their energies against the reaction coordinate.

"""
        parts.append(text + cell(f"display(MolstarViewer(read_gaussian_checkpoint({last}).irc.frames))")
                     + chart(f"_calculation.checkpoint_path_chart({last})", "x"))
    if checkpoint.vibrations is not None:
        text: sourcetypes.markdown = f"""{level}# Vibrational modes

Every harmonic mode with its reduced mass, force constant and infrared intensity.

"""
        parts.append(text + show(f"_calculation.checkpoint_modes_table({last})"))
    return "".join(parts)


def _has_orbitals(path):
    """Whether a formatted checkpoint holds orbital energies."""
    return "Alpha Orbital Energies" in read_fchk_records(path)


def structures_section(structures, locate):
    """Sections of a structure file, a quarto/calculations.py StructureFile: its molecules in a viewer over the first
    record's summary and folded coordinates, its partial charges on the molecule when a data field holds them, and
    its data fields, those of several lines each in a fold; ``locate`` writes the file's Python expression."""
    count = len(structures.records)
    holds = ("one molecule" if count == 1 else
             f"{count} records of the same atoms, shown as the frames of one viewer" if structures.shared else
             f"{count} molecules, each in its own viewer" + (", of which the first ten are shown" if count > 10 else ""))
    text: sourcetypes.markdown = f"""## Structure

The file holds {holds}; bonds are drawn from the distances between atoms.

"""
    code: sourcetypes.python = f"""from calculations import StructureFile
_structures = StructureFile({locate(structures.path)})
for _viewer in _structures.viewers():
    display(_viewer)"""
    detail: sourcetypes.markdown = """The title, formula and size of the first record, and what its header states.

"""
    note: sourcetypes.markdown = """Cartesian coordinates of every atom of the first record.

"""
    parts = [text + cell(code) + detail + show("_structures.summary_table()")
             + fold("### Coordinates", note + show("_structures.coordinates_table()"))]
    charges = structures.charges()
    if charges:
        extra: sourcetypes.markdown = rf"""## Partial charges

The partial charges of the data field `{charges[0]}`, drawn on the first record:

- Red atoms carry $q_A<0$, blue ones $q_A>0$ and white ones $q_A\approx0$, on a scale symmetric about zero.
- Hovering over an atom shows its $q_A$.

"""
        parts.append(extra + cell("display(_structures.charges_viewer())"))
    if structures.first["properties"]:
        remark: sourcetypes.markdown = """## Data fields

The SD data fields stored with the first record; a field of several lines follows in a fold of its own.

"""
        parts.append(remark + (show("_structures.fields_table()") if not structures.fields_table().empty else ""))
        for name, value in structures.long_fields():
            block = "\n".join(["```", value, "```", ""])
            parts.append(fold(f"### `{name}`", block + "\n"))
    return "".join(parts)


def starting_section(calculation, level="###"):
    """The structure a calculation starts from, in a viewer over its folded coordinates; empty without one."""
    geometry = calculation.initial_geometry()
    if not geometry:
        return ""
    overlay = calculation.coordinate_overlay()
    shown = ("" if not overlay else " Bonds and angles the input's coordinate section defines are measured on it, and "
             "the atoms of its dihedrals are labelled $\\tau$." if overlay.get("groups") else
             "" if not overlay else " Bonds and angles the input's coordinate section defines are measured on it.")
    text: sourcetypes.markdown = f"""{level} Starting geometry

The structure the calculation starts from.{shown}

"""
    if overlay:
        return text + cell("display(MolstarViewer(_calculation.geometry_frame(), **_calculation.coordinate_overlay()))")
    return text + viewer("_calculation.geometry_frame()")


def _input_sections(calculation):
    """Everything an input shows on its own, before any output: for a Gaussian input each linked job's Link 0
    commands, route and molecule specification, for a Lotus XYZ input its settings, and the starting geometry."""
    starting = starting_section(calculation)
    jobs = calculation.jobs
    if len(jobs) == 1:
        text: sourcetypes.markdown = f"""### Gaussian input

{gaussian_input(calculation, 1, "####")}{starting}"""
        return text
    if jobs:
        detail: sourcetypes.markdown = f"""### Linked jobs

The input runs {len(jobs)} jobs in turn, each reading the previous job's checkpoint; each has its own section below.

"""
        parts = [detail]
        for number in range(1, len(jobs) + 1):
            note: sourcetypes.markdown = f"""### {calculation.step_name(number)} {{#Input_{calculation.step_anchor(number)} .step}}

{gaussian_input(calculation, number, "####")}{starting_section(calculation, "####") if number == 1 else ""}"""
            parts.append(note)
        return "".join(parts)
    if calculation.lotus_settings() is not None:
        remark: sourcetypes.markdown = """### Settings

Settings from the XYZ comment line.

"""
        return remark + show("_calculation.lotus_settings()") + starting
    extra: sourcetypes.markdown = """### Structure

"""
    return extra + starting if starting else ""


def input_output_tabs(inputs, outputs):
    """Input and Output sections rendered through the shared Quarto/Bootstrap tabset helper."""
    text: sourcetypes.markdown = f"""## Input {{.step}}

{inputs or "No input data are retained for this calculation."}
## Output {{.step}}

{outputs or "No calculation output is available yet."}
"""
    return text


def input_body(calculation, outputs=""):
    """Show retained input, with the Output tab only when output is available."""
    inputs = _input_sections(calculation)
    if not outputs:
        text: sourcetypes.markdown = f"""## Input {{.step}}

{inputs or "No input data are retained for this calculation."}
"""
        return text
    return input_output_tabs(inputs, outputs)



def step_callout(calculation, number, icons):
    """Status callout of one linked job, listing the findings that imply its status."""
    findings = findings_table(calculation.step_findings(number), icons, show_source=False)
    reason: sourcetypes.markdown = findings
    return status_callout(calculation.step_status(number), reason)


def calculation_body(calculation, locate, icons):
    """The system and method, the parsed input and output tabs, and the technical details at the end."""
    inputs, outputs = [], []
    if calculation.program == "gaussian":
        multiple = len(calculation.jobs) > 1
        level = "####" if multiple else "###"
        for number in range(1, len(calculation.jobs) + 1):
            input_text = gaussian_input(calculation, number, level)
            if number == 1:
                input_text += starting_section(calculation, level)
            output_text = gaussian_output(calculation, number, level)
            if multiple:
                anchor = calculation.step_anchor(number)
                name = calculation.step_name(number)
                input_text = f"""### {name} {{#Input_{anchor} .step}}

{input_text}"""
                output_text = f"""### {name} {{#{anchor} .step}}

{step_callout(calculation, number, icons)}
{output_text}"""
            inputs.append(input_text)
            outputs.append(output_text)
    elif calculation.lotus_settings() is not None:
        text: sourcetypes.markdown = """### Settings

Settings from the XYZ comment line.

"""
        inputs.append(text + show("_calculation.lotus_settings()") + starting_section(calculation))
    if calculation.program == "lotus":
        text: sourcetypes.markdown = """### Electronic structure and screening

"""
        screening: sourcetypes.markdown = r"""Screening uses molecular polarizability and volume, not bulk-liquid permittivity.

- $i\in\mathcal O$ and $a\in\mathcal V$ index occupied and virtual orbitals.
- The volume $V$ encloses density above $0.001\,@UNIT@$.

For a doubly occupied reference, the isotropic part of the uncoupled (zeroth-order) polarizability $\boldsymbol{\alpha}^{(0)}$ averages three Cartesian components:

$$
\bar{\alpha}^{(0)}=\frac{1}{3}\operatorname{tr}\boldsymbol{\alpha}^{(0)}
=\frac{4}{3}\sum_{i\in\mathcal O}\sum_{a\in\mathcal V}
\frac{\left\lVert\langle\phi_i|\mathbf r|\phi_a\rangle\right\rVert^2}{\epsilon_a-\epsilon_i}
$$

The squared norm sums Cartesian components. Screening divides polarizability by molecular volume:

$$
\varepsilon_s=1+\frac{4\pi}{V}\,\bar{\alpha}^{(0)}
$$

"""
        screening = screening.replace("@UNIT@", unit_latex("bohr ** -3"))
        terms = {"dd_blyp": ("B88", "LYP"), "dd_svwn": ("Slater", "VWN")}.get(calculation.result["method"])
        if terms:
            screening += rf"""Self-consistent screening repeats the SCF until the applied and evaluated $\varepsilon_s$ agree:

$$
E_{{\mathrm{{XC}}}}=\alpha\,E_{{\mathrm{{X}}}}^{{\mathrm{{HF}}}}+(1-\alpha)\,E_{{\mathrm{{X}}}}^{{\mathrm{{{terms[0]}}}}}+\sqrt{{1-\alpha}}\,E_{{\mathrm{{C}}}}^{{\mathrm{{{terms[1]}}}}},\qquad \alpha=\frac{{1}}{{\varepsilon_s}}
$$

"""
        outputs.append(text + show("_calculation.lotus_summary()", precision=10) + screening)
        if calculation.lotus_energy_table() is not None:
            text: sourcetypes.markdown = """### Energy components

Coulomb, weighted exact exchange, and density-functional exchange–correlation contributions.

"""
            detail: sourcetypes.markdown = """These components omit kinetic, electron–nuclear and nuclear-repulsion terms; density-functional exchange and correlation remain combined.

"""
            outputs.append(text + show("_calculation.lotus_energy_table()", precision=12) + detail)
        if calculation.result["checks"]:
            text: sourcetypes.markdown = """### Checks

Reported response and consistency checks.

"""
            outputs.append(text + show("_calculation.lotus_checks()"))
        if calculation.result["scf_history"]:
            text: sourcetypes.markdown = """### SCF convergence

Energy and density change by recorded SCF step:

- Displayed step numbers start at one.
- Lotus numbers its initial step zero.

"""
            code: sourcetypes.python = """_energy, _change = _calculation.lotus_scf_charts()
display_chart(_energy, zoom_axes=('x',))
display_chart(_change, zoom_axes=('x',))"""
            outputs.append(text + cell(code))
        if calculation.result["orbital_history"]:
            text: sourcetypes.markdown = """### Orbital gap per iteration

The frontier orbital gap at each recorded step, numbered from one.

"""
            outputs.append(text + chart("_calculation.lotus_orbitals_chart()", "x"))
        if calculation.result["screening_history"]:
            text: sourcetypes.markdown = """### Screening convergence

The screening applied at each outer step, numbered from one, as it converges to the evaluated value.

"""
            outputs.append(text + chart("_calculation.lotus_screening_chart()", "x"))
    outputs.append(checkpoint_section(calculation.checkpoint_files(), locate, level="###", logged=calculation.result is not None))
    system = system_section(calculation, 1, "##") if calculation.program == "gaussian" and calculation.jobs else ""
    details: sourcetypes.markdown = """## Technical details

The program, the resources and the timing of the calculation.

"""
    return (system + input_output_tabs("".join(inputs), "".join(outputs)) + details
            + show("_calculation.overview(_calculation_states)"))

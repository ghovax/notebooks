"""Shared calculation execution, reporting and native result diagnostics."""

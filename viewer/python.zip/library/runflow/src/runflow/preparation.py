"""Pieces of a workflow's ``scripts/setup_workflow.py``, which writes its run folders, README and notebook and runs no calculation.

Every workflow that prepares its runs from code does so in one script, ``<workflow>/scripts/setup_workflow.py``, which refuses to
overwrite a run folder. What is the same for every workflow lives here; what is particular to it, such as how its runs are
chosen and what their inputs say, stays in the script.
"""

import re
from dataclasses import dataclass
from pathlib import Path

MERMAID_CONFIG = """---
config:
  markdownAutoWrap: false
  themeVariables:
    fontSize: "13px"
  themeCSS: |
    .nodeLabel, .nodeLabel p { white-space: nowrap !important; }
    .nodeLabel a { display: inline-flex; align-items: baseline; white-space: nowrap; gap: 0.25em; }
    .nodeLabel math { display: inline math !important; math-style: compact; }
    .nodeLabel .katex-display { display: inline; margin: 0; }
  theme: dark
  flowchart:
    useMaxWidth: false
    defaultRenderer: elk
    rankSpacing: 24
    nodeSpacing: 24
    diagramPadding: 8
---
"""


def spoken(rotation):
    """A signed number in words, because Gaussian's documentation says to avoid hyphens in a title.

    Args:
        rotation: Signed number, such as an angle in degrees.

    Returns:
        The number as text, with 'minus' in front of a negative one.
    """
    return f"minus {-rotation}" if rotation < 0 else str(rotation)


def atom_block(atoms):
    """Cartesian atom lines of a Gaussian input from ``(symbol, x, y, z)`` rows.

    Args:
        atoms: Rows of an element symbol and x, y, z coordinates in angstrom.

    Returns:
        One line per atom with six decimals, each ended by a newline.
    """
    return "".join(f"{symbol} {x:.6f} {y:.6f} {z:.6f}\n" for symbol, x, y, z in atoms)


def bullets(items):
    """A Markdown list.

    Args:
        items: The text of each item.

    Returns:
        The items as lines that start with a hyphen, without a trailing newline.
    """
    return "\n".join(f"- {item}" for item in items)


def diagram_text(body):
    """A workflow's Mermaid block: the shared configuration, then the graph, whose colours the build rewrites.

    Args:
        body: Graph source from ``flowchart TB`` on, ending with a newline.

    Returns:
        The fenced Mermaid block.
    """
    return "```mermaid\n" + MERMAID_CONFIG + body + "```\n"


def pending_styles(nodes, arrows):
    """Class and link styles of a diagram whose nodes are all pending; the build regenerates them with the statuses.

    Args:
        nodes: Identifiers of every node, which all receive the pending class.
        arrows: Number of arrows, which receive one link style each in order.

    Returns:
        The class definitions, the class assignment and the link styles, ended by a newline.
    """
    lines = ["    classDef pending stroke:#e5e7eb,stroke-width:2px;",
             "    classDef running stroke:#60A5FA,stroke-width:2px;",
             "    classDef verification stroke-dasharray:5 5;",
             "    classDef success stroke:#4ade80,stroke-width:2px;",
             "    classDef failed stroke:#f87171,stroke-width:2px;",
             "    classDef problems stroke:#facc15,stroke-width:2px;",
             f"    class {','.join(nodes)} pending;"]
    lines += [f"    linkStyle {index} stroke:#e5e7eb,color:#e5e7eb,stroke-width:2px;" for index in range(arrows)]
    return "\n".join(lines) + "\n"


@dataclass(frozen=True)
class Preparation:
    """What a workflow's prepared runs share: where it is, where it runs, when it was made and its figure."""

    # The workflow folder, below its project folder.
    workflow: Path
    # The projects folder on the calculation server, which each run's Slurm script changes into.
    server: str
    # ISO date the workflow was prepared.
    created: str
    # Figure shown after each title, as a path below the project folder, and its caption.
    figure: str
    caption: str

    @property
    def project(self):
        """The project folder.

        Returns:
            The folder that holds the workflow.
        """
        return self.workflow.parent

    def figure_block(self, up):
        """The centred figure of a README ``up`` folders below the project folder.

        Args:
            up: Relative path from the README back to the project folder, such as ../../.

        Returns:
            The HTML figure with the image and its caption.
        """
        return f"""<figure style="display: flex; flex-direction: column; align-items: center; margin: 1em 0;">
<img src="{up}{self.figure}" alt="{self.caption}">
<figcaption>{self.caption}</figcaption>
</figure>
"""

    def submit_text(self, folder, *, name, hours):
        """Slurm script of one run, which runs on its own.

        Args:
            folder: Name of the run folder, which the script changes into on the server.
            name: Slurm job name.
            hours: Wall time as HH:MM, to which zero seconds are added.

        Returns:
            The script, which asks for one node, one task, eight CPUs and 12 GB, logging to ``logs/scheduler.log``, and running
            ``scripts/run.py``.
        """
        return f"""#!/bin/bash
#SBATCH --job-name={name}
#SBATCH --partition=r01,r02,r03,r04,r05,r06,r07,r08,r09
#SBATCH --chdir={self.server}/{self.project.name}/{self.workflow.name}/{folder}
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=12G
#SBATCH --time={hours}:00:00
#SBATCH --output=logs/scheduler.log
#SBATCH --error=logs/scheduler.log
#SBATCH --open-mode=truncate

export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
exec "$HOME/.venvs/gaussian/bin/python" scripts/run.py
"""

    def run_readme(self, folder, *, title, page_title, goal, inputs, parameters, outputs):
        """README of one prepared run, which records what distinguishes it from its siblings.

        Args:
            folder: Name of the run folder.
            title: Heading of the page, which may hold LaTeX.
            page_title: Browser-tab title, a plain sentence.
            goal: The single goal sentence.
            inputs: Markdown of the inputs section.
            parameters: Markdown of the parameters section.
            outputs: Markdown of the outputs section.

        Returns:
            The README text, with the status ``not-submitted``.
        """
        return f"""---
created: '{self.created}'
original-folder: {folder}
role: calculation
page-title: {page_title}
assessment:
  status: not-submitted
---

# {title}
{self.figure_block("../../")}
## Goal

- {goal}

### Inputs

{inputs}

### Parameters

{parameters}

## Outputs

{outputs}

## Scientific assessment

- This run has been prepared but not submitted, so it has no outcome yet.
"""

    def write_run(self, folder, *, stem, input_text, run_script, readme, name, hours):
        """Write one prepared run folder; refuses to touch one that exists.

        Args:
            folder: Name of the run folder, created below the workflow.
            stem: Stem of the Gaussian input file.
            input_text: Text of the Gaussian input.
            run_script: Text of ``scripts/run.py``.
            readme: Text of the run README.
            name: Slurm job name.
            hours: Wall time as HH:MM.

        Raises:
            FileExistsError: The run folder already exists.
        """
        run = self.workflow / folder
        if run.exists():
            raise FileExistsError(f"Run folder already exists: {run}")
        for sub in ("inputs", "logs", "outputs", "checkpoints", "fields", "scripts"):
            (run / sub).mkdir(parents=True)
            if sub in ("logs", "outputs", "checkpoints", "fields"):
                (run / sub / ".gitkeep").write_text("")
        (run / "inputs" / f"{stem}.gjf").write_text(input_text)
        (run / "scripts" / "submit.sh").write_text(self.submit_text(folder, name=name, hours=hours))
        (run / "scripts" / "run.py").write_text(run_script)
        (run / "README.md").write_text(readme)

    def workflow_readme(self, *, page_title, title, status, goal, method, sequence, caveats, diagram):
        """README of a prepared workflow: front matter, the figure, the status quote, its sections and the diagram.

        Args:
            page_title: Browser-tab title, a plain sentence.
            title: Heading of the page.
            status: Sentences of the status quote, one list item each.
            goal: Goal items.
            method: Method items.
            sequence: Steps of the starting point and sequence, numbered in order.
            caveats: Caveat items.
            diagram: The Mermaid block, from ``diagram_text``.

        Returns:
            The README text, with the status ``prepared`` and the work date of the creation day.
        """
        steps = "\n".join(f"{number}. {step}" for number, step in enumerate(sequence, 1))
        quote = "\n".join(f"> - {item}" for item in status)
        return f"""---
created: '{self.created}'
original-folder: {self.workflow.name}
work-dates:
  - '{self.created}'
page-title: {page_title}
assessment:
  status: prepared
---

# {title}
{self.figure_block("../")}
> <img src="../../icons/hourglass.svg" width="16" height="16" alt="Prepared"> **Prepared**
>
{quote}

## Goal

{bullets(goal)}

## Method

{bullets(method)}

## Starting point and sequence

{steps}

## Status

### Caveats

{bullets(caveats)}

{diagram}
## Notebook

The [notebook](notebook.qmd) contains the workflow status and the Calculations section.
"""

    def workflow_notebook(self, title, page_title, abstract, keywords, callout):
        """Calculation-only notebook of a prepared workflow: its own front matter and status callout, to which
        quarto/render.py adds the shared header, formatting and Calculations section.

        Args:
            title: Title of the notebook.
            page_title: Browser-tab title.
            abstract: One-paragraph abstract.
            keywords: Keywords of the front matter.
            callout: Markdown of the status callout.

        Returns:
            The notebook source, its front matter and the status callout.
        """
        keys = "".join(f"  - {word}\n" for word in keywords)
        return f"""---
title: '{title}'
page-title: '{page_title}'
abstract: |
  {abstract}
date: {self.created}
keywords:
{keys}---

::: {{.callout-note .status-prepared title="Prepared"}}
{callout}
:::
"""

    def check_diagram(self, case):
        """Assert that every linked node of the workflow's diagram is labelled with its run's heading.

        The heading keeps its LaTeX, which the diagram renders from ``$$...$$``; the README's page-title is plain text
        for the browser tab, never a label.

        Args:
            case: The ``unittest.TestCase`` whose assertions are used.
        """
        text = (self.workflow / "README.md").read_text()
        nodes = re.findall(r"""\w+\["<a href='([^']+)/README\.md'>(.*?)</a>"\]""", text)
        case.assertTrue(nodes, "the diagram links no run")
        for folder, label in nodes:
            heading = re.search(r"^# (.*)$", (self.workflow / folder / "README.md").read_text(), re.M).group(1)
            case.assertEqual(label, heading.replace("$", "$$"))

    def check_runs(self, case, *, count, route):
        """Assertions every prepared workflow's tests share: run folders, metadata, scripts and inputs.

        Args:
            case: The ``unittest.TestCase`` whose assertions are used.
            count: Number of run folders expected.
            route: Text every run's first route section must contain.

        Returns:
            The run folders, in order.
        """
        from runflow.parsers.route import input_routes

        runs = sorted(path for path in self.workflow.iterdir() if re.fullmatch(r"\d{4}-\d{2}-\d{2}_\d{6}", path.name))
        case.assertEqual(len(runs), count)
        stamps = [int(run.name.split("_")[1]) for run in runs]
        case.assertEqual(stamps, list(range(stamps[0], stamps[0] + count)))
        case.assertEqual(int(self.workflow.name.split("_")[1]) + 1, stamps[0])
        for run in runs:
            text = (run / "README.md").read_text()
            case.assertIn(f"original-folder: {run.name}\n", text)
            case.assertIn("status: not-submitted", text)
            for folder in ("inputs", "logs", "outputs", "checkpoints", "fields", "scripts"):
                case.assertTrue((run / folder).is_dir(), (run, folder))
            case.assertFalse(list((run / "logs").glob("*.log")), "a prepared run has no log")
            compile((run / "scripts/run.py").read_text(), str(run / "scripts/run.py"), "exec")
            submit = (run / "scripts/submit.sh").read_text()
            case.assertIn(f"--chdir={self.server}/{self.project.name}/{self.workflow.name}/{run.name}", submit)
            case.assertIn("--open-mode=truncate", submit)
            (gjf,) = (run / "inputs").glob("*.gjf")
            case.assertIn(route, input_routes(gjf.read_text())[0])
        return runs

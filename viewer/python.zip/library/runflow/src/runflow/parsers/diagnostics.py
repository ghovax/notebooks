"""Separate native completion evidence from verified scheduler or process activity."""

import os
import re
import subprocess
from pathlib import Path

from .route import keyword_options, route_keywords


def _activity(job_id, process_id, path):
    """Verify activity explicitly rather than guessing from an unfinished log.

    Args:
        job_id: Slurm job ID to query, or None.
        process_id: Local process ID to query, or None.
        path: Log whose writing process is checked.

    Returns:
        The verified activity state and the source that verified it.

    Raises:
        ValueError: The job ID is not numeric.
    """
    if job_id is not None:
        if not re.fullmatch(r"[0-9]+(?:_[0-9]+)?", str(job_id)):
            raise ValueError(
                "Slurm job ID must be numeric, optionally with an array index"
            )
        try:
            result = subprocess.run(
                ["squeue", "--noheader", "--jobs", str(job_id), "--format=%T"],
                capture_output=True,
                text=True,
                timeout=10,
                check=True,
            )
            states = result.stdout.split()
            if states and all(state == "PENDING" for state in states):
                return "pending", "squeue"
            if any(
                state in {"RUNNING", "COMPLETING", "CONFIGURING"} for state in states
            ):
                return "running", "squeue"
        except (OSError, subprocess.SubprocessError):
            pass
    if process_id is not None:
        if not isinstance(process_id, int) or process_id <= 0:
            raise ValueError("Process ID must be a positive integer")
        try:
            os.kill(process_id, 0)
            result = subprocess.run(
                [
                    "lsof",
                    "-a",
                    "-p",
                    str(process_id),
                    "-Ffa",
                    "--",
                    str(path.resolve()),
                ],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
            if any(line in {"aw", "au"} for line in result.stdout.splitlines()):
                return "running", "open writer"
        except (OSError, subprocess.SubprocessError):
            pass
    return None, None


def _status(path, jobs, *, job_id=None, process_id=None, expected_jobs=None):
    """Report completion/failure or externally verified activity without inventing liveness.

    Args:
        path: Gaussian log.
        jobs: Its parsed linked jobs.
        job_id: Slurm job ID to verify activity with, or None.
        process_id: Local process ID to verify activity with, or None.
        expected_jobs: Number of linked jobs the input contains, or None.

    Returns:
        The log's state with the evidence for it.

    Raises:
        ValueError: The job ID is not numeric.
    """
    path = Path(path)
    if expected_jobs is not None and (
        not isinstance(expected_jobs, int) or expected_jobs < 1
    ):
        raise ValueError("Expected linked-job count must be a positive integer")
    activity, source = _activity(job_id, process_id, path)
    exists = path.is_file()
    records = []
    for index, job in enumerate(jobs, 1):
        failure = bool(job["errors"]) or any(
            not step["converged"] for step in job["scf_history"]
        )
        records.append(
            {
                # One-based linked-job position in the file.
                "job": index,
                # Native failure overrides a normal-termination marker.
                "state": "failed"
                if failure
                else "complete"
                if job["normal_termination"]
                else "unfinished",
                # Exact native diagnostic messages with their job-relative line positions.
                "errors": job["errors"],
            }
        )
    complete = bool(records) and all(
        record["state"] == "complete" for record in records
    )
    if expected_jobs is not None:
        complete = complete and len(records) == expected_jobs
    state = (
        "failed"
        if any(record["state"] == "failed" for record in records)
        else activity
        if activity
        else "complete"
        if complete
        else "unfinished"
        if exists
        else "missing"
    )
    return {
        # Overall evidence-based state; unfinished does not imply running or failed.
        "state": state,
        # Verified external activity only; None means no activity was established.
        "activity": activity,
        # Verification source, not an inferred scheduler identity.
        "source": source,
        # Individually assessed linked jobs, including incomplete trailing output.
        "jobs": records,
        # Caller-supplied linked-job count; None means the intended count is unknown.
        "expected_jobs": expected_jobs,
    }


def _sections(blocks):
    """Index native link boundaries and scientific headings without claiming full decoding.

    Args:
        blocks: Native text of each linked job, in order.

    Returns:
        One record per heading with its linked job and line.
    """
    pattern = re.compile(
        r"(?:Entering Link|Leave Link|SCF Done:|Population analysis using|Harmonic frequencies|Frequencies --|Excited State|Summary of reaction path|Optimization completed|Optimization stopped|Normal termination|Error termination|Convergence criterion not met|Magnetic shielding tensor|Polarizability|Wiberg bond index)",
        re.IGNORECASE,
    )
    records = []
    for job, block in enumerate(blocks, 1):
        for line, text in enumerate(block.splitlines(), 1):
            if pattern.search(text):
                records.append(
                    {
                        # One-based linked-job position.
                        "job": job,
                        # One-based line within that linked job.
                        "line": line,
                        # Exact printed heading; indexing is not a claim of semantic coverage.
                        "heading": text.strip(),
                    }
                )
    return records


def _route(job):
    """Route keywords of a linked job, each with its options, and the job's parsed request.

    Args:
        job: One parsed linked job.

    Returns:
        Lowercase keywords mapped to their options, and the job's request.
    """
    keywords = {
        name.lower(): keyword_options(options)
        for name, options in route_keywords(job["route"])
        if "/" not in name or options
    }
    return keywords, job["request"]


def _population(keywords):
    """Options of the Pop keyword, under either of its names.

    Args:
        keywords: Lowercase route keywords mapped to their options.

    Returns:
        The options of Pop or Population, empty without either.
    """
    return keywords.get("pop", keywords.get("population", {}))


# Whether a linked job's route requests each category, from its keywords and parsed request.
REQUESTS = {
    # Every job solves an SCF except one that only reads a guess.
    "scf": lambda keywords, request: "only" not in keywords.get("guess", {}),
    # An Opt job type.
    "optimization": lambda keywords, request: "opt" in request["jobs"],
    # A Freq job type.
    "vibrations": lambda keywords, request: "freq" in request["jobs"],
    # An excited-state method such as TD.
    "td": lambda keywords, request: request["excited"] is not None,
    # Pop=SaveNTO or Pop=NTO.
    "nto": lambda keywords, request: "savento" in _population(keywords) or "nto" in _population(keywords),
    # An IRC job type.
    "irc": lambda keywords, request: "irc" in request["jobs"],
    # The Pop keyword.
    "populations": lambda keywords, request: "pop" in keywords or "population" in keywords,
    # Pop=NBORead or a bond-index analysis.
    "bonds": lambda keywords, request: any(option in _population(keywords) for option in ("nboread", "bndidx")),
    # The NMR keyword.
    "nmr": lambda keywords, request: "nmr" in keywords,
    # A Polar job type.
    "response": lambda keywords, request: "polar" in request["jobs"],
    # GFInput prints the basis set.
    "basis": lambda keywords, request: "gfinput" in keywords,
    # The Pop keyword prints orbital energies.
    "orbitals": lambda keywords, request: "pop" in keywords or "population" in keywords,
    # Every job that solves an SCF prints its energy.
    "energies": lambda keywords, request: "only" not in keywords.get("guess", {}),
    # Analytic force constants come with frequencies, or with CalcFC or CalcAll in an optimization or IRC.
    "hessians": lambda keywords, request: "freq" in request["jobs"] or any(
        option in request["options"].get(name, {}) for name in ("opt", "irc") for option in ("calcfc", "calcall")
    ),
    # A Stable job type.
    "stability": lambda keywords, request: "stable" in request["jobs"],
    # The SCRF keyword.
    "solvent": lambda keywords, request: "scrf" in keywords,
    # A Freq job type prints thermochemistry.
    "thermochemistry": lambda keywords, request: "freq" in request["jobs"],
    # An optimization prints its internal coordinates.
    "internal_coordinates": lambda keywords, request: "opt" in request["jobs"],
}


def _coverage(blocks, jobs, category):
    """Explain one category's availability without assembling unrelated measurements.

    Args:
        blocks: Native text of each linked job, in order.
        jobs: Parsed linked jobs.
        category: Result category, such as ``vibrations`` or ``stability``.

    Returns:
        One record per linked job: whether the route requested the category, whether Gaussian printed it, and
        how many values were read.

    Raises:
        ValueError: The category is unknown.
    """
    # Each category: its container and key in a parsed job, and the heading that shows Gaussian printed it.
    specifications = [
        ('scf', '', 'scf_history', 'SCF Done:'),
        ('optimization', '', 'optimization_history', 'Step number|Optimization completed'),
        ('vibrations', '', 'frequencies', 'Frequencies --|Frequencies ---'),
        ('td', '', 'excitations', 'Excited State\\s+\\d+:'),
        ('nto', '', 'nto_states', 'Natural Transition Orbital Coefficients'),
        ('irc', '', 'irc_summary', 'Summary of (?:reaction path|the reaction path)'),
        ('populations', 'populations', None, 'Population analysis using'),
        ('bonds', 'bonds', None, 'Wiberg bond index matrix|MO bond order|overlap-weighted NAO bond order'),
        ('nmr', 'nmr', None, 'Magnetic shielding tensor'),
        ('response', '', 'polarizability', 'Polarizability=|SCF Polarizability|Dipole polarizability'),
        ('basis', 'basis', 'shells', 'AO basis set in the form of general basis input'),
        ('orbitals', 'orbital_data', 'orbitals', '(?:Alpha|Beta)\\s+occ\\. eigenvalues'),
        ('energies', 'energies', None, 'SCF Done:|EUMP2='),
        ('hessians', 'hessians', None, 'Force constants in Cartesian coordinates'),
        ('stability', '', 'stability', 'wavefunction is .*stable|wavefunction has .*instabilit'),
        ('solvent', 'solvent', 'parameters', 'Solvent\\s*:'),
        ('thermochemistry', '', 'thermochemistry', 'Zero-point correction'),
        ('internal_coordinates', '', 'internal_coordinates', 'Initial Parameters'),
    ]
    specification = next((item for item in specifications if item[0] == category), None)
    if specification is None:
        raise ValueError("Unknown result category: " + str(category))
    _, container, key, heading = specification
    records = []
    for index, (block, job) in enumerate(zip(blocks, jobs, strict=True), 1):
        parsed = job[container] if container else job
        values = parsed.get(key, []) if key else parsed
        count = len(values)
        requested = REQUESTS[category](*_route(job))
        printed = bool(re.search(heading, block, re.IGNORECASE))
        unfinished = not job["normal_termination"] or bool(job["errors"])
        state = (
            ("partial" if unfinished else "available")
            if count
            else "unparsed"
            if printed
            else "partial"
            if requested and unfinished
            else "not_printed"
            if requested
            else "not_requested"
            if job["route"]
            else "unknown"
        )
        records.append(
            {
                # One-based linked-job position.
                "job": index,
                # Requested independent diagnostic category.
                "category": category,
                # Category availability, distinct from process activity or physical validity.
                "state": state,
                # Number of primary records; interpretation depends on the chosen category.
                "count": count,
                # Whether the printed route explicitly asks for the category.
                "requested": requested,
                # Whether a recognized native data heading was found.
                "printed": printed,
            }
        )
    return records

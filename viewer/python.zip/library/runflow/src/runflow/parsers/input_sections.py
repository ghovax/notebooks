"""Sections a Gaussian input reads after its molecule specification for an optimization: the connectivity, the atoms
the optimization moves (ReadOptimize) and the changes to the redundant internal coordinates (ModRedundant).

Their order and syntax follow the manual's input section ordering (https://gaussian.com/input/), its Opt page for
ModRedundant and ReadOptimize (https://gaussian.com/opt/) and its Geom page for connectivity
(https://gaussian.com/geom/). The GIC section, which takes the ModRedundant section's place, is read by
:mod:`runflow.parsers.gic`.
"""

import math
import re

import numpy as np

from ..checkpoints import ELEMENTS
from .gic import _structure
from .route import route_keywords, split_items, unwrap

# What each coordinate type of a ModRedundant line measures, and the unit Gaussian reads and prints it in.
TYPES = dict(X=("cartesian", "angstrom"), B=("bond", "angstrom"), A=("angle", "degree"), D=("dihedral", "degree"),
             L=("linear bend", "degree"))
# The type of a line that names none, by its number of atoms from one to four.
IMPLIED_TYPES = ("X", "B", "A", "D")
# Largest number of atoms of each type; a linear bend takes a fourth atom, or -1, for its bend directions.
ATOM_COUNTS = dict(X=1, B=2, A=3, D=4, L=4)
# The function Gaussian's parameter table prints for each type.
PRINTED = dict(X="X", B="R", A="A", D="D", L="L")
# What each action code of a ModRedundant line does.
ACTIONS = dict(A="activate", F="freeze", B="build", K="kill", R="remove", D="diff", H="hessian", S="scan")
# ReadOptimize keywords, and whether each adds its atoms to the optimized set (True) or takes them out.
SELECTIONS = dict(atoms=True, notatoms=False, block=True, notblock=False, layer=True, notlayer=False, residue=True,
                  notresidue=False)
# An integer or decimal number as Gaussian writes it, with a D or E exponent.
NUMBER = re.compile(r"[-+]?(\d+\.?\d*|\.\d+)([DdEe][-+]?\d+)?")


def _float(text):
    """A number Gaussian wrote, with its D exponent read as E.

    Args:
        text: The number.

    Returns:
        Its value.
    """
    return float(re.sub("[Dd]", "e", text))


def _asks(names, option, shortest):
    """Whether a set of route options names one, written in full or abbreviated as Gaussian accepts.

    Args:
        names: Lower-case option names.
        option: The option in full, lower case.
        shortest: Fewest letters an abbreviation may have.

    Returns:
        True when some name is the option or an abbreviation of it.
    """
    return any(option.startswith(name) and len(name) >= shortest for name in names)


def route_sections(route):
    """Which of these sections a route asks for, from the options of its Opt and Geom keywords.

    Args:
        route: Route text of one linked job.

    Returns:
        ``connectivity`` (``Geom=Connectivity`` or ``ModConnectivity``), ``read_optimize`` (``ReadOptimize`` of Opt
        or Geom, or the older ``ReadFreeze``), ``modredundant`` (``ModRedundant`` of Opt or Geom) and ``structures``
        (3 for ``Opt=QST3``, 2 for ``QST2``, else 1); the first three are booleans.
    """
    names = dict(opt=set(), geom=set())
    for name, options in route_keywords(route):
        if name.lower() in names:
            names[name.lower()] |= {item.partition("=")[0].strip().lower() for item in split_items(unwrap(options))}
    both = names["opt"] | names["geom"]
    return dict(
        connectivity=any(_asks(names["geom"], option, 7) for option in ("connectivity", "modconnectivity")),
        read_optimize=any(_asks(both, option, 5) for option in ("readoptimize", "readfreeze"))
        or bool({"rdopt", "rdfreeze"} & both),
        modredundant=_asks(both, "modredundant", 6),
        structures=3 if "qst3" in names["opt"] else 2 if "qst2" in names["opt"] else 1,
    )


def parse_modredundant_line(text, number=1):
    """One line of a ModRedundant section: ``[Type] N1 [N2 [N3 [N4]]] [value] [Action [Params]] [[Min] Max]``.

    Args:
        text: The line.
        number: One-based position of the line in its section.

    Returns:
        A mapping with ``line``, ``text``, ``type`` (``X``, ``B``, ``A``, ``D`` or ``L``, implied by the number of
        atoms when the line names none, None when it cannot be), ``atoms`` (one-based numbers, ``*`` for a
        wildcard, -1 closing a linear bend), ``value`` (a value given before the action, in angstrom or degrees),
        ``action`` (``add`` without a code, else ``activate``, ``freeze``, ``build``, ``kill``, ``remove``,
        ``diff``, ``hessian`` or ``scan``), ``hessian`` (the diagonal element of ``H``), ``steps`` and ``step`` (of
        ``S``, the step in angstrom or degrees), ``minimum`` and ``maximum``, ``measure`` and ``unit`` (what the
        type measures, and its unit) and ``unparsed`` (words not understood).
    """
    tokens = text.replace(",", " ").replace("=", " ").split()
    entry = dict(line=number, text=text.strip(), type=None, atoms=[], value=None, action="add", hessian=None,
                 steps=None, step=None, minimum=None, maximum=None, measure=None, unit=None, unparsed=[])
    position = 0
    if tokens and tokens[0].upper() in TYPES:
        entry["type"], position = tokens[0].upper(), 1
    limit = ATOM_COUNTS.get(entry["type"], 4)
    while position < len(tokens) and len(entry["atoms"]) < limit and re.fullmatch(r"-?\d+|\*", tokens[position]):
        entry["atoms"].append("*" if tokens[position] == "*" else int(tokens[position]))
        position += 1
    if position < len(tokens) and NUMBER.fullmatch(tokens[position]) and not tokens[position].lstrip("-+").isdigit():
        entry["value"] = _float(tokens[position])
        position += 1
    if position < len(tokens) and tokens[position].upper() in ACTIONS:
        entry["action"] = ACTIONS[tokens[position].upper()]
        position += 1
        try:
            if entry["action"] == "hessian":
                entry["hessian"] = _float(tokens[position])
                position += 1
            elif entry["action"] == "scan":
                entry["steps"], entry["step"] = int(tokens[position]), _float(tokens[position + 1])
                position += 2
        except (IndexError, ValueError):
            entry["unparsed"].append(f"{tokens[position - 1]} needs its parameters")
    limits = []
    while position < len(tokens) and NUMBER.fullmatch(tokens[position]) and len(limits) < 2:
        limits.append(_float(tokens[position]))
        position += 1
    if limits:
        entry["minimum"], entry["maximum"] = (None, limits[0]) if len(limits) == 1 else tuple(limits)
    entry["unparsed"] += tokens[position:]
    if entry["type"] is None and 1 <= len(entry["atoms"]) <= 4:
        entry["type"] = IMPLIED_TYPES[len(entry["atoms"]) - 1]
    if entry["type"]:
        entry["measure"], entry["unit"] = TYPES[entry["type"]]
    return entry


def parse_modredundant_section(lines):
    """The lines of a ModRedundant section as entries.

    Args:
        lines: The section's lines, without its terminating blank line.

    Returns:
        One entry per nonblank line, as ``parse_modredundant_line`` returns it.
    """
    return [parse_modredundant_line(line, number) for number, line in enumerate(lines, 1) if line.strip()]


def validate_modredundant(entries, atom_count):
    """Problems of a ModRedundant section against its molecule.

    Args:
        entries: Entries of the section.
        atom_count: Number of atoms of the molecule, or None when it is not known.

    Returns:
        Messages, one per problem, which is an atom outside the molecule, a line whose type or number of atoms is
        not understood, a scan without its steps, or words not understood; empty for a clean section.
    """
    problems = []
    for entry in entries:
        where = f"line {entry['line']}"
        atoms = entry["atoms"]
        if entry["type"] is None or not atoms:
            problems.append(f"{where}: no coordinate type or atoms")
        elif entry["type"] != "L" and len(atoms) != IMPLIED_TYPES.index(entry["type"]) + 1:
            problems.append(f"{where}: {entry['type']} takes {IMPLIED_TYPES.index(entry['type']) + 1} atoms, not {len(atoms)}")
        for position, atom in enumerate(atoms):
            closing = entry["type"] == "L" and position == 3 and atom == -1
            if atom != "*" and not closing and (atom < 1 or (atom_count is not None and atom > atom_count)):
                problems.append(f"{where}: atom {atom} is not in the molecule")
        if entry["action"] == "scan" and (entry["steps"] is None or entry["step"] is None):
            problems.append(f"{where}: a scan needs its number of steps and step size")
        problems += [f"{where}: {item!r} is not understood" for item in entry["unparsed"]]
    return problems


def evaluate_modredundant(entries, coordinates):
    """Values of a section's coordinates at a geometry, in the units the section uses.

    Args:
        entries: Entries of the section.
        coordinates: Positions in angstrom as rows of x, y, z.

    Returns:
        One value per entry, a bond in angstrom and an angle or a dihedral in degrees, with None for a Cartesian or
        linear-bend line, a wildcard or an atom outside the geometry.
    """
    positions = np.asarray(coordinates, dtype=float)
    values = []
    for entry in entries:
        atoms = entry["atoms"]
        usable = entry["type"] in ("B", "A", "D") and len(atoms) == IMPLIED_TYPES.index(entry["type"]) + 1 and all(
            isinstance(atom, int) and 1 <= atom <= len(positions) for atom in atoms)
        if not usable:
            values.append(None)
            continue
        value = _structure(PRINTED[entry["type"]], atoms, positions)
        values.append(value if entry["type"] == "B" else math.degrees(value))
    return values


def merge_modredundant(entries, table):
    """ModRedundant lines joined with the coordinates Gaussian prints for them.

    Gaussian may print a coordinate with its atoms in the reverse order, as ``D(14,3,4,13)`` for ``D 13 4 3 14``.

    Args:
        entries: Entries of the section.
        table: The job's ``internal_coordinates``, empty when there is no log.

    Returns:
        One record per entry, the entry with ``name`` (the printed label), ``start`` (the printed start value in
        angstrom or degrees), ``frozen`` and ``scan`` from the printed row, each None when no row matches.
    """
    printed = {}
    for row in table:
        match = re.fullmatch(r"([A-Z])\(([-\d,]+)\)", row["definition"])
        if match:
            atoms = tuple(int(atom) for atom in match[2].split(","))
            printed.setdefault((match[1], atoms), row)
            printed.setdefault((match[1], atoms[::-1]), row)
    merged = []
    for entry in entries:
        row = printed.get((PRINTED.get(entry["type"]), tuple(entry["atoms"])))
        merged.append(dict(entry, name=row and row["name"], start=row and row["value"], frozen=row and row["frozen"],
                           scan=row and row["scan"]))
    return merged


def modredundant_echo(text):
    """The ModRedundant section Gaussian echoes as it reads one linked job's input.

    Args:
        text: Native text of one linked job.

    Returns:
        Its entries, as ``parse_modredundant_section`` reads them; empty when the job echoes none.
    """
    match = re.search(r"The following ModRedundant input section has been read:\n(.*?)(?:\n[ \t]*\n|\Z)", text, re.S)
    return parse_modredundant_section(match[1].splitlines()) if match else []


def parse_connectivity(lines):
    """A connectivity section: each line an atom followed by pairs of a bonded atom and the bond order.

    Args:
        lines: The section's lines.

    Returns:
        One mapping per nonblank line with ``line``, ``atom`` (one-based, None when unreadable), ``bonds`` (mappings
        of the bonded ``atom`` and the ``order``) and ``unparsed`` (words not understood).
    """
    records = []
    for number, line in enumerate(lines, 1):
        tokens = line.replace(",", " ").split()
        if not tokens:
            continue
        record = dict(line=number, atom=int(tokens[0]) if tokens[0].isdigit() else None, bonds=[], unparsed=[])
        rest = tokens[1:] if record["atom"] is not None else tokens
        for position in range(0, len(rest) - 1, 2):
            if rest[position].isdigit() and NUMBER.fullmatch(rest[position + 1]):
                record["bonds"].append(dict(atom=int(rest[position]), order=_float(rest[position + 1])))
            else:
                record["unparsed"] += rest[position:position + 2]
        if len(rest) % 2:
            record["unparsed"].append(rest[-1])
        records.append(record)
    return records


def parse_atom_selection(lines):
    """The rules of a ReadOptimize section, in the order Gaussian applies them.

    Args:
        lines: The section's lines.

    Returns:
        One mapping per rule with ``selection`` (``atoms``, ``block``, ``layer``, ``residue``, or ``none`` for
        ``noatoms``, which empties the set), ``include`` (True to optimize the items, False to hold them fixed) and
        ``items`` (atom numbers, ranges such as 3-6, element symbols or names, as text); bare items before any
        keyword are atoms.
    """
    rules, current = [], None
    for token in " ".join(lines).replace(",", " ").split():
        name, equals, value = token.partition("=")
        key = name.lower()
        if key == "noatoms" and not equals:
            rules.append(dict(selection="none", include=False, items=[]))
            current = None
            continue
        if key in SELECTIONS and equals:
            current = dict(selection=key.removeprefix("not"), include=SELECTIONS[key], items=[])
            rules.append(current)
            if not value:
                continue
            token = value
        if current is None:
            current = dict(selection="atoms", include=True, items=[])
            rules.append(current)
        current["items"].append(token)
    return rules


def resolve_atom_selection(rules, atomic_numbers):
    """The atoms an optimization moves after a ReadOptimize section's rules, starting from every atom.

    Args:
        rules: Rules from ``parse_atom_selection``.
        atomic_numbers: Atomic numbers of the molecule, in input order.

    Returns:
        The sorted one-based numbers of the optimized atoms, or None when a rule selects ONIOM blocks, layers or
        residues, or names an item that is neither an atom, a range nor an element.
    """
    symbols = [ELEMENTS[number - 1].casefold() for number in atomic_numbers]
    known = {symbol.casefold() for symbol in ELEMENTS}
    selected = set(range(1, len(symbols) + 1))
    for rule in rules:
        if rule["selection"] == "none":
            selected = set()
            continue
        if rule["selection"] != "atoms":
            return None
        matched = set()
        for item in rule["items"]:
            span = re.fullmatch(r"(\d+)-(\d+)", item)
            if span:
                matched |= set(range(int(span[1]), int(span[2]) + 1))
            elif item.isdigit():
                matched.add(int(item))
            elif item.casefold() in known:
                matched |= {index for index, symbol in enumerate(symbols, 1) if symbol == item.casefold()}
            else:
                return None
        selected = selected | matched if rule["include"] else selected - matched
    return sorted(atom for atom in selected if 1 <= atom <= len(symbols))

"""Generalized internal coordinates, Gaussian's GIC input section: its lines, formulas and values.

A GIC section follows the geometry of a job whose route asks for ``Opt=AddGIC``, ``Opt=ReadAllGIC``, ``Geom=AddGIC``
or ``Geom=ReadAllGIC``. Each line is ``label(options)=expression`` with every part optional, a coordinate function
of atoms or a formula of them, or a standalone option, as the Gaussian manual describes the GIC input
(https://gaussian.com/gic/).
"""

import math
import operator
import re

import numpy as np

from .route import route_keywords, split_items, unwrap

# What a route asks of the GIC machinery: the option that builds or reads coordinates, by Gaussian's own option name.
GIC_OPTIONS = dict(readallgic="read-all", addgic="add", gic="automatic", gicold="old")
# Modes whose job reads a GIC input section after its geometry.
SECTION_MODES = ("read-all", "add")

# Coordinate functions by every spelling the manual gives, in lower case, and the function each one names.
FUNCTIONS = {
    spelling: function
    for function, spellings in (
        ("R", ("r", "b", "bond", "stretch")),
        ("A", ("a", "angle", "bend")),
        ("D", ("d", "dihedral", "torsion")),
        ("L", ("l", "linear", "linearbend")),
        ("X", ("x",)),
        ("Y", ("y",)),
        ("Z", ("z",)),
        ("Cartesian", ("cartesian", "cart")),
        ("XCntr", ("xcntr",)),
        ("YCntr", ("ycntr",)),
        ("ZCntr", ("zcntr",)),
        ("DotDiff", ("dotdiff",)),
    )
    for spelling in spellings
}
# What each function measures, and the unit Gaussian prints a coordinate made of it alone: angstrom or degree.
KINDS = dict([
    ("R", ("bond", "angstrom")), ("A", ("angle", "degree")), ("D", ("dihedral", "degree")),
    ("L", ("linear bend", "degree")), ("X", ("cartesian", "angstrom")), ("Y", ("cartesian", "angstrom")),
    ("Z", ("cartesian", "angstrom")), ("XCntr", ("centroid", "angstrom")), ("YCntr", ("centroid", "angstrom")),
    ("ZCntr", ("centroid", "angstrom")), ("DotDiff", ("dot product", None)),
])
# The Cartesian component a call names, by every way the manual writes it, in upper case.
COMPONENTS = dict([("-1", "X"), ("1", "X"), ("-2", "Y"), ("2", "Y"), ("-3", "Z"), ("3", "Z"), ("X", "X"), ("Y", "Y"), ("Z", "Z")])
# Binary operators of a formula; exponentiation is ``**`` or ``^``.
OPERATORS = dict([("+", operator.add), ("-", operator.sub), ("*", operator.mul), ("/", operator.truediv), ("**", operator.pow)])
# Mathematical functions of a formula.
MATH = dict(sqrt=math.sqrt, exp=math.exp, sin=math.sin, cos=math.cos, tan=math.tan, arccos=math.acos)
# LaTeX of the mathematical functions other than the square root, which is drawn as a radical.
MATH_LATEX = dict(exp=r"\exp", sin=r"\sin", cos=r"\cos", tan=r"\tan", arccos=r"\arccos")
# What each action word of an option or a trailing word means, by every spelling the manual gives, in lower case.
ACTIONS = {
    spelling: action
    for action, spellings in (
        ("active", ("a", "active", "activate", "add", "build")),
        ("frozen", ("f", "frozen", "freeze")),
        ("inactive", ("r", "inactive", "remove")),
        ("kill", ("k", "kill", "removeall")),
        ("printonly", ("printonly",)),
        ("modify", ("modify",)),
        ("diff", ("d", "diff")),
    )
    for spelling in spellings
}
# Options that take a number, and the type that reads it.
NUMERIC = dict(stepsize=float, nsteps=int, min=float, max=float, fc=float, forceconstant=float, value=float)
# Standalone lines and the actions an ``Atom i action`` line takes.
STANDALONE = ("freezeall", "unfreezeall", "removeall")
ATOM_ACTIONS = dict(active="active", freeze="frozen", unfreeze="unfrozen", remove="inactive", removeall="kill", xyzonly="xyzonly")


def gic_mode(route):
    """How a route builds its generalized internal coordinates.

    Options of ``Opt`` and ``Geom`` are read together: ``ModRedundant`` combined with ``GIC`` is ``AddGIC``, as the
    manual says, and ``ReadAllGIC`` outranks the others.

    Args:
        route: Route text of one linked job.

    Returns:
        ``read-all`` (the section defines every coordinate), ``add`` (the section changes the default ones),
        ``automatic`` (``GIC`` builds them without a section), ``old`` (``GICOld``), or None without any GIC option.
    """
    found = set()
    for name, options in route_keywords(route):
        if name.lower() in ("opt", "geom"):
            names = {item.partition("=")[0].lower() for item in split_items(unwrap(options))}
            found |= {GIC_OPTIONS[item] for item in names if item in GIC_OPTIONS}
            if "modredundant" in names and "gic" in names:
                found.add("add")
    for mode in ("read-all", "add", "old", "automatic"):
        if mode in found:
            return mode
    return None


def _balanced(text, start):
    """Index just past the parenthesis that closes the one at ``start``.

    Args:
        text: Text holding the parentheses.
        start: Index of an opening parenthesis.

    Returns:
        The index after its partner, or -1 when it never closes.
    """
    depth = 0
    for index in range(start, len(text)):
        depth += (text[index] == "(") - (text[index] == ")")
        if depth == 0:
            return index + 1
    return -1


def _words(text):
    """Words of a line, split at spaces outside parentheses.

    Args:
        text: One line.

    Returns:
        The words in order.
    """
    words, depth, current = [], 0, ""
    for character in text:
        depth += (character == "(") - (character == ")")
        if character.isspace() and depth == 0:
            words.append(current)
            current = ""
        else:
            current += character
    return [word for word in words + [current] if word]


def _option_state(items, entry):
    """Read option items into an entry: actions, numeric settings and conditions.

    Args:
        items: Option items, a word or ``name=value`` each, with a condition as its keyword followed by a label.
        entry: Entry mapping to fill: ``options``, ``actions`` and ``unparsed``.
    """
    pending = None
    for item in items:
        name, _, value = item.partition("=")
        key = name.lower()
        if pending:
            entry["options"][pending] = item
            pending = None
        elif key in ("onlyif", "ifnot") and not value:
            pending = key
        elif key in NUMERIC and value:
            try:
                entry["options"][key] = NUMERIC[key](value.replace("D", "e").replace("d", "e"))
            except ValueError:
                entry["unparsed"].append(item)
        elif key in ACTIONS and not value:
            entry["actions"].append(ACTIONS[key])
        else:
            entry["unparsed"].append(item)
    if pending:
        entry["unparsed"].append(pending)


def _is_option(word):
    """Whether a trailing word of a line is an option rather than part of the expression.

    Args:
        word: One word of the line.

    Returns:
        True for an action, a numeric setting, or a condition keyword.
    """
    name, _, value = word.partition("=")
    key = name.lower()
    return (key in ACTIONS and not value) or (key in NUMERIC and bool(value)) or key in ("onlyif", "ifnot")


def parse_gic_line(text, number=1):
    """One line of a GIC section.

    Args:
        text: The line.
        number: One-based position of the line in its section.

    Returns:
        A mapping with ``line``, ``text``, ``kind`` (``coordinate`` or ``standalone``), ``label`` (None when
        Gaussian names it), ``expression`` (None for options on an existing label), ``actions`` (normalized,
        in order), ``options`` (numeric settings and conditions by lower-case name), ``unparsed`` (items not
        understood) and, for a standalone line, ``command`` and ``atom``.
    """
    text = text.strip()
    entry = dict(line=number, text=text, kind="coordinate", label=None, expression=None, actions=[], options={}, unparsed=[])
    # Square brackets and braces replace parentheses in Gaussian's syntax.
    line = text.translate(str.maketrans("[]{}", "()()"))
    lowered = re.sub(r"\s+", " ", line.lower())
    if lowered in STANDALONE:
        return dict(entry, kind="standalone", command=lowered, atom=None)
    atom = re.fullmatch(r"atom (\S+) (\w+)", lowered)
    if atom:
        action = ATOM_ACTIONS.get(atom[2])
        entry.update(kind="standalone", command="atom", atom="*" if atom[1] == "*" else int(atom[1]) if atom[1].isdigit() else None)
        entry["actions"] = [action] if action else []
        if not action or entry["atom"] is None:
            entry["unparsed"].append(text)
        return entry
    identifier = re.match(r"[A-Za-z][A-Za-z0-9_]*", line)
    rest, label, options = line, None, ""
    if identifier:
        cursor, group = identifier.end(), None
        if cursor < len(line) and line[cursor] == "(":
            close = _balanced(line, cursor)
            if close > 0:
                group, cursor = line[cursor + 1:close - 1], close
        after = line[cursor:].lstrip()
        if after.startswith("="):
            # label(options)=expression, or label=expression.
            label, options, rest = identifier[0], group or "", after[1:].strip()
        elif group is not None and identifier[0].lower() not in FUNCTIONS:
            # A label with options for an existing coordinate and no expression, such as F1F2(NSteps=10,StepSize=0.2).
            label, options, rest = identifier[0], group, after
    entry["label"] = label
    _option_state(split_items(options), entry)
    words = _words(rest)
    trailing = []
    while len(words) > 1 and (_is_option(words[-1]) or (len(words) > 2 and words[-2].lower() in ("onlyif", "ifnot"))):
        trailing.insert(0, words.pop())
    if len(words) == 1 and words[0] and _is_option(words[0]) and label is not None and not words[0].startswith("("):
        trailing.insert(0, words.pop())
    _option_state(trailing, entry)
    expression = " ".join(words).strip()
    if expression:
        entry["expression"] = expression
    return entry


def _tokens(expression):
    """Tokens of a formula.

    Args:
        expression: Formula text, with brackets already normalized.

    Returns:
        Numbers, names, operators and parentheses in order.

    Raises:
        ValueError: A character no formula uses.
    """
    pattern = re.compile(r"\s*(\d+\.?\d*(?:[eEdD][-+]?\d+)?|\.\d+(?:[eEdD][-+]?\d+)?|[A-Za-z_][A-Za-z0-9_]*|\*\*|[-+*/^(),])")
    position, tokens = 0, []
    while position < len(expression.rstrip()):
        match = pattern.match(expression, position)
        if not match:
            raise ValueError(f"Unreadable formula text at {expression[position:]!r}")
        tokens.append(match[1])
        position = match.end()
    return tokens


class _Parser:
    """Recursive-descent reader of a GIC formula into a small tree."""

    def __init__(self, expression):
        """Tokenize a formula.

        Args:
            expression: Formula text.
        """
        self.tokens = _tokens(expression.translate(str.maketrans("[]{}", "()()")))
        self.position = 0

    def peek(self):
        """Next token without taking it.

        Returns:
            The token, or None at the end.
        """
        return self.tokens[self.position] if self.position < len(self.tokens) else None

    def take(self, expected=None):
        """Take the next token.

        Args:
            expected: Token it must equal, when given.

        Returns:
            The token.

        Raises:
            ValueError: The formula ends early or the token differs from the expected one.
        """
        token = self.peek()
        if token is None or (expected is not None and token != expected):
            raise ValueError(f"Expected {expected!r} but found {token!r}")
        self.position += 1
        return token

    def expression(self):
        """Sum and difference of terms.

        Returns:
            The tree of the expression.
        """
        node = self.term()
        while self.peek() in ("+", "-"):
            node = ("bin", self.take(), node, self.term())
        return node

    def term(self):
        """Product and quotient of factors.

        Returns:
            The tree of the term.
        """
        node = self.unary()
        while self.peek() in ("*", "/"):
            node = ("bin", self.take(), node, self.unary())
        return node

    def unary(self):
        """A signed power.

        Returns:
            The tree of the factor.
        """
        if self.peek() in ("-", "+"):
            sign = self.take()
            operand = self.unary()
            return ("neg", operand) if sign == "-" else operand
        base = self.atom()
        if self.peek() in ("**", "^"):
            self.take()
            return ("bin", "**", base, self.unary())
        return base

    def atom(self):
        """A number, a label, a function call or a parenthesized expression.

        Returns:
            The tree of the atom.

        Raises:
            ValueError: A token that starts no atom.
        """
        token = self.take()
        if token == "(":
            node = self.expression()
            self.take(")")
            return node
        if re.match(r"[\d.]", token):
            return ("num", float(re.sub("[Dd]", "e", token)))
        if not re.match(r"[A-Za-z_]", token):
            raise ValueError(f"Unexpected {token!r}")
        if self.peek() != "(":
            return ("ref", token.lower())
        self.take("(")
        name = token.lower()
        if name in FUNCTIONS:
            function, arguments, depth = FUNCTIONS[name], [], 1
            current = []
            while depth:
                part = self.take()
                depth += (part == "(") - (part == ")")
                if depth == 0 or (part == "," and depth == 1):
                    arguments.append("".join(current))
                    current = []
                else:
                    current.append(part)
            return ("coord", function, arguments)
        arguments = [self.expression()]
        while self.peek() == ",":
            self.take()
            arguments.append(self.expression())
        self.take(")")
        if name not in MATH:
            raise ValueError(f"Unknown function {token!r}")
        return ("math", name, arguments)


def _atoms(arguments, function):
    """Atom numbers of a coordinate function's arguments.

    Args:
        arguments: Argument texts of the call.
        function: Canonical function name.

    Returns:
        One-based atom numbers, ``*`` for a wildcard, with ranges such as 12-15 of a centroid expanded; the
        component of a Cartesian call, ``X``, ``Y`` or ``Z``, comes second as text.
    """
    atoms = []
    for argument in arguments:
        argument = argument.strip()
        if not argument:
            continue
        span = re.fullmatch(r"(\d+)-(\d+)", argument)
        if span:
            atoms += list(range(int(span[1]), int(span[2]) + 1))
        elif re.fullmatch(r"-?\d+", argument):
            atoms.append(int(argument))
        else:
            atoms.append(argument.upper() if argument != "*" else "*")
    return atoms


def formula_tree(expression):
    """The tree of a GIC formula.

    Args:
        expression: Formula text.

    Returns:
        The tree as nested tuples, whose first item is ``num``, ``ref`` (a label, lower case), ``neg``, ``bin``, ``math`` or ``coord``.

    Raises:
        ValueError: Text that is not a formula.
    """
    parser = _Parser(expression)
    tree = parser.expression()
    if parser.peek() is not None:
        raise ValueError(f"Unexpected {parser.peek()!r} after the formula")
    return tree


def _latex_number(value):
    """A formula's constant in LaTeX.

    Args:
        value: The number.

    Returns:
        An integer without a decimal point, a decimal as Python writes it shortest, and an exponent as a power of ten.
    """
    if math.isfinite(value) and value == int(value) and abs(value) < 1e15:
        return str(int(value))
    text = repr(value)
    if "e" in text:
        mantissa, exponent = text.split("e")
        return rf"{mantissa}\times 10^{{{int(exponent)}}}"
    return text


def _latex_atoms(arguments):
    """The atoms of a coordinate call as a LaTeX subscript.

    Args:
        arguments: Argument texts of the call.

    Returns:
        The arguments separated by commas, with a range such as 12-15 written with an en dash and a wildcard as an asterisk.
    """
    parts = [argument.strip() for argument in arguments if argument.strip()]
    return ",".join(r"\ast" if part == "*" else re.sub(r"(?<=\d)-(?=\d)", r"\\text{–}", part) for part in parts)


def _latex(tree, names):
    """LaTeX of a formula tree.

    Args:
        tree: Tree from ``formula_tree``.
        names: Labels as written, by lower-case name.

    Returns:
        The LaTeX text, without math delimiters.
    """
    def grouped(node, operators, negative=False):
        """LaTeX of an operand, in parentheses when its operation binds less tightly than the one applied to it.

        Args:
            node: Operand tree.
            operators: Binary operations that need parentheses here.
            negative: Whether a negated operand needs them too.

        Returns:
            The operand's LaTeX.
        """
        text = _latex(node, names)
        wrap = (node[0] == "bin" and node[1] in operators) or (negative and node[0] == "neg")
        return rf"\left({text}\right)" if wrap else text

    kind = tree[0]
    if kind == "num":
        return _latex_number(tree[1])
    if kind == "ref":
        # A label's trailing number becomes a subscript, as P1 becomes P with subscript 1.
        name = names.get(tree[1], tree[1])
        numbered = re.fullmatch(r"(.*?[A-Za-z_])(\d+)", name)
        if numbered:
            return r"\mathrm{" + numbered[1].replace("_", r"\_") + "}_{" + numbered[2] + "}"
        return r"\mathrm{" + name.replace("_", r"\_") + "}"
    if kind == "neg":
        return "-" + grouped(tree[1], ("+", "-"))
    if kind == "math":
        arguments = [_latex(argument, names) for argument in tree[2]]
        if tree[1] == "sqrt":
            return rf"\sqrt{{{arguments[0]}}}"
        return MATH_LATEX[tree[1]] + r"\left(" + ", ".join(arguments) + r"\right)"
    if kind == "coord":
        function, arguments = tree[1], tree[2]
        atoms = [argument.strip() for argument in arguments if argument.strip()]
        if function == "DotDiff" and len(atoms) == 4:
            r = [rf"\mathbf{{r}}_{{{atom}}}" for atom in atoms]
            return rf"\left({r[0]}-{r[1]}\right)\cdot\left({r[2]}-{r[3]}\right)"
        if function == "Cartesian":
            component = next((str(atom) for atom in _atoms(arguments, function)[1:] if str(atom) in COMPONENTS), "X")
            function, arguments = COMPONENTS[component], arguments[:1]
        subscript = _latex_atoms(arguments)
        return r"\mathrm{" + function + "}" + (f"_{{{subscript}}}" if subscript else "")
    operation, left, right = tree[1:]
    if operation == "/":
        return rf"\frac{{{_latex(left, names)}}}{{{_latex(right, names)}}}"
    if operation == "**":
        base = _latex(left, names)
        if left[0] in ("bin", "neg") or (left[0] == "num" and left[1] < 0):
            base = rf"\left({base}\right)"
        return f"{base}^{{{_latex(right, names)}}}"
    if operation in ("+", "-"):
        return _latex(left, names) + operation + grouped(right, ("+", "-") if operation == "-" else (), negative=True)
    return grouped(left, ("+", "-")) + r"\cdot " + grouped(right, ("+", "-"), negative=True)


def latex(expression):
    r"""A GIC formula in LaTeX, from the tree ``formula_tree`` reads.

    A coordinate is its function with its atoms as a subscript, such as ``\mathrm{R}_{1,2}``, a quotient a fraction,
    a power a superscript, ``sqrt`` a radical and ``DotDiff(i,j,k,l)`` the manual's
    :math:`(\mathbf{r}_i-\mathbf{r}_j)\cdot(\mathbf{r}_k-\mathbf{r}_l)`; labels keep the case they are written in, with a
    trailing number as a subscript.

    Args:
        expression: Formula text.

    Returns:
        The LaTeX text, without math delimiters.

    Raises:
        ValueError: Text that is not a formula.
    """
    tokens = _tokens(expression.translate(str.maketrans("[]{}", "()()")))
    names = {token.lower(): token for token in tokens if re.match(r"[A-Za-z_]", token)}
    return _latex(formula_tree(expression), names)


def _nodes(tree):
    """Every node of a tree, parents first.

    Args:
        tree: Tree from ``formula_tree``.

    Yields:
        Each tuple node.
    """
    yield tree
    if tree[0] == "bin":
        yield from _nodes(tree[2])
        yield from _nodes(tree[3])
    elif tree[0] == "neg":
        yield from _nodes(tree[1])
    elif tree[0] == "math":
        for argument in tree[2]:
            yield from _nodes(argument)


def describe(entry):
    """Add what a coordinate line's formula is made of to its entry.

    Args:
        entry: A coordinate entry from ``parse_gic_line``, completed in place.

    Returns:
        The entry with ``terms`` (coordinate functions with their atoms), ``references`` (labels used), ``measure``
        (what a formula of one function alone measures, else ``formula``), ``unit`` (angstrom or degree for such
        a function alone, None otherwise, as a generic coordinate has arbitrary units) and ``error`` (why the
        formula could not be read, else None).
    """
    entry.update(terms=[], references=[], measure="none", unit=None, error=None)
    if entry["kind"] != "coordinate" or not entry["expression"]:
        return entry
    try:
        tree = formula_tree(entry["expression"])
    except ValueError as error:
        entry["error"] = str(error)
        return entry
    for node in _nodes(tree):
        if node[0] == "coord":
            function = node[1]
            atoms = _atoms(node[2], function)
            if function == "Cartesian":
                component = next((str(a) for a in atoms[1:] if str(a) in COMPONENTS), "")
                function = COMPONENTS.get(component, component or "X")
                atoms = atoms[:1]
            entry["terms"].append(dict(function=function, atoms=atoms))
        elif node[0] == "ref":
            entry["references"].append(node[1])
    if tree[0] == "coord" and entry["terms"]:
        entry["measure"], entry["unit"] = KINDS[entry["terms"][0]["function"]]
    else:
        entry["measure"] = "formula"
    return entry


def parse_gic_section(lines):
    """The lines of a GIC section as entries.

    Args:
        lines: The section's lines, without its terminating blank line.

    Returns:
        One entry per nonblank line, as ``parse_gic_line`` and ``describe`` return them.
    """
    entries = []
    for number, line in enumerate(lines, 1):
        if line.strip():
            entry = parse_gic_line(line, number)
            entries.append(describe(entry) if entry["kind"] == "coordinate" else entry)
    return entries


def validate(entries, atom_count):
    """Problems of a section against its molecule.

    Args:
        entries: Entries of the section.
        atom_count: Number of atoms of the molecule.

    Returns:
        Messages, one per problem, which is an atom outside the molecule, a label used before its definition, a
        formula that cannot be read or an option item not understood; empty for a clean section.
    """
    problems, defined = [], set()
    for entry in entries:
        where = f"line {entry['line']}"
        if entry["kind"] == "standalone":
            if entry["atom"] not in (None, "*") and not 1 <= entry["atom"] <= atom_count:
                problems.append(f"{where}: atom {entry['atom']} is not in the molecule")
        else:
            for term in entry["terms"]:
                for atom in term["atoms"]:
                    if isinstance(atom, int) and not 1 <= atom <= atom_count:
                        problems.append(f"{where}: atom {atom} is not in the molecule")
            for name in entry["references"]:
                if name not in defined:
                    problems.append(f"{where}: {name} is used before its definition")
            if entry["error"]:
                problems.append(f"{where}: {entry['error']}")
            if entry["label"]:
                defined.add(entry["label"].lower())
        problems += [f"{where}: option {item!r} is not understood" for item in entry["unparsed"]]
    return problems


def _structure(function, atoms, coordinates):
    """Value of one coordinate function in bohr, radians or bohr squared.

    Args:
        function: Canonical function name.
        atoms: Its atom list.
        coordinates: Array of positions in bohr.

    Returns:
        The value.

    Raises:
        ValueError: A function this evaluator does not support, or a wildcard.
    """
    if any(not isinstance(atom, int) for atom in atoms):
        raise ValueError(f"{function} with {atoms} cannot be evaluated")
    point = lambda number: coordinates[number - 1]
    if function == "R":
        return float(np.linalg.norm(point(atoms[0]) - point(atoms[1])))
    if function == "A":
        first, second = point(atoms[0]) - point(atoms[1]), point(atoms[2]) - point(atoms[1])
        return float(math.acos(np.clip(first @ second / np.linalg.norm(first) / np.linalg.norm(second), -1, 1)))
    if function == "D":
        b1, b2, b3 = (point(atoms[k + 1]) - point(atoms[k]) for k in range(3))
        n1, n2 = np.cross(b1, b2), np.cross(b2, b3)
        return float(math.atan2(np.cross(n1, n2) @ b2 / np.linalg.norm(b2), n1 @ n2))
    if function in ("X", "Y", "Z"):
        return float(point(atoms[0])["XYZ".index(function)])
    if function in ("XCntr", "YCntr", "ZCntr"):
        chosen = coordinates if not atoms else coordinates[[atom - 1 for atom in atoms]]
        return float(chosen.mean(axis=0)["XYZ".index(function[0])])
    if function == "DotDiff":
        # The manual's a = r_i - r_j and b = r_k - r_l.
        return float((point(atoms[0]) - point(atoms[1])) @ (point(atoms[2]) - point(atoms[3])))
    raise ValueError(f"{function} is not evaluated")


def _evaluate(tree, values, coordinates):
    """Value of a formula tree.

    Args:
        tree: Tree from ``formula_tree``.
        values: Labels evaluated so far, by lower-case name.
        coordinates: Positions in bohr.

    Returns:
        The number.

    Raises:
        ValueError: A label without a value or an unsupported function.
    """
    kind = tree[0]
    if kind == "num":
        return tree[1]
    if kind == "ref":
        if tree[1] not in values:
            raise ValueError(f"{tree[1]} has no value")
        return values[tree[1]]
    if kind == "neg":
        return -_evaluate(tree[1], values, coordinates)
    if kind == "math":
        return MATH[tree[1]](*(_evaluate(argument, values, coordinates) for argument in tree[2]))
    if kind == "coord":
        function, atoms = tree[1], _atoms(tree[2], tree[1])
        if function == "Cartesian":
            component = str(atoms[1]) if len(atoms) > 1 else "X"
            function, atoms = COMPONENTS.get(component, component), atoms[:1]
        return _structure(function, atoms, coordinates)
    left, right = _evaluate(tree[2], values, coordinates), _evaluate(tree[3], values, coordinates)
    return OPERATORS[tree[1]](left, right)


def evaluate(entries, coordinates):
    """Values of the labeled coordinates of a section at a geometry, in Gaussian's internal units.

    Bond lengths and Cartesian components are in bohr, angles and dihedrals in radians, a dot product in bohr
    squared, as the manual states Gaussian stores them; a formula mixes them as written. Lines without a label, and
    lines whose formula needs a function this evaluator does not support (linear bends), are left out.

    Args:
        entries: Entries of the section, in order.
        coordinates: Positions in angstrom as rows of x, y, z, in the frame the section's atoms refer to.

    Returns:
        Lower-case label mapped to its value.
    """
    from ..results import ureg

    positions = np.asarray(coordinates, dtype=float) * ureg.Quantity(1.0, "angstrom").m_as("bohr")
    values = {}
    for entry in entries:
        if entry["kind"] != "coordinate" or not entry["expression"] or not entry["label"] or entry["error"]:
            continue
        try:
            values[entry["label"].lower()] = _evaluate(formula_tree(entry["expression"]), values, positions)
        except (ValueError, ZeroDivisionError, OverflowError):
            continue
    return values


def merge_definitions(entries, table):
    """Printed internal coordinates joined with the GIC lines that define them.

    Args:
        entries: Entries of the job's GIC section, from ``parse_gic_section``.
        table: The job's ``internal_coordinates``.

    Returns:
        One record per printed coordinate, with the table's ``name``, ``definition``, ``value``, ``frozen`` and
        ``scan`` and, where a line of the section carries that label, its ``expression``, ``measure``, ``unit``,
        ``actions`` and ``options``; None for each of those when Gaussian generated the coordinate.
    """
    labeled = {entry["label"].lower(): entry for entry in entries if entry["kind"] == "coordinate" and entry["label"]}
    merged = []
    for row in table:
        entry = labeled.get(row["name"].lower())
        merged.append(dict(row, expression=entry and entry["expression"], measure=entry and entry["measure"],
                           unit=entry and entry["unit"], actions=entry and entry["actions"], options=entry and entry["options"]))
    return merged

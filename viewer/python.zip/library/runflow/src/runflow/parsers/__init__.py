"""Native numeric notation and warning handling shared by result readers."""

import hashlib
import re
from itertools import pairwise

NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[DEde][-+]?\d+)?"


def _number(value):
    """Read either native Fortran or decimal scientific notation.

    Args:
        value: Number text, such as ``0.11D+02`` or ``1.1e1``.

    Returns:
        The value as a float.
    """
    return float(value.replace("D", "E").replace("d", "e"))


def _values(text, pattern):
    """Collect numerical values without inventing entries for absent properties.

    Args:
        text: Text to search.
        pattern: Regular expression whose first group captures a number.

    Returns:
        The matched values as floats, empty when none is printed.
    """
    return [
        _number(value)
        for group in re.findall(pattern, text, re.MULTILINE)
        for value in re.findall(NUMBER, group)
    ]


def _warnings(text):
    """Retain each scientific warning with its indented continuation lines.

    Args:
        text: Native text to search.

    Returns:
        One string per warning.
    """
    lines = text.splitlines()
    messages = []
    for index, line in enumerate(lines):
        if (
            not re.search(r"\bwarn(?:ing)?\b", line, re.IGNORECASE)
            or "may not be used" in line
        ):
            continue
        parts = [line.strip()]
        indentation = len(line) - len(line.lstrip())
        for continuation in lines[index + 1 :]:
            if (
                not continuation.strip()
                or len(continuation) - len(continuation.lstrip()) <= indentation
            ):
                break
            parts.append(continuation.strip())
        messages.append(" ".join(parts))
    return messages


def _warning_code(text, program="gaussian"):
    """Identify recurring native warnings, with a stable fingerprint for unclassified messages.

    Args:
        text: Warning text as printed.
        program: Program that printed it, 'gaussian' or 'runflow', which selects the known patterns.

    Returns:
        A code such as gaussian.warning.checkpoint_basis for a known warning, or program.warning.other_ followed by a
        digest of the text with its numbers masked.
    """
    text = re.sub(r"^[*\s]*warning\W*", "", " ".join(text.split()), flags=re.IGNORECASE)
    if program == "runflow":
        rules = [
            ("constrained_saddle_only", r"^constrained saddle only\.?$"),
            ("screening_weights_changed", r"^geometry relaxation changed the rounded DD-DFT weights; review the residual before further calculations\.?$"),
            ("screening_first_cycle_geometry_and_weights", r"^using the first-cycle DD-DFT geometry and weights with the documented screening residual\.?$"),
            ("screening_first_cycle_weights", r"^using the first-cycle DD-DFT weights with the documented screening residual\.?$"),
        ]
    elif program == "gaussian":
        rules = [
            ("checkpoint_basis", r"basis set taken from checkpoint file"),
            ("large_mo_coefficient", r"largest (?:alpha|beta) MO coefficient"),
            ("small_orbital_gap", r"smallest (?:alpha|beta) delta epsilon"),
            ("low_frequency_thermochemistry", r"explicit consideration of .* degrees of freedom as vibrations"),
            ("classical_rotation", r"assumption of classical behavior for rotation"),
            ("irc_lqa_convergence", r"LQA convergence difficult"),
            ("ts_imaginary_frequencies", r"TS has more than .* imaginary frequenc"),
            ("small_imaginary_frequencies", r"one or more small imaginary frequencies"),
            ("inconsistent_solvent_volume", r"inconsistent VMol and RSolv"),
        ]
    else:
        rules = []
    for code, pattern in rules:
        if re.search(pattern, text, re.IGNORECASE):
            return f"{program}.warning.{code}"
    normalized = re.sub(NUMBER, "#", " ".join(text.casefold().split()))
    digest = hashlib.sha256(normalized.encode()).hexdigest()[:12]
    return f"{program}.warning.other_{digest}"


def _split_jobs(text):
    """Yield native linked-job text without interpreting unrelated sections.

    Args:
        text: Complete native Gaussian log.

    Yields:
        The text of each linked job, in order.
    """
    starts = [
        match.start()
        for match in re.finditer(r"^\s*Initial command:", text, re.MULTILINE)
    ]
    boundaries = [0, *starts[1:], len(text)]
    for begin, end in pairwise(boundaries):
        yield text[begin:end]


def _blocked_matrix(lines, start, rows=None, columns=None, symmetric=False):
    """Read native indexed matrix blocks without filling missing entries with zeros.

    Args:
        lines: Lines of the native text.
        start: Index of the first line of the blocks.
        rows: Expected number of rows, or None.
        columns: Expected number of columns, or None.
        symmetric: Whether only one triangle is printed.

    Returns:
        The matrix as nested lists with None for unprinted entries, the row labels and the index of the next line.
    """
    entries = {}
    labels = {}
    active = []
    index = start
    observed = False
    waiting = 4
    decimal = r"[-+]?(?:\d+\.\d*|\.\d+)(?:[DEde][-+]?\d+)?"
    while index < len(lines):
        line = lines[index]
        words = line.split()
        if words and all(word.isdigit() for word in words):
            active = [int(word) for word in words]
            waiting = 0
            index += 1
            continue
        row = re.match(r"^\s*(\d+)\s+", line)
        values = list(re.finditer(decimal, line[row.end() :])) if row else []
        if row and active and values:
            number = int(row[1])
            if len(values) > len(active):
                break
            for column, value in zip(active, values, strict=False):
                entries[number, column] = _number(value[0])
                if symmetric:
                    entries[column, number] = _number(value[0])
            labels[number] = line[row.end() : row.end() + values[0].start()].strip()
            observed = True
            waiting = 4
            index += 1
            continue
        if active and waiting < 3 and not row:
            waiting += 1
            index += 1
            continue
        if observed:
            break
        if (
            not words
            or "Eigenvalues" in line
            or re.fullmatch(r"[\s()A-Za-z0-9+*.,=\-]+", line)
        ):
            index += 1
            if index - start > 6 and not observed:
                break
            continue
        break
    if not entries:
        return [], [], index
    row_count = rows or max(row for row, column in entries)
    column_count = columns or max(column for row, column in entries)
    matrix = [
        [entries.get((i + 1, j + 1)) for j in range(column_count)]
        for i in range(row_count)
    ]
    return matrix, [labels.get(i + 1) for i in range(row_count)], index


def _is_nto(text, position, end):
    """Recognize NTO eigenvalues printed either before or after their table heading.

    Args:
        text: Native text holding the eigenvalue line.
        position: Start of the eigenvalue line.
        end: End of the eigenvalue line.

    Returns:
        Whether the eigenvalues belong to natural transition orbitals.
    """
    before = text[:position]
    if before.rfind("Natural Transition Orbital Coefficients:") > before.rfind(
        "Population analysis using"
    ):
        return True
    for line in text[end:].splitlines():
        stripped = line.strip()
        if not stripped or re.match(
            r"(?:Alpha|Beta)\s+(?:occ|virt)\. eigenvalues --", stripped
        ):
            continue
        return stripped.startswith("Natural Transition Orbital Coefficients:")
    return False

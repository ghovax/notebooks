"""Gaussian route sections: keywords with their options, and the request each linked job makes.

A route is read the way Gaussian reads it, so job types and their options come from Gaussian's own keywords
instead of labels typed beside the input.
"""

import re

# Gaussian's job-type keywords; a route without one is a single point.
JOB_TYPES = ("opt", "freq", "irc", "ircmax", "scan", "polar", "admp", "bomd", "force", "stable", "volume")
# Excited-state methods whose NStates and Root select the states.
EXCITED_METHODS = ("td", "tda", "cis")
# Gaussian's defaults when NStates or Root is not given.
DEFAULT_STATES, DEFAULT_ROOT = 3, 1


def split_items(text):
    """Items of a route or option list, separated by spaces, tabs or commas outside parentheses.

    Args:
        text: Route or option text.

    Returns:
        The items, without empty ones.
    """
    items, depth, current = [], 0, ""
    for character in text:
        depth += (character == "(") - (character == ")")
        if character in " \t," and depth == 0:
            items.append(current)
            current = ""
        else:
            current += character
    return [item for item in items + [current] if item]


def unwrap(value):
    """A value without one pair of enclosing parentheses.

    Args:
        value: Option text.

    Returns:
        The text inside the parentheses, or the value unchanged.
    """
    return value[1:-1] if value.startswith("(") and value.endswith(")") else value


def route_keywords(route):
    """Route keywords in Gaussian's syntax, without the leading #, #p, #n or #t.

    Options attach to their keyword as keyword=option, keyword(option), keyword=(options) or
    keyword (options), with optional spaces around the equals sign. A model chemistry, method/basis,
    has its slash before any option and comes back whole, with no option.

    Args:
        route: Route text of one linked job.

    Returns:
        (name, options) pairs in route order; options are empty for a bare keyword.
    """
    route = re.sub(r"\s*=\s*", "=", route.strip())
    route = re.sub(r"(\w)\s+\(", r"\1(", route)
    keywords = []
    for item in split_items(route):
        item = re.sub(r"^#[pPnNtT]?", "", item)
        if not item:
            continue
        if re.match(r"^[^=(]+/", item):
            keywords.append((item, ""))
            continue
        name, _, value = re.sub(r"^([^=(]+)\((.*)\)$", r"\1=(\2)", item).partition("=")
        keywords.append((name, value))
    return keywords


def keyword_options(options):
    """Options of one keyword as lowercase names mapped to their values.

    Args:
        options: Option text of one keyword, with or without parentheses.

    Returns:
        Lowercase option names mapped to their values, empty for a bare option.
    """
    pairs = (option.partition("=") for option in split_items(unwrap(options)))
    return {name.lower(): value for name, _, value in pairs}


def request(route):
    """What one linked job asks Gaussian to do, read from its route.

    Args:
        route: Route text of one linked job.

    Returns:
        ``jobs``, the job types in route order, ``["sp"]`` without one; ``options``, each job type's options,
        such as ``{"opt": {"ts": "", "calcfc": ""}}``; ``excited``, the excited-state method with its number of
        states and selected root, Gaussian's defaults filled in, or None for the ground state.
    """
    keywords = {}
    for name, options in route_keywords(route):
        if "/" not in name or options:
            keywords[name.lower()] = keyword_options(options)
    jobs = [name for name in keywords if name in JOB_TYPES]
    method = next((name for name in keywords if name in EXCITED_METHODS), None)
    excited = None
    if method:
        settings = keywords[method]
        excited = {
            # Excited-state method keyword, such as td.
            "method": method,
            # Number of excited states solved.
            "states": int(settings.get("nstates") or DEFAULT_STATES),
            # One-based state followed by optimizations, frequencies and properties.
            "root": int(settings.get("root") or DEFAULT_ROOT),
        }
    return {
        # Job types in route order; a route without one is a single point.
        "jobs": jobs or ["sp"],
        # Options of each job type as lowercase names mapped to their values.
        "options": {name: keywords[name] for name in jobs},
        # Excited-state method, states and root, or None for the ground state.
        "excited": excited,
    }


def input_routes(text):
    """Route of every linked job in a Gaussian input, in order.

    Args:
        text: Gaussian input text.

    Returns:
        One route per linked job, with lines joined by spaces.
    """
    routes = []
    for section in text.split("--Link1--"):
        lines = section.splitlines()
        start = next((index for index, line in enumerate(lines) if line.lstrip().startswith("#")), None)
        if start is None:
            continue
        end = next((index for index in range(start, len(lines)) if not lines[index].strip()), len(lines))
        routes.append(" ".join(line.strip() for line in lines[start:end]))
    return routes

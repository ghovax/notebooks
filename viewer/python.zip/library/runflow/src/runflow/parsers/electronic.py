"""Independent Gaussian electronic-energy, orbital, basis and environment readers."""

import re

from . import NUMBER, _blocked_matrix, _is_nto, _number


def _parse_energies(blocks):
    """Retain labelled energy families without mixing corrections and total energies.

    Args:
        blocks: Native text of each linked job, in order.

    Returns:
        The labelled energies of each linked job.
    """
    jobs = []
    patterns = [
        (r"SCF Done:\s+E\(([^)]+)\)\s*=\s*(" + NUMBER + r")", "total"),
        (
            r"\b(EUMP[2345]|UMP4\((?:DQ|SDQ|SDTQ)\)|MP5|CCSD\(T\))\s*=\s*("
            + NUMBER
            + r")",
            "total",
        ),
        (
            r"Wavefunction amplitudes converged\.\s+(E\(Corr\))\s*=\s*("
            + NUMBER
            + r")",
            "total",
        ),
        (
            r"\b(E2|E3|E4\((?:DQ|SDQ|SDTQ)\)|DEMP5|E2\(B2PLYP\))\s*=\s*("
            + NUMBER
            + r")",
            "correction",
        ),
        (r"(Grimme-\S+)\s+Dispersion energy\s*=\s*(" + NUMBER + r")", "dispersion"),
        (r"(ONIOM):\s+extrapolated energy\s*=\s*(" + NUMBER + r")", "extrapolated"),
    ]
    for block in blocks:
        records = []
        for pattern, kind in patterns:
            for match in re.finditer(pattern, block, re.IGNORECASE):
                records.append(
                    {
                        # One-based source line within the linked job.
                        "line": block.count("\n", 0, match.start()) + 1,
                        # Native method or energy label, without reconstructing a functional.
                        "label": match[1],
                        # Distinguishes total energies, corrections, dispersion and extrapolation.
                        "kind": kind,
                        # Printed energy in hartree; corrections are not standalone total energies.
                        "energy": _number(match[2]),
                    }
                )
        jobs.append(sorted(records, key=lambda item: item["line"]))
    return jobs


def _orbital_values(section):
    """Read canonical spin channels, retaining repeated population analyses.

    Args:
        section: Native text of one population analysis.

    Returns:
        The occupied and virtual orbital energies of each spin channel.
    """
    records = []
    channels = {}
    markers = list(
        re.finditer(
            r"^[ \t]*(Alpha|Beta)[ \t]+(occ|virt)\.[ \t]+eigenvalues --([^\n]+)",
            section,
            re.MULTILINE,
        )
    )
    for match in markers:
        # NTO eigenvalues are occupations and must never become canonical energies.
        if _is_nto(section, match.start(), match.end()):
            continue
        spin = match[1].lower()
        if spin not in channels or match[2] == "occ" and channels[spin]["virtual"]:
            record = {
                # One-based source line within the linked job.
                "line": section.count("\n", 0, match.start()) + 1,
                # Native alpha or beta channel; restricted output normally prints alpha only.
                "spin": spin,
                # Canonical occupied orbital energies in hartree, in printed order.
                "occupied": [],
                # Canonical virtual orbital energies in hartree, in printed order.
                "virtual": [],
            }
            channels[spin] = record
            records.append(record)
        channels[spin]["occupied" if match[2] == "occ" else "virtual"].extend(
            _number(v) for v in re.findall(NUMBER, match[3])
        )
    return records


def _parse_orbitals(blocks):
    """Read spin-resolved canonical energies and printed AO-by-MO coefficient tables.

    Args:
        blocks: Native text of each linked job, in order.

    Returns:
        The orbital energies and coefficient tables of each linked job.
    """
    jobs = []
    for block in blocks:
        n_basis = re.findall(r"NBasis=\s*(\d+)", block)
        n_mo = re.findall(r"NBsUse=\s*(\d+)", block)
        rows = int(n_basis[-1]) if n_basis else None
        columns = int(n_mo[-1]) if n_mo else rows
        coefficients = []
        for match in re.finditer(
            r"^[ \t]*(?:(Alpha|Beta)[ \t]+)?Molecular Orbital Coefficients:[^\n]*\n",
            block,
            re.MULTILINE,
        ):
            tail = block[match.end() :].splitlines()
            matrix, labels, end = _blocked_matrix(tail, 0, rows=rows, columns=columns)
            if not matrix:
                continue
            eigenvalues = [
                _number(v)
                for line in tail[:end]
                if "Eigenvalues --" in line
                for v in re.findall(NUMBER, line.split("--", 1)[1])
            ]
            coefficients.append(
                {
                    # One-based header line within the linked job.
                    "line": block.count("\n", 0, match.start()) + 1,
                    # Native spin channel; a restricted table is labelled restricted.
                    "spin": match[1].lower() if match[1] else "restricted",
                    # AO labels in native row order; atom indices remain part of the label.
                    "ao_labels": labels,
                    # Printed eigenvalues in hartree for the coefficient-table columns.
                    "eigenvalues": eigenvalues,
                    # AO-by-MO coefficients; unprinted entries remain None rather than zero.
                    "coefficients": matrix,
                    # Whether every expected AO/MO entry was actually printed.
                    "complete": all(
                        value is not None for row in matrix for value in row
                    ),
                }
            )
        jobs.append(
            {
                # Canonical occupied/virtual energies separated by native spin and population pass.
                "orbitals": _orbital_values(block),
                # Canonical molecular-orbital coefficient tables only, excluding NTO coefficients.
                "coefficients": coefficients,
            }
        )
    return jobs


def _parse_basis(blocks):
    """Read the printed basis label and GFInput shells without inferring missing data.

    Args:
        blocks: Native text of each linked job, in order.

    Returns:
        The basis label and shells of each linked job.
    """
    jobs = []
    for block in blocks:
        labels = re.findall(r"Standard basis:\s*([^\n]+)", block)
        shells = []
        for match in re.finditer(
            r"AO basis set in the form of general basis input[^\n]*\n", block
        ):
            lines = block[match.end() :].splitlines()
            atom = None
            index = 0
            while index < len(lines):
                words = lines[index].split()
                if not words or words == ["****"]:
                    index += 1
                    continue
                if len(words) == 2 and words[0].isdigit() and words[1] == "0":
                    atom = int(words[0])
                    index += 1
                    continue
                if (
                    atom is None
                    or len(words) < 3
                    or words[0] not in {"S", "P", "SP", "L", "D", "F", "G", "H", "I"}
                    or not words[1].isdigit()
                ):
                    break
                count = int(words[1])
                primitives = []
                for line in lines[index + 1 : index + 1 + count]:
                    data = line.split()
                    if len(data) < 2 or not all(re.fullmatch(NUMBER, v) for v in data):
                        break
                    primitives.append([_number(v) for v in data])
                shells.append(
                    {
                        # One-based atom index in the printed GFInput basis.
                        "atom": atom,
                        # Native shell label, including combined SP shells.
                        "shell": words[0],
                        # Printed shell scale factor; not silently applied a second time.
                        "scale": _number(words[2]),
                        # Primitive exponents in the native atomic-unit basis convention.
                        "exponents": [row[0] for row in primitives],
                        # Contraction coefficients; SP shells retain both coefficient columns.
                        "coefficients": [row[1:] for row in primitives],
                        # Whether all declared primitive rows were available.
                        "complete": len(primitives) == count,
                    }
                )
                index += count + 1
        jobs.append(
            {
                # Printed standard-basis label including Cartesian/spherical conventions.
                "label": labels[-1].strip() if labels else None,
                # Explicit GFInput contracted shells; empty if this format was not printed.
                "shells": shells,
            }
        )
    return jobs


def _parse_stability(blocks):
    """Read spin contamination and explicit wavefunction-stability conclusions.

    Args:
        blocks: Native text of each linked job, in order.

    Returns:
        The spin-squared values and stability conclusions of each linked job.
    """
    jobs = []
    for block in blocks:
        spins = []
        for match in re.finditer(
            r"S\*\*2 before annihilation\s+("
            + NUMBER
            + r"),\s+after\s+("
            + NUMBER
            + r")",
            block,
        ):
            spins.append(
                {
                    # One-based source line within the linked job.
                    "line": block.count("\n", 0, match.start()) + 1,
                    # Native expectation of S squared before spin annihilation.
                    "before": _number(match[1]),
                    # Native expectation of S squared after spin annihilation.
                    "after": _number(match[2]),
                }
            )
        stability = []
        for number, line in enumerate(block.splitlines(), 1):
            if re.search(
                r"wavefunction is .*stable|wavefunction has .*instabilit",
                line,
                re.IGNORECASE,
            ):
                stability.append(
                    {
                        # One-based source line within the linked job.
                        "line": number,
                        # Exact native stability conclusion, including the tested scope.
                        "message": line.strip(),
                        # True for an explicit stable result, False for instability, None if ambiguous.
                        "stable": False
                        if re.search(
                            r"not stable|unstable|instabilit", line, re.IGNORECASE
                        )
                        else True
                        if "stable" in line.lower()
                        else None,
                    }
                )
        jobs.append(
            {
                # Native before/after-annihilation spin expectations, dimensionless.
                "spin_squared": spins,
                # Explicit electronic-stability conclusions; empty if no test was printed.
                "stability": stability,
            }
        )
    return jobs


def _parse_solvent(blocks):
    """Read explicit PCM configuration and printed solvation contributions.

    Args:
        blocks: Native text of each linked job, in order.

    Returns:
        The solvent model, its parameters and contributions for each linked job.
    """
    jobs = []
    for block in blocks:
        records = []
        for match in re.finditer(
            r"Solvent\s*:\s*([^,\n]+),\s*Eps=\s*("
            + NUMBER
            + r")\s+Eps\(inf\)=\s*("
            + NUMBER
            + r")",
            block,
        ):
            records.append(
                {
                    # One-based source line within the linked job.
                    "line": block.count("\n", 0, match.start()) + 1,
                    # Native solvent name rather than a molecular-screening parameter.
                    "solvent": match[1].strip(),
                    # Static continuum-solvent dielectric constant; dimensionless.
                    "epsilon": _number(match[2]),
                    # Optical/high-frequency continuum dielectric constant; dimensionless.
                    "epsilon_infinity": _number(match[3]),
                }
            )
        contributions = []
        for match in re.finditer(
            r"(Dispersion|Cavitation|Repulsion) energy\s+([^=\n]+)=\s*("
            + NUMBER
            + r")",
            block,
            re.IGNORECASE,
        ):
            contributions.append(
                {
                    # Native non-electrostatic contribution name.
                    "label": match[1].lower(),
                    # Unit label as explicitly printed; no implicit kcal/mol conversion.
                    "units": match[2].strip(),
                    # Native numerical contribution in the explicitly stated units.
                    "value": _number(match[3]),
                }
            )
        jobs.append(
            {
                # Whether a native PCM configuration banner was printed.
                "pcm": "Polarizable Continuum Model" in block,
                # Explicit continuum solvent parameters, distinct from molecular screening.
                "parameters": records,
                # Printed non-electrostatic contributions, without inventing absent terms.
                "contributions": contributions,
            }
        )
    return jobs

"""Gaussian linked-job, optimization, vibration, TD and IRC log parsing."""

import re
from bisect import bisect_left
from functools import lru_cache

from . import NUMBER, _is_nto, _number, _warning_code, _warnings
from .population import _charge_analyses, _multipoles
from .input_sections import modredundant_echo
from .route import request


# Spin multiplicity 2S+1 of Gaussian's spin names in TD state labels.
MULTIPLICITIES = {"Singlet": 1, "Doublet": 2, "Triplet": 3, "Quartet": 4, "Quintet": 5, "Sextet": 6, "Septet": 7}


def _state_label(label):
    """Spin multiplicity and subgroup symmetry of a TD state label.

    Restricted references print a spin name, such as Singlet-B2U; unrestricted ones print an estimate of 2S+1 from
    <S**2>, such as 3.017-A, rounded here to the nearest integer. The symmetry is the irreducible representation in
    Gaussian's computational point group, or None when Gaussian printed ?Sym or ran without symmetry.

    Args:
        label: State label as Gaussian prints it, such as Singlet-B2U or 3.017-A.

    Returns:
        Mapping with the spin 'multiplicity' and the 'symmetry', each None when the label names none.
    """
    spin, _, symmetry = label.partition("-")
    multiplicity = MULTIPLICITIES.get(spin.capitalize())
    if multiplicity is None:
        try:
            multiplicity = round(float(spin))
        except ValueError:
            multiplicity = None
    return {
        # Spin multiplicity 2S+1 of the state; None when the label names none.
        "multiplicity": multiplicity,
        # State irrep in Gaussian's computational point group, as printed; None for ?Sym or no symmetry.
        "symmetry": None if not symmetry or "?" in symmetry else symmetry,
    }


@lru_cache(maxsize=8)
def _newlines(text):
    """Offsets of every newline in a text, found once per text.

    Args:
        text: Text to scan.

    Returns:
        The offsets of its newline characters, in order.
    """
    return [match.start() for match in re.finditer("\n", text)]


def _line(text, offset):
    """One-based line number of an offset in a text.

    Counting newlines from the start for every match made parsing quadratic in the log's length, so the offsets of the
    newlines are found once and searched by bisection.

    Args:
        text: Text the offset belongs to.
        offset: Character offset in the text.

    Returns:
        The one-based line number.
    """
    return bisect_left(_newlines(text), offset) + 1


def _moments(text, title):
    """Read the consecutive state-indexed rows of one transition-moment table.

    Args:
        text: Native text of one linked job.
        title: Heading of the table.

    Returns:
        One record per state, from the last such table: a TD optimization prints one per geometry, and the last
        belongs to the final geometry.
    """
    matches = list(re.finditer(title + r"[^\n]*\n[^\n]*\n", text, re.IGNORECASE))
    if not matches:
        return []
    match = matches[-1]
    rows = []
    for line in text[match.end() :].splitlines():
        parts = line.split()
        if not parts or not parts[0].isdigit() or len(parts) < 4:
            break
        # x/y/z are transition components, strength is their printed squared magnitude;
        # oscillator is dimensionless. Components and strength retain native atomic units.
        record = dict(
            zip(
                ("x", "y", "z", "strength", "oscillator"),
                map(_number, parts[1:]),
                strict=False,
            )
        )
        rows.append(
            {
                # One-based excited-state index.
                "state": int(parts[0]),
                **record,
            }
        )
    return rows


def _tables(text, title):
    """Read printed Cartesian tables, retaining their frame and source position.

    Args:
        text: Native text of one linked job.
        title: Heading of the tables, such as an orientation.

    Returns:
        One record per table, with its frame, atoms and vectors.
    """
    records = []
    pattern = title + r"[^\n]*\n\s*-+\n.*?\n.*?\n\s*-+\n(.*?)\n\s*-+"
    for match in re.finditer(pattern, text, re.DOTALL):
        rows = [line.split() for line in match[match.lastindex].splitlines()]
        if not rows or any(len(row) < 5 for row in rows):
            continue
        records.append(
            {
                # Zero-based character position within the linked Gaussian job.
                "offset": match.start(),
                # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                "line": _line(text, match.start()),
                # Native coordinate frame; Cartesian forces use input orientation.
                "frame": match[1].lower(),
                # One-based center indices in native table order.
                "centers": [int(row[0]) for row in rows],
                # Atomic numbers in the printed center order.
                "atomic_numbers": [int(row[1]) for row in rows],
                # Cartesian x/y/z rows: angstrom for geometries, hartree/bohr for forces.
                "vectors": [list(map(_number, row[-3:])) for row in rows],
            }
        )
    return records


def _vibrations(text):
    """Read distinct harmonic analyses, preferring matching high-precision vectors.

    Args:
        text: Native text of one linked job.

    Returns:
        The frequencies, reduced masses, force constants, IR intensities and mode sets.
    """
    pattern = r"^[ \t]*Frequencies[ \t]+(-{2,3})[ \t]+([^\n]+)"
    markers = list(re.finditer(pattern, text, re.MULTILINE))
    groups = []
    current = []
    precision = None
    for position, match in enumerate(markers):
        kind = "high" if match[1] == "---" else "standard"
        preceding = text[: match.start()].splitlines()[-3:]
        indices = next(
            (
                [int(n) for n in line.split()]
                for line in preceding
                if line.split() and all(n.isdigit() for n in line.split())
            ),
            [],
        )
        symmetry = preceding[-1].split() if preceding else []
        frequencies = [_number(value) for value in re.findall(NUMBER, match[2])]
        if current and (precision != kind or indices and indices[0] == 1):
            groups.append((precision, current))
            current = []
        precision = kind
        stop = (
            markers[position + 1].start() if position + 1 < len(markers) else len(text)
        )
        section = text[match.end() : stop]
        boundary = re.search(
            r"^[ \t]*(?:Thermochemistry|Harmonic frequencies|Zero-point correction|-----)",
            section,
            re.MULTILINE,
        )
        if boundary:
            section = section[: boundary.start()]
        properties = {}
        labels = [
            ("reduced_mass", r"(?:Red\. masses|Reduced masses)"),
            ("force_constant", r"(?:Frc consts|Force constants)"),
            ("ir_intensity", r"(?:IR Inten|IR Intensities)"),
            ("raman_activity", r"(?:Raman Activ|Raman Activities)"),
            ("depolarization_plane", r"(?:Depolar \(P\)|Depol\. \(Plane\))"),
            ("depolarization_unpolarized", r"(?:Depolar \(U\)|Depol\. \(Unpol\))"),
        ]
        for key, label in labels:
            values = re.search(label + r"[ \t]+-{2,3}([^\n]+)", section)
            properties[key] = (
                [_number(value) for value in re.findall(NUMBER, values[1])]
                if values
                else []
            )
        centers = []
        atoms = []
        vectors = [[] for _ in frequencies]
        if kind == "high":
            header = re.search(
                r"^[ \t]*Coord[ \t]+Atom[ \t]+Element:[^\n]*\n", section, re.MULTILINE
            )
            components = {}
            if header:
                for line in section[header.end() :].splitlines():
                    words = line.split()
                    if len(words) != 3 + len(frequencies) or not all(
                        w.isdigit() for w in words[:3]
                    ):
                        break
                    component, center, number = map(int, words[:3])
                    component = (component - 1) % 3 + 1
                    components[center, component] = [_number(v) for v in words[3:]]
                    if center not in centers:
                        centers.append(center)
                        atoms.append(number)
                if all(
                    (center, component) in components
                    for center in centers
                    for component in (1, 2, 3)
                ):
                    vectors = [
                        [
                            [
                                components[center, component][mode]
                                for component in (1, 2, 3)
                            ]
                            for center in centers
                        ]
                        for mode in range(len(frequencies))
                    ]
        else:
            header = re.search(
                r"^[ \t]*Atom[ \t]+AN[ \t]+X[ \t]+Y[ \t]+Z[^\n]*\n",
                section,
                re.MULTILINE,
            )
            if header:
                for line in section[header.end() :].splitlines():
                    words = line.split()
                    if len(words) != 2 + 3 * len(frequencies) or not all(
                        w.isdigit() for w in words[:2]
                    ):
                        break
                    centers.append(int(words[0]))
                    atoms.append(int(words[1]))
                    for mode in range(len(frequencies)):
                        vectors[mode].append(
                            [_number(v) for v in words[2 + 3 * mode : 5 + 3 * mode]]
                        )
        for mode, frequency in enumerate(frequencies):
            record = {
                # One-based native normal-mode index; None if the header is absent.
                "mode": indices[mode] if mode < len(indices) else None,
                # Printed irreducible-representation label, when available.
                "symmetry": symmetry[mode] if mode < len(symmetry) else None,
                # Projected frequency in inverse centimetres; negative flags imaginary.
                "frequency": frequency,
                # Native center indices, in displacement-table order.
                "centers": centers.copy(),
                # Atomic numbers in displacement-table order.
                "atomic_numbers": atoms.copy(),
                # Normalized Cartesian direction vectors; dimensionless, not an amplitude.
                "displacements": vectors[mode],
                # Whether retained vectors use the high-precision or standard native format.
                "vector_precision": kind if vectors[mode] else None,
            }
            # Reduced mass uses amu; force constant mDyne/angstrom; IR intensity km/mol.
            # Raman activity uses angstrom**4/amu; both depolarization ratios are dimensionless.
            for key, _ in labels:
                record[key] = (
                    properties[key][mode] if mode < len(properties[key]) else None
                )
            current.append(record)
    if current:
        groups.append((precision, current))
    analyses = []
    previous_kind = None
    for kind, modes in groups:
        if (
            kind == "standard"
            and previous_kind == "high"
            and analyses
            and len(analyses[-1]) == len(modes)
        ):
            high = analyses[-1]
            if all(
                a["mode"] == b["mode"] and abs(a["frequency"] - b["frequency"]) < 0.001
                for a, b in zip(high, modes, strict=True)
            ):
                for standard, precise in zip(modes, high, strict=True):
                    if (
                        precise["displacements"]
                        and precise["centers"] == standard["centers"]
                    ):
                        standard["displacements"] = precise["displacements"]
                        standard["vector_precision"] = "high"
                analyses[-1] = modes
                previous_kind = kind
                continue
        analyses.append(modes)
        previous_kind = kind
    return analyses


def _evaluations(text, geometries, forces):
    """Read native evaluation records without assuming convergence.

    Args:
        text: Native text of one linked job.
        geometries: Its Cartesian geometry tables.
        forces: Its Cartesian force tables.

    Returns:
        One record per energy evaluation, linked to its geometry and forces.
    """
    evaluations = []
    markers = list(
        re.finditer(r"SCF Done:\s+E\(([^)]+)\)\s*=\s*(" + NUMBER + r")", text)
    )
    for index, marker in enumerate(markers):
        stop = markers[index + 1].start() if index + 1 < len(markers) else len(text)
        geometry = next(
            (
                i
                for i in range(len(geometries) - 1, -1, -1)
                if geometries[i]["offset"] < marker.start()
            ),
            None,
        )
        force = next(
            (i for i, row in enumerate(forces) if marker.end() < row["offset"] < stop),
            None,
        )
        summary = re.search(
            r"Cartesian Forces:\s+Max\s+(" + NUMBER + r")\s+RMS\s+(" + NUMBER + r")",
            text[marker.end() : stop],
        )
        evaluations.append(
            {
                # Zero-based character position within the linked Gaussian job.
                "offset": marker.start(),
                # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                "line": _line(text, marker.start()),
                # Electronic energy in hartree.
                "energy": _number(marker[2]),
                # Zero-based geometry-record reference; None when no prior orientation exists.
                "geometry": geometry,
                # Zero-based reference into the force records, or None if no force table follows.
                "forces": force,
                # Maximum Cartesian force magnitude in hartree/bohr.
                "force_maximum": _number(summary[1]) if summary else None,
                # RMS Cartesian force in hartree/bohr.
                "force_rms": _number(summary[2]) if summary else None,
            }
        )
    return evaluations


def _optimization(text, evaluations):
    """Read native optimization records without assuming convergence.

    Args:
        text: Native text of one linked job.
        evaluations: Its energy evaluations.

    Returns:
        One record per optimization step, with its convergence checks.
    """
    optimization = []
    markers = list(
        re.finditer(
            r"^\s*Step number\s+(\d+) out of a maximum of\s+(\d+)(?: on scan point\s+(\d+) out of\s+(\d+))?",
            text,
            re.MULTILINE,
        )
    )
    for index, marker in enumerate(markers):
        stop = markers[index + 1].start() if index + 1 < len(markers) else len(text)
        section = text[marker.end() : stop]
        checks = [
            {
                # Native convergence criterion normalized to lowercase words.
                "criterion": " ".join(name.lower().split()),
                # Printed convergence or internal-coordinate value, in its native units.
                "value": _number(value),
                # Native convergence limit; force uses hartree/bohr, displacement bohr or radians.
                "threshold": _number(threshold),
                # Native YES/NO convergence result, not a recomputed tolerance.
                "passed": passed == "YES",
            }
            for name, value, threshold, passed in re.findall(
                r"^\s*(Maximum Force|RMS\s+Force|Maximum Displacement|RMS\s+Displacement)\s+("
                + NUMBER
                + r")\s+("
                + NUMBER
                + r")\s+(YES|NO)",
                section,
                re.MULTILINE,
            )
        ]
        evaluation = next(
            (
                i
                for i in range(len(evaluations) - 1, -1, -1)
                if evaluations[i]["offset"] < marker.start()
            ),
            None,
        )
        optimization.append(
            {
                # Native iteration number; Gaussian starts at one, Lotus at zero.
                "iteration": int(marker[1]),
                # Printed maximum optimization iterations for this segment.
                "limit": int(marker[2]),
                # Printed scan-target index, or None outside a relaxed scan.
                "scan_point": int(marker[3]) if marker[3] else None,
                # Printed total scan targets, or None outside a relaxed scan.
                "scan_count": int(marker[4]) if marker[4] else None,
                # Zero-based reference into evaluations; None when no prior SCF evaluation exists.
                "evaluation": evaluation,
                # Native force and displacement convergence tests for this iteration.
                "checks": checks,
                # Hessian eigenvalues Berny printed for this step in redundant internal coordinates, in native order.
                "eigenvalues": [
                    _number(value)
                    for line in re.findall(r"^\s*Eigenvalues ---(.*)$", section, re.MULTILINE)
                    for value in re.findall(NUMBER, line)
                ],
                # Whether Gaussian printed optimization completion for this iteration.
                "completed": "Optimization completed" in section,
                # Whether Gaussian printed Optimization stopped for this iteration.
                "stopped": "Optimization stopped" in section,
            }
        )
    return optimization


def _scan(text, optimization, evaluations):
    """Read native scan records without assuming convergence.

    Args:
        text: Native text of one linked job.
        optimization: Its optimization steps.
        evaluations: Its energy evaluations.

    Returns:
        One record per scan point.
    """
    scan = []
    for match in re.finditer(r"Optimization (completed|stopped)", text):
        prior = next(
            (
                row
                for row in reversed(optimization)
                if row["evaluation"] is not None
                and evaluations[row["evaluation"]]["offset"] < match.start()
            ),
            None,
        )
        if prior is None or prior["scan_point"] is None:
            continue
        following = text[match.end() :]
        end = re.search(r"(?:Leave Link|GradGradGrad|SCF Done:)", following)
        parameters = [
            {
                # Native internal-coordinate or GIC label.
                "name": name,
                # Printed internal-coordinate or GIC definition; units follow that definition.
                "definition": definition.strip(),
                # Printed convergence or internal-coordinate value, in its native units.
                "value": _number(value),
            }
            for name, definition, value in re.findall(
                r"^[ \t]*![ \t]+([A-Za-z][\w-]*)[ \t]+(.+?)[ \t]+("
                + NUMBER
                + r")[ \t]+(?:-DE/DX|Frozen|Scan)",
                following[: end.start()] if end else following,
                re.MULTILINE,
            )
        ]
        scan.append(
            {
                # Native IRC or relaxed-scan point index, not a zero-based reference.
                "point": prior["scan_point"],
                # Zero-based reference into evaluations; None when no prior SCF evaluation exists.
                "evaluation": prior["evaluation"],
                # Whether this scan target printed Optimization completed rather than stopped.
                "converged": match[1] == "completed",
                # Printed optimized internal-coordinate/GIC values at this scan target.
                "parameters": parameters,
            }
        )
    return scan


def _internal_coordinates(text):
    """Read the internal coordinates of Gaussian's first parameter table, which lists them as the job starts.

    Args:
        text: Native text of one linked job.

    Returns:
        One record per printed coordinate; empty when the job prints no parameter table.
    """
    table = re.search(
        r"Initial Parameters\s*!?\s*\n.*?!\s*Name\s+Definition\s+Value\s+Derivative Info\.\s*!\s*\n\s*-+\s*\n(.*?)\n\s*-{20,}",
        text,
        re.DOTALL,
    )
    if not table:
        return []
    rows = []
    for line in table[1].splitlines():
        match = re.match(r"^\s*!\s+(\S+)\s+(.+?)\s+(" + NUMBER + r")\s+(.*?)\s*!?\s*$", line)
        if match:
            rows.append(
                {
                    # Native coordinate label: the user's label for a GIC line, else Gaussian's, such as R1 or A3.
                    "name": match[1],
                    # Printed definition, such as R(1,2), or GIC-n for a formula whose definition is not printed.
                    "definition": match[2].strip(),
                    # Value at the start in the table's units, angstrom and degree for plain coordinates; a formula's
                    # GIC-n value is in arbitrary units.
                    "value": _number(match[3]),
                    # Whether the derivative column says the coordinate is frozen.
                    "frozen": "frozen" in match[4].lower(),
                    # Whether the derivative column marks the coordinate as the scanned one.
                    "scan": match[4].strip().lower().startswith("scan"),
                    # Derivative column as printed, possibly cut at the table's edge.
                    "derivative": match[4].strip(),
                }
            )
    return rows


def _gic_counts(text):
    """Read the counts Gaussian prints when it initializes the GIC definitions.

    Args:
        text: Native text of one linked job.

    Returns:
        The counts of initial, input, added, removed, frozen and final coordinates, and whether the job says
        its GIC-type coordinates are in arbitrary units; None when the job prints no such block.
    """
    block = re.search(r"Initializing the GIC definitions file\.(.*?)ITRead=", text, re.DOTALL)
    if not block:
        return None
    count = lambda label: next(iter(int(value) for value in re.findall(label + r"\s*=\s*(\d+)", block[1])), None)
    return {
        # Coordinates read from the checkpoint file before the input's changes.
        "initial": count("Number of initial coordinates"),
        # Lines of the GIC input section.
        "entries": count(r"Number of input entries/lines"),
        # Coordinates the input added.
        "added": count("Number of additional coordinates"),
        # Coordinates the input removed.
        "removed": count("Number of removed coordinates"),
        # Coordinates held frozen.
        "frozen": count("Number of frozen coordinates"),
        # Active and frozen coordinates after the changes.
        "final": count("Number of final active and frozen coordinates"),
        # Whether Gaussian notes that GIC-type coordinates are in arbitrary units.
        "arbitrary_units": "GIC-type coordinates are in arbitrary units" in text,
    }


def _irc(text, evaluations):
    """Read native IRC records without assuming convergence.

    Args:
        text: Native text of one linked job.
        evaluations: Its energy evaluations.

    Returns:
        The IRC points, summary, reference and direction completion.
    """
    irc = []
    points = list(re.finditer(r"Point Number:\s*(\d+)\s+Path Number:\s*(\d+)", text))
    for index, marker in enumerate(points):
        stop = points[index + 1].start() if index + 1 < len(points) else len(text)
        section = text[marker.end() : stop]
        current = re.search(
            r"CURRENT STRUCTURE\s+Cartesian Coordinates \(Ang\):.*?\n\s*-+\n.*?\n.*?\n\s*-+\n(.*?)\n\s*-+",
            section,
            re.DOTALL,
        )
        if current is None:
            continue
        rows = [line.split() for line in current[1].splitlines()]
        coordinate = re.search(
            r"NET REACTION COORDINATE UP TO THIS POINT\s*=\s*(" + NUMBER + r")", section
        )
        directions = re.findall(
            r"Point Number\s+\d+ in (FORWARD|REVERSE) path direction",
            text[: marker.start()],
        )
        evaluation = next(
            (
                i
                for i in range(len(evaluations) - 1, -1, -1)
                if evaluations[i]["offset"] < marker.start()
            ),
            None,
        )
        irc.append(
            {
                # Native IRC or relaxed-scan point index, not a zero-based reference.
                "point": int(marker[1]),
                # Native IRC path number; direction is retained separately.
                "path": int(marker[2]),
                # Explicit native forward/reverse IRC direction, or None when unavailable.
                "direction": directions[-1].lower() if directions else None,
                # Native IRC coordinate; retain the printed sign and mass-weighting convention.
                "coordinate": _number(coordinate[1]) if coordinate else None,
                # Zero-based reference into evaluations; None when no prior SCF evaluation exists.
                "evaluation": evaluation,
                # One-based center indices in native table order.
                "centers": [int(row[0]) for row in rows],
                # Atomic numbers in the printed center order.
                "atomic_numbers": [int(row[1]) for row in rows],
                # Accepted IRC Cartesian coordinates in angstrom, center order, x/y/z.
                "coordinates": [list(map(_number, row[-3:])) for row in rows],
            }
        )
    summary = []
    start = text.rfind("Summary of reaction path following")
    if start >= 0:
        table = re.search(
            r"Energy\s+Rx\s*Coord[^\n]*\n((?:[ \t]*\d+[ \t]+"
            + NUMBER
            + r"[ \t]+"
            + NUMBER
            + r"[^\n]*\n)+)",
            text[start:],
        )
        if table:
            summary = [
                {
                    # Native IRC or relaxed-scan point index, not a zero-based reference.
                    "point": int(i),
                    # Printed IRC energy relative to the TS in hartree.
                    "relative_energy": _number(energy),
                    # Native IRC coordinate; retain the printed sign and mass-weighting convention.
                    "coordinate": _number(coordinate),
                }
                for i, energy, coordinate in re.findall(
                    r"(\d+)\s+(" + NUMBER + r")\s+(" + NUMBER + r")", table[1]
                )
            ]
    reference = re.findall(
        r"Energies reported relative to the TS energy of\s+(" + NUMBER + r")", text
    )
    return {
        # Accepted IRC structures with path identity and SCF-evaluation references.
        "irc_points": irc,
        # Native summary rows containing TS-relative energy and signed coordinate.
        "irc_summary": summary,
        # Printed TS reference energy in hartree for the IRC summary.
        "irc_reference": _number(reference[-1]) if reference else None,
        # Explicit reaction-path completion; does not verify endpoint minima.
        "irc_complete": "Reaction path calculation complete." in text,
        # Explicit completion markers for each IRC direction.
        "irc_directions": {
            # Whether Gaussian explicitly printed forward-path completion.
            "forward": "Calculation of FORWARD path complete." in text,
            # Whether Gaussian explicitly printed reverse-path completion.
            "reverse": "Calculation of REVERSE path complete." in text,
        },
    }


def _cartesian(text):
    """Read geometries and Cartesian force tables with their native frames.

    Args:
        text: Native text of one linked job.

    Returns:
        The geometry tables and the force tables.
    """
    geometries = _tables(text, r"(Input|Standard|Z-Matrix) orientation:")
    forces = []
    # Force tables have one header rule rather than the orientation table's two.
    for match in re.finditer(
        r"Center\s+Atomic\s+Forces \(Hartrees/Bohr\)[^\n]*\n[^\n]*\n\s*-+\n(.*?)\n\s*-+",
        text,
        re.DOTALL,
    ):
        rows = [line.split() for line in match[1].splitlines()]
        forces.append(
            {
                # Zero-based character position within the linked Gaussian job.
                "offset": match.start(),
                # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                "line": _line(text, match.start()),
                # Native coordinate frame; Cartesian forces use input orientation.
                "frame": "input",
                # One-based center indices in native table order.
                "centers": [int(row[0]) for row in rows],
                # Atomic numbers in the printed center order.
                "atomic_numbers": [int(row[1]) for row in rows],
                # Cartesian x/y/z rows: angstrom for geometries, hartree/bohr for forces.
                "vectors": [list(map(_number, row[-3:])) for row in rows],
            }
        )
    return (geometries, forces)


def _route(block):
    """Read the first route section of a linked job.

    Gaussian echoes the route in fixed-width lines after one leading space and wraps them anywhere,
    also inside a keyword, so the lines are concatenated as printed rather than joined with spaces.

    Args:
        block: Native text of one linked job.

    Returns:
        The route text, empty when none is printed.
    """
    lines = block.splitlines()
    route = []
    for index, line in enumerate(lines):
        if line.strip().startswith("#"):
            for item in lines[index:]:
                if item.strip().startswith("---"):
                    break
                route.append(item.removeprefix(" "))
            break
    return " ".join("".join(route).split())


def _scf(block):
    """Read SCF evaluations and explicit failure evidence even after normal termination.

    Args:
        block: Native text of one linked job.

    Returns:
        The SCF history and the explicit errors.
    """
    records = []
    previous = 0
    nuclear_repulsion = None
    pattern = r"SCF Done:\s+E\(([^)]+)\)\s*=\s*(" + NUMBER + r").*?after\s+(\d+) cycles"
    markers = list(re.finditer(pattern, block))
    for index, match in enumerate(markers):
        history = block[previous : match.start()]
        stop = markers[index + 1].start() if index + 1 < len(markers) else len(block)
        summary = block[match.end() : stop]
        repulsions = re.findall(r"nuclear repulsion energy\s+(" + NUMBER + r")", history)
        if repulsions:
            nuclear_repulsion = _number(repulsions[-1])
        components = re.search(
            r"^[ \t]*KE=\s*(" + NUMBER + r")\s+PE=\s*(" + NUMBER + r")\s+EE=\s*(" + NUMBER + r")",
            summary,
            re.MULTILINE,
        )
        virial = re.search(r"-V/T\s*=\s*(" + NUMBER + r")", summary)
        samples = []
        for density in re.finditer(
            r"RMSDP=\s*(" + NUMBER + r")\s+MaxDP=\s*(" + NUMBER + r")([^\n]*)", history
        ):
            cycles = re.findall(r"Cycle\s+(\d+)\s+Pass", history[: density.start()])
            change = re.search(r"\bDE=\s*(" + NUMBER + r")", density[3])
            samples.append(
                {
                    # Native SCF cycle number when printed; otherwise None.
                    "iteration": int(cycles[-1]) if cycles else None,
                    # One-based source line within the linked Gaussian job.
                    "line": _line(block, previous + density.start()),
                    # RMS density change; dimensionless.
                    "density_rms": _number(density[1]),
                    # Maximum density change; dimensionless.
                    "density_maximum": _number(density[2]),
                    # Printed electronic energy change in hartree, if present.
                    "energy_change": _number(change[1]) if change else None,
                }
            )
        rms_limit = re.findall(
            r"Requested convergence on RMS density matrix\s*=\s*(" + NUMBER + r")",
            history,
        )
        maximum_limit = re.findall(
            r"Requested convergence on MAX density matrix\s*=\s*(" + NUMBER + r")",
            history,
        )
        energy_limit = re.findall(
            r"Requested convergence on\s+energy\s*=\s*(" + NUMBER + r")", history
        )
        last = samples[-1] if samples else None
        density_passed = (
            (
                last["density_rms"] <= _number(rms_limit[-1])
                and last["density_maximum"] <= _number(maximum_limit[-1])
            )
            if last and rms_limit and maximum_limit
            else None
        )
        failures = [
            line.strip()
            for line in history.splitlines()
            if re.search(
                r"Convergence criterion not met|Convergence failure|SCF (?:has )?not converged",
                line,
                re.IGNORECASE,
            )
        ]
        records.append(
            {
                # Native SCF method label.
                "method": match[1],
                # Electronic SCF energy in hartree; may be unconverged when flagged below.
                "energy": _number(match[2]),
                # Printed orbital kinetic energy KE in hartree; Kohn-Sham kinetic energy for DFT.
                "kinetic_energy": _number(components[1]) if components else None,
                # Printed one-electron potential term PE in hartree, not total potential energy.
                "nuclear_attraction": _number(components[2]) if components else None,
                # Printed EE term in hartree; includes exchange and, for DFT, correlation.
                "electron_interaction": _number(components[3]) if components else None,
                # Nuclear repulsion in hartree from the geometry preceding this SCF, never the next one.
                "nuclear_repulsion": nuclear_repulsion,
                # Gaussian's printed dimensionless -V/T ratio for this SCF solution.
                "virial_ratio": _number(virial[1]) if virial else None,
                # SCF cycle count reported by Gaussian, retained without reinterpretation.
                "cycles": int(match[3]),
                # Final RMS density change, dimensionless, or None when not printed.
                "density_rms": last["density_rms"] if last else None,
                # Final maximum density change, dimensionless, or None when not printed.
                "density_maximum": last["density_maximum"] if last else None,
                # Native requested RMS density threshold, dimensionless.
                "rms_threshold": _number(rms_limit[-1]) if rms_limit else None,
                # Native requested maximum density threshold, dimensionless.
                "maximum_threshold": _number(maximum_limit[-1])
                if maximum_limit
                else None,
                # Native requested electronic energy threshold in hartree.
                "energy_threshold": _number(energy_limit[-1]) if energy_limit else None,
                # Recomputed comparison against both printed density thresholds, or None.
                "density_passed": density_passed,
                # SCF Done without explicit failure and without known failed density criteria.
                "converged": not failures and density_passed is not False,
                # Explicit native messages that invalidate a printed SCF Done candidate.
                "failures": failures,
                # Per-cycle residuals and energy changes in output order.
                "cycle_history": samples,
            }
        )
        previous = match.end()
    return records


def _checks(block):
    """Read native convergence values and their printed pass flags.

    Args:
        block: Native text of one linked job.

    Returns:
        One record per printed criterion with its value, threshold and flag.
    """
    convergence = [
        {
            # Native convergence criterion normalized to lowercase words.
            "criterion": " ".join(name.lower().split()),
            # Printed convergence or internal-coordinate value, in its native units.
            "value": _number(value),
            # Native convergence limit; force uses hartree/bohr, displacement bohr or radians.
            "threshold": _number(threshold),
            # Native YES/NO convergence result, not a recomputed tolerance.
            "passed": passed == "YES",
        }
        for name, value, threshold, passed in re.findall(
            r"^\s*(Maximum Force|RMS\s+Force|Maximum Displacement|RMS\s+Displacement)"
            r"\s+(" + NUMBER + r")\s+(" + NUMBER + r")\s+(YES|NO)",
            block,
            re.MULTILINE,
        )
    ]
    return convergence


def _populations(block, evaluations, geometries):
    """Keep SCF and transition-density populations in distinct records.

    Args:
        block: Native text of one linked job.
        evaluations: The job's energy and force evaluations, each with its character ``offset`` in the block.
        geometries: The job's printed geometries, each with its character ``offset`` in the block, which tie a
            population analysis to the geometry it belongs to.

    Returns:
        One record per population analysis, with the density it describes.
    """
    populations = []
    evaluation_offsets = [entry["offset"] for entry in evaluations]
    geometry_offsets = [entry["offset"] for entry in geometries]
    population_markers = list(
        re.finditer(r"Population analysis using (.*?)\.\s*$", block, re.MULTILINE)
    )
    for index, match in enumerate(population_markers):
        stop = (
            population_markers[index + 1].start()
            if index + 1 < len(population_markers)
            else len(block)
        )
        # Do not attach a later SCF's properties to an earlier analysis when its output is incomplete.
        next_evaluation = bisect_left(evaluation_offsets, match.end())
        if next_evaluation < len(evaluations):
            stop = min(stop, evaluation_offsets[next_evaluation])
        section = block[match.end() : stop]
        evaluation = next_evaluation - 1 if next_evaluation else None
        geometry = evaluations[evaluation]["geometry"] if evaluation is not None else None
        # A new orientation since the SCF makes the association ambiguous.
        if evaluation is not None and bisect_left(geometry_offsets, match.start()) > bisect_left(
            geometry_offsets, evaluations[evaluation]["offset"]
        ):
            geometry = None
        dipole = re.search(
            r"Dipole moment[^\n]*\n\s*X=\s*("
            + NUMBER
            + r")\s+Y=\s*("
            + NUMBER
            + r")\s+Z=\s*("
            + NUMBER
            + r")\s+Tot=\s*("
            + NUMBER
            + r")",
            section,
        )
        charge_table = re.search(
            r"^\s*Mulliken charges:\s*\n\s*1\s*\n((?:\s*\d+\s+[A-Za-z]+\s+"
            + NUMBER
            + r"\s*\n)+)",
            section,
            re.MULTILINE,
        )
        charges = (
            []
            if not charge_table
            else [
                {
                    # One-based native atom index.
                    "atom": int(a),
                    # Chemical element symbol as printed.
                    "element": element,
                    # Mulliken atomic charge in elementary-charge units.
                    "charge": _number(value),
                }
                for a, element, value in re.findall(
                    r"(\d+)\s+([A-Za-z]+)\s+(" + NUMBER + r")", charge_table[1]
                )
            ]
        )
        quadrupole = re.search(
            r"^\s*Quadrupole moment[^\n]*\n([^\n]+\n[^\n]+)", section, re.MULTILINE
        )
        moments = (
            {}
            if quadrupole is None
            else {
                key.lower(): _number(value)
                for key, value in re.findall(
                    r"([XYZ]{2})=\s*(" + NUMBER + r")", quadrupole[1]
                )
            }
        )
        populations.append(
            {
                # One-based line of the population analysis in this linked job.
                "line": _line(block, match.start()),
                # Zero-based reference to the preceding SCF evaluation, when available.
                "evaluation": evaluation,
                # Zero-based reference to its geometry, when the association is unambiguous.
                "geometry": geometry,
                # Population context, distinguishing SCF and transition densities.
                "density": match[1],
                # Population dipole x/y/z and total in debye.
                "dipole": list(map(_number, dipole.groups())) if dipole else None,
                # Printed xx/yy/zz/xy/xz/yz components in debye angstrom.
                "quadrupole": moments,  # Debye angstrom.
                # Atom-indexed Mulliken charges; model-dependent populations.
                "mulliken_charges": charges,
                # Native charge schemes, retaining hydrogen-summed and full tables separately.
                "charge_analyses": _charge_analyses(section),
                # Higher molecular moments in native debye/angstrom conventions.
                "multipoles": _multipoles(section),
            }
        )
    return populations


def _thermochemistry(block):
    """Read thermal corrections and native partition contributions.

    Args:
        block: Native text of one linked job.

    Returns:
        The thermochemistry summary and its partition contributions.
    """
    thermo = {}
    # Every correction and summed thermochemical energy below is in hartree.
    for label, key in [
        # Harmonic zero-point vibrational correction.
        ("Zero-point correction", "zero_point"),
        # Finite-temperature internal-energy correction, including zero point.
        ("Thermal correction to Energy", "thermal_energy"),
        # Finite-temperature enthalpy correction.
        ("Thermal correction to Enthalpy", "thermal_enthalpy"),
        # Finite-temperature Gibbs free-energy correction.
        ("Thermal correction to Gibbs Free Energy", "thermal_gibbs"),
        # Electronic plus zero-point energy.
        ("Sum of electronic and zero-point Energies", "energy_zero_point"),
        # Electronic plus thermal internal energy.
        ("Sum of electronic and thermal Energies", "energy_thermal"),
        # Electronic plus thermal enthalpy.
        ("Sum of electronic and thermal Enthalpies", "enthalpy"),
        # Electronic plus thermal Gibbs free energy.
        ("Sum of electronic and thermal Free Energies", "gibbs"),
    ]:
        values = re.findall(re.escape(label) + r"=\s*(" + NUMBER + r")", block)
        if values:
            thermo[key] = _number(values[-1])
    conditions = re.search(
        r"Temperature\s+(" + NUMBER + r") Kelvin\.\s+Pressure\s+(" + NUMBER + r") Atm",
        block,
    )
    if conditions:
        thermo.update(
            # Ideal-gas analysis temperature in kelvin.
            temperature=_number(conditions[1]),
            # Ideal-gas analysis pressure in atmospheres.
            pressure=_number(conditions[2]),
        )
    symmetry = re.findall(r"Rotational symmetry number\s+(\d+)", block)
    if symmetry:
        # Rotational symmetry number used in the native entropy calculation.
        thermo["symmetry_number"] = int(symmetry[-1])
    components = []
    thermal_table = re.search(
        r"E \(Thermal\)\s+CV\s+S\n[^\n]+\n(.*?)\n\s+Q\s+Log10", block, re.DOTALL
    )
    if thermal_table:
        for name, energy, heat, entropy in re.findall(
            r"^\s*([A-Za-z]+(?:\s+\d+)?)\s+("
            + NUMBER
            + r")\s+("
            + NUMBER
            + r")\s+("
            + NUMBER
            + r")\s*$",
            thermal_table[1],
            re.MULTILINE,
        ):
            components.append(
                {
                    # Native thermochemical contribution, such as rotational or vibrational.
                    "component": " ".join(name.lower().split()),
                    # Thermal energy contribution in kcal/mol.
                    "energy": _number(energy),
                    # Native constant-volume heat capacity in cal/(mol K).
                    "heat_capacity": _number(heat),
                    # Native thermochemical entropy in cal/(mol K).
                    "entropy": _number(entropy),
                }
            )
    return (thermo, components)


def _links(block):
    """Gaussian's links of one linked job in execution order: Link 0, then each executable link as it finished.

    Link 0 holds the commands echoed before the route. Every other link is one of Gaussian's executables, such
    as l101 or l502; the log records each when it leaves, with its time, memory limit and timing. A link left
    several times, such as l502 during an optimization, appears once per exit.

    Args:
        block: Native text of one linked job.

    Returns:
        One record per link, each with its ``index`` and its details.
    """
    links = [
        {
            # Gaussian's link number; Link 0 reads the commands before the route.
            "index": 0,
            # Literal Link 0 commands by name, in their native units and spelling. Commands without a value,
            # such as %Save, map to an empty string, and %KJob keeps its space-separated arguments.
            "commands": {
                name: value.strip()
                for name, value in re.findall(
                    r"^[ \t]*(%[A-Za-z0-9]+)(?:[ \t]*=[ \t]*|[ \t]+|(?=[ \t]*$))(.*)$",
                    block.split("\n #", 1)[0],
                    re.MULTILINE,
                )
            },
        }
    ]
    # Only Link 1 prints its executable and process when it starts.
    entering = {
        int(match[1]): (match[2], int(match[3]))
        for match in re.finditer(r"Entering Link\s+(\d+)\s*=\s*(\S+)\s+PID=\s*(\d+)", block)
    }
    for match in re.finditer(
        r"^ Leave Link\s+(\d+) at (.+?), MaxMem=\s*(\d+)\s+cpu:\s*(" + NUMBER + r")\s+elap:\s*(" + NUMBER + r")",
        block,
        re.MULTILINE,
    ):
        index = int(match[1])
        program, process = entering.get(index, (None, None))
        links.append(
            {
                # Gaussian's link number, such as 101 for the input reader or 502 for the SCF.
                "index": index,
                # One-based line of the exit record within the linked job.
                "line": _line(block, match.start()),
                # Executable path, printed only for Link 1.
                "program": program,
                # Process ID, printed only for Link 1.
                "process": process,
                # Local time the link finished, as printed.
                "finished": match[2].strip(),
                # Memory limit in 8-byte words.
                "memory_limit": int(match[3]),
                # CPU time spent in the link, in seconds.
                "cpu_time": _number(match[4]),
                # Elapsed time spent in the link, in seconds.
                "wall_time": _number(match[5]),
            }
        )
    return links


def _metadata(block, route):
    """Read job settings, basis diagnostics and termination markers.

    Args:
        block: Native text of one linked job.
        route: The job's route text.

    Returns:
        The job's settings, counts, request and termination fields.
    """
    basis = re.findall(r"NBasis=\s*(\d+)", block)
    independent = re.findall(r"NBsUse=\s*(\d+)", block)
    electrons = re.findall(r"(\d+) alpha electrons\s+(\d+) beta electrons", block)
    methods = re.findall(r"SCF Done:\s+E\(([^)]+)\)", block)
    closed_shell = None
    if electrons:
        if electrons[-1][0] != electrons[-1][1]:
            closed_shell = False
        elif methods:
            method = methods[-1].upper()
            if method.startswith("RO"):
                closed_shell = False
            elif method.startswith("R"):
                closed_shell = True
    core = re.findall(r"NFC=\s*(\d+)", block)
    overlap = re.findall(r"EigKep=\s*(" + NUMBER + r")", block)
    coefficients = re.findall(
        r"largest alpha MO coefficient is\s+(" + NUMBER + r")", block, re.IGNORECASE
    )
    rotation = re.findall(r"Rotational constants \(GHZ\):([^\n]+)", block)
    repulsion = re.findall(r"nuclear repulsion energy\s+(" + NUMBER + r")", block)
    exchange = re.findall(r"ScaHFX=\s*(" + NUMBER + r")", block)
    charge = re.findall(r"Charge\s*=\s*(-?\d+)\s+Multiplicity\s*=\s*(\d+)", block)
    atoms = re.findall(r"NAtoms=\s*(\d+)", block)
    versions = re.findall(r"Gaussian\s+\d+:\s*([^\n]+)", block)
    cpus = re.findall(r"Will use up to\s+(\d+) processors", block)
    point_groups = re.findall(r"Full point group\s+(\S+)", block)
    masses = re.findall(r"Molecular mass:\s*(" + NUMBER + r")", block)
    atomic_masses = []
    for marker in re.finditer(r"AtmWgt=([^\n]*)", block):
        values = [_number(v) for v in re.findall(NUMBER, marker[1])]
        for line in block[marker.end() :].splitlines()[1:]:
            words = line.split()
            if not words or not all(re.fullmatch(NUMBER, w) for w in words):
                break
            values.extend(_number(v) for v in words)
        atomic_masses = values
    timing = {}
    for label, key in [("Job cpu time", "cpu_time"), ("Elapsed time", "wall_time")]:
        records = re.findall(
            re.escape(label)
            + r":\s*(\d+) days\s*(\d+) hours\s*(\d+) minutes\s*("
            + NUMBER
            + r") seconds",
            block,
        )
        if records:
            days, hours, minutes, seconds = records[-1]
            # Native accumulated CPU and elapsed wall time are both reported in seconds.
            timing[key] = (
                86400 * int(days)
                + 3600 * int(hours)
                + 60 * int(minutes)
                + _number(seconds)
            )
    lines = block.splitlines()
    patterns = [
        ("irc_error_termination", r"Error termination via Lnk1e in .*?l123\.exe"),
        ("termination", r"Error termination"),
        ("convergence_criterion", r"Convergence criterion not met"),
        ("convergence_failure", r"Convergence failure"),
        ("optimization_stopped", r"Optimization stopped"),
        ("optimization_steps_exceeded", r"Number of steps exceeded"),
        ("expected_numeric_input", r"Wanted (?:a floating point|an integer)"),
        ("unexpected_input_value", r"WANTED A .+ AS INPUT|Found a string as input"),
        ("file_write", r"Erroneous write"),
        ("constraints", r"Error imposing constraints"),
        ("internal_coordinate_formbx", r"FormBX had a problem"),
        ("route_syntax", r"QPErr --- A syntax error"),
        ("electron_multiplicity", r"The combination of multiplicity .+ electrons is impossible"),
        ("unsupported_basis_atom", r"Atomic number out of range for .+ basis set"),
        ("missing_file", r"FileIO operation on non-existent file"),
        ("internal_coordinate_system", r"Error in internal coordinate system"),
        ("linear_angle", r"Linear angle in (?:Bend|Tors)"),
        ("input_eof", r"End of file in (?:ZSymb|GetChg)"),
        ("basis_eof", r"End of file reading basis center|EOF while reading ECP pointer card"),
        ("charge_multiplicity_input", r"Charge and multiplicity card seems defective"),
        ("unknown_atom", r"Unrecognized atomic symbol"),
        ("distance_matrix", r"Problem with the distance matrix"),
        ("atoms_too_close", r"Atoms too close"),
        ("insufficient_memory", r"Not enough memory to run at all|galloc:\s+could not allocate memory"),
        ("diagonalization", r"diagonalization failure|Diagonalization in DiagDN via DSPEV failed"),
        ("pcm_matrix_inverse", r"Inv3 failed in PCMMkU"),
        ("irc_corrector_steps", r"Max(?:imum number of)? corrector steps ex(?:c|s)e{1,2}ded"),
        ("irc_optimization", r"GS2 Optimization Failure"),
        ("orbital_gap", r"Fatal Problem: The smallest alpha delta epsilon"),
        ("occupied_orbital_projection", r"Unable to project read-in occupied orbitals"),
        ("blas_lapack_arguments", r"Bad arguments to LAPack or BLAS routine"),
        ("internal_consistency_getijb", r"Internal consistency failure #\d+ in GetIJB"),
        ("scf_not_converged", r"SCF (?:has )?not converged"),
        ("input_parser_type", r"Illegal IType or MSType generated by parse"),
        ("input_zmatrix_symbol", r"Symbol .+ not found in Z-matrix|Unknown center \d+"),
        ("input_optimization_variables", r"FOPT requested but NVar="),
        ("memory_allocation", r"Out-of-memory error|malloc failed|needs more words of memory|words are not enough for AIAXAO"),
        ("file_range", r"Operation on file out of range"),
        ("quadrature", r"Inaccurate quadrature in CalDSu"),
        ("unavailable_third_derivatives", r"No func 3rd derivs with"),
        ("biorthogonal_vectors", r"Unable to match L and R vectors in BiOrth"),
        ("scratch_open", r"Logic error in SftOpn"),
        ("solvent_epsilon_infinity", r"EpsInf not defined for this solvent"),
        ("input_molecular_specification", r"Input Error\s+Input Error"),
        ("dispersion_parameters", r"R6DS8: Unable to choose the S8 parameter|R6DRCv: No RCov radius available|R6DC6: No C6 coefficient available"),
        ("solvent_cavity_atoms", r"No solvent atoms in DisRep"),
        ("solvent_vdw_radius", r"GetVDW:\s+no radius for atom"),
        ("internal_variable_count", r"NRF ne Abs NRFX"),
        ("curvilinear_step", r"New curvilinear step not converged"),
        ("internal_variables_initialization", r"ERROR IN INITNF"),
        ("orbital_localisation", r"Excessive mixing of (?:frozen )?core and valence orbitals"),
        ("hessian_storage", r"GetHes: LRWHes > LHess"),
        ("correlation_cycles", r"\*?MAX\. CYCLES\*?"),
        ("temp_input_file", r"Can't create file Temp input file"),
        ("deleted_input_file", r"Internal input file was deleted"),
        ("file_open", r"Cannot open (?:new )?file|open-new-file"),
        ("file_g_write", r"g_write"),
        ("nuclear_coordinate_error", r"NtrErr Called from|Error termination in NtrErr"),
        ("segmentation_fault", r"[Ss]egmentation (?:violation|fault)"),
        ("illegal_instruction", r"[Ii]llegal (?:instruction|opcode)"),
        ("windows_severe_error", r"Severe Error Message #\s*2070"),
        ("mmcore_bounds", r"NIJ > Max2 in MMCore"),
        ("transition_orthogonality", r"Tx not orthogonal to T"),
        ("wrong_negative_eigenvalues", r"Wrong number of Negative eigenvalues"),
        ("no_atoms", r"There are no atoms in this input structure"),
        ("bad_file", r"Bad file opened by FileIO"),
        ("garbage_pointers", r"RdWrB1 read garbage pointers"),
    ]

    def diagnostic(index, code):
        """Retain a native line without Gaussian's leading bullet, its position and its diagnostic code.

        Args:
            index: Zero-based index of the line in the linked job.
            code: Stable identifier of the message, or of the unclassified context.

        Returns:
            Mapping with the 'code', the one-based 'line' and the 'message' with repeated spaces collapsed.
        """
        text = re.sub(r"^[-–—]{1,2}\s+", "", lines[index].strip())
        return {
            # Stable identifier of the native message or unclassified context.
            "code": code,
            # One-based position in the linked job.
            "line": index + 1,
            # Native text without its leading bullet, with repeated spaces collapsed.
            "message": re.sub(r"\s{2,}", " ", text),
        }

    errors = []
    context = []
    error_lines = set()
    for index, line in enumerate(lines):
        code = next((name for name, pattern in patterns if re.search(pattern, line, re.IGNORECASE)), None)
        if code:
            errors.append(diagnostic(index, f"gaussian.error.{code}"))
            error_lines.add(index + 1)
        if re.search(r"Error termination", line, re.IGNORECASE):
            for position in range(max(0, index - 6), index):
                text = lines[position].strip()
                if text and not re.fullmatch(r"[-*= ]+", text):
                    context.append(diagnostic(position, "gaussian.error.termination_context"))

    # Gaussian restates one failure on adjacent lines; keep the most specific message.
    if any(error["message"].startswith("Number of steps exceeded") for error in errors):
        errors = [error for error in errors if not error["code"].endswith("optimization_stopped")]
    # An error termination is the consequence of a specific failure, not a second cause.
    if any(not error["code"].endswith("termination") for error in errors):
        errors = [error for error in errors if not error["code"].endswith("termination")]
    # Context repeats across overlapping windows and must not restate an error.
    context = list({entry["line"]: entry for entry in context if entry["line"] not in error_lines}.values())
    return {
        # Native Gaussian release/platform identification, when printed.
        "version": versions[-1].strip() if versions else None,
        # Printed shared-memory processor allocation, not an assumed scheduler request.
        "processors": int(cpus[-1]) if cpus else None,
        # Gaussian's links in execution order: Link 0's commands, then each executable link as it finished.
        "links": _links(block),
        # Printed point-group label; it is not a claim that constraints were removed.
        "point_group": point_groups[-1] if point_groups else None,
        # Native molecular mass in atomic mass units.
        "molecular_mass": _number(masses[-1]) if masses else None,
        # Native atom masses in atomic mass units, preserving isotope order.
        "atomic_masses": atomic_masses,
        # Accumulated native CPU and elapsed wall-time fields, in seconds.
        "timing": timing,
        # Explicit scientific or execution failure messages, including unconverged SCF.
        "errors": errors,
        # Unclassified text preceding a native error termination, preserved as context.
        "error_context": context,
        # Molecular integer charge in elementary-charge units.
        "charge": int(charge[-1][0]) if charge else None,
        # Printed spin multiplicity, 2S+1.
        "multiplicity": int(charge[-1][1]) if charge else None,
        # Printed number of atoms, or None when unavailable.
        "atom_count": int(atoms[-1]) if atoms else None,
        # Job types, their options and the excited state this linked job requests; not certification of a result.
        "request": request(route),
        # First printed route section for this linked job, rejoined at Gaussian's line wraps.
        "route": route,
        # Whether this linked job printed normal termination; not physical validation.
        "normal_termination": "Normal termination of Gaussian" in block,
        # Whether this linked job printed an error termination.
        "error_termination": "Error termination" in block,
        # Native scientific warnings retained without dismissing them.
        "warnings": _warnings(block),
        # Stable diagnostic code for each native warning, in the same order.
        "warning_codes": [_warning_code(text) for text in _warnings(block)],
        # Number of AO basis functions in this record.
        "basis_count": int(basis[-1]) if basis else None,
        # Printed number of linearly independent basis functions used.
        "independent_count": int(independent[-1]) if independent else None,
        # Printed alpha and beta electron counts, respectively.
        "electron_counts": list(map(int, electrons[-1])) if electrons else None,
        # Restricted doubly occupied reference or known open shell; equal-spin unrestricted cases stay unknown.
        "closed_shell": closed_shell,
        # Smallest retained AO-overlap eigenvalue; dimensionless.
        "overlap_minimum": _number(overlap[-1]) if overlap else None,
        # Largest alpha MO coefficient reported in a warning; dimensionless.
        "coefficient_maximum": _number(coefficients[-1]) if coefficients else None,
        # Printed number of frozen core orbitals in the TD treatment.
        "frozen_core": int(core[-1]) if core else None,
        # Applied HF exchange fraction; dimensionless.
        "exact_exchange": _number(exchange[-1]) if exchange else None,
        # Printed rotational constants in gigahertz; unresolved tokens remain None.
        "rotational_constants": [
            _number(value) if re.fullmatch(NUMBER, value) else None
            for value in rotation[-1].split()
        ]
        if rotation
        else [],
        # Printed nuclear repulsion energy in hartree.
        "nuclear_repulsion": _number(repulsion[-1]) if repulsion else None,
        # Whether any optimization-completion marker occurs in this linked job.
        "optimization_complete": "Optimization completed" in block,
    }


def _nto_values(block, occupancy):
    """Read only explicitly contextualized NTO weights, excluding canonical energies.

    Args:
        block: Native text of one linked job.
        occupancy: ``occ`` or ``virt``, the eigenvalue lines to read.

    Returns:
        The NTO weights of that occupancy, from the last NTO analysis: a job that repeats the analysis, as at
        every geometry of a TD optimization, prints one set each, and the last belongs to the final geometry.
    """
    values, end = [], None
    for match in re.finditer(
        r"^[ \t]*Alpha[ \t]+" + occupancy + r"\. eigenvalues --([^\n]+)",
        block,
        re.MULTILINE,
    ):
        if _is_nto(block, match.start(), match.end()):
            # Lines of one analysis follow each other directly; anything between them starts a new analysis.
            if end is None or block[end : match.start()].strip():
                values = []
            values.extend(_number(value) for value in re.findall(NUMBER, match[1]))
            end = match.end()
    return values


def _electronic_transitions(block):
    """Read TD roots, transition moments, configurations and NTO weights.

    Args:
        block: Native text of one linked job.

    Returns:
        The excited-state records of the job.
    """
    roots = {}
    for match in re.finditer(r"Root\s+(\d+) (has converged|not converged)", block):
        roots[int(match[1])] = match[2] == "has converged"
    excitations = []
    markers = list(
        re.finditer(
            r"Excited State\s+(\d+):\s+(\S+)\s+("
            + NUMBER
            + r") eV\s+("
            + NUMBER
            + r") nm\s+f=("
            + NUMBER
            + r")\s+<S\*\*2>=("
            + NUMBER
            + r")",
            block,
        )
    )
    for index, match in enumerate(markers):
        stop = (
            markers[index + 1].start()
            if index + 1 < len(markers)
            else block.find("SavETr:", match.end())
        )
        section = block[match.end() : stop if stop >= 0 else len(block)]
        configs = [
            {
                # One-based occupied MO index in a TD contribution.
                "occupied": int(a),
                # One-based virtual MO index in a TD contribution.
                "virtual": int(b),
                # Printed TD excitation/de-excitation arrow; not a reaction-path direction.
                "direction": arrow,
                # Printed TD excitation/de-excitation coefficient; dimensionless, not an NTO weight.
                "amplitude": _number(value),
                # Spin channel of an unrestricted contribution, printed as an A or B suffix on its orbitals: alpha or
                # beta; None for a restricted one.
                "spin": {"A": "alpha", "B": "beta"}.get(spin),
            }
            for a, spin, arrow, b, _, value in re.findall(
                r"^\s*(\d+)([AB]?)\s*(->|<-)\s*(\d+)([AB]?)\s+(" + NUMBER + r")\s*$",
                section,
                re.MULTILINE,
            )
        ]
        excitations.append(
            {
                # One-based excited-state index.
                "state": int(match[1]),
                # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                "line": _line(block, match.start()),
                # Printed state label, such as Singlet-B2U, Triplet-A', Singlet-?Sym or 3.017-A.
                "label": match[2],
                **_state_label(match[2]),
                # Excitation energy in electronvolt.
                "energy": _number(match[3]),
                # TD transition wavelength in nanometres.
                "wavelength": _number(match[4]),
                # Dimensionless TD oscillator strength.
                "oscillator": _number(match[5]),
                # Printed excited-state expectation of S**2; dimensionless.
                "spin_squared": _number(match[6]),
                # Printed occupied-to-virtual TD contributions; not a complete wavefunction.
                "configurations": configs,
            }
        )
    return {
        # Last explicit convergence flag for each one-based TD root.
        "root_convergence": roots,
        # Whether expansion-vector convergence was explicitly printed.
        "td_converged": "Convergence achieved on expansion vectors." in block,
        # TD states in printed order, retaining repeated states during optimization.
        "excitations": excitations,
        # State-specific TD total energies, distinct from ground-state SCF energies.
        "excited_energies": [
            {
                # One-based source line, relative to the linked Gaussian job or entire Lotus file.
                "line": _line(block, match.start()),
                # Electronic energy in hartree.
                "energy": _number(match[1]),
            }
            for match in re.finditer(
                r"Total Energy, E\(TD-HF/TD-DFT\)\s*=\s*(" + NUMBER + r")", block
            )
        ],
        # Length-gauge transition electric dipole components and strengths in atomic units.
        "length_moments": _moments(
            block, "Ground to excited state transition electric dipole moments"
        ),
        # Velocity-gauge transition components and strengths in atomic units.
        "velocity_moments": _moments(
            block, "Ground to excited state transition velocity dipole moments"
        ),
        # Printed transition magnetic dipole components in atomic units.
        "magnetic_moments": _moments(
            block, "Ground to excited state transition magnetic dipole moments"
        ),
        # One-based states whose NTOs were explicitly saved.
        "nto_states": [
            int(n)
            for n in re.findall(r"Saving Alpha spin NTOs for state\s+(\d+)", block)
        ],
        # Printed occupied NTO weights, without truncation or renormalization.
        "nto_holes": _nto_values(block, "occ"),
        # Printed virtual NTO weights, without truncation or renormalization.
        "nto_particles": _nto_values(block, "virt"),
    }


def _archive_value(text):
    """Archive value: a number, a list of numbers, or the text when it is not numeric.

    Args:
        text: One archive field value.

    Returns:
        The decoded value.
    """
    parts = text.split(",")
    try:
        numbers = [int(part) if re.fullmatch(r"[+-]?\d+", part) else float(part) for part in parts]
    except ValueError:
        return text
    return numbers[0] if len(numbers) == 1 else numbers


def _archive(block):
    """Decode the archive entry Gaussian prints when a linked job ends normally.

    The entry is printed in fixed-width lines after one leading space and wrapped anywhere, so the
    lines are concatenated as printed. Fields are separated by a backslash (a vertical bar in some
    builds) and sections by two separators: header, route, title, molecule, then key=value property
    sections.

    Args:
        block: Native text of one linked job.

    Returns:
        The decoded header, route, title, atoms and properties, or None without an entry.
    """
    lines = block.splitlines()
    start = next((index for index, line in enumerate(lines) if re.match(r"^ 1([\\|])1\1", line)), None)
    if start is None:
        return None
    text = ""
    for line in lines[start:]:
        text += line.removeprefix(" ")
        separator = text[1]
        if text.rstrip().endswith(separator + "@"):
            break
    text = text.rstrip()
    separator = text[1]
    sections = text.removesuffix(separator + "@").split(separator * 2)
    header = sections[0].split(separator)
    molecule = sections[3].split(separator)
    charge, multiplicity = (int(value) for value in molecule[0].split(",")[:2])
    atoms = []
    for row in molecule[1:]:
        fields = row.split(",")
        # An optional integer freeze code may precede the coordinates.
        atoms.append([fields[0], *map(float, fields[-3:])])
    atom_count = len(atoms)
    properties, arrays = {}, {}
    for section in sections[4:]:
        if not section:
            continue
        if "=" in section.split(",")[0]:
            # A trailing separator leaves an empty field, which is not a property.
            for field in filter(None, section.split(separator)):
                key, _, value = field.partition("=")
                properties[key] = _archive_value(value)
            continue
        values = _archive_value(section)
        values = values if isinstance(values, list) else [values]
        if len(values) == 3 * atom_count * (3 * atom_count + 1) // 2:
            arrays["force_constants"] = values
        elif len(values) == 3 * atom_count:
            arrays["first_derivatives"] = values
        else:
            arrays.setdefault("unrecognized", []).append(values)
    return {
        # Host on which Gaussian ran, from the GINC field.
        "host": header[2].removeprefix("GINC-"),
        # Job type label, such as SP, FOpt, FTS, Freq or Scan.
        "job_type": header[3],
        # Method label as Gaussian files it, such as RB3LYP or RB3LYP TD-FC.
        "method": header[4],
        # Basis-set label.
        "basis": header[5],
        # Stoichiometry.
        "formula": header[6],
        # User name recorded by Gaussian.
        "user": header[7],
        # Date the job ended, as printed.
        "date": header[8],
        # Route section as archived.
        "route": sections[1],
        # Title section as archived.
        "title": sections[2],
        # Total charge.
        "charge": charge,
        # Spin multiplicity.
        "multiplicity": multiplicity,
        # Final geometry as (symbol, x, y, z) rows in angstrom, in the archived orientation.
        "atoms": atoms,
        # Archived properties, such as Version, State, HF, RMSD, RMSF, Dipole, PG and NImag, by key.
        "properties": properties,
        # Numeric sections: force_constants in hartree/bohr^2 (lower triangle), first_derivatives in
        # hartree/bohr, and any unrecognized sections in printed order.
        "arrays": arrays,
    }


def _parse_gaussian(block):
    """Decode core measurements using one shared geometry/evaluation history.

    Args:
        block: Native text of one linked job.

    Returns:
        The parsed linked job.
    """
    geometries, forces = _cartesian(block)
    evaluations = _evaluations(block, geometries, forces)
    optimization = _optimization(block, evaluations)
    analyses = _vibrations(block)
    modes = [mode for analysis in analyses for mode in analysis]
    thermochemistry, components = _thermochemistry(block)
    return {
        **_metadata(block, _route(block)),
        **_electronic_transitions(block),
        **_irc(block, evaluations),
        # Archive entry printed at normal termination, decoded; None when absent.
        "archive": _archive(block),
        # Native SCF candidates, density residuals and convergence evidence.
        "scf_history": _scf(block),
        # Native geometry records in angstrom, retaining their printed frames.
        "geometries": geometries,
        # Native Cartesian force records in hartree/bohr, input orientation.
        "forces": forces,
        # Shared SCF energy and geometry/force references for this job.
        "evaluations": evaluations,
        # Native Berny steps, excluding IRC corrector steps.
        "optimization_history": optimization,
        # Native force/displacement convergence values, thresholds and pass flags.
        "optimization_checks": _checks(block),
        # Completed or stopped scan targets, with native coordinate values.
        "scan_points": _scan(block, optimization, evaluations),
        # Internal coordinates of the first parameter table, with their start values and frozen or scanned flags.
        "internal_coordinates": _internal_coordinates(block),
        # Counts of the GIC definitions Gaussian initialized, or None when the job builds none.
        "gic_counts": _gic_counts(block),
        # ModRedundant lines Gaussian echoes as it reads the input, as parse_modredundant_section reads them.
        "modredundant_input": modredundant_echo(block),
        # Projected frequencies in inverse centimetres; negative denotes imaginary.
        "frequencies": [mode["frequency"] for mode in modes],
        # Mode reduced masses in atomic mass units.
        "reduced_masses": [mode["reduced_mass"] for mode in modes],
        # Mode force constants in millidyne/angstrom.
        "force_constants": [mode["force_constant"] for mode in modes],
        # Harmonic infrared intensities in kilometre/mole.
        "ir_intensities": [mode["ir_intensity"] for mode in modes],
        # Distinct harmonic analyses with matching high/standard listings merged.
        "frequency_sets": analyses,
        # Density-labelled atomic populations and molecular multipoles.
        "populations": _populations(block, evaluations, geometries),
        # Thermal energies in hartree, with native temperature and pressure.
        "thermochemistry": thermochemistry,
        # Component energy in kcal/mol; heat capacity and entropy in cal/(mol K).
        "thermal_components": components,
    }

"""Scientific checks on parsed Gaussian results, shared by project workflows."""

import math
from pathlib import Path

from .checkpoints import ELEMENTS
from .results import read_gaussian


def finished_jobs(path):
    """Linked jobs of a Gaussian log that terminated normally in every linked step.

    Args:
        path: Gaussian log to read.

    Returns:
        Parsed linked jobs, as returned by :func:`runflow.results.read_gaussian`.

    Raises:
        ValueError: The log is incomplete or a linked job did not terminate normally.
    """
    result = read_gaussian(path)
    jobs = result["jobs"]
    if result["status"]["state"] != "complete" or not jobs or not all(job["normal_termination"] for job in jobs):
        raise ValueError(f"Gaussian prerequisite did not finish successfully: {path}")
    return jobs


def final_geometry(path, *, optimized=True):
    """Final Cartesian geometry of a finished Gaussian log as (symbol, x, y, z) rows in angstrom.

    Args:
        path: Gaussian log to read.
        optimized: Require a converged optimization, so the coordinates are its result.

    Returns:
        One (symbol, x, y, z) row per atom.

    Raises:
        ValueError: The log did not finish, its optimization did not converge, or it prints no orientation.
    """
    jobs = require_optimized(path) if optimized else finished_jobs(path)
    geometry = next((job["geometries"][-1] for job in reversed(jobs) if job["geometries"]), None)
    if geometry is None:
        raise ValueError(f"No Cartesian orientation in {path}")
    return [(ELEMENTS[number - 1], *vector) for number, vector in zip(geometry["atomic_numbers"], geometry["vectors"])]


def require_optimized(path):
    """Require a finished Gaussian log with a converged optimization.

    Args:
        path: Gaussian log to read.

    Returns:
        Its parsed linked jobs.

    Raises:
        ValueError: The log did not finish or no optimization converged.
    """
    jobs = finished_jobs(path)
    if not any(job["optimization_complete"] for job in jobs):
        raise ValueError(f"The prerequisite optimization did not converge: {path}")
    return jobs


def require_saddle(path, atom_count):
    """Require a complete frequency set with exactly one imaginary mode.

    Args:
        path: Gaussian log to read.
        atom_count: Number of atoms, giving the expected 3N-6 modes.

    Returns:
        The harmonic frequencies in inverse centimetres.

    Raises:
        ValueError: The set is incomplete or does not have exactly one imaginary mode.
    """
    values = [value for job in finished_jobs(path) for value in job["frequencies"]]
    if len(values) != 3 * atom_count - 6 or sum(value < 0 for value in values) != 1:
        raise ValueError(f"A first-order saddle with exactly one imaginary mode is required: {path}")
    return values


def mode_bond_changes(job, bonds):
    """Length and stretch of each one-based atom pair in the first imaginary mode of one linked job.

    Args:
        job: Parsed linked job with a harmonic analysis.
        bonds: One-based atom pairs.

    Returns:
        The lengths in angstrom, and for each pair the change of its length along the mode's normalized displacements.
    """
    vectors = job["geometries"][-1]["vectors"]
    mode = next(mode for analysis in job["frequency_sets"] for mode in analysis if mode["frequency"] < 0)
    lengths, stretches = [], []
    for first, second in bonds:
        axis = [a - b for a, b in zip(vectors[first - 1], vectors[second - 1])]
        length = math.hypot(*axis)
        relative = [a - b for a, b in zip(mode["displacements"][first - 1], mode["displacements"][second - 1])]
        lengths.append(length)
        stretches.append(sum(a * b for a, b in zip(axis, relative)) / length)
    return lengths, stretches


def stretches_in_phase(stretches, minimum_stretch):
    """Whether one mode moves every named bond in phase by at least the minimum stretch.

    Args:
        stretches: Signed change of each named bond along the mode.
        minimum_stretch: Smallest absolute change that counts as a stretch, in the unit of ``stretches``.

    Returns:
        True when every change reaches the minimum and all have the same sign.
    """
    return all(abs(value) >= minimum_stretch for value in stretches) and len({value > 0 for value in stretches}) == 1


def require_forming_saddle(path, atom_count, bonds, *, minimum_stretch=0.3):
    """Require a first-order saddle whose imaginary mode stretches every forming bond in phase.

    One imaginary mode alone does not identify a reaction: a soft conformational saddle also has one.

    Args:
        path: Gaussian log to read.
        atom_count: Number of atoms, giving the expected 3N-6 modes.
        bonds: One-based atom pairs of the forming bonds.
        minimum_stretch: Smallest accepted bond change along the normalized mode displacements.

    Returns:
        The harmonic frequencies in inverse centimetres.

    Raises:
        ValueError: The curvature is wrong or the mode does not stretch every forming bond in phase.
    """
    values = require_saddle(path, atom_count)
    _, stretches = mode_bond_changes(next(job for job in finished_jobs(path) if job["frequencies"]), bonds)
    if not stretches_in_phase(stretches, minimum_stretch):
        raise ValueError(f"The imaginary mode does not stretch every forming bond in phase: {path}")
    return values


def require_irc(path, *, minima=2):
    """Require both IRC directions to complete and Gaussian to detect ``minima`` path minima.

    Args:
        path: Gaussian log to read.
        minima: Number of minima Gaussian must report detecting, or None to skip that check.

    Returns:
        Its parsed linked jobs.

    Raises:
        ValueError: A direction did not complete or the detected minima differ.
    """
    jobs = finished_jobs(path)
    irc = [job for job in jobs if "irc" in job["request"]["jobs"]]
    if not irc or not all(job["irc_directions"].get(direction) for job in irc for direction in ("forward", "reverse")):
        raise ValueError(f"Both IRC directions have not completed: {path}")
    # Gaussian's native minimum detection is not part of the parsed IRC records.
    if minima is not None and Path(path).read_text().count("PES minimum detected") != minima:
        raise ValueError(f"The IRC branches did not reach {minima} detected minima: {path}")
    return jobs


def irc_endpoint(path, number):
    """Final point of one IRC path as (symbol, x, y, z) rows in angstrom, with its point index.

    Args:
        path: Gaussian log to read.
        number: Gaussian's IRC path number, 1 or 2.

    Returns:
        The point index and one (symbol, x, y, z) row per atom.

    Raises:
        ValueError: The IRC did not complete or the path has no points.
    """
    points = [point for job in require_irc(path, minima=None) for point in job["irc_points"] if point["path"] == number]
    if not points:
        raise ValueError(f"IRC path {number} has no points: {path}")
    point = points[-1]
    return point["point"], [(ELEMENTS[n - 1], *xyz) for n, xyz in zip(point["atomic_numbers"], point["coordinates"])]


def irc_terminus(path, direction):
    """Last accepted point of one IRC direction, from a finished or a stopped path.

    A stopped path still supplies a starting geometry; this establishes neither a completed path nor a minimum.

    Args:
        path: Gaussian log to read.
        direction: ``forward`` or ``reverse``.

    Returns:
        The point index and one (symbol, x, y, z) row per atom.

    Raises:
        ValueError: The direction has no accepted points.
    """
    points = [point for job in read_gaussian(path)["jobs"] for point in job["irc_points"] if point["direction"] == direction]
    if not points:
        raise ValueError(f"The {direction} IRC direction has no points: {path}")
    point = points[-1]
    return point["point"], [(ELEMENTS[n - 1], *xyz) for n, xyz in zip(point["atomic_numbers"], point["coordinates"])]


def require_minimum(path, atom_count, *, excited=False):
    """Require a complete frequency calculation with no imaginary normal modes.

    Args:
        path: Gaussian log to read.
        atom_count: Number of atoms, giving the expected 3N-6 modes.
        excited: Also require the excited-state calculation whose surface was probed.

    Raises:
        ValueError: The set is incomplete, has an imaginary mode, or lacks the excited-state calculation.
    """
    jobs = finished_jobs(Path(path))
    values = [value for job in jobs for value in job["frequencies"]]
    if len(values) != 3 * atom_count - 6 or any(value < 0 for value in values):
        raise ValueError("A complete minimum with no imaginary modes is required")
    if excited and not any(job["excitations"] for job in jobs):
        raise ValueError("The prerequisite does not contain an excited-state calculation")


def require_stable(jobs):
    """Require every stability test in the linked jobs to conclude that the wavefunction is stable.

    Args:
        jobs: Parsed linked jobs.

    Raises:
        ValueError: No stability test was found or one found an instability.
    """
    conclusions = [entry for job in jobs for entry in job["stability"]]
    if not conclusions or not all(entry["stable"] for entry in conclusions):
        raise ValueError(
            "The SCF wavefunction is not confirmed stable: " + "; ".join(entry["message"] for entry in conclusions)
        )


def ground_state(job):
    """Final SCF energy and frontier orbital energies of one linked job, all in hartree.

    Args:
        job: One parsed linked job.

    Returns:
        The total energy, HOMO and LUMO energies and the orbital gap; the gap is not an optical excitation.
    """
    orbitals = job["orbital_data"]["orbitals"][-1]
    homo, lumo = max(orbitals["occupied"]), min(orbitals["virtual"])
    return {
        # Final SCF electronic energy in hartree.
        "total_energy": job["scf_history"][-1]["energy"],
        # Highest occupied orbital energy in hartree.
        "homo": homo,
        # Lowest virtual orbital energy in hartree.
        "lumo": lumo,
        # LUMO minus HOMO in hartree; an orbital gap, not an optical excitation.
        "orbital_gap": lumo - homo,
    }

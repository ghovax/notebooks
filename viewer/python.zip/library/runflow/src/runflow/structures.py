"""Read files that are not program output: Gaussian inputs, and MDL SDF and Molfile records."""
import re
from datetime import datetime
from pathlib import Path

import numpy as np

from .checkpoints import ELEMENTS
from .parsers.route import request, route_keywords
from .results import ureg


def _atoms_v2000(lines, counts):
    """Element symbols and coordinates of a V2000 atom block, from its counts line."""
    atoms = int(counts[0:3])
    rows = lines[:atoms]
    symbols = [row[31:34].strip() for row in rows]
    coordinates = [[float(row[0:10]), float(row[10:20]), float(row[20:30])] for row in rows]
    return symbols, coordinates, int(counts[3:6])


def _atoms_v3000(lines):
    """Element symbols and coordinates of a V3000 atom block, and its bond count."""
    symbols, coordinates, bonds, block = [], [], 0, None
    for line in lines:
        if not line.startswith("M  V30 "):
            continue
        fields = line[7:].split()
        if fields[:2] == ["BEGIN", "ATOM"] or fields[:2] == ["BEGIN", "BOND"]:
            block = fields[1]
        elif fields[:1] == ["END"]:
            block = None
        elif fields[:1] == ["COUNTS"]:
            bonds = int(fields[2])
        elif block == "ATOM":
            symbols.append(fields[1])
            coordinates.append([float(value) for value in fields[2:5]])
    return symbols, coordinates, bonds


def read_sdf(path):
    """Every record of an SDF or Molfile: its title, atomic numbers, coordinates and SD data fields.

    Args:
        path: SDF file, records separated by ``$$$$``, or a single Molfile.

    Returns:
        One mapping per record with ``title``, ``program`` (the program that wrote it, from the header), ``written``
        (the date and time the header states, without a time zone, or None), ``dimensions``
        (``2D`` or ``3D`` when the header states them, else empty), ``comment``, ``numbers`` (atomic numbers),
        ``coordinates`` (Pint array of atoms by three Cartesian components in angstrom), ``bonds`` (count from the
        connection table) and ``properties`` (SD data fields by name, as text, lines kept).

    Raises:
        ValueError: A record has no counts line, or an element symbol is unknown.
    """
    text = Path(path).read_text(errors="replace").replace("\r\n", "\n")
    records = []
    for block in text.split("$$$$"):
        lines = block.strip("\n").split("\n")
        if len(lines) < 4 or not block.strip():
            continue
        counts = lines[3]
        if "V3000" in counts:
            symbols, coordinates, bonds = _atoms_v3000(lines[4:])
        elif "V2000" in counts or counts[:6].strip():
            symbols, coordinates, bonds = _atoms_v2000(lines[4:], counts)
        else:
            raise ValueError(f"{path}: a record has no counts line")
        lookup = {symbol.casefold(): number for number, symbol in enumerate(ELEMENTS, 1)}
        try:
            numbers = [lookup[symbol.casefold()] for symbol in symbols]
        except KeyError as error:
            raise ValueError(f"{path}: unknown element {error.args[0]}") from None
        # SD data fields follow the connection table: a "> <name>" line, then values up to a blank line.
        properties, name = {}, None
        end = next((index for index, line in enumerate(lines) if line.startswith("M  END")), len(lines))
        for line in lines[end + 1:]:
            if line.startswith(">"):
                start = line.find("<")
                name = line[start + 1:line.find(">", start)] if start >= 0 else line[1:].strip()
                properties[name] = ""
            elif name is not None and line.strip():
                properties[name] = (properties[name] + "\n" + line).strip()
            elif not line.strip():
                name = None
        # The header's second line: user initials, the program name in columns 3 to 10 (OEChem pads it with
        # dashes), the date and time as MMDDYYHHmm in columns 11 to 20 and the dimensional code in columns 21 and 22.
        header = lines[1]
        try:
            written = datetime.strptime(header[10:20], "%m%d%y%H%M")
        except ValueError:
            written = None
        records.append(dict(title=lines[0].strip(), program=header[2:10].strip(" -"), written=written,
                            dimensions=header[20:22] if header[20:22] in ("2D", "3D") else "",
                            comment=lines[2].strip(), numbers=np.array(numbers),
                            coordinates=ureg.Quantity(np.array(coordinates, dtype=float).reshape(-1, 3), "angstrom"),
                            bonds=bonds, properties=properties))
    return records


def atom_values(text, atoms):
    """One value per atom from an SD data field written as a count line, then one ``atom value`` line per listed
    atom, as PubChem writes partial charges; atoms not listed get zero.

    Args:
        text: The field's text.
        atoms: Number of atoms in the record.

    Returns:
        Array of the values by atom, or None when the field is not written that way.
    """
    lines = [line.split() for line in text.strip().splitlines()]
    if len(lines) < 2 or len(lines[0]) != 1 or not lines[0][0].isdigit() or int(lines[0][0]) != len(lines) - 1:
        return None
    values = np.zeros(atoms)
    try:
        for atom, value in lines[1:]:
            values[int(atom) - 1] = float(value)
    except (ValueError, IndexError):
        return None
    return values


def read_gaussian_input(path):
    """Every linked job of a Gaussian input, shaped like the jobs runflow reads from a log where the input defines them.

    Args:
        path: Gaussian input (``.gjf`` or ``.com``), jobs separated by ``--Link1--``.

    Returns:
        One mapping per job with ``links`` (the Link 0 commands as the first link's ``commands``), ``route`` (its
        lines joined), ``request`` (the parsed route), ``archive`` (a mapping holding the ``title``, or None),
        ``charge`` and ``multiplicity`` (None when read from the checkpoint), ``geometries`` (one mapping of
        ``atomic_numbers`` and Cartesian ``vectors`` in angstrom, or none for a checkpoint geometry or a Z-matrix)
        and ``timing`` (None, as nothing has run).
    """
    lookup = {symbol.casefold(): number for number, symbol in enumerate(ELEMENTS, 1)}
    number = lambda value: re.fullmatch(r"[-+]?(\d+\.?\d*|\.\d+)([DdEe][-+]?\d+)?", value)
    jobs = []
    text = Path(path).read_text(errors="replace").replace("\r\n", "\n")
    for section in re.split(r"(?im)^\s*--link1--\s*$", text):
        lines, index, commands = section.split("\n"), 0, {}
        while index < len(lines) and (not lines[index].strip() or lines[index].lstrip().startswith("%")):
            if lines[index].strip():
                key, _, value = lines[index].strip().partition("=")
                commands[key.strip()] = value.strip()
            index += 1
        if index >= len(lines) or not lines[index].lstrip().startswith("#"):
            continue
        route = []
        while index < len(lines) and lines[index].strip():
            route.append(lines[index].strip())
            index += 1
        route = " ".join(route)
        geometry = {name.lower(): options.lower() for name, options in route_keywords(route)}.get("geom", "")
        title, charge, multiplicity, numbers, vectors = "", None, None, [], []
        if "allcheck" not in geometry:
            # The title section, then the charge and multiplicity line and the atoms, each after a blank line.
            index += 1
            heading = []
            while index < len(lines) and lines[index].strip():
                heading.append(lines[index].strip())
                index += 1
            title = " ".join(heading)
            index += 1
            if index < len(lines) and lines[index].strip():
                fields = lines[index].replace(",", " ").split()
                charge, multiplicity = int(fields[0]), int(fields[1])
                index += 1
                while "check" not in geometry and index < len(lines) and lines[index].strip():
                    fields = lines[index].replace(",", " ").split()
                    symbol = re.match(r"[A-Za-z]+|\d+", fields[0])
                    element = symbol and (int(symbol[0]) if symbol[0].isdigit() else lookup.get(symbol[0].casefold()))
                    # Cartesian rows only, with an optional freeze flag; a Z-matrix is left for Gaussian to convert.
                    if not element or len(fields) not in (4, 5) or not all(number(value) for value in fields[-3:]):
                        numbers, vectors = [], []
                        break
                    numbers.append(element)
                    vectors.append([float(re.sub("[Dd]", "e", value)) for value in fields[-3:]])
                    index += 1
        first_link = {
            # Link 0 commands by name, with their values as written.
            "commands": commands,
        }
        specification = {
            # Atomic numbers of the Cartesian molecule specification, in input order.
            "atomic_numbers": numbers,
            # Cartesian coordinates in angstrom, one row per atom.
            "vectors": vectors,
        }
        archive = {
            # The input's title section, joined into one line as Gaussian archives it.
            "title": title,
        } if title else None
        jobs.append(dict(links=[first_link], route=route, request=request(route),
                         archive=archive, charge=charge, multiplicity=multiplicity,
                         geometries=[specification] if numbers else [], timing=None))
    return jobs

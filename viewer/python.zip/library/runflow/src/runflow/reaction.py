"""The atoms of a reaction, found from its geometries rather than from their order in the input.

Bonds come from ASE's covalent cutoffs as a networkx graph. The fragments are the molecules at the reactant end, and
the bonds that differ between the two ends are the ones forming or breaking. Every pair of atoms of two fragments then
has one role, whatever the reaction. An optional RDKit reaction template only names things: conventional atom names
such as C1, the order of the fragments and the roles' display names.
"""

from dataclasses import dataclass, field
from itertools import combinations

import numpy as np

# Roles of a pair of atoms of two fragments: a forming bond, two reacting atoms that do not bond, a non-reacting heavy
# atom with no non-reacting hydrogen, and a non-reacting hydrogen.
ROLES = ("forming", "reacting", "spectator", "hydrogen")


def bond_graph(numbers, coordinates, tolerance=0.4):
    """The covalent bonds of a geometry as a graph of zero-based atoms.

    Two atoms are bonded within ``tolerance`` of the sum of their covalent radii, ASE's natural cutoffs, as in common
    connectivity rules; a margin rather than a factor holds for short radii too, as F2's 1.42 angstrom bond against
    radii of 0.57, while bonds still forming at a saddle are not bonded.

    Args:
        numbers: Atomic numbers.
        coordinates: Positions in angstrom, one row per atom.
        tolerance: Margin in angstrom beyond the sum of the covalent radii.

    Returns:
        A networkx graph with one node per atom and one edge per bond.
    """
    import networkx as nx
    from ase import Atoms
    from ase.neighborlist import build_neighbor_list, natural_cutoffs

    molecule = Atoms(numbers=np.asarray(numbers, dtype=int), positions=np.asarray(coordinates, dtype=float))
    # Each atom's cutoff is its covalent radius plus half the margin, so a pair's is the sum of radii plus the margin.
    cutoffs = [radius + tolerance / 2 for radius in natural_cutoffs(molecule)]
    neighbors = build_neighbor_list(molecule, cutoffs=cutoffs, skin=0.0, self_interaction=False, bothways=True)
    graph = nx.from_scipy_sparse_array(neighbors.get_connectivity_matrix(sparse=True))
    graph.add_nodes_from(range(len(molecule)))
    return graph


def fragments(graph):
    """The connected fragments of a bond graph, each as its sorted atoms, in the order of their first atom.

    Args:
        graph: A graph of ``bond_graph``.

    Returns:
        A list of lists of zero-based atoms.
    """
    import networkx as nx

    return sorted((sorted(component) for component in nx.connected_components(graph)), key=lambda atoms: atoms[0])


def hill_formula(numbers, atoms=None):
    """The formula of some atoms in the Hill system, as Chemical Abstracts writes it and molmass makes it: with carbon,
    carbon, then hydrogen, then the other elements alphabetically; without carbon, every element alphabetically,
    hydrogen included, so HF is written FH.

    Args:
        numbers: Atomic numbers of the whole structure.
        atoms: Zero-based atoms, by default all.

    Returns:
        The formula, such as C4H6, written for mhchem's ``\\ce``.
    """
    from collections import Counter

    from ase.data import chemical_symbols
    from molmass import Formula

    chosen = range(len(numbers)) if atoms is None else atoms
    counts = Counter(chemical_symbols[int(numbers[atom])] for atom in chosen)
    return Formula("".join(f"{symbol}{count}" for symbol, count in counts.items())).formula


@dataclass(frozen=True)
class Template:
    """A reaction template that names a reaction's atoms and roles; it never decides them.

    Attributes:
        smarts: A reaction SMARTS whose mapped atoms are named by element and map number, such as C1; the bonds its
            product side adds between mapped atoms must be bonds the geometries form.
        roles: Display names of the pair roles of ``ROLES``, such as "Primary carbons" for the forming pairs.
    """

    smarts: str
    roles: dict = field(default_factory=dict)


# The parent Diels-Alder reaction: diene carbons 1 to 4, dienophile carbons 5 and 6, forming the bonds 1-6 and 4-5.
DIELS_ALDER = Template("[C:1]=[C:2]-[C:3]=[C:4].[C:5]=[C:6]>>[C:1]1-[C:2]=[C:3]-[C:4]-[C:5]-[C:6]-1", roles={
    # The pairs that become the new sigma bonds, C1-C6 and C4-C5.
    "forming": "Primary carbons",
    # The diene's end carbons with the dienophile carbon they do not bond to.
    "reacting": "Terminal carbons",
    # The diene's inner carbons, C2 and C3, with a dienophile carbon.
    "spectator": "Secondary carbons",
    # Every pair with a hydrogen.
    "hydrogen": "Hydrogens"})


@dataclass(frozen=True)
class Reaction:
    """The atoms of a reaction: its fragments, the bonds that change and the names of its atoms and roles.

    Attributes:
        numbers: Atomic numbers.
        fragments: The molecules at the reactant end, each as its sorted zero-based atoms.
        forming: Bonds present at the product end and not at the reactant end, as sorted pairs of zero-based atoms.
        breaking: Bonds present at the reactant end and not at the product end.
        names: The name of each atom: its template name, such as C1, or its element and one-based input number.
        role_names: Display names of the roles a template gives; empty without one.
    """

    numbers: np.ndarray
    fragments: list
    forming: list
    breaking: list
    names: dict
    role_names: dict

    @property
    def reacting(self):
        """The atoms of the bonds that form or break.

        Returns:
            A set of zero-based atoms.
        """
        return {atom for pair in self.forming + self.breaking for atom in pair}

    def formula(self, fragment):
        """The Hill formula of a fragment, such as C4H6.

        Args:
            fragment: The fragment's position in ``fragments``.

        Returns:
            The formula, written for mhchem's ``\\ce``.
        """
        return hill_formula(self.numbers, self.fragments[fragment])

    def role(self, first, second):
        """The role of a pair of atoms of two fragments: ``forming``, ``reacting``, ``spectator`` or ``hydrogen``.

        Args:
            first: A zero-based atom.
            second: A zero-based atom of another fragment.

        Returns:
            The first that applies: a forming bond; two reacting atoms; a pair with a non-reacting hydrogen; otherwise a
            pair with a non-reacting heavy atom.
        """
        reacting = self.reacting
        if tuple(sorted((first, second))) in self.forming:
            return "forming"
        if first in reacting and second in reacting:
            return "reacting"
        hydrogen = any(atom not in reacting and self.numbers[atom] == 1 for atom in (first, second))
        return "hydrogen" if hydrogen else "spectator"

    def pair_groups(self, first, second):
        """The pairs of atoms of two fragments by role, in the fragments' own atom order.

        Args:
            first: Position of one fragment in ``fragments``.
            second: Position of the other.

        Returns:
            A mapping of every role of ``ROLES`` to its pairs ``(a, b)``, ``a`` the position of an atom in the first
            fragment and ``b`` in the second; each pair of the two fragments is in exactly one role.
        """
        groups = {role: [] for role in ROLES}
        for a, atom in enumerate(self.fragments[first]):
            for b, other in enumerate(self.fragments[second]):
                groups[self.role(atom, other)].append((a, b))
        return groups

    def role_name(self, role, default):
        """The display name of a role.

        Args:
            role: One of ``ROLES``.
            default: The name to use when the template gives none.

        Returns:
            The template's name of the role, or ``default``.
        """
        return self.role_names.get(role, default)

    def bond_name(self, pair):
        """A bond as mhchem writes it, from the names of its atoms.

        Args:
            pair: Two zero-based atoms.

        Returns:
            The bond, such as C1-C6.
        """
        return "-".join(self.names[atom] for atom in pair)


def _changes(start, end):
    """The bonds of one bond graph that another lacks.

    Args:
        start: The graph the bonds are missing from.
        end: The graph that has them.

    Returns:
        The bonds of ``end`` not in ``start``, as sorted pairs of zero-based atoms.
    """
    return sorted(tuple(sorted(edge)) for edge in end.edges if not start.has_edge(*edge))


def reaction(numbers, reactant, product, *, tolerance=0.4, template=None, charge=0):
    """The atoms of a reaction from the geometries at the two ends of its path.

    The bonds the product end has and the reactant end lacks are forming, and those it lacks are breaking; which end
    is which is the caller's to say, since no count of fragments decides it for every reaction. A template, matched on the reactant end with RDKit, names the atoms and roles and orders the fragments
    by their lowest mapped atom; its match must form exactly the template's new bonds.

    Args:
        numbers: Atomic numbers.
        reactant: The reactant end's positions in angstrom.
        product: The product end's positions in angstrom.
        tolerance: Margin in angstrom beyond the sum of covalent radii within which two atoms are bonded.
        template: A ``Template`` that names the atoms and roles, or None for element names and input numbers.
        charge: Total charge, for RDKit's bond orders when a template is matched.

    Returns:
        The ``Reaction``.

    Raises:
        ValueError: If no bond changes between the ends, or the template does not match the reactant end with its new
            bonds among those formed.
    """
    from ase.data import chemical_symbols

    numbers = np.asarray(numbers, dtype=int)
    start, end = bond_graph(numbers, reactant, tolerance), bond_graph(numbers, product, tolerance)
    forming, breaking = _changes(start, end), _changes(end, start)
    if not forming and not breaking:
        raise ValueError("No bond changes between the two ends of the path.")
    parts = fragments(start)
    names = {atom: f"{chemical_symbols[number]}{atom + 1}" for atom, number in enumerate(numbers)}
    roles = {}
    if template is not None:
        mapped = _match(numbers, reactant, template, forming, charge)
        names.update({atom: f"{chemical_symbols[numbers[atom]]}{number}" for number, atom in mapped.items()})
        rank = {atom: number for number, atom in mapped.items()}
        parts.sort(key=lambda atoms: min((rank[atom] for atom in atoms if atom in rank), default=np.inf))
        roles = dict(template.roles)
    return Reaction(numbers, parts, forming, breaking, names, roles)


def _match(numbers, reactant, template, forming, charge):
    """The template's map numbers on the reactant's atoms, from the RDKit match whose new bonds are all forming.

    Args:
        numbers: Atomic numbers.
        reactant: The reactant end's positions in angstrom.
        template: The ``Template``.
        forming: The forming bonds found from the geometries.
        charge: Total charge, for RDKit's bond orders.

    Returns:
        A mapping of each map number to a zero-based atom.

    Raises:
        ValueError: If no match of the reactant side forms exactly bonds among those found.
    """
    from rdkit import Chem
    from rdkit.Chem import rdChemReactions, rdDetermineBonds

    block = f"{len(numbers)}\n\n" + "\n".join(
        f"{Chem.GetPeriodicTable().GetElementSymbol(int(z))} {x:.6f} {y:.6f} {w:.6f}" for z, (x, y, w) in zip(numbers, reactant))
    molecule = Chem.MolFromXYZBlock(block)
    rdDetermineBonds.DetermineBonds(molecule, charge=charge)
    scheme = rdChemReactions.ReactionFromSmarts(template.smarts)
    reactants = Chem.CombineMols(*scheme.GetReactants()) if scheme.GetNumReactantTemplates() > 1 else scheme.GetReactantTemplate(0)
    products = scheme.GetProducts()
    numbers_of = lambda query: {atom.GetIdx(): atom.GetAtomMapNum() for atom in query.GetAtoms() if atom.GetAtomMapNum()}
    before = {tuple(sorted((numbers_of(reactants)[b.GetBeginAtomIdx()], numbers_of(reactants)[b.GetEndAtomIdx()])))
              for b in reactants.GetBonds() if b.GetBeginAtom().GetAtomMapNum() and b.GetEndAtom().GetAtomMapNum()}
    after = {tuple(sorted((numbers_of(product)[b.GetBeginAtomIdx()], numbers_of(product)[b.GetEndAtomIdx()])))
             for product in products for b in product.GetBonds()
             if b.GetBeginAtom().GetAtomMapNum() and b.GetEndAtom().GetAtomMapNum()}
    new = after - before
    found = set(forming)
    for match in molecule.GetSubstructMatches(reactants, uniquify=False):
        mapped = {numbers_of(reactants)[index]: atom for index, atom in enumerate(match) if index in numbers_of(reactants)}
        if {tuple(sorted((mapped[a], mapped[b]))) for a, b in new} <= found:
            return mapped
    raise ValueError("The template does not match the reactant end with its new bonds among the forming ones.")

"""Complete native Gaussian parsing, Lotus histories and retained-array checks."""

import hashlib
import os
import pickle
import re
from functools import lru_cache
from pathlib import Path

import numpy as np

from .checkpoints import (
    GaussianCheckpoint,
    ReactionPath,
    Vibrations,
    read_fchk_records,
    read_gaussian_checkpoint,
    ureg,
    xyz_frames,
)
from .parsers import _split_jobs
from .parsers.diagnostics import _coverage, _sections, _status
from .parsers.electronic import (
    _parse_basis,
    _parse_energies,
    _parse_orbitals,
    _parse_solvent,
    _parse_stability,
)
from .parsers.gaussian import _parse_gaussian
from .parsers.lotus import read_lotus
from .parsers.population import _parse_bonds
from .parsers.properties import _parse_hessians, _parse_nmr, _parse_response

__all__ = [
    "GaussianCheckpoint",
    "ReactionPath",
    "Vibrations",
    "read_gaussian",
    "read_fchk_records",
    "read_gaussian_checkpoint",
    "read_lotus",
    "ureg",
    "xyz_frames",
]


# Parsed Gaussian logs, reused by content while the parser is unchanged: notebook cells read the same large logs
# several times, and a page build parses them before its pages render.
PARSED = Path.home() / ".cache/research-findings/parsed"


@lru_cache(maxsize=1)
def _parser_digest():
    """Digest of runflow's own source, so a parser change invalidates every cached log."""
    digest = hashlib.sha256()
    for path in sorted(Path(__file__).resolve().parent.rglob("*.py")):
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _parsed_key(text, expected_jobs):
    """Cache name of one parsed log, by its exact text, linked-job expectation and the parser."""
    digest = hashlib.sha256(text.encode())
    digest.update(f"|{expected_jobs}|{_parser_digest()}".encode())
    return digest.hexdigest()


def read_gaussian(path, *, job_id=None, process_id=None, expected_jobs=None):
    """Read the file once and return all supported data, status and coverage per linked job.

    Missing measurements remain None or empty collections. Native output is unchanged. The parse of a log whose
    activity is not being verified is reused from a cache keyed by its exact content and runflow's parser source.

    Args:
        path: Gaussian log.
        job_id: Slurm job ID to verify activity with, or None.
        process_id: Local process ID to verify activity with, or None.
        expected_jobs: Number of linked jobs the input contains, or None.

    Returns:
        ``status``, ``scan`` and ``jobs``; a missing file gives an empty jobs list and a missing or verified
        scheduler status.
    """
    path = Path(path)
    text = path.read_text() if path.is_file() else ""
    if text and not text.endswith(("\n", "\r")) and not re.search(r"(?:Normal|Error) termination", text.splitlines()[-1]):
        text = text.rpartition("\n")[0]
    # A live job is verified against its scheduler or writing process, which a cached parse would freeze; only a
    # parse made without such verification is cached.
    cached = None
    if text and job_id is None and process_id is None:
        cached = PARSED / f"{_parsed_key(text, expected_jobs)}.pickle"
        try:
            return pickle.loads(cached.read_bytes())
        except (OSError, EOFError, pickle.UnpicklingError):
            pass
    blocks = list(_split_jobs(text)) if text else []
    jobs = []
    for block in blocks:
        jobs.append(
            {
                **_parse_gaussian(block),
                **_parse_stability([block])[0],
                **_parse_response([block])[0],
                # Labelled total energies and contributions in hartree.
                "energies": _parse_energies([block])[0],
                # Explicit basis label and GFInput primitive/contraction records.
                "basis": _parse_basis([block])[0],
                # Canonical orbital energies in hartree and printed coefficients.
                "orbital_data": _parse_orbitals([block])[0],
                # PCM parameters and native solvation contributions.
                "solvent": _parse_solvent([block])[0],
                # Native numerical bond indices, never inferred from geometry.
                "bonds": _parse_bonds([block])[0],
                # Printed Cartesian force constants in hartree/bohr squared.
                "hessians": _parse_hessians([block])[0],
                # Atomic NMR shielding tensors in ppm.
                "nmr": _parse_nmr([block])[0],
                # Availability of supported categories for this linked job.
                "coverage": {},
                # Native section headings with job-relative source line positions.
                "sections": [],
            }
        )
    categories = (
        "scf",
        "optimization",
        "vibrations",
        "td",
        "nto",
        "irc",
        "populations",
        "bonds",
        "nmr",
        "response",
        "basis",
        "orbitals",
        "energies",
        "hessians",
        "stability",
        "solvent",
        "thermochemistry",
    )
    for job in jobs:
        job["scan"] = _scan_records(job)
    for category in categories:
        for job, coverage in zip(jobs, _coverage(blocks, jobs, category), strict=True):
            job["coverage"][category] = coverage
    for section in _sections(blocks):
        jobs[section["job"] - 1]["sections"].append(section)
    status = _status(
        path, jobs, job_id=job_id, process_id=process_id, expected_jobs=expected_jobs
    )
    for job, record in zip(jobs, status["jobs"], strict=True):
        job["state"] = record[
            "state"
        ]  # Native completion state, distinct from live activity.
    result = {
        # File-level completion and externally verified activity.
        "status": status,
        # Distinct relaxed-scan targets across all linked jobs, in native order.
        "scan": _distinct_scan_records(jobs),
        # Full supported measurements grouped by native linked job, in output order.
        "jobs": jobs,
    }
    if cached is not None:
        try:
            PARSED.mkdir(parents=True, exist_ok=True)
            # Written beside its final name and moved, so a parallel reader never sees half a file.
            partial = cached.with_suffix(f".{os.getpid()}.part")
            partial.write_bytes(pickle.dumps(result))
            partial.replace(cached)
        except OSError:
            pass  # A read-only cache, as in the browser's memory file system, leaves the parse uncached.
    return result


def _scan_records(job):
    """Normalize distinct relaxed-scan targets from parsed linked jobs.

    Args:
        job: One parsed linked job.

    Returns:
        One record per scan target.
    """
    records = []
    for point in job["scan_points"]:
        if point["evaluation"] is None:
            continue
        evaluation = job["evaluations"][point["evaluation"]]
        if evaluation["geometry"] is None:
            continue
        geometry = job["geometries"][evaluation["geometry"]]
        coordinates = np.asarray(geometry["vectors"])
        duplicate = any(
            np.allclose(record["coordinates"].magnitude, coordinates, atol=1e-8, rtol=0)
            and abs(record["energy"].magnitude - evaluation["energy"]) < 1e-9
            for record in records
        )
        if duplicate:
            continue
        records.append(
            {
                # Native one-based relaxed-scan target number.
                "point": point["point"],
                # Whether Gaussian completed optimization at this target.
                "converged": point["converged"],
                # Native SCF energy in hartree.
                "energy": evaluation["energy"] * ureg.hartree,
                # Full Cartesian gradient norm.
                "force_rms": evaluation["force_rms"] * ureg.hartree / ureg.bohr,
                # Atomic numbers in native center order.
                "atomic_numbers": geometry["atomic_numbers"],
                # Accepted geometry in native center order.
                "coordinates": coordinates * ureg.angstrom,
                # Printed constrained-coordinate definitions and values.
                "parameters": point["parameters"],
            }
        )
    return records


def _distinct_scan_records(jobs):
    """Merge linked scan sections without repeating their shared boundary target.

    Args:
        jobs: Parsed linked jobs.

    Returns:
        The scan records in order.
    """
    records = []
    for job in jobs:
        for record in job["scan"]:
            coordinates = record["coordinates"].to("angstrom").magnitude
            duplicate = any(
                np.allclose(
                    existing["coordinates"].to("angstrom").magnitude,
                    coordinates,
                    atol=1e-8,
                    rtol=0,
                )
                and abs(existing["energy"].to("hartree").magnitude - record["energy"].to("hartree").magnitude) < 1e-9
                for existing in records
            )
            if not duplicate:
                normalized = dict(record)
                # File-level targets are numbered continuously after linked-job merges.
                normalized["point"] = len(records) + 1
                records.append(normalized)
    return records

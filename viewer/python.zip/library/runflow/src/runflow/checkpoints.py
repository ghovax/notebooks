"""Structured readers for Gaussian formatted checkpoints."""

import re
from dataclasses import dataclass
from pathlib import Path
from textwrap import dedent

import numpy as np
from pint import UnitRegistry

ureg = UnitRegistry()


def read_fchk_records(path):
    """Every scalar and array record of a formatted checkpoint, by its native name, without changing the file.

    Args:
        path: Formatted checkpoint (``.fchk``) to read.

    Returns:
        Mapping of each native record name to its scalar or NumPy array value.

    Raises:
        ValueError: A record cannot be read.
    """
    lines = Path(path).read_text().splitlines()
    records, index = {}, 2
    while index < len(lines):
        line = lines[index]
        index += 1
        match = re.match(r"^(.{40})\s+([IRC])\s+(.*)$", line)
        if not match:
            continue
        name, kind, value = match.groups()
        name = name.strip()
        if kind == "C":
            if value.strip().startswith("N="):
                index += (int(value.split("=")[1]) + 4) // 5
            continue
        convert = int if kind == "I" else float
        if value.strip().startswith("N="):
            count = int(value.split("=")[1])
            tokens = []
            while len(tokens) < count and index < len(lines):
                tokens.extend(lines[index].split())
                index += 1
            if len(tokens) != count:
                raise ValueError(f"Invalid checkpoint record {name}.")
            records[name] = np.asarray(
                [convert(token.replace("D", "E")) for token in tokens]
            )
        else:
            records[name] = convert(value.replace("D", "E"))
    return records


# Element symbols by atomic number, from hydrogen.
ELEMENTS = ["H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og"]


def xyz_frames(numbers, geometries):
    """Serialize matching Cartesian geometries in angstrom as native XYZ frames.

    Args:
        numbers: Atomic numbers, one per atom.
        geometries: Pint array of frames by atoms by three Cartesian components, convertible to angstrom.

    Returns:
        XYZ text with one frame per geometry.

    Raises:
        ValueError: An atomic number is invalid, or the geometries are not finite tables matching the atoms.
    """
    if any(int(number) != number or not 1 <= number <= len(ELEMENTS) for number in numbers):
        raise ValueError("XYZ atoms require valid integer atomic numbers.")
    symbols = [ELEMENTS[int(number) - 1] for number in numbers]
    geometries = np.asarray(geometries.to("angstrom").magnitude)
    if (
        geometries.ndim != 3
        or geometries.shape[1:] != (len(numbers), 3)
        or not np.isfinite(geometries).all()
    ):
        raise ValueError("Geometries must contain matching finite Cartesian atom tables.")
    template = dedent("""
        {count}
        Molecular geometry
        {atoms}
        """).lstrip()
    frames = []
    for geometry in geometries:
        atoms = "\n".join(
            f"{symbol} {x:.9f} {y:.9f} {z:.9f}"
            for symbol, (x, y, z) in zip(symbols, geometry, strict=True)
        )
        frames.append(template.format(count=len(numbers), atoms=atoms))
    return frames


@dataclass(frozen=True)
class Vibrations:
    """Cartesian mode directions and harmonic properties in Gaussian's native units.

    Attributes:
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of equilibrium Cartesian coordinates.
        frequencies: Pint array of harmonic frequencies; negative values are imaginary modes.
        masses: Pint array of reduced masses, one per mode.
        constants: Pint array of force constants, one per mode.
        intensities: Pint array of IR intensities, one per mode.
        modes: Array of modes by atoms by three Cartesian displacement components.
    """

    numbers: np.ndarray
    coordinates: object
    frequencies: object
    masses: object
    constants: object
    intensities: object
    modes: np.ndarray

    def trajectory(self, mode, *, amplitude, steps=41):
        """Scale a one-based mode to a requested maximum atomic excursion.

        Args:
            mode: One-based index of the normal mode.
            amplitude: Pint length of the largest atomic displacement.
            steps: Number of frames over one period, at least five.

        Returns:
            XYZ text of the frames, sampling phase rather than physical time.

        Raises:
            ValueError: The mode does not exist, the amplitude is negative or not finite, there are fewer than five
                steps, or the mode has no displacement.
        """
        amplitude = amplitude.to("angstrom")
        if not 1 <= mode <= len(self.frequencies) or not np.isfinite(amplitude.magnitude) or amplitude.magnitude < 0:
            raise ValueError("Specify an available mode and a nonnegative finite amplitude.")
        if steps < 5:
            raise ValueError("A mode trajectory requires at least five frames.")
        direction = self.modes[mode - 1]
        scale = np.linalg.norm(direction, axis=1).max()
        if scale <= 0:
            raise ValueError("The selected normal mode has no displacement.")
        phase = np.linspace(0, 2 * np.pi, steps, endpoint=False)
        geometries = (
            self.coordinates.to("angstrom").magnitude
            + amplitude.magnitude * np.sin(phase)[:, None, None] * direction / scale
        ) * ureg.angstrom
        return xyz_frames(self.numbers, geometries)


@dataclass(frozen=True)
class ReactionPath:
    """Matched geometries, energies and Cartesian gradients ordered along an IRC.

    Attributes:
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of points by atoms by three Cartesian components.
        coordinate: Pint array of the reaction coordinate at each point.
        energies: Pint array of total energies at each point.
        gradients: Pint array of Cartesian gradients at each point.
    """

    numbers: np.ndarray
    coordinates: object
    coordinate: object
    energies: object
    gradients: object

    @property
    def rms(self):
        """Return RMS Cartesian gradients in hartree per bohr.

        Returns:
            Pint array with one RMS gradient per path point.
        """
        return np.sqrt(np.mean(self.gradients.to("hartree/bohr").magnitude ** 2, axis=(1, 2))) * ureg.hartree / ureg.bohr

    @property
    def frames(self):
        """Return the reaction path as an XYZ trajectory in angstrom.

        Returns:
            XYZ text with one frame per path point.
        """
        return xyz_frames(self.numbers, self.coordinates)


@dataclass(frozen=True)
class GaussianCheckpoint:
    """Native geometry with optional harmonic modes and IRC path data.

    Attributes:
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of the current Cartesian coordinates.
        vibrations: Harmonic modes, or None without a frequency result.
        irc: Reaction path, or None without IRC records.
    """

    numbers: np.ndarray
    coordinates: object
    vibrations: Vibrations | None
    irc: ReactionPath | None


def _vibrations(records, numbers, coordinates):
    """Extract harmonic modes when the checkpoint contains a frequency result.

    Args:
        records: Native records from :func:`read_fchk_records`.
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of Cartesian coordinates.

    Returns:
        The :class:`Vibrations`, or None without mode records.

    Raises:
        ValueError: The mode records do not match each other or the atom count.
    """
    if "Vib-Modes" not in records or "Vib-E2" not in records:
        return None
    count = len(numbers)
    modes = records["Vib-Modes"].reshape(-1, count, 3)
    properties = records["Vib-E2"].reshape(-1, len(modes))
    if len(modes) != 3 * count - 6 or not np.isfinite(properties).all():
        raise ValueError("Expected a complete nonlinear-molecule frequency analysis.")
    return Vibrations(
        numbers,
        coordinates,
        properties[0] / ureg.centimeter,
        properties[1] * ureg.amu,
        properties[2] * ureg.millidyne / ureg.angstrom,
        properties[3] * ureg.kilometer / ureg.mole,
        modes,
    )


def _irc(records, numbers):
    """Extract an IRC path when the checkpoint contains matched path records.

    Args:
        records: Native records from :func:`read_fchk_records`.
        numbers: Atomic numbers, one per atom.

    Returns:
        The :class:`ReactionPath`, or None without IRC records.

    Raises:
        ValueError: The path records do not match each other or the atom count.
    """
    prefix = "IRC point       1 "
    required = (
        prefix + "Results for each geome",
        prefix + "Geometries",
        prefix + "Gradient at each geome",
    )
    if not all(name in records for name in required):
        return None
    results = records[required[0]].reshape(-1, 2)
    count = len(numbers)
    coordinates = records[required[1]].reshape(-1, count, 3) * ureg.bohr
    gradients = records[required[2]].reshape(-1, count, 3) * ureg.hartree / ureg.bohr
    if len(coordinates) != len(results) or len(gradients) != len(results):
        raise ValueError("The IRC checkpoint has unmatched result records.")
    order = np.argsort(results[:, 1])
    if not np.isfinite(results).all() or not np.all(np.diff(results[order, 1]) > 0):
        raise ValueError("The IRC coordinate must contain unique finite points.")
    return ReactionPath(
        numbers,
        coordinates[order],
        results[order, 1] * ureg.bohr * ureg.amu**0.5,
        results[order, 0] * ureg.hartree,
        gradients[order],
    )


def read_gaussian_checkpoint(path):
    """Return native coordinates, modes and IRC records from one formatted checkpoint.

    Args:
        path: Formatted checkpoint (``.fchk``) to read.

    Returns:
        The :class:`GaussianCheckpoint`.

    Raises:
        FileNotFoundError: The checkpoint does not exist.
        ValueError: Its records are incomplete or inconsistent.
    """
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Gaussian checkpoint is missing: {path}")
    records = read_fchk_records(path)
    try:
        numbers = np.asarray(records["Atomic numbers"], dtype=int)
        count = int(records["Number of atoms"])
        coordinates = np.asarray(
            records["Current cartesian coordinates"], dtype=float
        ).reshape(count, 3) * ureg.bohr
    except KeyError as error:
        raise ValueError(f"Required checkpoint geometry field is missing: {error.args[0]}") from error
    if len(numbers) != count or not np.isfinite(coordinates).all():
        raise ValueError("Checkpoint atom numbers and Cartesian coordinates do not match.")
    return GaussianCheckpoint(
        numbers=numbers,
        coordinates=coordinates,
        vibrations=_vibrations(records, numbers, coordinates),
        irc=_irc(records, numbers),
    )


# Cartesian exponents of each function of a shell, in Gaussian's formatted-checkpoint order.
_CARTESIAN = {0: [(0, 0, 0)], 1: [(1, 0, 0), (0, 1, 0), (0, 0, 1)],
              -1: [(0, 0, 0), (1, 0, 0), (0, 1, 0), (0, 0, 1)],
              2: [(2, 0, 0), (0, 2, 0), (0, 0, 2), (1, 1, 0), (1, 0, 1), (0, 1, 1)]}


def _double_factorial(n):
    """Odd double factorial (2l-1)!!, with (-1)!! = 1."""
    return float(np.prod(np.arange(n, 0, -2))) if n > 0 else 1.0


def orbital_grid(records, orbital, *, spacing=0.3, margin=5.0, bounds=None, block=24, cutoff=1e-9):
    """One alpha orbital of a formatted checkpoint sampled on a Cartesian grid around the molecule, in bohr.

    Supports s, sp, p and Cartesian d shells, each function normalized on its own as in Gaussian's formatted
    checkpoints. The grid is evaluated in cubic blocks, and a shell is skipped for a block beyond the distance where
    every one of its functions falls below ``cutoff``, so the cost follows the molecule rather than the grid volume.

    Args:
        records: Records from ``read_fchk_records``.
        orbital: Zero-based alpha orbital index.
        spacing: Grid step in bohr.
        margin: Padding around the outermost nuclei in bohr.
        bounds: Lower and upper grid corners in bohr, replacing the nuclei and margin.
        block: Grid points along each edge of an evaluation block.
        cutoff: Basis-function magnitude below which a shell is neglected.

    Returns:
        Grid origin, step vectors (rows) and atom rows ``[Z, Z, x, y, z]``, all in bohr, and the orbital values
        in ``a_0^{-3/2}`` with shape ``(nx, ny, nz)``.

    Raises:
        ValueError: The checkpoint holds a shell type this evaluator does not support.
    """
    types = np.asarray(records["Shell types"], dtype=int)
    unsupported = sorted(set(types) - set(_CARTESIAN))
    if unsupported:
        raise ValueError(f"Unsupported shell types {unsupported}; only s, sp, p and Cartesian d are evaluated.")
    counts = np.asarray(records["Number of primitives per shell"], dtype=int)
    exponents = np.asarray(records["Primitive exponents"], dtype=float)
    contraction = np.asarray(records["Contraction coefficients"], dtype=float)
    p_contraction = np.asarray(records.get("P(S=P) Contraction coefficients", np.zeros_like(contraction)), dtype=float)
    centres = np.asarray(records["Coordinates of each shell"], dtype=float).reshape(-1, 3)
    basis = int(records["Number of basis functions"])
    coefficients = np.asarray(records["Alpha MO coefficients"], dtype=float).reshape(-1, basis)[orbital]
    numbers = np.asarray(records["Atomic numbers"], dtype=int)
    nuclei = np.asarray(records["Current cartesian coordinates"], dtype=float).reshape(-1, 3)
    lower, upper = ((nuclei.min(axis=0) - margin, nuclei.max(axis=0) + margin) if bounds is None
                    else (np.asarray(bounds[0], dtype=float), np.asarray(bounds[1], dtype=float)))
    shape = np.ceil((upper - lower) / spacing).astype(int) + 1
    starts = np.concatenate([[0], np.cumsum(counts)])
    # Per shell: exponents, the primitive weights of each function times its orbital coefficient, the powers of
    # each function and the radius beyond which the shell is negligible.
    shells, function = [], 0
    for shell, kind in enumerate(types):
        alpha = exponents[starts[shell]:starts[shell + 1]]
        total = alpha[:, None] + alpha[None, :]
        functions = []
        for powers in _CARTESIAN[kind]:
            order = sum(powers)
            weights = (p_contraction if kind == -1 and order == 1 else contraction)[starts[shell]:starts[shell + 1]]
            factorials = np.prod([_double_factorial(2 * p - 1) for p in powers])
            norms = (2 * alpha / np.pi) ** 0.75 * (4 * alpha) ** (order / 2) / np.sqrt(factorials)
            # Renormalize the contraction so the contracted function has unit norm.
            overlap = (np.pi / total) ** 1.5 / (2 * total) ** order * factorials
            scale = 1 / np.sqrt(np.sum(np.outer(weights * norms, weights * norms) * overlap))
            if coefficients[function]:
                functions.append((np.asarray(powers), coefficients[function] * scale * weights * norms))
            function += 1
        if functions:
            # A bound on every function of the shell at distance r is sum |w| r^L exp(-alpha_min r^2); grow r until
            # it falls below the cutoff.
            largest = max(np.abs(w).sum() for _, w in functions)
            order = max(int(p.sum()) for p, _ in functions)
            radius = 1.0
            while largest * radius ** order * np.exp(-alpha.min() * radius ** 2) > cutoff:
                radius *= 1.2
            shells.append((centres[shell], alpha, functions, radius))
    if function != basis:
        raise ValueError(f"Shells give {function} functions, but the checkpoint has {basis}.")
    values = np.zeros(tuple(shape))
    axes = [lower[k] + spacing * np.arange(shape[k]) for k in range(3)]
    for i in range(0, shape[0], block):
        for j in range(0, shape[1], block):
            for k in range(0, shape[2], block):
                x, y, z = axes[0][i:i + block], axes[1][j:j + block], axes[2][k:k + block]
                corner_low = np.array([x[0], y[0], z[0]])
                corner_high = np.array([x[-1], y[-1], z[-1]])
                points = np.stack(np.meshgrid(x, y, z, indexing="ij"), axis=-1).reshape(-1, 3)
                result = np.zeros(len(points))
                for centre, alpha, functions, radius in shells:
                    # Distance from the shell centre to the nearest point of the block.
                    gap = np.maximum(0, np.maximum(corner_low - centre, centre - corner_high))
                    if gap @ gap > radius * radius:
                        continue
                    relative = points - centre
                    gaussians = np.exp(-np.outer(np.einsum("ij,ij->i", relative, relative), alpha))
                    for powers, weights in functions:
                        radial = gaussians @ weights
                        if powers.any():
                            radial *= np.prod(relative ** powers, axis=1)
                        result += radial
                values[i:i + block, j:j + block, k:k + block] = result.reshape(len(x), len(y), len(z))
    atoms = np.column_stack([numbers, numbers, nuclei]).astype(float)
    return lower, np.eye(3) * spacing, atoms, values


def density_grid(records, orbitals, weights, *, spacing=0.3, margin=5.0, bounds=None, block=24, cutoff=1e-9):
    """Weighted sums of squared alpha orbitals of a formatted checkpoint on a Cartesian grid, in bohr.

    Each density sum_m w_m psi_m(r)^2 is built from many orbitals at once. In each cubic block every basis function
    is evaluated once, by factoring its Gaussians along the three axes, exp(-a r^2) = exp(-a x^2) exp(-a y^2)
    exp(-a z^2), so exponentials are taken only on the block's edges; every orbital then follows from one matrix
    product. Shells and normalization are as in ``orbital_grid``; a shell is skipped for a block beyond the
    distance where every one of its normalized functions falls below ``cutoff``.

    Args:
        records: Records from ``read_fchk_records``.
        orbitals: Zero-based alpha orbital indices.
        weights: Weight of each orbital's squared amplitude, or one row of weights per density.
        spacing: Grid step in bohr.
        margin: Padding around the outermost nuclei in bohr.
        bounds: Lower and upper grid corners in bohr, replacing the nuclei and margin.
        block: Grid points along each edge of an evaluation block.
        cutoff: Basis-function magnitude below which a shell is neglected.

    Returns:
        Grid origin, step vectors (rows) and atom rows ``[Z, Z, x, y, z]``, all in bohr, and the density in
        ``a_0^{-3}`` with shape ``(nx, ny, nz)``, or one such density per row of ``weights``.

    Raises:
        ValueError: The checkpoint holds a shell type this evaluator does not support.
    """
    types = np.asarray(records["Shell types"], dtype=int)
    unsupported = sorted(set(types) - set(_CARTESIAN))
    if unsupported:
        raise ValueError(f"Unsupported shell types {unsupported}; only s, sp, p and Cartesian d are evaluated.")
    counts = np.asarray(records["Number of primitives per shell"], dtype=int)
    exponents = np.asarray(records["Primitive exponents"], dtype=float)
    contraction = np.asarray(records["Contraction coefficients"], dtype=float)
    p_contraction = np.asarray(records.get("P(S=P) Contraction coefficients", np.zeros_like(contraction)), dtype=float)
    centres = np.asarray(records["Coordinates of each shell"], dtype=float).reshape(-1, 3)
    basis = int(records["Number of basis functions"])
    coefficients = np.asarray(records["Alpha MO coefficients"], dtype=float).reshape(-1, basis)[list(orbitals)].T
    weights = np.asarray(weights, dtype=float)
    single = weights.ndim == 1
    weights = np.atleast_2d(weights)
    numbers = np.asarray(records["Atomic numbers"], dtype=int)
    nuclei = np.asarray(records["Current cartesian coordinates"], dtype=float).reshape(-1, 3)
    lower, upper = ((nuclei.min(axis=0) - margin, nuclei.max(axis=0) + margin) if bounds is None
                    else (np.asarray(bounds[0], dtype=float), np.asarray(bounds[1], dtype=float)))
    shape = np.ceil((upper - lower) / spacing).astype(int) + 1
    starts = np.concatenate([[0], np.cumsum(counts)])
    # Per shell: its centre, exponents, each function's index, powers and normalized primitive weights, and the
    # radius beyond which every function is negligible.
    shells, function = [], 0
    for shell, kind in enumerate(types):
        alpha = exponents[starts[shell]:starts[shell + 1]]
        total = alpha[:, None] + alpha[None, :]
        functions = []
        for powers in _CARTESIAN[kind]:
            order = sum(powers)
            primitive = (p_contraction if kind == -1 and order == 1 else contraction)[starts[shell]:starts[shell + 1]]
            factorials = np.prod([_double_factorial(2 * p - 1) for p in powers])
            norms = (2 * alpha / np.pi) ** 0.75 * (4 * alpha) ** (order / 2) / np.sqrt(factorials)
            overlap = (np.pi / total) ** 1.5 / (2 * total) ** order * factorials
            scale = 1 / np.sqrt(np.sum(np.outer(primitive * norms, primitive * norms) * overlap))
            functions.append((function, tuple(int(p) for p in powers), scale * primitive * norms))
            function += 1
        largest = max(np.abs(w).sum() for _, _, w in functions)
        order = max(sum(p) for _, p, _ in functions)
        radius = 1.0
        while largest * radius ** order * np.exp(-alpha.min() * radius ** 2) > cutoff:
            radius *= 1.2
        shells.append((centres[shell], alpha, functions, radius))
    if function != basis:
        raise ValueError(f"Shells give {function} functions, but the checkpoint has {basis}.")
    values = np.zeros((len(weights), *shape))
    axes = [lower[k] + spacing * np.arange(shape[k]) for k in range(3)]
    for i in range(0, shape[0], block):
        for j in range(0, shape[1], block):
            for k in range(0, shape[2], block):
                edges = (axes[0][i:i + block], axes[1][j:j + block], axes[2][k:k + block])
                size = tuple(len(edge) for edge in edges)
                corner_low = np.array([edge[0] for edge in edges])
                corner_high = np.array([edge[-1] for edge in edges])
                columns, indices = [], []
                for centre, alpha, functions, radius in shells:
                    gap = np.maximum(0, np.maximum(corner_low - centre, centre - corner_high))
                    if gap @ gap > radius * radius:
                        continue
                    # Along each axis: the offsets from the centre and the Gaussian of every primitive.
                    offsets = [edge - centre[d] for d, edge in enumerate(edges)]
                    gaussians = [np.exp(-np.outer(offset ** 2, alpha)) for offset in offsets]
                    for index, powers, primitive in functions:
                        factors = [gaussians[d] * (offsets[d] ** powers[d])[:, None] if powers[d] else gaussians[d]
                                   for d in range(3)]
                        # sum_p w_p X_p(x) Y_p(y) Z_p(z) as a product of an (x, y) plane and the z factors.
                        plane = np.einsum("ip,jp->ijp", factors[0] * primitive, factors[1]).reshape(-1, len(alpha))
                        columns.append((plane @ factors[2].T).ravel())
                        indices.append(index)
                if columns:
                    amplitudes = np.column_stack(columns) @ coefficients[indices]
                    values[:, i:i + block, j:j + block, k:k + block] = (
                        (amplitudes ** 2) @ weights.T).T.reshape(len(weights), *size)
    atoms = np.column_stack([numbers, numbers, nuclei]).astype(float)
    return lower, np.eye(3) * spacing, atoms, values[0] if single else values

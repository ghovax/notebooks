"""Structured readers for Gaussian formatted checkpoints."""

import re
from dataclasses import dataclass
from pathlib import Path
from textwrap import dedent

import numpy as np
from pint import UnitRegistry

ureg = UnitRegistry()


def read_fchk_records(path):
    """Every scalar and array record of a formatted checkpoint, by its native name, without changing the file.

    Args:
        path: Formatted checkpoint (``.fchk``) to read.

    Returns:
        Mapping of each native record name to its scalar or NumPy array value.

    Raises:
        ValueError: A record cannot be read.
    """
    lines = Path(path).read_text().splitlines()
    records, index = {}, 2
    while index < len(lines):
        line = lines[index]
        index += 1
        match = re.match(r"^(.{40})\s+([IRC])\s+(.*)$", line)
        if not match:
            continue
        name, kind, value = match.groups()
        name = name.strip()
        if kind == "C":
            if value.strip().startswith("N="):
                index += (int(value.split("=")[1]) + 4) // 5
            continue
        convert = int if kind == "I" else float
        if value.strip().startswith("N="):
            count = int(value.split("=")[1])
            # Gaussian writes six integers or five reals a line; the block is converted by NumPy in one call.
            rows = -(-count // (6 if kind == "I" else 5))
            text = " ".join(lines[index:index + rows])
            index += rows
            tokens = (text.replace("D", "E") if kind == "R" else text).split()
            if len(tokens) != count:
                raise ValueError(f"Invalid checkpoint record {name}.")
            records[name] = np.array(tokens, dtype=np.int64 if kind == "I" else float)
        else:
            records[name] = convert(value.replace("D", "E"))
    return records


# Element symbols by atomic number, from hydrogen.
ELEMENTS = ["H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Nh", "Fl", "Mc", "Lv", "Ts", "Og"]


def xyz_frames(numbers, geometries):
    """Serialize matching Cartesian geometries in angstrom as native XYZ frames.

    Args:
        numbers: Atomic numbers, one per atom.
        geometries: Pint array of frames by atoms by three Cartesian components, convertible to angstrom.

    Returns:
        XYZ text with one frame per geometry.

    Raises:
        ValueError: An atomic number is invalid, or the geometries are not finite tables matching the atoms.
    """
    if any(int(number) != number or not 1 <= number <= len(ELEMENTS) for number in numbers):
        raise ValueError("XYZ atoms require valid integer atomic numbers.")
    symbols = [ELEMENTS[int(number) - 1] for number in numbers]
    geometries = np.asarray(geometries.to("angstrom").magnitude)
    if (
        geometries.ndim != 3
        or geometries.shape[1:] != (len(numbers), 3)
        or not np.isfinite(geometries).all()
    ):
        raise ValueError("Geometries must contain matching finite Cartesian atom tables.")
    template = dedent("""
        {count}
        Molecular geometry
        {atoms}
        """).lstrip()
    frames = []
    for geometry in geometries:
        atoms = "\n".join(
            f"{symbol} {x:.9f} {y:.9f} {z:.9f}"
            for symbol, (x, y, z) in zip(symbols, geometry, strict=True)
        )
        frames.append(template.format(count=len(numbers), atoms=atoms))
    return frames


@dataclass(frozen=True)
class Vibrations:
    """Cartesian mode directions and harmonic properties in Gaussian's native units.

    Attributes:
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of equilibrium Cartesian coordinates.
        frequencies: Pint array of harmonic frequencies; negative values are imaginary modes.
        masses: Pint array of reduced masses, one per mode.
        constants: Pint array of force constants, one per mode.
        intensities: Pint array of IR intensities, one per mode.
        modes: Array of modes by atoms by three Cartesian displacement components.
    """

    numbers: np.ndarray
    coordinates: object
    frequencies: object
    masses: object
    constants: object
    intensities: object
    modes: np.ndarray

    def trajectory(self, mode, *, amplitude, steps=41):
        """Scale a one-based mode to a requested maximum atomic excursion.

        Args:
            mode: One-based index of the normal mode.
            amplitude: Pint length of the largest atomic displacement.
            steps: Number of frames over one period, at least five.

        Returns:
            XYZ text of the frames, sampling phase rather than physical time.

        Raises:
            ValueError: The mode does not exist, the amplitude is negative or not finite, there are fewer than five
                steps, or the mode has no displacement.
        """
        amplitude = amplitude.to("angstrom")
        if not 1 <= mode <= len(self.frequencies) or not np.isfinite(amplitude.magnitude) or amplitude.magnitude < 0:
            raise ValueError("Specify an available mode and a nonnegative finite amplitude.")
        if steps < 5:
            raise ValueError("A mode trajectory requires at least five frames.")
        direction = self.modes[mode - 1]
        scale = np.linalg.norm(direction, axis=1).max()
        if scale <= 0:
            raise ValueError("The selected normal mode has no displacement.")
        phase = np.linspace(0, 2 * np.pi, steps, endpoint=False)
        geometries = (
            self.coordinates.to("angstrom").magnitude
            + amplitude.magnitude * np.sin(phase)[:, None, None] * direction / scale
        ) * ureg.angstrom
        return xyz_frames(self.numbers, geometries)


@dataclass(frozen=True)
class ReactionPath:
    """Matched geometries, energies and Cartesian gradients ordered along an IRC.

    Attributes:
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of points by atoms by three Cartesian components.
        coordinate: Pint array of the reaction coordinate at each point.
        energies: Pint array of total energies at each point.
        gradients: Pint array of Cartesian gradients at each point.
    """

    numbers: np.ndarray
    coordinates: object
    coordinate: object
    energies: object
    gradients: object

    @property
    def rms(self):
        """Return RMS Cartesian gradients in hartree per bohr.

        Returns:
            Pint array with one RMS gradient per path point.
        """
        return np.sqrt(np.mean(self.gradients.to("hartree/bohr").magnitude ** 2, axis=(1, 2))) * ureg.hartree / ureg.bohr

    @property
    def frames(self):
        """Return the reaction path as an XYZ trajectory in angstrom.

        Returns:
            XYZ text with one frame per path point.
        """
        return xyz_frames(self.numbers, self.coordinates)


@dataclass(frozen=True)
class GaussianCheckpoint:
    """Native geometry with optional harmonic modes and IRC path data.

    Attributes:
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of the current Cartesian coordinates.
        vibrations: Harmonic modes, or None without a frequency result.
        irc: Reaction path, or None without IRC records.
    """

    numbers: np.ndarray
    coordinates: object
    vibrations: Vibrations | None
    irc: ReactionPath | None


def _vibrations(records, numbers, coordinates):
    """Extract harmonic modes when the checkpoint contains a frequency result.

    Args:
        records: Native records from :func:`read_fchk_records`.
        numbers: Atomic numbers, one per atom.
        coordinates: Pint array of Cartesian coordinates.

    Returns:
        The :class:`Vibrations`, or None without mode records.

    Raises:
        ValueError: The mode records do not match each other or the atom count.
    """
    if "Vib-Modes" not in records or "Vib-E2" not in records:
        return None
    count = len(numbers)
    modes = records["Vib-Modes"].reshape(-1, count, 3)
    properties = records["Vib-E2"].reshape(-1, len(modes))
    if len(modes) != 3 * count - 6 or not np.isfinite(properties).all():
        raise ValueError("Expected a complete nonlinear-molecule frequency analysis.")
    return Vibrations(
        numbers,
        coordinates,
        properties[0] / ureg.centimeter,
        properties[1] * ureg.amu,
        properties[2] * ureg.millidyne / ureg.angstrom,
        properties[3] * ureg.kilometer / ureg.mole,
        modes,
    )


def _irc(records, numbers):
    """Extract an IRC path when the checkpoint contains matched path records.

    Args:
        records: Native records from :func:`read_fchk_records`.
        numbers: Atomic numbers, one per atom.

    Returns:
        The :class:`ReactionPath`, or None without IRC records.

    Raises:
        ValueError: The path records do not match each other or the atom count.
    """
    prefix = "IRC point       1 "
    required = (
        prefix + "Results for each geome",
        prefix + "Geometries",
        prefix + "Gradient at each geome",
    )
    if not all(name in records for name in required):
        return None
    results = records[required[0]].reshape(-1, 2)
    count = len(numbers)
    coordinates = records[required[1]].reshape(-1, count, 3) * ureg.bohr
    gradients = records[required[2]].reshape(-1, count, 3) * ureg.hartree / ureg.bohr
    if len(coordinates) != len(results) or len(gradients) != len(results):
        raise ValueError("The IRC checkpoint has unmatched result records.")
    order = np.argsort(results[:, 1])
    if not np.isfinite(results).all() or not np.all(np.diff(results[order, 1]) > 0):
        raise ValueError("The IRC coordinate must contain unique finite points.")
    return ReactionPath(
        numbers,
        coordinates[order],
        results[order, 1] * ureg.bohr * ureg.amu**0.5,
        results[order, 0] * ureg.hartree,
        gradients[order],
    )


def read_gaussian_checkpoint(path):
    """Return native coordinates, modes and IRC records from one formatted checkpoint.

    Args:
        path: Formatted checkpoint (``.fchk``) to read.

    Returns:
        The :class:`GaussianCheckpoint`.

    Raises:
        FileNotFoundError: The checkpoint does not exist.
        ValueError: Its records are incomplete or inconsistent.
    """
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Gaussian checkpoint is missing: {path}")
    records = read_fchk_records(path)
    try:
        numbers = np.asarray(records["Atomic numbers"], dtype=int)
        count = int(records["Number of atoms"])
        coordinates = np.asarray(
            records["Current cartesian coordinates"], dtype=float
        ).reshape(count, 3) * ureg.bohr
    except KeyError as error:
        raise ValueError(f"Required checkpoint geometry field is missing: {error.args[0]}") from error
    if len(numbers) != count or not np.isfinite(coordinates).all():
        raise ValueError("Checkpoint atom numbers and Cartesian coordinates do not match.")
    return GaussianCheckpoint(
        numbers=numbers,
        coordinates=coordinates,
        vibrations=_vibrations(records, numbers, coordinates),
        irc=_irc(records, numbers),
    )


def spins(records):
    """The spin channels of a formatted checkpoint's orbitals.

    Args:
        records: Records from ``read_fchk_records``.

    Returns:
        ``["alpha"]`` for a restricted wavefunction, ``["alpha", "beta"]`` for an unrestricted one.
    """
    return ["alpha", "beta"] if "Beta MO coefficients" in records else ["alpha"]


def spin_record(records, spin, name):
    """One spin channel's record of a formatted checkpoint, such as its MO coefficients or orbital energies.

    Args:
        records: Records from ``read_fchk_records``.
        spin: ``"alpha"`` or ``"beta"``.
        name: The record's name with ``{Spin}`` or ``{spin}`` for the channel, such as ``"{Spin} MO coefficients"``.

    Returns:
        The record; a restricted checkpoint's beta channel is its alpha one.

    Raises:
        ValueError: If the spin is neither alpha nor beta.
        KeyError: If the checkpoint has no such record.
    """
    if spin not in ("alpha", "beta"):
        raise ValueError(f"The spin is alpha or beta, not {spin!r}.")
    key = name.format(Spin=spin.capitalize(), spin=spin)
    if key not in records and spin == "beta" and "Beta MO coefficients" not in records:
        key = name.format(Spin="Alpha", spin="alpha")
    return records[key]


# Letters of the angular momenta l = 0, 1, 2, ...: s, p, d, f, then the alphabet from g without j and the letters
# already used.
ANGULAR_LETTERS = "spdfghiklmnoqrtuvwxyz"


def momentum_letter(momentum):
    """The spectroscopic letter of an angular momentum.

    Args:
        momentum: The angular momentum l, from zero.

    Returns:
        Its letter: s, p, d, f, g, h, i, k and on.
    """
    return ANGULAR_LETTERS[momentum]


def _pyscf_powers(momentum):
    """Exponents of PySCF's Cartesian functions of one angular momentum, in its order.

    Args:
        momentum: The angular momentum.

    Returns:
        The (x, y, z) exponents of each function, the power of x falling first, then of y.
    """
    return [(x, y, momentum - x - y) for x in range(momentum, -1, -1) for y in range(momentum - x, -1, -1)]


def _pure_functions(momentum):
    """The real solid harmonics of a pure shell as Cartesian polynomials, in the formatted checkpoint's order m = 0, +1,
    -1, +2, -2, ...: ``runflow.symmetry.PURE`` where it writes them out, otherwise PySCF's, whose d and f harmonics are
    those of ``PURE`` in the same order and signs.

    Args:
        momentum: The angular momentum, two or more.

    Returns:
        One mapping of Cartesian exponents to coefficients per function.
    """
    from .symmetry import PURE

    return PURE[momentum] if momentum in PURE else _pyscf_pure(momentum)


def _pyscf_pure(momentum):
    """PySCF's real solid harmonics of one angular momentum as Cartesian polynomials, reordered to the formatted
    checkpoint's m = 0, +1, -1, +2, -2, ...

    Args:
        momentum: The angular momentum, two or more.

    Returns:
        One mapping of Cartesian exponents to coefficients per function.
    """
    from pyscf.gto.mole import cart2sph

    matrix, powers = cart2sph(momentum), _pyscf_powers(momentum)
    order = [0] + [m for k in range(1, momentum + 1) for m in (k, -k)]
    return [{powers[row]: float(matrix[row, momentum + m]) for row in np.flatnonzero(np.abs(matrix[:, momentum + m]) > 1e-12)}
            for m in order]


def basis_supported(records):
    """Whether the basis of a formatted checkpoint can be evaluated: s, sp and p shells, Cartesian d and f shells, and
    pure shells of any angular momentum. Cartesian shells above f are not, since their order in the checkpoint is not
    the one written out here.

    Args:
        records: Records from ``read_fchk_records``.

    Returns:
        True when every shell type is supported.
    """
    from .symmetry import CARTESIAN

    return all(kind == -1 or kind < -1 or kind in CARTESIAN for kind in np.asarray(records["Shell types"], dtype=int))


def _basis(records):
    """PySCF's Cartesian basis on a formatted checkpoint's own shells, and the checkpoint's functions in it.

    Every function of the checkpoint is a combination of PySCF's Cartesian functions of its shell: the Cartesian
    monomials of ``runflow.symmetry.CARTESIAN`` or the solid harmonics of ``_pure_functions``, each normalized on its
    own as Gaussian writes them.

    Args:
        records: Records from ``read_fchk_records``.

    Returns:
        The PySCF molecule, with Cartesian functions, its overlap matrix, and the transform whose column i gives the
        checkpoint's function i in PySCF's functions.

    Raises:
        ValueError: The checkpoint holds a shell type that ``basis_supported`` rejects, or its shells do not give its
            number of functions.
    """
    from pyscf import gto
    from pyscf.data.elements import ELEMENTS as SYMBOLS

    from .symmetry import CARTESIAN

    if not basis_supported(records):
        raise ValueError("Cartesian shells above f are not supported; pure shells of any angular momentum are.")
    types = np.asarray(records["Shell types"], dtype=int)
    counts = np.asarray(records["Number of primitives per shell"], dtype=int)
    exponents = np.asarray(records["Primitive exponents"], dtype=float)
    contraction = np.asarray(records["Contraction coefficients"], dtype=float)
    p_contraction = np.asarray(records.get("P(S=P) Contraction coefficients", np.zeros_like(contraction)), dtype=float)
    owners = np.asarray(records["Shell to atom map"], dtype=int) - 1
    numbers = np.asarray(records["Atomic numbers"], dtype=int)
    nuclei = np.asarray(records["Current cartesian coordinates"], dtype=float).reshape(-1, 3)
    starts = np.concatenate([[0], np.cumsum(counts)])
    # One PySCF shell per angular momentum, an sp shell as an s and a p shell; each atom keeps its own label and basis.
    shells, order = {atom: [] for atom in range(len(numbers))}, []
    for shell, kind in enumerate(types):
        primitives = slice(starts[shell], starts[shell + 1])
        parts = [(0, contraction), (1, p_contraction)] if kind == -1 else [(abs(kind), contraction)]
        for momentum, weights in parts:
            atom = owners[shell]
            # The checkpoint's shell as its atom, angular momentum and occurrence among that atom's shells of it.
            order.append((atom, momentum, sum(entry[0] == momentum for entry in shells[atom])))
            shells[atom].append([momentum, *zip(exponents[primitives], weights[primitives])])
    labels = [f"{SYMBOLS[number]}{atom + 1}" for atom, number in enumerate(numbers)]
    molecule = gto.M(atom=[[label, tuple(position)] for label, position in zip(labels, nuclei)], unit="Bohr",
                     basis={label: shells[atom] for atom, label in enumerate(labels)}, cart=True,
                     spin=int(numbers.sum()) % 2, verbose=0)
    overlap = molecule.intor_symmetric("int1e_ovlp_cart")
    # PySCF orders an atom's shells by angular momentum, so each of its shells is found by atom, angular momentum and
    # occurrence; its Cartesian functions fall in the power of x, then of y, where the checkpoint has its own order.
    offsets, seen, position = {}, {}, 0
    for shell in range(molecule.nbas):
        atom, momentum = molecule.bas_atom(shell), molecule.bas_angular(shell)
        for _ in range(molecule.bas_nctr(shell)):
            occurrence = seen.get((atom, momentum), 0)
            seen[(atom, momentum)] = occurrence + 1
            offsets[(atom, momentum, occurrence)] = position
            position += (momentum + 1) * (momentum + 2) // 2
    kinds = [kind for kind in types for _ in ([0, 1] if kind == -1 else [kind])]
    columns = []
    for key, kind in zip(order, kinds):
        start, momentum = offsets[key], key[1]
        powers = _pyscf_powers(momentum)
        functions = [{p: 1.0} for p in CARTESIAN[momentum]] if kind >= -1 else _pure_functions(momentum)
        for function in functions:
            column = np.zeros(len(overlap))
            for power, weight in function.items():
                column[start + powers.index(power)] = weight
            columns.append(column)
    transform = np.array(columns).T
    if transform.shape[1] != int(records["Number of basis functions"]):
        raise ValueError(f"Shells give {transform.shape[1]} functions, but the checkpoint has "
                         f"{int(records['Number of basis functions'])}.")
    transform /= np.sqrt(np.einsum("ki,kl,li->i", transform, overlap, transform))
    return molecule, overlap, transform


def _grid(records, margin, bounds, spacing):
    """The corners and shape of a Cartesian grid around a checkpoint's nuclei, or within given bounds, in bohr.

    Args:
        records: Records from ``read_fchk_records``.
        margin: Padding around the outermost nuclei.
        bounds: Lower and upper corners, replacing the nuclei and margin, or None.
        spacing: Grid step.

    Returns:
        The lower corner, the number of points along each axis, the atomic numbers and the nuclei.
    """
    numbers = np.asarray(records["Atomic numbers"], dtype=int)
    nuclei = np.asarray(records["Current cartesian coordinates"], dtype=float).reshape(-1, 3)
    lower, upper = ((nuclei.min(axis=0) - margin, nuclei.max(axis=0) + margin) if bounds is None
                    else (np.asarray(bounds[0], dtype=float), np.asarray(bounds[1], dtype=float)))
    return lower, np.ceil((upper - lower) / spacing).astype(int) + 1, numbers, nuclei


def _on_grid(molecule, lower, shape, spacing, combine, chunk):
    """Values built from PySCF's Cartesian functions at every point of a grid, a chunk of points at a time.

    Args:
        molecule: The PySCF molecule of ``_basis``.
        lower: The grid's lower corner in bohr.
        shape: The number of points along each axis.
        spacing: Grid step in bohr.
        combine: Maps the functions' values at the points, one row per point, to one row of results per point.
        chunk: Points evaluated together.

    Returns:
        The results with shape ``(*shape, results)``.
    """
    axes = [lower[k] + spacing * np.arange(shape[k]) for k in range(3)]
    points = np.stack(np.meshgrid(*axes, indexing="ij"), axis=-1).reshape(-1, 3)
    parts = [combine(molecule.eval_gto("GTOval_cart", points[start:start + chunk]))
             for start in range(0, len(points), chunk)]
    return np.concatenate(parts).reshape(*shape, -1)


def orbital_grid(records, orbital, *, spin="alpha", spacing=0.3, margin=5.0, bounds=None, chunk=20000):
    """One orbital of a formatted checkpoint sampled on a Cartesian grid around the molecule, in bohr.

    The basis functions are PySCF's on the checkpoint's own shells, as ``_basis`` makes them: s, sp and p shells,
    Cartesian d and f shells and pure shells of any angular momentum, each function normalized on its own as in
    Gaussian's formatted checkpoints. PySCF skips shells negligible at a point.

    Args:
        records: Records from ``read_fchk_records``.
        orbital: Zero-based orbital index.
        spin: The spin channel, ``"alpha"`` or ``"beta"``; a restricted checkpoint's beta orbitals are its alpha ones.
        spacing: Grid step in bohr.
        margin: Padding around the outermost nuclei in bohr.
        bounds: Lower and upper grid corners in bohr, replacing the nuclei and margin.
        chunk: Grid points evaluated together.

    Returns:
        Grid origin, step vectors (rows) and atom rows ``[Z, Z, x, y, z]``, all in bohr, and the orbital values
        in ``a_0^{-3/2}`` with shape ``(nx, ny, nz)``.

    Raises:
        ValueError: The checkpoint holds a shell type ``basis_supported`` rejects.
    """
    molecule, _, transform = _basis(records)
    basis = int(records["Number of basis functions"])
    vector = transform @ np.asarray(spin_record(records, spin, "{Spin} MO coefficients"), dtype=float).reshape(-1, basis)[orbital]
    lower, shape, numbers, nuclei = _grid(records, margin, bounds, spacing)
    values = _on_grid(molecule, lower, shape, spacing, lambda functions: (functions @ vector)[:, None], chunk)[..., 0]
    atoms = np.column_stack([numbers, numbers, nuclei]).astype(float)
    return lower, np.eye(3) * spacing, atoms, values


def _shell_functions(kind):
    """Angular momentum of each function of a formatted-checkpoint shell, in its order.

    Args:
        kind: Gaussian's shell type: 0, 1 and 2 or 3 for Cartesian s, p, d and f, -1 for sp, -2 and -3 for pure d and f.

    Returns:
        One angular momentum per function.
    """
    if kind == -1:
        return [0, 1, 1, 1]
    momentum = abs(kind)
    return [momentum] * ((momentum + 1) * (momentum + 2) // 2 if kind >= 0 else 2 * momentum + 1)


def overlap_matrix(records):
    """Overlap matrix of a formatted checkpoint's basis functions, each normalized on its own as Gaussian writes them.

    The integrals come from PySCF on the checkpoint's own shells, all taken as Cartesian, combined into the checkpoint's
    functions as ``_basis`` makes them: s, sp and p shells, Cartesian d and f shells and pure shells of any angular
    momentum.

    Args:
        records: Records from ``read_fchk_records``.

    Returns:
        The symmetric overlap matrix, dimensionless, in the checkpoint's order of basis functions.

    Raises:
        ValueError: The checkpoint holds a shell type that ``basis_supported`` rejects.
    """
    _, overlap, transform = _basis(records)
    return transform.T @ overlap @ transform


def basis_function_owners(records):
    """The atom and angular momentum of every basis function of a formatted checkpoint, in the order of its
    coefficients.

    Args:
        records: Records from ``read_fchk_records``.

    Returns:
        Two integer arrays: the zero-based atom and the angular momentum of each basis function.
    """
    types = np.asarray(records["Shell types"], dtype=int)
    owners = np.asarray(records["Shell to atom map"], dtype=int) - 1
    atoms, momenta = [], []
    for shell, kind in enumerate(types):
        for momentum in _shell_functions(kind):
            atoms.append(owners[shell])
            momenta.append(momentum)
    return np.asarray(atoms, dtype=int), np.asarray(momenta, dtype=int)


def orbital_composition(records, orbitals, overlap=None, spin="alpha"):
    r"""Mulliken composition of the orbitals of one spin channel of a formatted checkpoint by atom and angular momentum.

    The share of the functions of atom :math:`A` with angular momentum :math:`l` in an orbital with coefficients
    :math:`\mathbf{c}` is :math:`w_{A,l}=\sum_{\mu\in A,\ l_\mu=l}c_\mu(\mathbf{S}\mathbf{c})_\mu`; the shares of one
    orbital add up to one.

    Args:
        records: Records from ``read_fchk_records``.
        orbitals: Zero-based alpha orbital indices.
        overlap: The checkpoint's overlap matrix, when already calculated by ``overlap_matrix``.
        spin: The spin channel, ``"alpha"`` or ``"beta"``.

    Returns:
        Array of shape (orbitals, atoms, momenta), the shares of the s, p, d and f functions on each atom, up to the
        highest angular momentum of the basis.

    Raises:
        ValueError: The checkpoint holds an unsupported shell type, or its orbitals are not orthonormal in the
            calculated overlap, which would make the shares meaningless.
    """
    matrix = overlap_matrix(records) if overlap is None else overlap
    basis = int(records["Number of basis functions"])
    coefficients = np.asarray(spin_record(records, spin, "{Spin} MO coefficients"),
                              dtype=float).reshape(-1, basis)[list(orbitals)].T
    gram = coefficients.T @ matrix @ coefficients
    if not np.allclose(gram, np.eye(len(gram)), atol=1e-5):
        raise ValueError("The checkpoint's orbitals are not orthonormal in the calculated overlap.")
    atoms, momenta = basis_function_owners(records)
    shares = coefficients * (matrix @ coefficients)
    table = np.zeros((len(orbitals), int(records["Number of atoms"]), momenta.max() + 1))
    for column in range(len(orbitals)):
        np.add.at(table[column], (atoms, momenta), shares[:, column])
    return table


def density_grid(records, orbitals, weights, *, spin="alpha", spacing=0.3, margin=5.0, bounds=None, chunk=20000):
    """Weighted sums of squared orbitals of one spin channel of a formatted checkpoint on a Cartesian grid, in bohr.

    Each density sum_m w_m psi_m(r)^2 is built from many orbitals at once: the basis functions are evaluated once at
    every point, as in ``orbital_grid``, and every orbital follows from one matrix product.

    Args:
        records: Records from ``read_fchk_records``.
        orbitals: Zero-based orbital indices.
        weights: Weight of each orbital's squared amplitude, or one row of weights per density.
        spin: The spin channel, ``"alpha"`` or ``"beta"``.
        spacing: Grid step in bohr.
        margin: Padding around the outermost nuclei in bohr.
        bounds: Lower and upper grid corners in bohr, replacing the nuclei and margin.
        chunk: Grid points evaluated together.

    Returns:
        Grid origin, step vectors (rows) and atom rows ``[Z, Z, x, y, z]``, all in bohr, and the density in
        ``a_0^{-3}`` with shape ``(nx, ny, nz)``, or one such density per row of ``weights``.

    Raises:
        ValueError: The checkpoint holds a shell type ``basis_supported`` rejects.
    """
    molecule, _, transform = _basis(records)
    basis = int(records["Number of basis functions"])
    coefficients = transform @ np.asarray(spin_record(records, spin, "{Spin} MO coefficients"),
                                          dtype=float).reshape(-1, basis)[list(orbitals)].T
    weights = np.asarray(weights, dtype=float)
    single = weights.ndim == 1
    weights = np.atleast_2d(weights)
    lower, shape, numbers, nuclei = _grid(records, margin, bounds, spacing)
    values = np.moveaxis(_on_grid(molecule, lower, shape, spacing,
                                  lambda functions: ((functions @ coefficients) ** 2) @ weights.T, chunk), -1, 0)
    atoms = np.column_stack([numbers, numbers, nuclei]).astype(float)
    return lower, np.eye(3) * spacing, atoms, values[0] if single else values

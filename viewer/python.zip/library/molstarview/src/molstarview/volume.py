"""Generic cube-grid isosurfaces, scalar color mapping and persistent comparisons."""

import base64
import gzip
import hashlib
import json
import os
import re
from dataclasses import dataclass
from functools import cached_property, lru_cache
from io import StringIO
from itertools import product
from pathlib import Path
from textwrap import dedent

import anywidget
import numpy as np
import traitlets
from runflow.results import ureg, xyz_frames

from . import store
from .viewer import MolstarViewer, choice_axes


# Gaussian cubes parsed once, kept in binary by the path, size and modification time of the text.
CUBES = Path.home() / ".cache/research-findings/cubes"
# The finest step of the asinh-compressed samples of ``CubeGrid.compact``: about 0.1 % of a value above the knee, far
# below what a surface or the volume fog can show, which leaves gzip far fewer distinct differences to store.
RESOLUTION = 2e-3


def _encoded(source, knee, written):
    """The compact encoding of a grid, reused from the disk cache by the grid's content and checked against its digest.

    Args:
        source: The grid to encode.
        knee: The magnitude below which the encoding is linear.
        written: The unit the decoded field is written in.

    Returns:
        The encoded bytes.

    Raises:
        OSError: If a store is set and the cache cannot keep the bytes the uploader must find.
    """
    name = store.CACHE / f"{_payload_key(source, (knee, written))}.name"
    try:
        digest = name.read_text()
        data = store.stored(digest).read_bytes()
        if hashlib.sha256(data).hexdigest() == digest:
            return data
    except OSError:
        pass
    data = source.compact(knee, written)
    digest = hashlib.sha256(data).hexdigest()
    try:
        store.write_atomic(store.stored(digest), data)
        store.write_atomic(name, digest.encode())
    except OSError:
        # A read-only cache, as in the browser's memory file system, leaves the field uncached.
        if os.environ.get(store.STORE):
            raise
    return data


@lru_cache(maxsize=1)
def _encoder_digest():
    """Digest of the source that writes an encoded field, so an encoding change invalidates every cached field and no
    other edit to this module does.

    Returns:
        The hexadecimal SHA-256 of the source of ``CubeGrid.compact`` and ``CubeGrid.text``.
    """
    import inspect

    return hashlib.sha256((inspect.getsource(CubeGrid.compact) + inspect.getsource(CubeGrid.text)).encode()).hexdigest()


def _payload_key(source, encoding):
    """Cache name of one encoded field, by the grid it writes and the step, knee and unit of its encoding.

    Args:
        source: The grid to be written.
        encoding: The knee and unit that the encoding is written with.

    Returns:
        The hexadecimal SHA-256 of the grid's arrays, the encoding and the encoder's digest.
    """
    digest = hashlib.sha256()
    for array in (source.origin, source.axes, source.atoms, source.values):
        contiguous = np.ascontiguousarray(array)
        digest.update(f"{contiguous.dtype}-{contiguous.shape}-".encode())
        digest.update(contiguous.tobytes())
    digest.update(f"{encoding!r}-{_encoder_digest()}".encode())
    return digest.hexdigest()


@dataclass(frozen=True)
class CubeGrid:
    """A single scalar grid, with Gaussian cube coordinates in bohr.

    Attributes:
        origin: The position of the first grid point, three numbers in bohr.
        axes: The step between grid points along each axis, a 3 by 3 array in bohr with one row per axis.
        atoms: One row per atom: its atomic number, its charge column and its position in bohr.
        values: The scalar field at every grid point, an array of the grid's shape.
    """

    origin: np.ndarray
    axes: np.ndarray
    atoms: np.ndarray
    values: np.ndarray

    @classmethod
    def read(cls, path):
        """Read a positive-axis, single-field Gaussian cube without altering it.

        Args:
            path: The cube file, as a ``pathlib.Path``.

        Returns:
            The grid, with origin and axes in bohr.

        Raises:
            ValueError: If the cube has no atoms or a non-positive axis, or its values are incomplete or not finite.
        """
        # Parsing the text is the slow part, so each version of a cube, by its path, size and modification time, is
        # parsed once and kept in binary; a read-only cache, as in the browser, parses it every time.
        info = Path(path).stat()
        name = hashlib.sha256(f"{Path(path).resolve()}|{info.st_size}|{info.st_mtime_ns}".encode()).hexdigest()
        parsed = CUBES / f"{name}.npz"
        try:
            with np.load(parsed) as kept:
                return cls(kept["origin"], kept["axes"], kept["atoms"], kept["values"])
        except OSError:
            pass
        grid = cls._parse(Path(path))
        try:
            parsed.parent.mkdir(parents=True, exist_ok=True)
            partial = parsed.with_name(f".{parsed.name}.{os.getpid()}.part.npz")
            np.savez(partial, origin=grid.origin, axes=grid.axes, atoms=grid.atoms, values=grid.values)
            partial.replace(parsed)
        except OSError:
            pass
        return grid

    @classmethod
    def _parse(cls, path):
        """The grid of a Gaussian cube's text, as ``read`` describes it.

        Args:
            path: The cube file.

        Returns:
            The grid, with origin and axes in bohr.

        Raises:
            ValueError: If the cube has no atoms or a non-positive axis, or its values are incomplete or not finite.
        """
        with path.open() as stream:
            next(stream)
            next(stream)
            head = next(stream).split()
            count = int(head[0])
            origin = np.asarray(head[1:4], dtype=float)
            grid = np.asarray([next(stream).split() for _ in range(3)], dtype=float)
            if count <= 0 or (grid[:, 0] <= 0).any():
                raise ValueError("Expected a scalar Gaussian cube with positive bohr axes.")
            atoms = np.asarray([next(stream).split() for _ in range(count)], dtype=float)
            values = np.fromstring(stream.read(), sep=" ")
        shape = tuple(grid[:, 0].astype(int))
        if values.size != np.prod(shape) or not np.isfinite(values).all():
            raise ValueError("The cube has an incomplete or non-finite scalar grid.")
        return cls(origin, grid[:, 1:], atoms, values.reshape(shape))

    @classmethod
    def cached(cls, metadata, numbers, positions, function, *, spacing=0.3, margin=5.0, folder=None):
        """``from_function``, kept as an uncompressed single-precision file named by the SHA-256 of the grid's metadata as canonical JSON,
        the metadata stored in the file, so a later call reads the grid instead of sampling it again.

        Args:
            metadata: JSON-serializable mapping of what defines the field, such as the keys and indices of the orbitals
                it is drawn from; the atoms, positions and grid settings are added to it.
            numbers: Atomic numbers, as ``from_function`` takes them.
            positions: Atom positions in angstrom.
            function: The field, as ``from_function`` takes it.
            spacing: Distance between grid points in bohr.
            margin: Distance from the outermost atoms to the box's faces in bohr.
            folder: Where grids are kept; by default ``~/.cache/research-findings/grids``.

        Returns:
            The sampled grid.
        """
        folder = Path(folder) if folder is not None else Path.home() / ".cache/research-findings/grids"
        described = {**metadata, "numbers": [int(number) for number in numbers],
                     "positions": np.asarray(positions, dtype=float).tolist(), "spacing": spacing, "margin": margin}
        text = json.dumps(described, sort_keys=True, separators=(",", ":"))
        path = folder / f"{hashlib.sha256(text.encode()).hexdigest()}.npz"
        if path.exists():
            with np.load(path) as kept:
                return cls(kept["origin"], kept["axes"], kept["atoms"], kept["values"])
        grid = cls.from_function(numbers, positions, function, spacing=spacing, margin=margin)
        # Single precision, far finer than a page shows, uncompressed, as a smooth field hardly compresses and
        # reading it back is then a copy; returned as stored, so a fresh and a cached grid are the same.
        grid = cls(grid.origin, grid.axes, grid.atoms, grid.values.astype(np.float32))
        folder.mkdir(parents=True, exist_ok=True)
        np.savez(path, origin=grid.origin, axes=grid.axes, atoms=grid.atoms, values=grid.values, metadata=text)
        return grid

    @classmethod
    def from_function(cls, numbers, positions, function, *, spacing=0.3, margin=5.0):
        """Sample any scalar field over the box around the atoms, such as an orbital or a density from any library.

        The grid is axis-aligned, ``spacing`` bohr apart, and reaches ``margin`` bohr beyond the atoms.

        Args:
            numbers: Atomic numbers of the atoms the viewer draws.
            positions: Atom positions in angstrom, one row per atom.
            function: Takes some of the grid points, an array of shape (N, 3) in bohr, and returns N values.
            spacing: Distance between grid points in bohr.
            margin: Distance from the outermost atoms to the box's faces in bohr.

        Returns:
            The sampled grid.
        """
        positions = (np.asarray(positions, dtype=float) * ureg.angstrom).to("bohr").magnitude
        lower, upper = positions.min(axis=0) - margin, positions.max(axis=0) + margin
        shape = np.ceil((upper - lower) / spacing).astype(int) + 1
        mesh = np.stack(np.meshgrid(*[lower[i] + spacing * np.arange(shape[i]) for i in range(3)], indexing="ij"), axis=-1)
        points = mesh.reshape(-1, 3)
        # In chunks, so a function that expands every point into many terms stays within memory.
        values = np.concatenate([np.asarray(function(points[i:i + 100000]), dtype=float) for i in range(0, len(points), 100000)]).reshape(tuple(shape))
        atoms = np.column_stack([numbers, numbers, positions]).astype(float)
        return cls(lower, np.diag([spacing] * 3), atoms, values)

    def text(self, *, values=True):
        """Serialize the grid in memory for Molstar's native cube parser, or only its header without ``values``.

        Args:
            values: Whether to write the field's values after the header.

        Returns:
            The cube text, with a Gaussian cube's header and six values to a line.
        """
        header = ["Molecular scalar field", "Coordinates in bohr",
                  f"{len(self.atoms)} " + " ".join(f"{v:.9f}" for v in self.origin)]
        header.extend(f"{size} " + " ".join(f"{v:.9f}" for v in axis)
                      for size, axis in zip(self.values.shape, self.axes, strict=True))
        header.extend(f"{int(row[0])} " + " ".join(f"{v:.9f}" for v in row[1:]) for row in self.atoms)
        header_text = "\n".join(header)
        if not values:
            return header_text + "\n"
        buffer = StringIO()
        samples = self.values.ravel()
        complete = samples.size // 6 * 6
        np.savetxt(buffer, samples[:complete].reshape(-1, 6), fmt="%.8E")
        if complete < samples.size:
            np.savetxt(buffer, samples[complete:][None, :], fmt="%.8E")
        template = dedent("""
            {header}
            {values}
            """).lstrip()
        return template.format(header=header_text, values=buffer.getvalue().rstrip())


    def compact(self, knee, unit):
        """The field as gzipped bytes for the viewer's ``decodeField``: its cube header, then integer samples.

        The viewer writes the decoded field in multiples of ``unit``, the units its settings use.

        Each sample is u = rint(asinh(v / knee) / step), so the rounding error is the same fraction of the value at
        every level above the knee, instead of the same absolute step, which leaves few steps below a low level. Samples
        are stored as 16-bit differences from the one before, in the grid's file order, where a smooth field compresses
        well; only these differences must fit 16 bits, not the samples. The step is ``RESOLUTION``, or the steepest
        change between neighbours over 2^15 - 2 where that is coarser, so the differences always fit. The differences
        are written as all their low bytes, then all their high bytes, which are nearly all 0 or 255 and gzip packs
        tightly.

        Args:
            knee: The magnitude below which the encoding is linear, usually half the lowest level to be shown.
            unit: The unit the viewer writes the decoded field in.

        Returns:
            The header length, the knee in units, the step and the header, followed by the differences, gzipped.
        """
        compressed = np.arcsinh(self.values.ravel() / knee)
        steepest = float(np.abs(np.diff(compressed, prepend=0)).max())
        # Rounding moves a difference by at most one step.
        step = max(max(steepest, 1e-12) / (2**15 - 2), RESOLUTION)
        differences = np.diff(np.rint(compressed / step).astype(np.int64), prepend=0).astype("<i2")
        header = self.text(values=False).encode()
        shuffled = differences.view(np.uint8).reshape(-1, 2).T.tobytes()
        return gzip.compress(np.uint32(len(header)).astype("<u4").tobytes() + np.asarray([knee / unit, step], "<f8").tobytes()
                             + header + shuffled, compresslevel=9)


@dataclass(frozen=True, kw_only=True)
class VolumeSurface:
    """A scalar isosurface with an optional registered field for color mapping.

    Attributes:
        grid: The field whose level set is drawn.
        isovalue: The level of the surface in the field's units; for a signed surface, the magnitude of both levels.
        color_grid: A second field on the same grid that colours the surface, or None for a uniform colour.
        color_factor: The factor that converts ``color_grid`` to the units of the colour scale.
        signed: Whether the surface is drawn at both +isovalue and -isovalue, in the negative and positive end colours.
        floor: The smallest level the viewer's settings may choose, which keeps every point at or above it in the
            displayed box; None fixes the surface at ``isovalue``.
    """

    grid: CubeGrid
    isovalue: float
    color_grid: CubeGrid | None = None
    color_factor: float = 1.0
    # Whether the surface is drawn at both +isovalue and -isovalue of a signed field such as an orbital, in the
    # negative and positive end colours, instead of at one isovalue.
    signed: bool = False
    # Smallest contour level the viewer's settings may choose, which keeps every point at or above it in the
    # displayed box; None fixes the surface at ``isovalue``.
    floor: float | None = None

    def __post_init__(self):
        """Require finite contour parameters and matched source grids for scalar coloring.

        Raises:
            ValueError: If the isovalue or colour factor is not finite, the floor is not between zero and the isovalue, or
                the colour grid differs from the surface's grid in origin, axes, atoms or shape.
        """
        if not np.isfinite(self.isovalue) or not np.isfinite(self.color_factor):
            raise ValueError("Contour level and color conversion must be finite.")
        if self.floor is not None and not 0 < self.floor <= abs(self.isovalue):
            raise ValueError("An adjustable level needs a floor between zero and the isovalue.")
        if self.color_grid is not None:
            for attribute in ("origin", "axes", "atoms"):
                if not np.array_equal(getattr(self.grid, attribute), getattr(self.color_grid, attribute)):
                    raise ValueError(f"Surface and color field have different {attribute}.")
            if self.grid.values.shape != self.color_grid.values.shape:
                raise ValueError("Surface and color fields must share their source grid.")

    @classmethod
    def enclosing(cls, grid, share=0.9, **options):
        r"""A signed surface at the level whose region of larger magnitude holds ``share`` of :math:`\int|f|\,\mathrm{d}V`,
        the usual way to draw orbitals and their products, with the settings' floor an eighth of that level.

        Args:
            grid: The field.
            share: Share of the integrated magnitude the surface encloses.
            **options: Further fields of the surface, such as a colour grid.

        Returns:
            The surface.
        """
        magnitudes = np.sort(np.abs(grid.values).ravel())[::-1]
        total = np.cumsum(magnitudes)
        level = float(magnitudes[min(np.searchsorted(total, share * total[-1]), len(magnitudes) - 1)])
        return cls(grid=grid, isovalue=level, signed=True, floor=level / 8, **options)

    @cached_property
    def lowest_level(self):
        """The smallest level the settings may choose, in the field's units. It is the floor, raised just above the largest
        magnitude near the source grid's faces when the field there exceeds it, so no chosen surface or fog reaches the
        grid's edge, or None for a fixed level.

        Returns:
            float or None
        """
        if self.floor is None:
            return None
        # The outer three layers: the displayed box adds two layers around the chosen region and must stay inside.
        values = np.abs(self.grid.values)
        faces = max(float(values.take(layers, axis).max()) for axis in range(3) for layers in ([0, 1, 2], [-3, -2, -1]))
        return min(max(self.floor, 1.05 * faces), abs(self.isovalue))

    @cached_property
    def display_grids(self):
        """Crop vacuum and retain the original coloring samples; the viewer makes the surface smooth from this grid.

        The box holds every point a level at or above the lowest level can reach, with four layers around it. The value
        is the cropped grid of the field and the matching grid of the colour field, or None without one.

        Returns:
            tuple

        Raises:
            ValueError: If the grid holds no point at the level, or the surface reaches the original cube's boundary.
        """
        # The box holds every point a chosen level can reach: those at or above the floor of an adjustable one.
        level = self.isovalue if self.floor is None else np.copysign(self.lowest_level, self.isovalue)
        if self.signed:
            mask = np.abs(self.grid.values) >= abs(level)
        else:
            mask = self.grid.values >= level if level >= 0 else self.grid.values <= level
        # Project the mask onto each axis instead of allocating coordinates for every occupied voxel.
        occupied = [np.flatnonzero(mask.any(axis=tuple(j for j in range(3) if j != axis))) for axis in range(3)]
        if not len(occupied[0]):
            raise ValueError("The grid does not contain the requested isosurface.")
        # Four layers beyond the region where the cube has them, so the viewer's spline, mirrored at the box's faces,
        # does not fold the surface back near them.
        if any(axis[0] == 0 or axis[-1] == size - 1 for axis, size in zip(occupied, self.grid.values.shape, strict=True)):
            raise ValueError("The isosurface reaches the original cube boundary.")
        lower = np.maximum([axis[0] - 4 for axis in occupied], 0)
        upper = np.minimum([axis[-1] + 5 for axis in occupied], self.grid.values.shape)
        window = tuple(slice(int(a), int(b)) for a, b in zip(lower, upper, strict=True))
        origin = self.grid.origin + lower @ self.grid.axes
        contour = CubeGrid(origin, self.grid.axes, self.grid.atoms, self.grid.values[window])
        color = None if self.color_grid is None else CubeGrid(origin, self.grid.axes,
            self.grid.atoms, self.color_grid.values[window] * self.color_factor)
        return contour, color

    @cached_property
    def bounds(self):
        """The lower and upper Cartesian corners of the displayed field, as an array of shape (2, 3) in angstrom.

        Returns:
            numpy.ndarray
        """
        grid, _ = self.display_grids
        corners = np.asarray(list(product(*[(0, size - 1) for size in grid.values.shape])))
        positions = (
            (grid.origin + corners @ grid.axes) * ureg.bohr
        ).to("angstrom").magnitude
        return np.asarray([positions.min(axis=0), positions.max(axis=0)])

    def color_limits(self):
        """Sample the color field at contour crossings using native trilinear interpolation.

        Returns:
            The smallest and largest colour value on the surface, as floats in the colour field's units.

        Raises:
            ValueError: If the surface has no colour field, or no contour crossing is found.
        """
        from scipy.ndimage import map_coordinates

        grid, color = self.display_grids
        if color is None:
            raise ValueError("A scalar color field is required to derive color limits.")
        samples = []
        for axis in range(3):
            lower, upper = [slice(None)] * 3, [slice(None)] * 3
            lower[axis], upper[axis] = slice(None, -1), slice(1, None)
            first, second = grid.values[tuple(lower)], grid.values[tuple(upper)]
            mask = ((first < self.isovalue) != (second < self.isovalue))
            coordinates = np.asarray(np.nonzero(mask), dtype=float)
            coordinates[axis] += (self.isovalue - first[mask]) / (second[mask] - first[mask])
            samples.append(map_coordinates(color.values, coordinates, order=1,
                                           mode="nearest", prefilter=False))
        values = np.concatenate(samples)
        if not len(values):
            raise ValueError("No isosurface crossings were found.")
        return float(values.min()), float(values.max())

    def scene(self, *, height, distances):
        """The molecule and box a viewer of this surface shows, shared by all its views.

        Args:
            height: Viewer height in pixels.
            distances: Pairs of one-based atom numbers measured in the scene.

        Returns:
            The viewer's scene settings, a mapping of the scene archive, frame count, requested frame, distances, height
            and bounds.
        """
        atoms = self.display_grids[0].atoms
        return {
            "scene": MolstarViewer._build_scene(xyz_frames(atoms[:, 0].astype(int), (atoms[None, :, 2:] * ureg.bohr).to("angstrom"))),
            "frame_count": 1,
            "requested": 1,
            "distances": MolstarViewer._distance_pairs(distances, len(atoms)),
            "height": height,
            "bounds": self.bounds.tolist(),
        }

    def view(self, *, color_range, colors, opacity):
        """Encode the surface's fields and look for one view of a viewer, without writing derived files.

        Args:
            color_range: The values at the lower and upper end of the colour scale.
            colors: Hexadecimal colours of the scale, from its lower to its upper end.
            opacity: Opacity of the surface, above zero and at most one.

        Returns:
            A mapping with the encoded ``field`` and ``color_field``, the ``isovalue`` and ``field_scale`` of the units
            the field is written in, ``signed``, the adjustable ``level_range`` (empty for a fixed level), ``opacity``,
            ``color_range`` and ``colors``.
        """
        grid, color = self.display_grids
        # A contour field is written so its isovalue is a round number, the units the viewer's fog is tuned in.
        unit = abs(self.isovalue) / 200
        def payload(source, knee, written):
            """A compressed field for the viewer to decode: its address in the store (``molstarview.store``), or
            without a store the base64 text of the bytes themselves.

            Args:
                source: The grid to encode.
                knee: The magnitude below which the encoding is linear.
                written: The unit the decoded field is written in.

            Returns:
                The field's address in the store, or its base64 text.
            """
            data = _encoded(source, knee, written)
            return store.address(data) or base64.b64encode(data).decode()

        return {
            "field": payload(grid, (self.lowest_level or abs(self.isovalue)) / 2, unit),
            # A colour field has no level, so its knee follows its own range.
            "color_field": payload(color, max(float(np.abs(color.values).max()), 1e-30) / 1000, 1.0) if color is not None else "",
            # In the units the field is written in.
            "isovalue": self.isovalue / unit,
            "field_scale": unit,
            "signed": self.signed,
            # The levels the settings may choose, in the units the field is written in: from the floor to just below
            # the largest magnitude, where the surface vanishes; empty for a fixed level.
            "level_range": [] if self.floor is None else [
                self.lowest_level / unit, 0.98 * float(np.abs(self.display_grids[0].values).max()) / unit],
            "opacity": opacity,
            "color_range": list(color_range),
            "colors": list(colors),
            "fields": [],
            "color_fields": [],
        }


def color_field_view(surfaces, *, isovalue, title, colors=("#d7301f", "#2b6cb0"), opacity=0.85, color_label="",
                     field_name="", field_symbol="", field_unit=""):
    """A view of the field that colours ``surfaces``, drawn in space as signed surfaces, for ``VolumeViewer``'s ``alternates``.

    The surfaces are at -``isovalue`` and +``isovalue`` in the colour field's units, in the end ``colors``; the
    settings lower the level to an eighth, as far as each field's box allows. An electrostatic potential on a density
    surface thus also shows where it is strongly negative or positive.

    Args:
        surfaces: One ``VolumeSurface`` or a mapping of snapshot titles to them, each with a colour grid.
        isovalue: The level of the signed surfaces, in the colour field's units.
        title: The title of the view, on the toolbar button that switches to it.
        colors: Hexadecimal colours of the negative and positive surfaces.
        opacity: Opacity of the surfaces, above zero and at most one.
        color_label: The quantity and unit shown above the colour scale.
        field_name: The name shown on the first line of a hover label; may hold ``$...$`` LaTeX.
        field_symbol: The symbol of the field, in LaTeX, before its value in hover labels.
        field_unit: The unit of the field, in LaTeX, after its value in hover labels.

    Returns:
        A mapping of the arguments ``VolumeViewer`` takes for an alternate view.
    """
    def in_space(surface):
        """The colour field of one surface as a signed surface of its own.

        Args:
            surface: A ``VolumeSurface`` with a colour grid.

        Returns:
            A signed, adjustable surface of the colour field in its units.
        """
        grid = surface.color_grid
        return VolumeSurface(grid=CubeGrid(grid.origin, grid.axes, grid.atoms, grid.values * surface.color_factor),
                             isovalue=isovalue, signed=True, floor=isovalue / 8)
    shown = {name: in_space(each) for name, each in surfaces.items()} if isinstance(surfaces, dict) else in_space(surfaces)
    return {"title": title, "surface": shown, "color_range": (-isovalue, isovalue), "colors": colors, "opacity": opacity,
            "color_label": color_label, "field_name": field_name, "field_symbol": field_symbol, "field_unit": field_unit}


class VolumeViewer(MolstarViewer):
    """Display one scalar surface, or several as native Molstar snapshots, in the native viewport.

    ``surface`` is one ``VolumeSurface`` or a mapping from snapshot titles to surfaces of the
    same molecule. Titles may contain ``$...$`` LaTeX, typeset in the snapshot selector and its list.
    Each snapshot shows its own geometry and surface, and the camera is shared. ``field_name``,
    ``field_symbol`` (LaTeX) and ``field_unit`` (LaTeX) name the field's quantity in hover labels; ``field_name`` may hold
    ``$...$`` LaTeX, and is left empty where the symbol already says it.
    """

    # The views of the field, each with its title, fields (``field`` and ``color_field`` for one surface, ``fields`` and
    # ``color_fields`` for snapshots), level, look and quantity; a toolbar button switches between several.
    views = traitlets.List(traitlets.Dict()).tag(sync=True)
    # The initial view fits the molecule; the field's box sets clipping.
    fit_atoms = traitlets.Bool(True).tag(sync=True)
    # Per snapshot, the colour and hover text of every atom shown by the composition button; empty for no button.
    snapshot_atoms = traitlets.List(traitlets.Dict()).tag(sync=True)
    # The colour scale of those atoms: its range, colours, label and description.
    atom_scale = traitlets.Dict().tag(sync=True)
    # Per snapshot, the colour-scale label and hover symbol of its field, when it differs from the view's; empty for none.
    snapshot_fields = traitlets.List(traitlets.Dict()).tag(sync=True)

    def __init__(self, surface, *, color_range=(-1.0, 1.0), colors=("#ff0000", "#ffffff", "#0000ff"), opacity=0.6,
                 height=440, distances=(), camera_bounds=None, color_label="", field_name="", field_symbol="",
                 field_unit="", title="", alternates=(), choices=(), atom_shares=None, atom_label="",
                 atom_colors=("#efedf5", "#9e9ac8", "#3f007d"), atom_title="Toggle Atom Shares",
                 surface_title="Toggle Surfaces", snapshot_fields=None):
        """Embed a scalar field with optional shared lower/upper clipping bounds in angstrom.

        A coloured surface shows its colour scale in the viewport, from the lower to the upper end of ``color_range``,
        with ``color_label``, the quantity and its unit, above it.

        Args:
            surface: One ``VolumeSurface``, or a mapping from snapshot titles to surfaces of the same molecule, each
                snapshot showing its own geometry and surface under one shared camera. Titles may contain ``$...$``
                LaTeX, typeset in the snapshot selector and its list. With ``choices`` the keys are tuples of one value
                per choice.
            color_range: The values at the lower and upper end of the colour scale.
            colors: Hexadecimal colours of the scale, from its lower to its upper end, at least two.
            opacity: Opacity of the surfaces, above zero and at most one.
            height: Viewer height in pixels.
            distances: Pairs of one-based atom numbers measured in the scene.
            camera_bounds: Lower and upper corners in angstrom that clip the scene, shared by viewers that are compared;
                by default the box of every view's field.
            color_label: The quantity and its unit above the colour scale, ``$...$`` LaTeX allowed. A label carrying a
                ``description``, as page quantities do, offers it from an info button.
            field_name: The name on the first line of a hover label, ``$...$`` LaTeX allowed; empty where the symbol
                already says it.
            field_symbol: The symbol of the field, in LaTeX, before its value in hover labels.
            field_unit: The unit of the field, in LaTeX, after its value in hover labels.
            title: The title of this view, on the toolbar button that switches to the next one when there are alternates.
            alternates: Further views of the same molecule, which a toolbar button switches to in turn, in place and with
                the camera kept. Each is a mapping of ``title``, ``surface`` (one ``VolumeSurface``, or a mapping with the
                same snapshot titles as ``surface``) and the look and quantity arguments of this view, as
                ``color_field_view`` builds them.
            choices: Pairs of ``(label, {value: text})``, or triples with flags, that replace the snapshot menu by one
                dropdown or field per axis, as in ``MolstarViewer``. ``surface`` then maps a tuple of one value per choice to each snapshot's surface, and
                each alternate maps the same tuples to its own surfaces.
            atom_shares: Per snapshot, in the order of ``surface``, one share per atom, such as its share of the
                snapshot's orbital, one hover text per atom with ``$...$`` LaTeX and optionally the key of its colour
                scale; snapshots with one key share a scale. A toolbar toggle then colours
                the atoms by their shares, from zero to the largest of any snapshot, another hides or shows the
                surfaces, and hovering an atom adds its text.
            atom_label: The quantity and unit above the atoms' colour scale, with its optional ``description``, or a
                mapping of each scale's key to its own.
            atom_colors: Hexadecimal colours of the atoms' scale, from zero to the largest share.
            atom_title: The title of the toggle of the atoms' colours, in Title Case as Molstar's own.
            surface_title: The title of the toggle of the surfaces, in Title Case as Molstar's own.
            snapshot_fields: Per snapshot, in the order of ``surface``, a pair of the colour-scale label and the hover
                symbol (LaTeX) of its field while it is shown, such as one atom's part of an orbital; the view's own
                label and symbol otherwise.

        Raises:
            ValueError: If choices are given without a mapping of surfaces, the camera bounds are not finite corners with
                positive extent, the views differ in snapshots or atoms, or the surfaces, colours, opacity or color range
                are invalid.
            TypeError: If a view's surface is not a ``VolumeSurface`` or a non-empty mapping of them.
            ValueError: If atom shares are given without snapshots, or are not one finite share and one text per atom of
                each snapshot, or the snapshot fields are not one pair per snapshot.
        """
        axes, indices = None, None
        if choices:
            if not isinstance(surface, dict):
                raise ValueError("Choices select among the snapshots of one view.")
            axes, indices, titles = choice_axes(surface, choices)
            # Each alternate keys its snapshots as the first view does, and takes the same titles.
            alternates = [{**view, "surface": dict(zip(titles, view["surface"].values()))
                           if isinstance(view["surface"], dict) and list(view["surface"]) == list(surface) else view["surface"]}
                          for view in alternates]
            surface = dict(zip(titles, surface.values()))
        if camera_bounds is not None:
            camera_bounds = np.asarray(camera_bounds, dtype=float)
            if (camera_bounds.shape != (2, 3) or not np.isfinite(camera_bounds).all()
                    or np.any(camera_bounds[0] >= camera_bounds[1])):
                raise ValueError("Camera bounds must be finite lower/upper XYZ corners with positive extent.")
        first = {"title": title, "surface": surface, "color_range": color_range, "colors": colors, "opacity": opacity,
                 "color_label": color_label, "field_name": field_name, "field_symbol": field_symbol, "field_unit": field_unit}
        shown = [self._surfaces(view["surface"]) for view in (first, *alternates)]
        if any(list(each) != list(shown[0]) for each in shown) or (isinstance(surface, dict) and any(
                not isinstance(view["surface"], dict) for view in alternates)):
            raise ValueError("Every view must have the same snapshots as the first.")
        atoms = [next(iter(each.values())).display_grids[0].atoms for each in shown]
        if any(not np.array_equal(a, atoms[0]) for a in atoms):
            raise ValueError("Every view must describe the same atoms.")
        snapshots = isinstance(surface, dict)
        settings = (self._snapshot_scene(shown[0], height=height, distances=distances) if snapshots
                    else surface.scene(height=height, distances=distances))
        views = self._packed([self._view(each, snapshots, **view)
                              for each, view in zip(shown, (first, *alternates), strict=True)])
        # The camera's clipping covers every view's field, unless bounds are given.
        bounds = np.stack([np.asarray(self._bounds(each)) for each in shown])
        settings["bounds"] = (camera_bounds.tolist() if camera_bounds is not None
                              else [bounds[:, 0].min(axis=0).tolist(), bounds[:, 1].max(axis=0).tolist()])
        if axes:
            settings.update(choices=[dict(label=label, options=list(options.values()), **flags) for label, options, flags in axes],
                            snapshot_choices=indices)
        if atom_shares is not None:
            settings.update(self._atom_shares(atom_shares, len(shown[0]) if snapshots else 0, len(atoms[0]), atom_label,
                                              atom_colors))
            settings["atom_scale"].update(title=str(atom_title), surface_title=str(surface_title))
        if snapshot_fields is not None:
            if not snapshots or len(snapshot_fields) != len(shown[0]):
                raise ValueError("Give one field label and symbol per snapshot.")
            settings["snapshot_fields"] = [{"label": str(label), "symbol": str(symbol)} for label, symbol in snapshot_fields]
        anywidget.AnyWidget.__init__(self, views=views, **settings)

    @staticmethod
    def _atom_shares(shares, snapshots, count, label, colors):
        """The colours and hover texts of the atoms of each snapshot, and the colour scale of each kind of share.

        Args:
            shares: Per snapshot, one share per atom and one hover text per atom, and optionally the key of its colour
                scale, such as one per part of an orbital; snapshots with one key share a scale from zero to their
                largest share.
            snapshots: The number of snapshots, zero for a single surface.
            count: The number of atoms.
            label: The quantity and unit above the colour scale, with its optional ``description``, or a mapping of
                each scale's key to its own.
            colors: Hexadecimal colours of the scales, from zero to the largest share.

        Returns:
            The settings ``snapshot_atoms``, the colours, texts and scale of each snapshot's atoms, and ``atom_scale``
            with each scale's range, colours and label under ``scales``.

        Raises:
            ValueError: If there are no snapshots, the shares do not match them, or a snapshot does not give one finite
                share and one text per atom.
        """
        shares = [(np.asarray(item[0], dtype=float), [str(text) for text in item[1]], str(item[2]) if len(item) > 2 else "")
                  for item in shares]
        if not snapshots or len(shares) != snapshots:
            raise ValueError("Give one pair of atom shares and texts per snapshot.")
        if any(values.shape != (count,) or not np.isfinite(values).all() or len(texts) != count for values, texts, _ in shares):
            raise ValueError("Give one finite share and one text per atom.")
        labels = label if isinstance(label, dict) else {}
        scales = {}
        for key in dict.fromkeys(key for *_, key in shares):
            upper = max(float(values.max()) for values, _, other in shares if other == key)
            name = labels.get(key, label if not isinstance(label, dict) else "")
            scales[key] = {"color_range": [0.0, upper if upper > 0 else 1.0], "colors": list(colors),
                           "color_label": str(name), "color_description": getattr(name, "description", "") or ""}
        return {"snapshot_atoms": [{"colors": MolstarViewer._atom_colors(values, count, tuple(scales[key]["color_range"]),
                                                                         colors)[0], "details": texts, "scale": key}
                                   for values, texts, key in shares],
                "atom_scale": {"scales": scales}}

    @staticmethod
    def _surfaces(surface):
        """One surface or a mapping of snapshot titles to surfaces, as a mapping, checked.

        Args:
            surface: A ``VolumeSurface`` or a mapping of titles to them.

        Returns:
            The mapping, with a single surface under the empty title.

        Raises:
            TypeError: If the surface is neither a ``VolumeSurface`` nor a non-empty mapping of them.
            ValueError: If a snapshot title is empty.
        """
        if isinstance(surface, dict):
            if not surface or not all(isinstance(s, VolumeSurface) for s in surface.values()):
                raise TypeError("Supply a non-empty mapping of titles to VolumeSurface objects.")
            if not all(isinstance(title, str) and title.strip() for title in surface):
                raise ValueError("Each snapshot needs a non-empty title.")
            return dict(surface)
        if not isinstance(surface, VolumeSurface):
            raise TypeError("Supply one VolumeSurface or a mapping of titles to them.")
        return {"": surface}

    @staticmethod
    def _bounds(surfaces):
        """Lower and upper corners enclosing every surface's displayed field.

        Args:
            surfaces: A mapping of snapshot titles to surfaces.

        Returns:
            The lower and upper corner in angstrom, as lists of three numbers.
        """
        bounds = np.stack([surface.bounds for surface in surfaces.values()])
        return [bounds[:, 0].min(axis=0).tolist(), bounds[:, 1].max(axis=0).tolist()]

    @staticmethod
    def _packed(views):
        """The views with their stored fields packed into few files (``molstarview.store.pack``), in the order the
        viewer shows them: each snapshot's field and colour field in every view, so the snapshots a reader steps
        through and the views of one snapshot share their files.

        Args:
            views: The views, as ``_view`` returns them.

        Returns:
            The same views with packed addresses.
        """
        count = max(len(view["fields"]) for view in views)
        order = [view[key] for view in views for key in ("field", "color_field")]
        order += [view[key][index] for index in range(count) for view in views for key in ("fields", "color_fields")
                  if index < len(view[key])]
        packed = store.pack(order)
        swap = lambda text: packed.get(text, text)
        return [dict(view, field=swap(view["field"]), color_field=swap(view["color_field"]),
                     fields=[swap(text) for text in view["fields"]], color_fields=[swap(text) for text in view["color_fields"]])
                for view in views]

    @staticmethod
    def _view(surfaces, snapshots, *, title, surface, color_range, colors, opacity, color_label="", field_name="",
              field_symbol="", field_unit=""):
        """One view: its title, the encoded fields of its surfaces, its level settings, look and quantity.

        Args:
            surfaces: A mapping of snapshot titles to surfaces.
            snapshots: Whether the surfaces are snapshots, each with its own encoded field.
            title: The view's title.
            surface: The view's surface or surfaces, as given by the caller.
            color_range: The values at the lower and upper end of the colour scale.
            colors: Hexadecimal colours of the scale.
            opacity: Opacity of the surfaces.
            color_label: The quantity and unit above the colour scale, with its optional ``description``.
            field_name: The name on the first line of a hover label.
            field_symbol: The symbol of the field in hover labels.
            field_unit: The unit of the field in hover labels.

        Returns:
            The view as the browser takes it, with the first surface's encoding, the fields of every snapshot, the level range
            that every snapshot can reach, and the labels.

        Raises:
            ValueError: If the opacity or colour range is invalid, fewer than two colours are given or one is not
                hexadecimal, or only some snapshot surfaces have an adjustable level.
        """
        if not 0 < opacity <= 1 or len(color_range) != 2 or not color_range[0] < color_range[1]:
            raise ValueError("Specify a positive opacity and an increasing color range.")
        if len(colors) < 2 or any(re.fullmatch(r"#[0-9a-fA-F]{6}", c) is None for c in colors):
            raise ValueError("Supply at least two hexadecimal colors.")
        encoded = [each.view(color_range=color_range, colors=colors, opacity=opacity) for each in surfaces.values()]
        view = dict(encoded[0])
        if snapshots:
            ranges = [item["level_range"] for item in encoded]
            if any(ranges) and not all(ranges):
                raise ValueError("Either every snapshot surface has an adjustable level or none has.")
            # Every snapshot's floor is reachable, and the strongest field sets the top.
            view.update(level_range=[max(r[0] for r in ranges), max(r[1] for r in ranges)] if all(ranges) else [],
                        field="", color_field="", fields=[item["field"] for item in encoded],
                        color_fields=[item["color_field"] for item in encoded])
        view.update(title=title, color_label=str(color_label), color_description=getattr(color_label, "description", "") or "",
                    field_name=field_name, field_symbol=field_symbol, field_unit=field_unit)
        return view

    @staticmethod
    def _snapshot_scene(surfaces, *, height, distances):
        """The molecule of several surfaces as frames of one trajectory, one native snapshot each.

        Args:
            surfaces: A mapping of snapshot titles to surfaces of the same atoms.
            height: Viewer height in pixels.
            distances: Pairs of one-based atom numbers measured in the scene.

        Returns:
            The viewer's scene settings, a mapping of the scene archive, frame count, requested frame, distances, height
            and snapshot titles.

        Raises:
            ValueError: If the surfaces do not describe the same atoms in the same order.
        """
        atoms = [surface.display_grids[0].atoms for surface in surfaces.values()]
        if any(not np.array_equal(a[:, 0], atoms[0][:, 0]) for a in atoms):
            raise ValueError("Snapshot surfaces must describe the same atoms in the same order.")
        # Each geometry becomes one frame, so native distances follow the displayed snapshot.
        frames = xyz_frames(atoms[0][:, 0].astype(int),
                            (np.stack([a[:, 2:] for a in atoms]) * ureg.bohr).to("angstrom"))
        return {"scene": MolstarViewer._build_scene(frames), "frame_count": len(surfaces), "requested": 1,
                "distances": MolstarViewer._distance_pairs(distances, len(atoms[0])), "height": height,
                "snapshots": [title.strip() for title in surfaces]}

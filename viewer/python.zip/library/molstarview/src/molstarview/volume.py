"""Generic cube-grid isosurfaces, scalar color mapping and persistent comparisons."""

import base64
import gzip
import hashlib
import os
import re
from dataclasses import dataclass
from functools import cached_property, lru_cache
from io import StringIO
from itertools import product
from pathlib import Path
from textwrap import dedent

import anywidget
import numpy as np
import traitlets
from runflow.results import ureg, xyz_frames

from .viewer import MolstarViewer


# Relative rounding of a contour field's compact encoding: about 0.2 % of the value at every level, which keeps surface
# normals within a fraction of a degree of the unrounded field's at every level.
COMPACT_STEP = 0.002

# Encoded fields, reused by their grid content while the encoder is unchanged: a page carries each field once, and
# compressing one took most of a volume page's render.
VOLUMES = Path.home() / ".cache/research-findings/volumes"


@lru_cache(maxsize=1)
def _encoder_digest():
    """Digest of this module's source, so an encoding change invalidates every cached field."""
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def _payload_key(source, encoding):
    """Cache name of one encoded field, by the grid it writes and the step, knee and unit of its encoding."""
    digest = hashlib.sha256()
    for array in (source.origin, source.axes, source.atoms, source.values):
        contiguous = np.ascontiguousarray(array)
        digest.update(f"{contiguous.dtype}|{contiguous.shape}|".encode())
        digest.update(contiguous.tobytes())
    digest.update(f"{encoding!r}|{_encoder_digest()}".encode())
    return digest.hexdigest()


@dataclass(frozen=True)
class CubeGrid:
    """A single scalar grid, with Gaussian cube coordinates in bohr."""

    origin: np.ndarray
    axes: np.ndarray
    atoms: np.ndarray
    values: np.ndarray

    @classmethod
    def read(cls, path):
        """Read a positive-axis, single-field Gaussian cube without altering it."""
        with path.open() as stream:
            next(stream)
            next(stream)
            head = next(stream).split()
            count = int(head[0])
            origin = np.asarray(head[1:4], dtype=float)
            grid = np.asarray([next(stream).split() for _ in range(3)], dtype=float)
            if count <= 0 or (grid[:, 0] <= 0).any():
                raise ValueError("Expected a scalar Gaussian cube with positive bohr axes.")
            atoms = np.asarray([next(stream).split() for _ in range(count)], dtype=float)
            values = np.fromstring(stream.read(), sep=" ")
        shape = tuple(grid[:, 0].astype(int))
        if values.size != np.prod(shape) or not np.isfinite(values).all():
            raise ValueError("The cube has an incomplete or non-finite scalar grid.")
        return cls(origin, grid[:, 1:], atoms, values.reshape(shape))

    def text(self, *, values=True):
        """Serialize the grid in memory for Molstar's native cube parser, or only its header without ``values``."""
        header = ["Molecular scalar field", "Coordinates in bohr",
                  f"{len(self.atoms)} " + " ".join(f"{v:.9f}" for v in self.origin)]
        header.extend(f"{size} " + " ".join(f"{v:.9f}" for v in axis)
                      for size, axis in zip(self.values.shape, self.axes, strict=True))
        header.extend(f"{int(row[0])} " + " ".join(f"{v:.9f}" for v in row[1:]) for row in self.atoms)
        header_text = "\n".join(header)
        if not values:
            return header_text + "\n"
        buffer = StringIO()
        samples = self.values.ravel()
        complete = samples.size // 6 * 6
        np.savetxt(buffer, samples[:complete].reshape(-1, 6), fmt="%.8E")
        if complete < samples.size:
            np.savetxt(buffer, samples[complete:][None, :], fmt="%.8E")
        template = dedent("""
            {header}
            {values}
            """).lstrip()
        return template.format(header=header_text, values=buffer.getvalue().rstrip())


    def compact(self, knee, step, unit):
        """The field as gzipped bytes for the viewer's ``decodeField``: its cube header, then integer samples.

        The viewer writes the decoded field in multiples of ``unit``, the units its settings use.

        Each sample is u = rint(asinh(v / knee) / step), so the rounding error is the same fraction of the value at
        every level above the knee, instead of the same absolute step, which leaves few steps below a low level. Samples
        are stored as little-endian 16-bit differences along the fastest axis, where a smooth field compresses well.
        """
        samples = np.rint(np.arcsinh(self.values / knee) / step)
        if np.abs(samples).max() >= 2**15:
            raise ValueError("The field's range does not fit the compact encoding at this step.")
        differences = np.diff(samples.astype("<i2"), axis=-1, prepend=0).astype("<i2")
        header = self.text(values=False).encode()
        return gzip.compress(np.uint32(len(header)).astype("<u4").tobytes() + np.asarray([knee / unit, step], "<f8").tobytes()
                             + header + differences.tobytes(), compresslevel=6)


@dataclass(frozen=True, kw_only=True)
class VolumeSurface:
    """A scalar isosurface with an optional registered field for color mapping."""

    grid: CubeGrid
    isovalue: float
    color_grid: CubeGrid | None = None
    color_factor: float = 1.0
    # Whether the surface is drawn at both +isovalue and -isovalue of a signed field such as an orbital, in the
    # negative and positive end colours, instead of at one isovalue.
    signed: bool = False
    # Smallest contour level the viewer's settings may choose, which keeps every point at or above it in the
    # displayed box; None fixes the surface at ``isovalue``.
    floor: float | None = None

    def __post_init__(self):
        """Require finite contour parameters and matched source grids for scalar coloring."""
        if not np.isfinite(self.isovalue) or not np.isfinite(self.color_factor):
            raise ValueError("Contour level and color conversion must be finite.")
        if self.floor is not None and not 0 < self.floor <= abs(self.isovalue):
            raise ValueError("An adjustable level needs a floor between zero and the isovalue.")
        if self.color_grid is not None:
            for attribute in ("origin", "axes", "atoms"):
                if not np.array_equal(getattr(self.grid, attribute), getattr(self.color_grid, attribute)):
                    raise ValueError(f"Surface and color field have different {attribute}.")
            if self.grid.values.shape != self.color_grid.values.shape:
                raise ValueError("Surface and color fields must share their source grid.")

    @cached_property
    def lowest_level(self):
        """The smallest level the settings may choose: the floor, raised just above the largest magnitude near the
        source grid's faces when the field there exceeds it, so no chosen surface or fog reaches the grid's edge;
        None for a fixed level."""
        if self.floor is None:
            return None
        # The outer three layers: the displayed box adds two layers around the chosen region and must stay inside.
        values = np.abs(self.grid.values)
        faces = max(float(values.take(layers, axis).max()) for axis in range(3) for layers in ([0, 1, 2], [-3, -2, -1]))
        return min(max(self.floor, 1.05 * faces), abs(self.isovalue))

    @cached_property
    def display_grids(self):
        """Crop vacuum and retain the original coloring samples; the viewer makes the surface smooth from this grid."""
        # The box holds every point a chosen level can reach: those at or above the floor of an adjustable one.
        level = self.isovalue if self.floor is None else np.copysign(self.lowest_level, self.isovalue)
        if self.signed:
            mask = np.abs(self.grid.values) >= abs(level)
        else:
            mask = self.grid.values >= level if level >= 0 else self.grid.values <= level
        # Project the mask onto each axis instead of allocating coordinates for every occupied voxel.
        occupied = [np.flatnonzero(mask.any(axis=tuple(j for j in range(3) if j != axis))) for axis in range(3)]
        if not len(occupied[0]):
            raise ValueError("The grid does not contain the requested isosurface.")
        lower = np.maximum([axis[0] - 2 for axis in occupied], 0)
        upper = np.minimum([axis[-1] + 3 for axis in occupied], self.grid.values.shape)
        if np.any(lower == 0) or np.any(upper == self.grid.values.shape):
            raise ValueError("The isosurface approaches the original cube boundary.")
        window = tuple(slice(int(a), int(b)) for a, b in zip(lower, upper, strict=True))
        origin = self.grid.origin + lower @ self.grid.axes
        contour = CubeGrid(origin, self.grid.axes, self.grid.atoms, self.grid.values[window])
        color = None if self.color_grid is None else CubeGrid(origin, self.grid.axes,
            self.grid.atoms, self.color_grid.values[window] * self.color_factor)
        return contour, color

    @cached_property
    def bounds(self):
        """Return lower and upper Cartesian corners of the displayed field in angstrom."""
        grid, _ = self.display_grids
        corners = np.asarray(list(product(*[(0, size - 1) for size in grid.values.shape])))
        positions = (
            (grid.origin + corners @ grid.axes) * ureg.bohr
        ).to("angstrom").magnitude
        return np.asarray([positions.min(axis=0), positions.max(axis=0)])

    def color_limits(self):
        """Sample the color field at contour crossings using native trilinear interpolation."""
        from scipy.ndimage import map_coordinates

        grid, color = self.display_grids
        if color is None:
            raise ValueError("A scalar color field is required to derive color limits.")
        samples = []
        for axis in range(3):
            lower, upper = [slice(None)] * 3, [slice(None)] * 3
            lower[axis], upper[axis] = slice(None, -1), slice(1, None)
            first, second = grid.values[tuple(lower)], grid.values[tuple(upper)]
            mask = ((first < self.isovalue) != (second < self.isovalue))
            coordinates = np.asarray(np.nonzero(mask), dtype=float)
            coordinates[axis] += (self.isovalue - first[mask]) / (second[mask] - first[mask])
            samples.append(map_coordinates(color.values, coordinates, order=1,
                                           mode="nearest", prefilter=False))
        values = np.concatenate(samples)
        if not len(values):
            raise ValueError("No isosurface crossings were found.")
        return float(values.min()), float(values.max())

    def settings(self, *, color_range, colors, opacity, height, distances):
        """Encode a scalar surface for Molstar without writing derived files."""
        grid, color = self.display_grids
        atoms = grid.atoms
        # A contour field is written so its isovalue is a round number, the units the viewer's fog is tuned in.
        unit = abs(self.isovalue) / 200
        def payload(source, knee, written):
            """Compress a field in memory for the viewer to decode, written in multiples of ``written``, with its
            encoding reused from the disk cache by the grid's content."""
            cached = VOLUMES / f"{_payload_key(source, (COMPACT_STEP, knee, written))}.b64"
            try:
                return cached.read_text()
            except OSError:
                pass
            encoded = base64.b64encode(source.compact(knee, COMPACT_STEP, written)).decode()
            try:
                VOLUMES.mkdir(parents=True, exist_ok=True)
                # Written beside its final name and moved, so a parallel reader never sees half a file.
                partial = cached.with_suffix(f".{os.getpid()}.part")
                partial.write_text(encoded)
                partial.replace(cached)
            except OSError:
                pass  # A read-only cache, as in the browser's memory file system, leaves the field uncached.
            return encoded

        return {
            "scene": MolstarViewer._build_scene(
                xyz_frames(
                    atoms[:, 0].astype(int),
                    (atoms[None, :, 2:] * ureg.bohr).to("angstrom"),
                )
            ),
            "frame_count": 1,
            "requested": 1,
            "distances": MolstarViewer._distance_pairs(distances, len(atoms)),
            "height": height,
            "bounds": self.bounds.tolist(),
            "field": payload(grid, (self.lowest_level or abs(self.isovalue)) / 2, unit),
            # A colour field has no level, so its knee follows its own range.
            "color_field": payload(color, max(float(np.abs(color.values).max()), 1e-30) / 1000, 1.0) if color is not None else "",
            # In the units the field is written in.
            "isovalue": self.isovalue / unit,
            "field_scale": unit,
            "signed": self.signed,
            # The levels the settings may choose, in the units the field is written in: from the floor to just below
            # the largest magnitude, where the surface vanishes; empty for a fixed level.
            "level_range": [] if self.floor is None else [
                self.lowest_level / unit, 0.98 * float(np.abs(self.display_grids[0].values).max()) / unit],
            "opacity": opacity,
            "color_range": list(color_range),
            "colors": list(colors),
        }


class VolumeViewer(MolstarViewer):
    """Display one scalar surface, or several as native Molstar snapshots, in the native viewport.

    ``surface`` is one ``VolumeSurface`` or a mapping from snapshot titles to surfaces of the
    same molecule. Titles may contain ``$...$`` LaTeX, typeset in the snapshot selector and its list.
    Each snapshot shows its own geometry and surface, and the camera is shared. ``field_name``,
    ``field_symbol`` (LaTeX) and ``field_unit`` (LaTeX) name the field's quantity in hover labels.
    """

    field = traitlets.Unicode().tag(sync=True)
    color_field = traitlets.Unicode("").tag(sync=True)
    fields = traitlets.List(traitlets.Unicode()).tag(sync=True)
    color_fields = traitlets.List(traitlets.Unicode()).tag(sync=True)
    isovalue = traitlets.Float().tag(sync=True)
    # Lower and upper contour levels the settings panel offers, in the field's written units; empty for none.
    level_range = traitlets.List(traitlets.Float()).tag(sync=True)
    # Surfaces at both signs of the isovalue, in the first and last colours.
    signed = traitlets.Bool(False).tag(sync=True)
    opacity = traitlets.Float(0.6).tag(sync=True)
    # The initial view fits the molecule; the field's box sets clipping.
    fit_atoms = traitlets.Bool(True).tag(sync=True)

    def __init__(self, surface, *, color_range=(-1.0, 1.0),
                 colors=("#ff0000", "#ffffff", "#0000ff"), opacity=0.6,
                 height=440, distances=(), camera_bounds=None, color_label="", field_name="", field_symbol="",
                 field_unit=""):
        """Embed a scalar field with optional shared lower/upper clipping bounds in angstrom.

        A coloured surface shows its colour scale in the viewport, from the lower to the upper end of
        ``color_range``, with ``color_label``, the quantity and its unit, above it; ``$...$`` in it is LaTeX.
        """
        surfaces = dict(surface) if isinstance(surface, dict) else None
        if surfaces is not None:
            if not surfaces or not all(isinstance(s, VolumeSurface) for s in surfaces.values()):
                raise TypeError("Supply a non-empty mapping of titles to VolumeSurface objects.")
            if not all(isinstance(title, str) and title.strip() for title in surfaces):
                raise ValueError("Each snapshot needs a non-empty title.")
        elif not isinstance(surface, VolumeSurface):
            raise TypeError("Supply one VolumeSurface or a mapping of titles to them.")
        if not 0 < opacity <= 1 or len(color_range) != 2 or not color_range[0] < color_range[1]:
            raise ValueError("Specify a positive opacity and an increasing color range.")
        if len(colors) < 2 or any(re.fullmatch(r"#[0-9a-fA-F]{6}", c) is None for c in colors):
            raise ValueError("Supply at least two hexadecimal colors.")
        if camera_bounds is not None:
            camera_bounds = np.asarray(camera_bounds, dtype=float)
            if (camera_bounds.shape != (2, 3) or not np.isfinite(camera_bounds).all()
                    or np.any(camera_bounds[0] >= camera_bounds[1])):
                raise ValueError("Camera bounds must be finite lower/upper XYZ corners with positive extent.")
        if surfaces is None:
            settings = surface.settings(color_range=color_range, colors=colors,
                opacity=opacity, height=height, distances=distances)
        else:
            settings = self._snapshot_settings(surfaces, color_range=color_range, colors=colors,
                opacity=opacity, height=height, distances=distances)
        if camera_bounds is not None:
            settings["bounds"] = camera_bounds.tolist()
        settings.update(color_label=str(color_label), color_description=getattr(color_label, "description", "") or "",
                        field_name=field_name, field_symbol=field_symbol, field_unit=field_unit)
        anywidget.AnyWidget.__init__(self, **settings)

    @staticmethod
    def _snapshot_settings(surfaces, **options):
        """Encode several surfaces as frames of one trajectory, one native snapshot each."""
        encoded = [surface.settings(**options) for surface in surfaces.values()]
        atoms = [surface.display_grids[0].atoms for surface in surfaces.values()]
        if any(not np.array_equal(a[:, 0], atoms[0][:, 0]) for a in atoms):
            raise ValueError("Snapshot surfaces must describe the same atoms in the same order.")
        # Each geometry becomes one frame, so native distances follow the displayed snapshot.
        frames = xyz_frames(atoms[0][:, 0].astype(int),
                            (np.stack([a[:, 2:] for a in atoms]) * ureg.bohr).to("angstrom"))
        bounds = np.stack([surface.bounds for surface in surfaces.values()])
        settings = dict(encoded[0])
        ranges = [item["level_range"] for item in encoded]
        if any(ranges) and not all(ranges):
            raise ValueError("Either every snapshot surface has an adjustable level or none has.")
        settings.update(
            # Every snapshot's floor is reachable, and the strongest field sets the top.
            level_range=[max(r[0] for r in ranges), max(r[1] for r in ranges)] if all(ranges) else [],
            scene=MolstarViewer._build_scene(frames),
            frame_count=len(surfaces),
            bounds=[bounds[:, 0].min(axis=0).tolist(), bounds[:, 1].max(axis=0).tolist()],
            field="", color_field="",
            fields=[item["field"] for item in encoded],
            color_fields=[item["color_field"] for item in encoded],
            snapshots=[title.strip() for title in surfaces],
        )
        return settings

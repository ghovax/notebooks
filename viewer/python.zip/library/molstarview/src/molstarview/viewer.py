"""Python interface to MolViewSpec scenes and Molstar's measurement manager."""

from pathlib import Path
from textwrap import dedent
from collections.abc import Mapping
from numbers import Integral
import base64

import anywidget
import molviewspec as mvs
from molviewspec.nodes import ComponentExpression
import numpy as np
import traitlets



class MolstarViewer(anywidget.AnyWidget):
    """Display XYZ frames with native atom-pair distances and one persistent camera.

    Atom pairs and frames are one-based. ``frame`` confirms the displayed frame;
    ``error`` reports a browser-side load failure. Distances use angstrom.

    ``groups`` is a sequence of mappings with ``label`` (inline Markdown with optional
    ``$...$`` LaTeX, drawn as a text overlay at the group's centroid and shown when hovering its atoms) and ``atoms``
    (one-based, disjoint atom numbers). Atom colours and representations stay Molstar's defaults.

    Hovering shows the viewer's own labels in Molstar's highlight box: the atom, bond, measurement or field value
    under the pointer, written in words with ``$...$`` LaTeX.

    ``arrows`` is a sequence of mappings with ``start`` and ``end`` (angstrom, in the
    frames' coordinates) and optional ``color`` (``#rrggbb``) and ``tooltip`` (plain
    text). Each becomes a native MolViewSpec arrow primitive, for example a
    displacement field drawn on a structure.

    ``atom_values`` gives one number per atom, such as a partial charge. Atoms are then drawn as balls and sticks
    coloured on the ``colors`` scale from the lower to the upper end of ``color_range`` (symmetric about zero by
    default), with ``color_label``, the quantity and its unit, above a colour scale in the viewport. Each atom's
    hover label adds its entry of ``atom_details`` (text with ``$...$`` LaTeX), such as its charge.
    """

    _esm = Path(__file__).parent / "static" / "viewer.js"
    _css = Path(__file__).parent / "static" / "viewer.css"
    scene = traitlets.Unicode().tag(sync=True)
    frame_count = traitlets.Int().tag(sync=True)
    distances = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)
    # One-based atom triples of native angle measurements, the vertex in the middle.
    angles = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)
    # Virtual atoms drawn as small spheres: atoms, colour, size and label of each group.
    markers = traitlets.List(traitlets.Dict()).tag(sync=True)
    # Measurements whose native number is replaced by a readout drawn in front of the scene: their kind and atoms.
    readouts = traitlets.List(traitlets.Dict()).tag(sync=True)
    bounds = traitlets.List(traitlets.List(traitlets.Float())).tag(sync=True)
    height = traitlets.Int(440).tag(sync=True)
    requested = traitlets.Int(1).tag(sync=True)
    frame = traitlets.Int(0).tag(sync=True)
    error = traitlets.Unicode("").tag(sync=True)
    annotations = traitlets.List(traitlets.Dict()).tag(sync=True)
    snapshots = traitlets.List(traitlets.Unicode()).tag(sync=True)
    segments = traitlets.List(traitlets.Int()).tag(sync=True)
    # Dropdowns that together select a snapshot: each has a label and its option texts, and ``snapshot_choices`` gives
    # every snapshot's option index on each of them.
    choices = traitlets.List(traitlets.Dict()).tag(sync=True)
    snapshot_choices = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)
    # Named, one-based frames available from the trajectory controls.
    frame_labels = traitlets.List(traitlets.Dict()).tag(sync=True)
    # Whether faded copies of the frames behind the shown one follow it, toggled from the toolbar.
    trail = traitlets.Bool(False).tag(sync=True)
    # Trail copies per 0.1 angstrom moved by the fastest atom.
    trail_density = traitlets.Float(1.0).tag(sync=True)
    # The zero-based frames each frame range draws as trail copies.
    trail_frames = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)
    # Per-atom colours of an atom-valued quantity, with its colour scale; empty for Molstar's element colours.
    atom_colors = traitlets.List(traitlets.Unicode()).tag(sync=True)
    color_range = traitlets.List(traitlets.Float()).tag(sync=True)
    colors = traitlets.List(traitlets.Unicode()).tag(sync=True)
    # Quantity and unit of the colour scale, shown above it.
    color_label = traitlets.Unicode("").tag(sync=True)
    # Explanation of that quantity, Markdown with $...$ LaTeX, opened from an info button beside the label; empty for
    # none. A label carrying a ``description``, as page quantities do, supplies it.
    color_description = traitlets.Unicode("").tag(sync=True)
    # Hover details of each atom, LaTeX allowed; empty for none.
    atom_details = traitlets.List(traitlets.Unicode()).tag(sync=True)
    # A volume's quantity for hover labels: its name, LaTeX symbol and unit, and the factor turning stored values
    # into that unit.
    field_name = traitlets.Unicode("").tag(sync=True)
    field_symbol = traitlets.Unicode("").tag(sync=True)
    field_unit = traitlets.Unicode("").tag(sync=True)
    field_scale = traitlets.Float(1.0).tag(sync=True)

    def __init__(self, frames, *, distances=(), height=440, groups=(), arrows=(), trail=None, trail_density=1.0,
                 atom_values=None, atom_details=None, color_range=None, colors=("#d7301f", "#ffffff", "#2b6cb0"),
                 color_label="", frame_labels=None, choices=None, snapshot_frame_labels=None,
                 angles=(), markers=(), readouts=()):
        """Validate matching XYZ frames and prepare one native trajectory.

        ``frames`` may instead map snapshot titles to their own frame sequences of the same atoms: each becomes
        a native snapshot that plays its frames alone; titles may contain ``$...$`` LaTeX, typeset in the selector
        and its list. With ``trail`` faded copies of the molecule along the shown
        range fade with their distance from the shown frame as a motion blur, shown by a Motion trail toggle that
        starts off. Copies are placed by how far atoms move, so a path that lingers gets few and a large motion gets
        many: ``trail_density`` copies per 0.1 angstrom moved by the fastest atom. The toggle is offered whenever there is more than one frame; pass ``trail=False`` to leave it out.
        ``frame_labels`` maps descriptive labels to one-based frame numbers for the frame selector. An input sequence
        may also carry a ``frame_labels`` mapping; an explicit argument takes precedence.

        ``choices`` replaces the single snapshot menu by one dropdown per axis, so a snapshot per combination needs
        no menu entry per combination: a sequence of ``(label, options)`` pairs, ``label`` inline Markdown with
        optional ``$...$`` LaTeX and ``options`` a mapping of each value to its displayed text. ``frames`` then maps
        a tuple of one value per choice to that snapshot's frame sequence. Choosing a value on one dropdown shows the
        snapshot with it that keeps the earlier dropdowns and agrees with the later ones on the most of them. An
        earlier dropdown limits the options of the later ones to combinations that have a snapshot, so a combination
        without one cannot be chosen.

        ``angles`` is a sequence of one-based atom triples, the vertex in the middle, registered as native angle
        measurements like the distances. ``markers`` is a sequence of mappings with ``atoms`` (one-based), ``color``
        (``#rrggbb``), optional ``visible`` (``False`` for a point that only anchors a measurement, such as the end of an
        angle's arm, and is not drawn at all), optional ``size`` (a fraction of the van der Waals radius, default 0.09, about a hydrogen's drawn size) and ``label`` (hover
        text): those atoms are virtual points, such as a pivot appended to every frame, drawn as small spheres without
        bonds so that measurements can attach to positions that are not atoms. The other atoms are drawn as balls and
        sticks in the usual colours; markers cannot be combined with ``atom_values``.

        ``readouts`` replaces the number of a native measurement by a label drawn in front of the scene at every frame,
        so it can neither hide behind an atom nor carry superfluous decimals: a sequence of mappings with ``kind``
        (``"distance"`` or ``"angle"``), the measurement's ``atoms``, a ``label`` symbol in LaTeX, and for a distance
        its ``unit`` and optionally the ``position`` along it of the label (default 0.5). ``offset`` moves the label on the screen by ``(across, down)`` label heights, to keep readouts that lie close
        together apart. ``size`` is the label's height in angstrom at the
        scene's depth (default 0.28, a little more than Molstar's own numbers once typeset). The label reads
        r = 1.70 Å or θ = 90°, typeset in LaTeX, an angle without trailing zeros, and stands inside an
        angle, a third of the way along its shorter arm; an arm shorter than 1e-6 angstrom counts as perpendicular to
        the other, as when a point projected onto a plane meets it. A marker's ``label`` is a LaTeX symbol, which
        names its atom in hover labels.

        ``snapshot_frame_labels`` names frames of the snapshots: a mapping of labels to one-based frame numbers
        within a snapshot, negative numbers counting from its end, the same for every snapshot, or a mapping of each
        snapshot's key to its own, such as a last frame named for what the optimization reached. The frame menu then offers the labels of the shown snapshot only.
        """
        frame_labels = getattr(frames, "frame_labels", {}) if frame_labels is None else frame_labels
        snapshots, axes, snapshot_choices = {}, [], []
        if choices and not isinstance(frames, dict):
            raise ValueError("Choices select among snapshots: map each combination of values to its frame sequence.")
        if isinstance(frames, dict):
            if choices:
                axes = [(str(label), dict(options)) for label, options in choices]
                if any(len(set(options.values())) != len(options) for _, options in axes):
                    raise ValueError("The options of one choice need distinct texts.")
                keyed = {}
                snapshot_keys = []
                for key, sequence in frames.items():
                    key = key if isinstance(key, tuple) else (key,)
                    if len(key) != len(axes) or any(value not in options for value, (_, options) in zip(key, axes)):
                        raise ValueError("Each snapshot key needs one listed option for every choice.")
                    snapshot_choices.append([list(options).index(value) for value, (_, options) in zip(key, axes)])
                    keyed[", ".join(options[value] for value, (_, options) in zip(key, axes))] = sequence
                    snapshot_keys.append(key)
                if any(len({choice[axis] for choice in snapshot_choices}) != len(options) for axis, (_, options) in enumerate(axes)):
                    raise ValueError("Every option of a choice needs at least one snapshot.")
                frames = keyed
            snapshots = {title.strip(): list(sequence) for title, sequence in frames.items()}
            snapshot_keys = snapshot_keys if choices else list(snapshots)
            if not snapshots or not all(title and sequence for title, sequence in snapshots.items()):
                raise ValueError("Each snapshot needs a non-empty title and at least one frame.")
            frames = [frame for sequence in snapshots.values() for frame in sequence]
        frames = list(frames)
        if not frames:
            raise ValueError("Supply at least one XYZ frame.")
        if not hasattr(frame_labels, "items"):
            raise ValueError("Frame labels must map names to one-based frame numbers.")
        labels = []
        for label, index in frame_labels.items():
            if (not isinstance(label, str) or not label.strip() or not isinstance(index, Integral)
                    or isinstance(index, bool) or not 1 <= index <= len(frames)):
                raise ValueError("Each frame label needs a name and a valid one-based frame number.")
            labels.append({"label": label.strip(), "frame": int(index)})
        if len({entry["label"] for entry in labels}) != len(labels):
            raise ValueError("Frame labels must be unique.")
        if snapshot_frame_labels:
            if not snapshots:
                raise ValueError("Snapshot frame labels need snapshots.")
            start = 0
            # One mapping for every snapshot, or a mapping of each snapshot's key to its own.
            each = all(isinstance(entry, Mapping) for entry in snapshot_frame_labels.values())
            for key, sequence in zip(snapshot_keys, snapshots.values()):
                for label, number in (snapshot_frame_labels.get(key, {}) if each else snapshot_frame_labels).items():
                    if (not isinstance(label, str) or not label.strip() or not isinstance(number, Integral) or isinstance(number, bool)
                            or number == 0 or abs(number) > len(sequence)):
                        raise ValueError("Each snapshot frame label needs a name and a frame number within every snapshot.")
                    labels.append({"label": label.strip(), "frame": start + (number if number > 0 else len(sequence) + number + 1)})
                start += len(sequence)
        if not isinstance(height, Integral) or height < 200:
            raise ValueError("Viewer height must be an integer of at least 200 pixels.")
        geometries, elements = [], None
        for number, frame in enumerate(frames, 1):
            lines = frame.strip().splitlines()
            if len(lines) < 3:
                raise ValueError(f"XYZ frame {number} is incomplete.")
            count = int(lines[0])
            rows = [line.split() for line in lines[2:]]
            if count < 1 or len(rows) != count or any(len(row) != 4 for row in rows):
                raise ValueError(f"XYZ frame {number} has an invalid atom table.")
            symbols = tuple(row[0] for row in rows)
            if elements is not None and symbols != elements:
                raise ValueError("XYZ frames must preserve atom identities and order.")
            elements = symbols
            xyz = np.asarray([row[1:] for row in rows], dtype=float)
            if not np.isfinite(xyz).all():
                raise ValueError(f"XYZ frame {number} contains non-finite coordinates.")
            geometries.append(xyz)
        pairs = self._distance_pairs(distances, len(elements))
        groups = self._atom_groups(groups, len(elements))
        annotations = [dict(text=group["label"], atoms=group["atoms"], centers=[frame[np.asarray(group["atoms"]) - 1].mean(axis=0).tolist()
                                                          for frame in geometries]) for group in groups]
        arrows = self._arrows(arrows)
        atom_colors, color_range = self._atom_colors(atom_values, len(elements), color_range, colors)
        angles = self._angles(angles, len(elements))
        readouts = self._readouts(readouts, geometries, len(elements))
        annotations += readouts["annotations"]
        markers = self._markers(markers, len(elements))
        if markers and atom_colors:
            raise ValueError("Markers cannot be combined with atom values.")
        atom_details = list(atom_details or [])
        if atom_details and len(atom_details) != len(elements):
            raise ValueError("Give one hover detail per atom.")
        coordinates = np.concatenate([np.reshape(geometries, (-1, 3))]
                                     + [np.asarray([arrow["start"], arrow["end"]]) for arrow in arrows])
        bounds = [coordinates.min(axis=0) - 0.7, coordinates.max(axis=0) + 0.7]
        if not trail_density > 0:
            raise ValueError("The trail density must be positive.")
        # Every animated viewer offers the motion trail, hidden until toggled on, unless asked not to.
        trail = len(frames) > 1 if trail is None else bool(trail)
        virtual = [atom - 1 for marker in markers for atom in marker["atoms"]]
        trail_frames = self._trail_frames(geometries, [len(sequence) for sequence in snapshots.values()] or [len(frames)],
                                          virtual, trail_density) if trail else []
        super().__init__(scene=self._build_scene(frames, arrows, atom_colors, markers, elements), atom_details=atom_details,
                         atom_colors=atom_colors, color_range=list(color_range), colors=list(colors), color_label=str(color_label),
                         color_description=getattr(color_label, "description", "") or "",
                         frame_count=len(frames), trail=bool(trail), trail_density=float(trail_density), trail_frames=trail_frames, distances=pairs,
                         angles=angles, markers=markers,
                         readouts=readouts["measurements"], bounds=[bound.tolist() for bound in bounds],
                         height=int(height), annotations=annotations, frame_labels=labels,
                         snapshots=list(snapshots),
                         choices=[dict(label=label, options=list(options.values())) for label, options in axes],
                         snapshot_choices=snapshot_choices,
                         segments=[len(sequence) for sequence in snapshots.values()])

    @staticmethod
    def _trail_frames(geometries, ranges, virtual, density):
        """The frames each range draws as trail copies: both its ends, and each frame where some real atom has moved
        0.1 / ``density`` angstrom from the last copy, so the copies follow the motion rather than the frame count."""
        step = 0.1 / density
        real = np.setdiff1d(np.arange(len(geometries[0])), virtual)
        chosen, start = [], 0
        for count in ranges:
            kept = [start]
            for frame in range(start + 1, start + count):
                if np.linalg.norm(geometries[frame][real] - geometries[kept[-1]][real], axis=1).max() >= step:
                    kept.append(frame)
            if kept[-1] != start + count - 1:
                kept.append(start + count - 1)
            chosen.append(kept)
            start += count
        return chosen

    @staticmethod
    def _distance_pairs(distances, count):
        """Validate unique one-based atom pairs for native distance measurements."""
        pairs = [list(pair) for pair in distances]
        for pair in pairs:
            if (len(pair) != 2 or any(not isinstance(atom, Integral) or isinstance(atom, bool)
                                      or atom < 1 or atom > count for atom in pair)
                    or pair[0] == pair[1]):
                raise ValueError("Each distance must identify two distinct one-based atoms.")
        if len({tuple(sorted(pair)) for pair in pairs}) != len(pairs):
            raise ValueError("Distance pairs must be unique.")
        return pairs

    @staticmethod
    def _angles(angles, count):
        """Validate one-based atom triples of three distinct atoms, the vertex in the middle."""
        triples = [list(triple) for triple in angles]
        for triple in triples:
            if (len(triple) != 3 or any(not isinstance(atom, Integral) or isinstance(atom, bool) or atom < 1 or atom > count
                                        for atom in triple) or len(set(triple)) != 3):
                raise ValueError("Each angle must identify three distinct one-based atoms.")
        if len({tuple(triple) for triple in triples}) != len(triples):
            raise ValueError("Angle triples must be unique.")
        return [[int(atom) for atom in triple] for triple in triples]

    @staticmethod
    def _readouts(readouts, geometries, count):
        """Validate readouts and the label each draws at every frame, as the measurements and annotations they make."""
        measurements, annotations = [], []
        for readout in readouts:
            kind = readout["kind"]
            atoms = [int(atom) for atom in readout["atoms"]]
            need = {"distance": 2, "angle": 3}.get(kind)
            if need is None or len(atoms) != need or len(set(atoms)) != need or any(atom < 1 or atom > count for atom in atoms):
                raise ValueError("A readout is a distance of two or an angle of three distinct one-based atoms.")
            label, unit = str(readout["label"]), str(readout.get("unit", ""))
            position = float(readout.get("position", 0.5))
            size = float(readout.get("size", 0.28))
            offset = [float(value) for value in readout.get("offset", (0, 0))]
            texts, centers = [], []
            for xyz in geometries:
                points = xyz[np.asarray(atoms) - 1]
                if kind == "distance":
                    texts.append(f"${label}={np.linalg.norm(points[1] - points[0]):.2f}\\,{unit}$")
                    centers.append((points[0] + position * (points[1] - points[0])).tolist())
                    continue
                arms = [points[0] - points[1], points[2] - points[1]]
                lengths = [float(np.linalg.norm(arm)) for arm in arms]
                real = [arm / length for arm, length in zip(arms, lengths) if length > 1e-6]
                value = 90.0 if len(real) < 2 else float(np.degrees(np.arccos(np.clip(real[0] @ real[1], -1, 1))))
                direction = sum(real) if real else np.zeros(3)
                norm = float(np.linalg.norm(direction))
                direction = direction / norm if norm > 1e-9 else (real[0] if real else direction)
                reach = min(length for length in lengths if length > 1e-6) if real else 0.0
                text = f"{value:.1f}".rstrip("0").rstrip(".")
                texts.append(f"${label}={text}^\\circ$")
                centers.append((points[1] + 0.3 * reach * direction).tolist())
            measurements.append(dict(kind=kind, atoms=atoms))
            annotations.append(dict(text=texts[0], texts=texts, atoms=[], centers=centers, size=size, offset=offset))
        return dict(measurements=measurements, annotations=annotations)

    @staticmethod
    def _markers(markers, count):
        """Validate groups of virtual atoms with a colour, size and optional hover label."""
        checked, seen = [], set()
        for marker in markers:
            atoms, color = list(marker["atoms"]), marker["color"]
            size, label = float(marker.get("size", 0.09)), str(marker.get("label", ""))
            if not atoms or any(not isinstance(atom, Integral) or isinstance(atom, bool) or atom < 1 or atom > count for atom in atoms):
                raise ValueError("Each marker must list valid one-based atoms.")
            if len(set(atoms)) != len(atoms) or seen & set(atoms):
                raise ValueError("Marker atoms must be unique and disjoint.")
            if not (isinstance(color, str) and len(color) == 7 and color.startswith("#") and int(color[1:], 16) >= 0):
                raise ValueError("A marker colour must be written #rrggbb.")
            if not size > 0:
                raise ValueError("A marker size must be positive.")
            seen |= set(atoms)
            checked.append(dict(atoms=[int(atom) for atom in atoms], color=color.lower(), size=size, label=label, visible=bool(marker.get("visible", True))))
        return checked

    @staticmethod
    def _atom_groups(groups, count):
        """Validate labelled, disjoint one-based atom groups."""
        checked, seen = [], set()
        for group in groups:
            label, atoms = group["label"], list(group["atoms"])
            if not isinstance(label, str) or not label.strip():
                raise ValueError("Each group needs a non-empty label.")
            if not atoms or any(not isinstance(atom, Integral) or isinstance(atom, bool)
                                or atom < 1 or atom > count for atom in atoms):
                raise ValueError("Each group must list valid one-based atoms.")
            if len(set(atoms)) != len(atoms) or seen & set(atoms):
                raise ValueError("Group atoms must be unique and disjoint.")
            seen |= set(atoms)
            checked.append(dict(label=label.strip(), atoms=[int(atom) for atom in atoms]))
        return checked

    @staticmethod
    def _atom_colors(values, count, color_range, colors):
        """Map one finite value per atom linearly onto the colour scale; returns the colours and the range used."""
        if values is None:
            return [], color_range or (-1.0, 1.0)
        values = np.asarray(values, dtype=float)
        if values.shape != (count,) or not np.isfinite(values).all():
            raise ValueError("Give one finite value per atom.")
        if color_range is None:
            bound = float(np.abs(values).max()) or 1.0
            color_range = (-bound, bound)
        lower, upper = map(float, color_range)
        if not lower < upper or len(colors) < 2:
            raise ValueError("Give an increasing colour range and at least two colours.")
        stops = np.asarray([[int(c[i:i + 2], 16) for i in (1, 3, 5)] for c in colors], dtype=float)
        positions = np.clip((values - lower) / (upper - lower), 0, 1) * (len(colors) - 1)
        below = np.minimum(positions.astype(int), len(colors) - 2)
        mixed = stops[below] + (positions - below)[:, None] * (stops[below + 1] - stops[below])
        return ["#" + "".join(f"{round(v):02x}" for v in rgb) for rgb in mixed], (lower, upper)

    @staticmethod
    def _arrows(arrows):
        """Validate finite arrow end points with optional hex colours and tooltips."""
        checked = []
        for arrow in arrows:
            start, end = (np.asarray(arrow[key], dtype=float) for key in ("start", "end"))
            if start.shape != (3,) or end.shape != (3,) or not np.isfinite([start, end]).all():
                raise ValueError("Each arrow needs finite three-component start and end points.")
            color, tooltip = arrow.get("color", "#d62728"), arrow.get("tooltip")
            if not (isinstance(color, str) and len(color) == 7 and color.startswith("#")
                    and all(c in "0123456789abcdefABCDEF" for c in color[1:])):
                raise ValueError("Arrow colours must be #rrggbb strings.")
            if tooltip is not None and not isinstance(tooltip, str):
                raise ValueError("Arrow tooltips must be plain text.")
            checked.append(dict(start=start.tolist(), end=end.tolist(), color=color, tooltip=tooltip))
        return checked

    @staticmethod
    def _build_scene(frames, arrows=(), atom_colors=(), markers=(), elements=()):
        """Load one native XYZ trajectory, with coloured atoms drawn as balls and sticks in their own colours."""
        builder = mvs.create_builder()
        builder.canvas(background_color="white")
        template = dedent("""
            {frame}
            """).lstrip()
        trajectory = "".join(template.format(frame=frame.rstrip()) for frame in frames)
        structure = builder.download(url="trajectory.xyz").parse(format="xyz").model_structure(model_index=0)
        if atom_colors:
            representation = structure.component(selector="all").representation(type="ball_and_stick")
            for color in dict.fromkeys(atom_colors):
                representation.color(color=color, selector=[ComponentExpression(atom_index=index)
                                                            for index, value in enumerate(atom_colors) if value == color])
        if markers:
            virtual = {atom - 1 for marker in markers for atom in marker["atoms"]}
            body = [index for index in range(len(elements)) if index not in virtual]
            # The viewer colours these atoms like the native preset; only the virtual points are coloured here.
            structure.component(selector=[ComponentExpression(atom_index=index) for index in body]).representation(type="ball_and_stick")
            for marker in (marker for marker in markers if marker["visible"]):
                component = structure.component(selector=[ComponentExpression(atom_index=atom - 1) for atom in marker["atoms"]])
                if marker["label"]:
                    component.tooltip(text=marker["label"])
                component.representation(type="spacefill", size_factor=marker["size"]).color(color=marker["color"])
        if arrows:
            primitives = builder.primitives()
            for arrow in arrows:
                length = float(np.linalg.norm(np.subtract(arrow["end"], arrow["start"])))
                # Short arrows keep a visible head without the head exceeding the shaft.
                cap = min(0.25, 0.45 * length)
                primitives.arrow(start=arrow["start"], end=arrow["end"], show_end_cap=True,
                                 end_cap_length=cap, end_cap_radius=0.5 * cap + 0.02,
                                 tube_radius=0.035, color=arrow["color"], tooltip=arrow["tooltip"])
        archive = mvs.MVSX(data=builder.get_state(),
                           assets={"trajectory.xyz": trajectory.encode()}).dumps()
        return "base64," + base64.b64encode(archive).decode()

    def set_frame(self, frame):
        """Request a one-based frame, retaining camera orientation and native distances."""
        if not isinstance(frame, Integral) or isinstance(frame, bool) or not 1 <= frame <= self.frame_count:
            raise ValueError(f"Frame must be an integer between 1 and {self.frame_count}.")
        self.requested = int(frame)

"""Python interface to MolViewSpec scenes and Molstar's measurement manager."""

from datetime import datetime, timezone
from pathlib import Path
from textwrap import dedent
from collections.abc import Mapping
from numbers import Integral
import base64
import io
import zipfile

import anywidget
import molviewspec as mvs
from molviewspec.nodes import ComponentExpression
import numpy as np
import traitlets

from . import store

# A scene archive larger than this many bytes is kept in the store, when one is set, instead of in the page.
INLINE_SCENE = 32 * 1024
# The time written into every scene archive, the earliest a zip entry can hold.
FIXED_TIME = datetime(1980, 1, 1, tzinfo=timezone.utc)


def choice_axes(keys, choices):
    """The dropdown axes of ``choices``, each snapshot key's option index on every axis, and its title.

    Each key is one value per choice, or a single value for one choice. The title joins the option texts. Every option
    of every choice must belong to some key.

    Args:
        keys: The snapshot keys, tuples of one value per choice, or single values when there is one choice.
        choices: Pairs of ``(label, {value: text})``, one per dropdown: its label and the text shown for each value,
            or triples with a mapping of flags: ``input`` makes it a text field in Molstar's form-control markup, where
            an option's text is typed, a number clamped to the nearest option allowed, for long runs such as atom
            numbers; ``collapse`` hides it while its first option, a placeholder such as "all atoms", is the only one
            that can be chosen.

    Returns:
        The axes as a list of triples of a label, its options and its flags; the indices, one list per key giving its
        option index on every axis; and the titles, one per key, joining its option texts with commas.

    Raises:
        ValueError: If the option texts of a choice are not distinct, a key does not give one listed option for every
            choice, or an option of a choice belongs to no key.
    """
    axes = [(str(choice[0]), dict(choice[1]), dict(choice[2]) if len(choice) > 2 else {}) for choice in choices]
    if any(set(flags) - {"input", "collapse"} for _, _, flags in axes):
        raise ValueError("A choice's flags are input and collapse.")
    if any(len(set(options.values())) != len(options) for _, options, _ in axes):
        raise ValueError("The options of one choice need distinct texts.")
    indices, titles = [], []
    for key in keys:
        key = key if isinstance(key, tuple) else (key,)
        if len(key) != len(axes) or any(value not in options for value, (_, options, _) in zip(key, axes)):
            raise ValueError("Each snapshot key needs one listed option for every choice.")
        indices.append([list(options).index(value) for value, (_, options, _) in zip(key, axes)])
        titles.append(", ".join(options[value] for value, (_, options, _) in zip(key, axes)))
    if any(len({index[axis] for index in indices}) != len(options) for axis, (_, options, _) in enumerate(axes)):
        raise ValueError("Every option of a choice needs at least one snapshot.")
    return axes, indices, titles


class MolstarViewer(anywidget.AnyWidget):
    """Display XYZ frames with native atom-pair distances and one persistent camera.

    Atom pairs and frames are one-based. ``frame`` confirms the displayed frame;
    ``error`` reports a browser-side load failure. Distances use angstrom.

    ``groups`` is a sequence of mappings with ``label`` (inline Markdown with optional
    ``$...$`` LaTeX, drawn as a text overlay at the group's centroid and shown when hovering its atoms) and ``atoms``
    (one-based, disjoint atom numbers). Atom colours and representations stay Molstar's defaults.

    Hovering shows the viewer's own labels in Molstar's highlight box: the atom, bond, measurement or field value
    under the pointer, written in words with ``$...$`` LaTeX.

    ``arrows`` is a sequence of mappings with ``start`` and ``end`` (angstrom, in the
    frames' coordinates) and optional ``color`` (``#rrggbb``) and ``tooltip`` (plain
    text). Each becomes a native MolViewSpec arrow primitive, for example a
    displacement field drawn on a structure.

    ``atom_values`` gives one number per atom, such as a partial charge. Atoms are then drawn as balls and sticks
    coloured on the ``colors`` scale from the lower to the upper end of ``color_range`` (symmetric about zero by
    default), with ``color_label``, the quantity and its unit, above a colour scale in the viewport. Each atom's
    hover label adds its entry of ``atom_details`` (text with ``$...$`` LaTeX), such as its charge.
    """

    _esm = Path(__file__).parent / "static" / "viewer.js"
    _css = Path(__file__).parent / "static" / "viewer.css"
    scene = traitlets.Unicode().tag(sync=True)
    frame_count = traitlets.Int().tag(sync=True)
    distances = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)
    # One-based atom triples of native angle measurements, the vertex in the middle.
    angles = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)
    # Virtual atoms drawn as small spheres: atoms, colour, size and label of each group.
    markers = traitlets.List(traitlets.Dict()).tag(sync=True)
    # Measurements whose native number is replaced by a readout drawn in front of the scene: their kind and atoms.
    readouts = traitlets.List(traitlets.Dict()).tag(sync=True)
    bounds = traitlets.List(traitlets.List(traitlets.Float())).tag(sync=True)
    height = traitlets.Int(440).tag(sync=True)
    requested = traitlets.Int(1).tag(sync=True)
    frame = traitlets.Int(0).tag(sync=True)
    error = traitlets.Unicode("").tag(sync=True)
    annotations = traitlets.List(traitlets.Dict()).tag(sync=True)
    snapshots = traitlets.List(traitlets.Unicode()).tag(sync=True)
    segments = traitlets.List(traitlets.Int()).tag(sync=True)
    # Dropdowns that together select a snapshot: each has a label and its option texts, and ``snapshot_choices`` gives
    # every snapshot's option index on each of them.
    choices = traitlets.List(traitlets.Dict()).tag(sync=True)
    snapshot_choices = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)
    # Named, one-based frames available from the trajectory controls.
    frame_labels = traitlets.List(traitlets.Dict()).tag(sync=True)
    # Whether faded copies of the frames behind the shown one follow it, toggled from the toolbar.
    trail = traitlets.Bool(False).tag(sync=True)
    # Trail copies per 0.1 angstrom moved by the fastest atom.
    trail_density = traitlets.Float(1.0).tag(sync=True)
    # The zero-based frames each frame range draws as trail copies.
    trail_frames = traitlets.List(traitlets.List(traitlets.Int())).tag(sync=True)
    # Per-atom colours of an atom-valued quantity, with its colour scale; empty for Molstar's element colours.
    atom_colors = traitlets.List(traitlets.Unicode()).tag(sync=True)
    color_range = traitlets.List(traitlets.Float()).tag(sync=True)
    colors = traitlets.List(traitlets.Unicode()).tag(sync=True)
    # Quantity and unit of the colour scale, shown above it.
    color_label = traitlets.Unicode("").tag(sync=True)
    # Explanation of that quantity, Markdown with $...$ LaTeX, opened from an info button beside the label; empty for
    # none. A label carrying a ``description``, as page quantities do, supplies it.
    color_description = traitlets.Unicode("").tag(sync=True)
    # Hover details of each atom, LaTeX allowed; empty for none.
    atom_details = traitlets.List(traitlets.Unicode()).tag(sync=True)

    def __init__(self, frames, *, distances=(), height=440, groups=(), arrows=(), trail=None, trail_density=1.0,
                 atom_values=None, atom_details=None, color_range=None, colors=("#d7301f", "#ffffff", "#2b6cb0"),
                 color_label="", frame_labels=None, choices=None, snapshot_frame_labels=None,
                 angles=(), markers=(), readouts=()):
        """Validate matching XYZ frames and prepare one native trajectory.

        Atom numbers are one-based and lengths are in angstrom.

        Args:
            frames: Complete XYZ strings of the same atoms in the same order. A mapping of snapshot titles to such
                sequences gives one native snapshot per title, each playing its frames alone; titles may contain ``$...$``
                LaTeX, typeset in the selector and its list. With ``choices`` the keys are tuples of one value per choice.
            distances: Atom pairs measured with Molstar's measurement tool.
            height: Viewer height in pixels, at least 200.
            groups: Mappings with ``label`` (inline Markdown with optional ``$...$`` LaTeX, drawn at the group's centroid
                and shown when hovering its atoms) and ``atoms`` (disjoint atom numbers).
            arrows: Mappings with ``start`` and ``end`` (angstrom, in the frames' coordinates) and optional ``color``
                (``#rrggbb``) and ``tooltip`` (plain text), each drawn as a native MolViewSpec arrow.
            trail: Whether faded copies of the molecule along the shown range follow it as a motion blur, shown by a
                Motion trail toggle that starts off. None offers it whenever there is more than one frame; ``False`` leaves
                it out.
            trail_density: Copies per 0.1 angstrom moved by the fastest atom, so a path that lingers gets few and a large
                motion many.
            atom_values: One number per atom, such as a partial charge. Atoms are then drawn as balls and sticks coloured
                on the ``colors`` scale; cannot be combined with ``markers``.
            atom_details: One hover text per atom, LaTeX allowed, such as its charge.
            color_range: Lower and upper end of the colour scale, symmetric about zero over ``atom_values`` by default.
            colors: Hexadecimal colours of the scale from its lower to its upper end, at least two.
            color_label: The quantity and its unit, shown above the colour scale; ``$...$`` is LaTeX. A label carrying a
                ``description``, as page quantities do, offers it from an info button.
            frame_labels: Descriptive labels mapped to frame numbers, for the frame selector. An input sequence may carry
                a ``frame_labels`` mapping, which an explicit argument overrides.
            choices: Pairs of ``(label, options)`` that replace the snapshot menu by one dropdown per axis: ``label`` is
                inline Markdown with optional LaTeX and ``options`` maps each value to its text. ``frames`` then maps a
                tuple of one value per choice to that snapshot's frames. Choosing a value shows the snapshot that keeps the
                earlier dropdowns and agrees with the later ones on most of them, and an earlier dropdown limits the later
                ones to combinations that exist. A triple adds the flags ``input`` (a text field where an option's
                text is typed, a number clamped to the nearest allowed) and ``collapse`` (hidden while its first option
                is the only one allowed), as in ``choice_axes``.
            snapshot_frame_labels: Names of frames within snapshots: a mapping of labels to frame numbers, negative
                counting from the end, the same for every snapshot, or a mapping of each snapshot's key to its own. The
                frame menu offers the labels of the shown snapshot only.
            angles: Atom triples, the vertex in the middle, registered as native angle measurements like the distances.
            markers: Virtual atoms, such as a pivot appended to every frame, drawn as small spheres without bonds:
                mappings with ``atoms``, ``color`` (``#rrggbb``), optional ``visible`` (``False`` for a point that only
                anchors a measurement and is not drawn), optional ``size`` (a fraction of the van der Waals radius, default
                0.09) and ``label`` (hover text, a LaTeX symbol naming its atom).
            readouts: Labels drawn in front of the scene at every frame in place of a native measurement's number:
                mappings with ``kind`` (``"distance"`` or ``"angle"``), the measurement's ``atoms``, a LaTeX ``label``
                symbol, for a distance its ``unit`` and optionally the ``position`` along it of the label (default 0.5),
                ``offset`` as ``(across, down)`` in label heights to keep close readouts apart, and ``size``, the label's
                height in angstrom (default 0.28). The label reads, for example, r = 1.70 Å or θ = 90°, an angle without
                trailing zeros and standing inside the angle a third of the way along its shorter arm; an arm shorter than
                1e-6 angstrom counts as perpendicular to the other.

        Raises:
            ValueError: If the frames, snapshot titles, labels, choices, distances, angles, groups, arrows, markers,
                readouts, atom values, details, height or trail density are invalid, or markers are combined with atom
                values.
        """
        frame_labels = getattr(frames, "frame_labels", {}) if frame_labels is None else frame_labels
        snapshots, axes, snapshot_choices = {}, [], []
        if choices and not isinstance(frames, dict):
            raise ValueError("Choices select among snapshots: map each combination of values to its frame sequence.")
        if isinstance(frames, dict):
            if choices:
                axes, snapshot_choices, titles = choice_axes(frames, choices)
                snapshot_keys = [key if isinstance(key, tuple) else (key,) for key in frames]
                frames = dict(zip(titles, frames.values()))
            snapshots = {title.strip(): list(sequence) for title, sequence in frames.items()}
            snapshot_keys = snapshot_keys if choices else list(snapshots)
            if not snapshots or not all(title and sequence for title, sequence in snapshots.items()):
                raise ValueError("Each snapshot needs a non-empty title and at least one frame.")
            frames = [frame for sequence in snapshots.values() for frame in sequence]
        frames = list(frames)
        if not frames:
            raise ValueError("Supply at least one XYZ frame.")
        if not hasattr(frame_labels, "items"):
            raise ValueError("Frame labels must map names to one-based frame numbers.")
        labels = []
        for label, index in frame_labels.items():
            if (not isinstance(label, str) or not label.strip() or not isinstance(index, Integral)
                    or isinstance(index, bool) or not 1 <= index <= len(frames)):
                raise ValueError("Each frame label needs a name and a valid one-based frame number.")
            labels.append({"label": label.strip(), "frame": int(index)})
        if len({entry["label"] for entry in labels}) != len(labels):
            raise ValueError("Frame labels must be unique.")
        if snapshot_frame_labels:
            if not snapshots:
                raise ValueError("Snapshot frame labels need snapshots.")
            start = 0
            # One mapping for every snapshot, or a mapping of each snapshot's key to its own.
            each = all(isinstance(entry, Mapping) for entry in snapshot_frame_labels.values())
            for key, sequence in zip(snapshot_keys, snapshots.values()):
                for label, number in (snapshot_frame_labels.get(key, {}) if each else snapshot_frame_labels).items():
                    if (not isinstance(label, str) or not label.strip() or not isinstance(number, Integral) or isinstance(number, bool)
                            or number == 0 or abs(number) > len(sequence)):
                        raise ValueError("Each snapshot frame label needs a name and a frame number within every snapshot.")
                    labels.append({"label": label.strip(), "frame": start + (number if number > 0 else len(sequence) + number + 1)})
                start += len(sequence)
        if not isinstance(height, Integral) or height < 200:
            raise ValueError("Viewer height must be an integer of at least 200 pixels.")
        geometries, elements = [], None
        for number, frame in enumerate(frames, 1):
            lines = frame.strip().splitlines()
            if len(lines) < 3:
                raise ValueError(f"XYZ frame {number} is incomplete.")
            count = int(lines[0])
            rows = [line.split() for line in lines[2:]]
            if count < 1 or len(rows) != count or any(len(row) != 4 for row in rows):
                raise ValueError(f"XYZ frame {number} has an invalid atom table.")
            symbols = tuple(row[0] for row in rows)
            if elements is not None and symbols != elements:
                raise ValueError("XYZ frames must preserve atom identities and order.")
            elements = symbols
            xyz = np.asarray([row[1:] for row in rows], dtype=float)
            if not np.isfinite(xyz).all():
                raise ValueError(f"XYZ frame {number} contains non-finite coordinates.")
            geometries.append(xyz)
        pairs = self._distance_pairs(distances, len(elements))
        groups = self._atom_groups(groups, len(elements))
        annotations = [dict(text=group["label"], atoms=group["atoms"], centers=[frame[np.asarray(group["atoms"]) - 1].mean(axis=0).tolist()
                                                          for frame in geometries]) for group in groups]
        arrows = self._arrows(arrows)
        atom_colors, color_range = self._atom_colors(atom_values, len(elements), color_range, colors)
        angles = self._angles(angles, len(elements))
        readouts = self._readouts(readouts, geometries, len(elements))
        annotations += readouts["annotations"]
        markers = self._markers(markers, len(elements))
        if markers and atom_colors:
            raise ValueError("Markers cannot be combined with atom values.")
        atom_details = list(atom_details or [])
        if atom_details and len(atom_details) != len(elements):
            raise ValueError("Give one hover detail per atom.")
        coordinates = np.concatenate([np.reshape(geometries, (-1, 3))]
                                     + [np.asarray([arrow["start"], arrow["end"]]) for arrow in arrows])
        bounds = [coordinates.min(axis=0) - 0.7, coordinates.max(axis=0) + 0.7]
        if not trail_density > 0:
            raise ValueError("The trail density must be positive.")
        # Every animated viewer offers the motion trail, hidden until toggled on, unless asked not to.
        trail = len(frames) > 1 if trail is None else bool(trail)
        virtual = [atom - 1 for marker in markers for atom in marker["atoms"]]
        trail_frames = self._trail_frames(geometries, [len(sequence) for sequence in snapshots.values()] or [len(frames)],
                                          virtual, trail_density) if trail else []
        super().__init__(scene=self._build_scene(frames, arrows, atom_colors, markers, elements), atom_details=atom_details,
                         atom_colors=atom_colors, color_range=list(color_range), colors=list(colors), color_label=str(color_label),
                         color_description=getattr(color_label, "description", "") or "",
                         frame_count=len(frames), trail=bool(trail), trail_density=float(trail_density), trail_frames=trail_frames, distances=pairs,
                         angles=angles, markers=markers,
                         readouts=readouts["measurements"], bounds=[bound.tolist() for bound in bounds],
                         height=int(height), annotations=annotations, frame_labels=labels,
                         snapshots=list(snapshots),
                         choices=[dict(label=label, options=list(options.values()), **flags) for label, options, flags in axes],
                         snapshot_choices=snapshot_choices,
                         segments=[len(sequence) for sequence in snapshots.values()])

    @staticmethod
    def _trail_frames(geometries, ranges, virtual, density):
        """The frames each range draws as trail copies: both its ends, and each frame where some real atom has moved
        0.1 / ``density`` angstrom from the last copy, so the copies follow the motion rather than the frame count.

        Args:
            geometries: Coordinates of every frame, one array of shape (atoms, 3) per frame.
            ranges: The number of frames of each snapshot, or of the whole trajectory.
            virtual: Zero-based indices of the virtual atoms, which are left out of the motion.
            density: Copies per 0.1 angstrom moved by the fastest atom.

        Returns:
            For each range, the zero-based frame numbers drawn as copies, in order.
        """
        step = 0.1 / density
        real = np.setdiff1d(np.arange(len(geometries[0])), virtual)
        chosen, start = [], 0
        for count in ranges:
            kept = [start]
            for frame in range(start + 1, start + count):
                if np.linalg.norm(geometries[frame][real] - geometries[kept[-1]][real], axis=1).max() >= step:
                    kept.append(frame)
            if kept[-1] != start + count - 1:
                kept.append(start + count - 1)
            chosen.append(kept)
            start += count
        return chosen

    @staticmethod
    def _distance_pairs(distances, count):
        """Validate unique one-based atom pairs for native distance measurements.

        Args:
            distances: Pairs of one-based atom numbers.
            count: The number of atoms.

        Returns:
            The pairs as lists of two integers.

        Raises:
            ValueError: If a pair is not two distinct atoms of the structure, or a pair repeats.
        """
        pairs = [list(pair) for pair in distances]
        for pair in pairs:
            if (len(pair) != 2 or any(not isinstance(atom, Integral) or isinstance(atom, bool)
                                      or atom < 1 or atom > count for atom in pair)
                    or pair[0] == pair[1]):
                raise ValueError("Each distance must identify two distinct one-based atoms.")
        if len({tuple(sorted(pair)) for pair in pairs}) != len(pairs):
            raise ValueError("Distance pairs must be unique.")
        return pairs

    @staticmethod
    def _angles(angles, count):
        """Validate one-based atom triples of three distinct atoms, the vertex in the middle.

        Args:
            angles: Triples of one-based atom numbers.
            count: The number of atoms.

        Returns:
            The triples as lists of three integers.

        Raises:
            ValueError: If a triple is not three distinct atoms of the structure, or a triple repeats.
        """
        triples = [list(triple) for triple in angles]
        for triple in triples:
            if (len(triple) != 3 or any(not isinstance(atom, Integral) or isinstance(atom, bool) or atom < 1 or atom > count
                                        for atom in triple) or len(set(triple)) != 3):
                raise ValueError("Each angle must identify three distinct one-based atoms.")
        if len({tuple(triple) for triple in triples}) != len(triples):
            raise ValueError("Angle triples must be unique.")
        return [[int(atom) for atom in triple] for triple in triples]

    @staticmethod
    def _readouts(readouts, geometries, count):
        """Validate readouts and the label each draws at every frame, as the measurements and annotations they make.

        Args:
            readouts: Mappings with ``kind``, ``atoms``, ``label`` and the optional ``unit``, ``position``, ``size`` and
                ``offset``, as ``MolstarViewer`` takes them.
            geometries: Coordinates of every frame, one array of shape (atoms, 3) per frame, in angstrom.
            count: The number of atoms.

        Returns:
            A mapping with ``measurements`` (the kind and atoms of each readout) and ``annotations`` (each readout's
            LaTeX text and centre at every frame, with its size and offset).

        Raises:
            ValueError: If a readout is not a distance of two or an angle of three distinct atoms of the structure.
        """
        measurements, annotations = [], []
        for readout in readouts:
            kind = readout["kind"]
            atoms = [int(atom) for atom in readout["atoms"]]
            need = {"distance": 2, "angle": 3}.get(kind)
            if need is None or len(atoms) != need or len(set(atoms)) != need or any(atom < 1 or atom > count for atom in atoms):
                raise ValueError("A readout is a distance of two or an angle of three distinct one-based atoms.")
            label, unit = str(readout["label"]), str(readout.get("unit", ""))
            position = float(readout.get("position", 0.5))
            size = float(readout.get("size", 0.28))
            offset = [float(value) for value in readout.get("offset", (0, 0))]
            texts, centers = [], []
            for xyz in geometries:
                points = xyz[np.asarray(atoms) - 1]
                if kind == "distance":
                    texts.append(f"${label}={np.linalg.norm(points[1] - points[0]):.2f}\\,{unit}$")
                    centers.append((points[0] + position * (points[1] - points[0])).tolist())
                    continue
                arms = [points[0] - points[1], points[2] - points[1]]
                lengths = [float(np.linalg.norm(arm)) for arm in arms]
                real = [arm / length for arm, length in zip(arms, lengths) if length > 1e-6]
                value = 90.0 if len(real) < 2 else float(np.degrees(np.arccos(np.clip(real[0] @ real[1], -1, 1))))
                direction = sum(real) if real else np.zeros(3)
                norm = float(np.linalg.norm(direction))
                direction = direction / norm if norm > 1e-9 else (real[0] if real else direction)
                reach = min(length for length in lengths if length > 1e-6) if real else 0.0
                text = f"{value:.1f}".rstrip("0").rstrip(".")
                texts.append(f"${label}={text}^\\circ$")
                centers.append((points[1] + 0.3 * reach * direction).tolist())
            measurements.append(dict(kind=kind, atoms=atoms))
            annotations.append(dict(text=texts[0], texts=texts, atoms=[], centers=centers, size=size, offset=offset))
        return dict(measurements=measurements, annotations=annotations)

    @staticmethod
    def _markers(markers, count):
        """Validate groups of virtual atoms with a colour, size and optional hover label.

        Args:
            markers: Mappings with ``atoms``, ``color`` and the optional ``size``, ``label`` and ``visible``.
            count: The number of atoms.

        Returns:
            The markers with their atom numbers as integers, colour in lower case and every optional entry filled in.

        Raises:
            ValueError: If a marker has no valid atoms, shares an atom with another, has a colour not written #rrggbb or a
                size that is not positive.
        """
        checked, seen = [], set()
        for marker in markers:
            atoms, color = list(marker["atoms"]), marker["color"]
            size, label = float(marker.get("size", 0.09)), str(marker.get("label", ""))
            if not atoms or any(not isinstance(atom, Integral) or isinstance(atom, bool) or atom < 1 or atom > count for atom in atoms):
                raise ValueError("Each marker must list valid one-based atoms.")
            if len(set(atoms)) != len(atoms) or seen & set(atoms):
                raise ValueError("Marker atoms must be unique and disjoint.")
            if not (isinstance(color, str) and len(color) == 7 and color.startswith("#") and int(color[1:], 16) >= 0):
                raise ValueError("A marker colour must be written #rrggbb.")
            if not size > 0:
                raise ValueError("A marker size must be positive.")
            seen |= set(atoms)
            checked.append(dict(atoms=[int(atom) for atom in atoms], color=color.lower(), size=size, label=label, visible=bool(marker.get("visible", True))))
        return checked

    @staticmethod
    def _atom_groups(groups, count):
        """Validate labelled, disjoint one-based atom groups.

        Args:
            groups: Mappings with ``label`` and ``atoms``.
            count: The number of atoms.

        Returns:
            The groups with their labels stripped and their atom numbers as integers.

        Raises:
            ValueError: If a label is empty, a group has no valid atoms, or two groups share an atom.
        """
        checked, seen = [], set()
        for group in groups:
            label, atoms = group["label"], list(group["atoms"])
            if not isinstance(label, str) or not label.strip():
                raise ValueError("Each group needs a non-empty label.")
            if not atoms or any(not isinstance(atom, Integral) or isinstance(atom, bool)
                                or atom < 1 or atom > count for atom in atoms):
                raise ValueError("Each group must list valid one-based atoms.")
            if len(set(atoms)) != len(atoms) or seen & set(atoms):
                raise ValueError("Group atoms must be unique and disjoint.")
            seen |= set(atoms)
            checked.append(dict(label=label.strip(), atoms=[int(atom) for atom in atoms]))
        return checked

    @staticmethod
    def _atom_colors(values, count, color_range, colors):
        """Map one finite value per atom linearly onto the colour scale.

        Args:
            values: One number per atom, or None for none.
            count: The number of atoms.
            color_range: The values at the ends of the scale, or None for the largest magnitude of ``values`` either side
                of zero.
            colors: Hexadecimal colours of the scale, from its lower to its upper end.

        Returns:
            The colour of every atom as ``#rrggbb`` (empty without values) and the range used.

        Raises:
            ValueError: If ``values`` is not one finite number per atom, or the range does not increase or fewer than two
                colours are given.
        """
        if values is None:
            return [], color_range or (-1.0, 1.0)
        values = np.asarray(values, dtype=float)
        if values.shape != (count,) or not np.isfinite(values).all():
            raise ValueError("Give one finite value per atom.")
        if color_range is None:
            bound = float(np.abs(values).max()) or 1.0
            color_range = (-bound, bound)
        lower, upper = map(float, color_range)
        if not lower < upper or len(colors) < 2:
            raise ValueError("Give an increasing colour range and at least two colours.")
        stops = np.asarray([[int(c[i:i + 2], 16) for i in (1, 3, 5)] for c in colors], dtype=float)
        positions = np.clip((values - lower) / (upper - lower), 0, 1) * (len(colors) - 1)
        below = np.minimum(positions.astype(int), len(colors) - 2)
        mixed = stops[below] + (positions - below)[:, None] * (stops[below + 1] - stops[below])
        return ["#" + "".join(f"{round(v):02x}" for v in rgb) for rgb in mixed], (lower, upper)

    @staticmethod
    def _arrows(arrows):
        """Validate finite arrow end points with optional hex colours and tooltips.

        Args:
            arrows: Mappings with ``start`` and ``end`` and the optional ``color`` and ``tooltip``.

        Returns:
            The arrows with their end points as lists, a colour (default red) and a tooltip or None.

        Raises:
            ValueError: If an end point is not three finite numbers, a colour is not written #rrggbb or a tooltip is not
                text.
        """
        checked = []
        for arrow in arrows:
            start, end = (np.asarray(arrow[key], dtype=float) for key in ("start", "end"))
            if start.shape != (3,) or end.shape != (3,) or not np.isfinite([start, end]).all():
                raise ValueError("Each arrow needs finite three-component start and end points.")
            color, tooltip = arrow.get("color", "#d62728"), arrow.get("tooltip")
            if not (isinstance(color, str) and len(color) == 7 and color.startswith("#")
                    and all(c in "0123456789abcdefABCDEF" for c in color[1:])):
                raise ValueError("Arrow colours must be #rrggbb strings.")
            if tooltip is not None and not isinstance(tooltip, str):
                raise ValueError("Arrow tooltips must be plain text.")
            checked.append(dict(start=start.tolist(), end=end.tolist(), color=color, tooltip=tooltip))
        return checked

    @staticmethod
    def _build_scene(frames, arrows=(), atom_colors=(), markers=(), elements=()):
        """Load one native XYZ trajectory, with coloured atoms drawn as balls and sticks in their own colours.

        Args:
            frames: Complete XYZ strings of the same atoms.
            arrows: Validated arrows, drawn as MolViewSpec primitives.
            atom_colors: The colour of every atom, or empty for Molstar's element colours.
            markers: Validated markers, drawn as small spheres without bonds.
            elements: The element symbols of the atoms, whose number places the markers among them.

        Returns:
            The MolViewSpec archive of the scene: its address in the store (``molstarview.store``) when it is larger
            than ``INLINE_SCENE`` bytes and a store is set, otherwise base64-encoded with a ``base64,`` prefix.
        """
        builder = mvs.create_builder()
        builder.canvas(background_color="white")
        template = dedent("""
            {frame}
            """).lstrip()
        trajectory = "".join(template.format(frame=frame.rstrip()) for frame in frames)
        structure = builder.download(url="trajectory.xyz").parse(format="xyz").model_structure(model_index=0)
        if atom_colors:
            representation = structure.component(selector="all").representation(type="ball_and_stick")
            for color in dict.fromkeys(atom_colors):
                representation.color(color=color, selector=[ComponentExpression(atom_index=index)
                                                            for index, value in enumerate(atom_colors) if value == color])
        if markers:
            virtual = {atom - 1 for marker in markers for atom in marker["atoms"]}
            body = [index for index in range(len(elements)) if index not in virtual]
            # The viewer colours these atoms like the native preset; only the virtual points are coloured here.
            structure.component(selector=[ComponentExpression(atom_index=index) for index in body]).representation(type="ball_and_stick")
            for marker in (marker for marker in markers if marker["visible"]):
                component = structure.component(selector=[ComponentExpression(atom_index=atom - 1) for atom in marker["atoms"]])
                if marker["label"]:
                    component.tooltip(text=marker["label"])
                component.representation(type="spacefill", size_factor=marker["size"]).color(color=marker["color"])
        if arrows:
            primitives = builder.primitives()
            for arrow in arrows:
                length = float(np.linalg.norm(np.subtract(arrow["end"], arrow["start"])))
                # Short arrows keep a visible head without the head exceeding the shaft.
                cap = min(0.25, 0.45 * length)
                primitives.arrow(start=arrow["start"], end=arrow["end"], show_end_cap=True,
                                 end_cap_length=cap, end_cap_radius=0.5 * cap + 0.02,
                                 tube_radius=0.035, color=arrow["color"], tooltip=arrow["tooltip"])
        state = builder.get_state()
        # A scene depends only on what it shows, so equal scenes are equal bytes and keep one name in the store: a
        # fixed time stands in for the time of building, in the state and in the archive's entries.
        state.metadata.timestamp = FIXED_TIME.isoformat()
        archive = io.BytesIO()
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
            for name, data in (("index.mvsj", state.model_dump_json(exclude_none=True).encode()),
                               ("trajectory.xyz", trajectory.encode())):
                entry = zipfile.ZipInfo(name, date_time=FIXED_TIME.timetuple()[:6])
                entry.compress_type = zipfile.ZIP_DEFLATED
                bundle.writestr(entry, data)
        archive = archive.getvalue()
        # A large scene, such as a long trajectory, loads only when its viewer first mounts; a small one stays in the
        # page, where it costs less than a request.
        return (len(archive) > INLINE_SCENE and store.address(archive)) or "base64," + base64.b64encode(archive).decode()

    def set_frame(self, frame):
        """Request a one-based frame, retaining camera orientation and native distances.

        Args:
            frame: The frame to show, from 1 to ``frame_count``.

        Raises:
            ValueError: If ``frame`` is not an integer within that range.
        """
        if not isinstance(frame, Integral) or isinstance(frame, bool) or not 1 <= frame <= self.frame_count:
            raise ValueError(f"Frame must be an integer between 1 and {self.frame_count}.")
        self.requested = int(frame)

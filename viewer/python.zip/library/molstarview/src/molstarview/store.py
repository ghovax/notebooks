"""Large viewer data kept apart from the page: encoded volume fields and big scenes, named by the SHA-256 of their bytes.

With the environment variable ``STORE`` set to an address ending in ``/``, a viewer names such data there, the address
plus the digest, and keeps the bytes in ``CACHE / "objects"`` for an uploader to send; the browser fetches them when a
viewer first needs them and may cache them for good, as a name always means the same bytes. Without it, the page carries
the data itself.
"""

import hashlib
import os
from pathlib import Path

# Encoded fields and stored objects, reused across renders: ``objects/<digest>`` holds the bytes of each.
CACHE = Path.home() / ".cache/research-findings/volumes"
# The environment variable naming the store's address.
STORE = "MOLSTARVIEW_FIELD_STORE"


def stored(digest):
    """The cached bytes of a stored object.

    Args:
        digest: The hexadecimal SHA-256 of the bytes.

    Returns:
        The path of the cached file.
    """
    return CACHE / "objects" / digest


def write_atomic(path, data):
    """Write bytes beside their final name and move them, so a parallel reader never sees half a file.

    Args:
        path: The final file.
        data: The bytes to write.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_name(f".{path.name}.{os.getpid()}.part")
    partial.write_bytes(data)
    partial.replace(path)


def address(data):
    """The store's address for some bytes, kept in the cache for the uploader, or None without a store.

    Args:
        data: The bytes.

    Returns:
        The address, or None when no store is set.

    Raises:
        OSError: If the cache cannot keep the bytes the uploader must find.
    """
    store = os.environ.get(STORE, "")
    if not store:
        return None
    digest = hashlib.sha256(data).hexdigest()
    path = stored(digest)
    if not path.exists():
        write_atomic(path, data)
    return store + digest

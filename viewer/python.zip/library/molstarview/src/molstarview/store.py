"""Large viewer data kept apart from the page: encoded volume fields and big scenes, named by the SHA-256 of their bytes.

With the environment variable ``STORE`` set to an address ending in ``/``, a viewer names such data there, the address
plus the digest, and keeps the bytes in ``CACHE / "objects"`` for an uploader to send; the browser fetches them when a
viewer first needs them and may cache them for good, as a name always means the same bytes. Without it, the page carries
the data itself.
"""

import hashlib
import os
from pathlib import Path

# Encoded fields and stored objects, reused across renders: ``objects/<digest>`` holds the bytes of each.
CACHE = Path.home() / ".cache/research-findings/volumes"
# The environment variable naming the store's address.
STORE = "MOLSTARVIEW_FIELD_STORE"
# A viewer's stored fields are packed, in the order it shows them, into files of at most this many bytes: far fewer
# files to host, while showing a snapshot fetches at most this much and its neighbours then come from the cache.
PACK_BYTES = 1 << 20


def stored(digest):
    """The cached bytes of a stored object.

    Args:
        digest: The hexadecimal SHA-256 of the bytes.

    Returns:
        The path of the cached file.
    """
    return CACHE / "objects" / digest


def write_atomic(path, data):
    """Write bytes beside their final name and move them, so a parallel reader never sees half a file.

    Args:
        path: The final file.
        data: The bytes to write.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_name(f".{path.name}.{os.getpid()}.part")
    partial.write_bytes(data)
    partial.replace(path)


def pack(addresses):
    """Pack stored objects, in order, into files of at most ``PACK_BYTES``, each a stored object of its own.

    Args:
        addresses: Store addresses in the order a viewer shows them; other text, such as base64, is left as it is.

    Returns:
        Each store address's new address: ``<pack>#<start>-<end>``, the bytes from ``start`` up to ``end`` of the pack,
        or the address itself for an object packed alone.
    """
    store = os.environ.get(STORE, "")
    unique = list(dict.fromkeys(text for text in addresses if store and text.startswith(store)))
    packed, chunk, size = {}, [], 0

    def flush():
        """Store the gathered objects as one pack, or leave a lone object as it is."""
        if len(chunk) == 1:
            packed[chunk[0][0]] = chunk[0][0]
        elif chunk:
            data = b"".join(part for _, part in chunk)
            target = address(data)
            start = 0
            for text, part in chunk:
                packed[text] = f"{target}#{start}-{start + len(part)}"
                start += len(part)
        chunk.clear()

    for text in unique:
        part = stored(text[len(store):]).read_bytes()
        if chunk and size + len(part) > PACK_BYTES:
            flush()
            size = 0
        chunk.append((text, part))
        size += len(part)
    flush()
    return packed


def address(data):
    """The store's address for some bytes, kept in the cache for the uploader, or None without a store.

    Args:
        data: The bytes.

    Returns:
        The address, or None when no store is set.

    Raises:
        OSError: If the cache cannot keep the bytes the uploader must find.
    """
    store = os.environ.get(STORE, "")
    if not store:
        return None
    digest = hashlib.sha256(data).hexdigest()
    path = stored(digest)
    if not path.exists():
        write_atomic(path, data)
    return store + digest
